--
-- PostgreSQL database dump
--

\restrict kfoEfdfFcCtEwYJQY9lc9erAqFQAFRey3jfAxRnYbr4UDFIWdTuscOR6DZeTRJE

-- Dumped from database version 16.10 (Ubuntu 16.10-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 18.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.system_mode DROP CONSTRAINT IF EXISTS system_mode_pkey;
DROP TABLE IF EXISTS public.system_mode;
SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: system_mode; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.system_mode (
    id integer DEFAULT 1 NOT NULL,
    mode character varying(20) DEFAULT 'offline'::character varying NOT NULL,
    CONSTRAINT system_mode_id_check CHECK ((id = 1))
);


--
-- Data for Name: system_mode; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.system_mode (id, mode) FROM stdin;
1	offline
\.


--
-- Name: system_mode system_mode_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_mode
    ADD CONSTRAINT system_mode_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

\unrestrict kfoEfdfFcCtEwYJQY9lc9erAqFQAFRey3jfAxRnYbr4UDFIWdTuscOR6DZeTRJE

