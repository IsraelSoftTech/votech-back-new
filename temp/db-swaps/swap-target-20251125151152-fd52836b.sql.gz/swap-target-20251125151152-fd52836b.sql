--
-- PostgreSQL database dump
--

\restrict t0D2S65Csr5qoiybOGUuAuF4PshcbaJdyUhzr5hbyiQtbMC5eTAgYapehfRJJ2m

-- Dumped from database version 18.1
-- Dumped by pg_dump version 18.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.user_sessions DROP CONSTRAINT IF EXISTS user_sessions_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_activities DROP CONSTRAINT IF EXISTS user_activities_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.timetables DROP CONSTRAINT IF EXISTS timetables_class_id_fkey;
ALTER TABLE IF EXISTS ONLY public.terms DROP CONSTRAINT IF EXISTS terms_academic_year_id_fkey;
ALTER TABLE IF EXISTS ONLY public.teachers DROP CONSTRAINT IF EXISTS teachers_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.teacher_discipline_cases DROP CONSTRAINT IF EXISTS teacher_discipline_cases_teacher_id_fkey;
ALTER TABLE IF EXISTS ONLY public.teacher_discipline_cases DROP CONSTRAINT IF EXISTS teacher_discipline_cases_resolved_by_fkey;
ALTER TABLE IF EXISTS ONLY public.teacher_discipline_cases DROP CONSTRAINT IF EXISTS teacher_discipline_cases_recorded_by_fkey;
ALTER TABLE IF EXISTS ONLY public.teacher_discipline_cases DROP CONSTRAINT IF EXISTS teacher_discipline_cases_class_id_fkey;
ALTER TABLE IF EXISTS ONLY public.teacher_assignments DROP CONSTRAINT IF EXISTS teacher_assignments_teacher_id_fkey;
ALTER TABLE IF EXISTS ONLY public.teacher_assignments DROP CONSTRAINT IF EXISTS teacher_assignments_subject_id_fkey;
ALTER TABLE IF EXISTS ONLY public.teacher_assignments DROP CONSTRAINT IF EXISTS teacher_assignments_class_id_fkey;
ALTER TABLE IF EXISTS ONLY public.subject_coefficients DROP CONSTRAINT IF EXISTS subject_coefficients_subject_id_fkey;
ALTER TABLE IF EXISTS ONLY public.subject_coefficients DROP CONSTRAINT IF EXISTS subject_coefficients_class_id_fkey;
ALTER TABLE IF EXISTS ONLY public.subject_classifications DROP CONSTRAINT IF EXISTS subject_classifications_subject_id_fkey;
ALTER TABLE IF EXISTS ONLY public.subject_classifications DROP CONSTRAINT IF EXISTS subject_classifications_class_id_fkey;
ALTER TABLE IF EXISTS ONLY public.students DROP CONSTRAINT IF EXISTS students_specialty_id_fkey;
ALTER TABLE IF EXISTS ONLY public.students DROP CONSTRAINT IF EXISTS students_class_id_fkey;
ALTER TABLE IF EXISTS ONLY public.students DROP CONSTRAINT IF EXISTS students_academic_year_id_fkey;
ALTER TABLE IF EXISTS ONLY public.specialty_classes DROP CONSTRAINT IF EXISTS specialty_classes_specialty_id_fkey;
ALTER TABLE IF EXISTS ONLY public.specialty_classes DROP CONSTRAINT IF EXISTS specialty_classes_class_id_fkey;
ALTER TABLE IF EXISTS ONLY public.sequences DROP CONSTRAINT IF EXISTS sequences_term_id_fkey;
ALTER TABLE IF EXISTS ONLY public.sequences DROP CONSTRAINT IF EXISTS sequences_academic_year_id_fkey1;
ALTER TABLE IF EXISTS ONLY public.sequences DROP CONSTRAINT IF EXISTS sequences_academic_year_id_fkey;
ALTER TABLE IF EXISTS ONLY public.salaries DROP CONSTRAINT IF EXISTS salaries_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.salaries DROP CONSTRAINT IF EXISTS salaries_applicant_id_fkey;
ALTER TABLE IF EXISTS ONLY public.messages DROP CONSTRAINT IF EXISTS messages_sender_id_fkey;
ALTER TABLE IF EXISTS ONLY public.messages DROP CONSTRAINT IF EXISTS messages_receiver_id_fkey;
ALTER TABLE IF EXISTS ONLY public.marks DROP CONSTRAINT IF EXISTS marks_uploaded_by_fkey;
ALTER TABLE IF EXISTS ONLY public.marks DROP CONSTRAINT IF EXISTS marks_term_id_fkey;
ALTER TABLE IF EXISTS ONLY public.marks DROP CONSTRAINT IF EXISTS marks_subject_id_fkey;
ALTER TABLE IF EXISTS ONLY public.marks DROP CONSTRAINT IF EXISTS marks_sequence_id_fkey;
ALTER TABLE IF EXISTS ONLY public.marks DROP CONSTRAINT IF EXISTS marks_class_id_fkey;
ALTER TABLE IF EXISTS ONLY public.marks DROP CONSTRAINT IF EXISTS marks_academic_year_id_fkey;
ALTER TABLE IF EXISTS ONLY public.lessons DROP CONSTRAINT IF EXISTS lessons_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.lessons DROP CONSTRAINT IF EXISTS lessons_reviewed_by_fkey;
ALTER TABLE IF EXISTS ONLY public.lesson_plans DROP CONSTRAINT IF EXISTS lesson_plans_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.lesson_plans DROP CONSTRAINT IF EXISTS lesson_plans_reviewed_by_fkey;
ALTER TABLE IF EXISTS ONLY public.hods DROP CONSTRAINT IF EXISTS hods_subject_id_fkey;
ALTER TABLE IF EXISTS ONLY public.hods DROP CONSTRAINT IF EXISTS hods_hod_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.hod_teachers DROP CONSTRAINT IF EXISTS hod_teachers_teacher_id_fkey;
ALTER TABLE IF EXISTS ONLY public.hod_teachers DROP CONSTRAINT IF EXISTS hod_teachers_hod_id_fkey;
ALTER TABLE IF EXISTS ONLY public.groups DROP CONSTRAINT IF EXISTS groups_creator_id_fkey;
ALTER TABLE IF EXISTS ONLY public.group_participants DROP CONSTRAINT IF EXISTS group_participants_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.group_participants DROP CONSTRAINT IF EXISTS group_participants_group_id_fkey;
ALTER TABLE IF EXISTS ONLY public.financial_transactions DROP CONSTRAINT IF EXISTS financial_transactions_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.financial_transactions DROP CONSTRAINT IF EXISTS financial_transactions_budget_head_id_fkey;
ALTER TABLE IF EXISTS ONLY public.events DROP CONSTRAINT IF EXISTS events_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.discipline_cases DROP CONSTRAINT IF EXISTS discipline_cases_teacher_id_fkey;
ALTER TABLE IF EXISTS ONLY public.discipline_cases DROP CONSTRAINT IF EXISTS discipline_cases_resolved_by_fkey;
ALTER TABLE IF EXISTS ONLY public.discipline_cases DROP CONSTRAINT IF EXISTS discipline_cases_recorded_by_fkey;
ALTER TABLE IF EXISTS ONLY public.discipline_cases DROP CONSTRAINT IF EXISTS discipline_cases_class_id_fkey;
ALTER TABLE IF EXISTS ONLY public.db_swap_logs DROP CONSTRAINT IF EXISTS db_swap_logs_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.classes DROP CONSTRAINT IF EXISTS classes_department_id_fkey;
ALTER TABLE IF EXISTS ONLY public.classes DROP CONSTRAINT IF EXISTS classes_class_master_id_fkey;
ALTER TABLE IF EXISTS ONLY public.class_subjects DROP CONSTRAINT IF EXISTS class_subjects_teacher_id_fkey;
ALTER TABLE IF EXISTS ONLY public.class_subjects DROP CONSTRAINT IF EXISTS class_subjects_subject_id_fkey;
ALTER TABLE IF EXISTS ONLY public.class_subjects DROP CONSTRAINT IF EXISTS class_subjects_department_id_fkey;
ALTER TABLE IF EXISTS ONLY public.class_subjects DROP CONSTRAINT IF EXISTS class_subjects_class_id_fkey;
ALTER TABLE IF EXISTS ONLY public.class_masters DROP CONSTRAINT IF EXISTS class_masters_class_id_fkey;
ALTER TABLE IF EXISTS ONLY public.change_logs DROP CONSTRAINT IF EXISTS change_logs_changed_by_fkey;
ALTER TABLE IF EXISTS ONLY public.cases DROP CONSTRAINT IF EXISTS cases_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.cases DROP CONSTRAINT IF EXISTS cases_class_id_fkey;
ALTER TABLE IF EXISTS ONLY public.cases DROP CONSTRAINT IF EXISTS cases_assigned_to_fkey;
ALTER TABLE IF EXISTS ONLY public.case_sessions DROP CONSTRAINT IF EXISTS case_sessions_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.case_sessions DROP CONSTRAINT IF EXISTS case_sessions_case_id_fkey;
ALTER TABLE IF EXISTS ONLY public.case_reports DROP CONSTRAINT IF EXISTS case_reports_sent_to_fkey;
ALTER TABLE IF EXISTS ONLY public.case_reports DROP CONSTRAINT IF EXISTS case_reports_sent_by_fkey;
ALTER TABLE IF EXISTS ONLY public.case_reports DROP CONSTRAINT IF EXISTS case_reports_case_id_fkey;
ALTER TABLE IF EXISTS ONLY public.attendance_sessions DROP CONSTRAINT IF EXISTS attendance_sessions_taken_by_fkey;
ALTER TABLE IF EXISTS ONLY public.attendance_sessions DROP CONSTRAINT IF EXISTS attendance_sessions_class_id_fkey;
ALTER TABLE IF EXISTS ONLY public.attendance_records DROP CONSTRAINT IF EXISTS attendance_records_teacher_id_fkey;
ALTER TABLE IF EXISTS ONLY public.attendance_records DROP CONSTRAINT IF EXISTS attendance_records_session_id_fkey;
ALTER TABLE IF EXISTS ONLY public.asset_depreciation DROP CONSTRAINT IF EXISTS asset_depreciation_inventory_id_fkey;
ALTER TABLE IF EXISTS ONLY public.applications DROP CONSTRAINT IF EXISTS applications_reviewed_by_fkey;
ALTER TABLE IF EXISTS ONLY public.applications DROP CONSTRAINT IF EXISTS applications_applicant_id_fkey;
ALTER TABLE IF EXISTS ONLY public.academic_bands DROP CONSTRAINT IF EXISTS academic_bands_class_id_fkey;
ALTER TABLE IF EXISTS ONLY public.academic_bands DROP CONSTRAINT IF EXISTS academic_bands_academic_year_id_fkey;
DROP INDEX IF EXISTS public.unique_class_name_per_department;
DROP INDEX IF EXISTS public.terms_academic_year_id_name_key;
DROP INDEX IF EXISTS public.sequences_term_id_order_number;
DROP INDEX IF EXISTS public.sequences_academic_year_id_name;
DROP INDEX IF EXISTS public.marks_term_id;
DROP INDEX IF EXISTS public.marks_subject_id;
DROP INDEX IF EXISTS public.marks_student_id;
DROP INDEX IF EXISTS public.marks_sequence_id;
DROP INDEX IF EXISTS public.marks_class_id;
DROP INDEX IF EXISTS public.marks_academic_year_id;
DROP INDEX IF EXISTS public.idx_user_sessions_user_id;
DROP INDEX IF EXISTS public.idx_user_sessions_status;
DROP INDEX IF EXISTS public.idx_user_activities_user_id;
DROP INDEX IF EXISTS public.idx_user_activities_created_at;
DROP INDEX IF EXISTS public.idx_user_activities_activity_type;
DROP INDEX IF EXISTS public.idx_staff_employment_status_staff_name;
DROP INDEX IF EXISTS public.idx_staff_attendance_staff_name;
DROP INDEX IF EXISTS public.idx_staff_attendance_date;
DROP INDEX IF EXISTS public.idx_messages_read;
DROP INDEX IF EXISTS public.idx_discipline_cases_type;
DROP INDEX IF EXISTS public.idx_discipline_cases_teacher;
DROP INDEX IF EXISTS public.class_subjects_unique_idx;
DROP INDEX IF EXISTS public.academic_bands_academic_year_id_class_id_band_min_band_max;
ALTER TABLE IF EXISTS ONLY public.vocational DROP CONSTRAINT IF EXISTS vocational_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_username_key;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.user_sessions DROP CONSTRAINT IF EXISTS user_sessions_pkey;
ALTER TABLE IF EXISTS ONLY public.user_activities DROP CONSTRAINT IF EXISTS user_activities_pkey;
ALTER TABLE IF EXISTS ONLY public.marks DROP CONSTRAINT IF EXISTS unique_mark_constraint;
ALTER TABLE IF EXISTS ONLY public.class_subjects DROP CONSTRAINT IF EXISTS unique_class_subject_teacher;
ALTER TABLE IF EXISTS ONLY public.class_subjects DROP CONSTRAINT IF EXISTS unique_class_subject_department;
ALTER TABLE IF EXISTS ONLY public.timetables DROP CONSTRAINT IF EXISTS timetables_pkey;
ALTER TABLE IF EXISTS ONLY public.timetables DROP CONSTRAINT IF EXISTS timetables_class_id_key;
ALTER TABLE IF EXISTS ONLY public.timetable_configs DROP CONSTRAINT IF EXISTS timetable_configs_pkey;
ALTER TABLE IF EXISTS ONLY public.terms DROP CONSTRAINT IF EXISTS terms_pkey;
ALTER TABLE IF EXISTS ONLY public.teachers DROP CONSTRAINT IF EXISTS teachers_pkey;
ALTER TABLE IF EXISTS ONLY public.teacher_discipline_cases DROP CONSTRAINT IF EXISTS teacher_discipline_cases_pkey;
ALTER TABLE IF EXISTS ONLY public.teacher_assignments DROP CONSTRAINT IF EXISTS teacher_assignments_teacher_id_class_id_subject_id_key;
ALTER TABLE IF EXISTS ONLY public.teacher_assignments DROP CONSTRAINT IF EXISTS teacher_assignments_pkey;
ALTER TABLE IF EXISTS ONLY public.system_mode DROP CONSTRAINT IF EXISTS system_mode_pkey;
ALTER TABLE IF EXISTS ONLY public.subjects DROP CONSTRAINT IF EXISTS subjects_pkey;
ALTER TABLE IF EXISTS ONLY public.subjects DROP CONSTRAINT IF EXISTS subjects_code_key;
ALTER TABLE IF EXISTS ONLY public.subject_coefficients DROP CONSTRAINT IF EXISTS subject_coefficients_pkey;
ALTER TABLE IF EXISTS ONLY public.subject_coefficients DROP CONSTRAINT IF EXISTS subject_coefficients_class_id_subject_id_key;
ALTER TABLE IF EXISTS ONLY public.subject_classifications DROP CONSTRAINT IF EXISTS subject_classifications_pkey;
ALTER TABLE IF EXISTS ONLY public.subject_classifications DROP CONSTRAINT IF EXISTS subject_classifications_class_id_subject_id_key;
ALTER TABLE IF EXISTS ONLY public.students DROP CONSTRAINT IF EXISTS students_student_id_key;
ALTER TABLE IF EXISTS ONLY public.students DROP CONSTRAINT IF EXISTS students_pkey;
ALTER TABLE IF EXISTS ONLY public.staff_employment_status DROP CONSTRAINT IF EXISTS staff_employment_status_staff_name_key;
ALTER TABLE IF EXISTS ONLY public.staff_employment_status DROP CONSTRAINT IF EXISTS staff_employment_status_pkey;
ALTER TABLE IF EXISTS ONLY public.staff_attendance_settings DROP CONSTRAINT IF EXISTS staff_attendance_settings_setting_key_key;
ALTER TABLE IF EXISTS ONLY public.staff_attendance_settings DROP CONSTRAINT IF EXISTS staff_attendance_settings_pkey;
ALTER TABLE IF EXISTS ONLY public.staff_attendance_records DROP CONSTRAINT IF EXISTS staff_attendance_records_pkey;
ALTER TABLE IF EXISTS ONLY public.specialty_classes DROP CONSTRAINT IF EXISTS specialty_classes_pkey;
ALTER TABLE IF EXISTS ONLY public.specialties DROP CONSTRAINT IF EXISTS specialties_pkey;
ALTER TABLE IF EXISTS ONLY public.sequences DROP CONSTRAINT IF EXISTS sequences_pkey;
ALTER TABLE IF EXISTS ONLY public.salary_payslip_settings DROP CONSTRAINT IF EXISTS salary_payslip_settings_pkey;
ALTER TABLE IF EXISTS ONLY public.salary_descriptions DROP CONSTRAINT IF EXISTS salary_descriptions_pkey;
ALTER TABLE IF EXISTS ONLY public.salaries DROP CONSTRAINT IF EXISTS salaries_user_id_month_year_key;
ALTER TABLE IF EXISTS ONLY public.salaries DROP CONSTRAINT IF EXISTS salaries_user_id_month_key;
ALTER TABLE IF EXISTS ONLY public.salaries DROP CONSTRAINT IF EXISTS salaries_pkey;
ALTER TABLE IF EXISTS ONLY public.messages DROP CONSTRAINT IF EXISTS messages_pkey;
ALTER TABLE IF EXISTS ONLY public.marks DROP CONSTRAINT IF EXISTS marks_pkey;
ALTER TABLE IF EXISTS ONLY public.lessons DROP CONSTRAINT IF EXISTS lessons_pkey;
ALTER TABLE IF EXISTS ONLY public.lesson_plans DROP CONSTRAINT IF EXISTS lesson_plans_pkey;
ALTER TABLE IF EXISTS ONLY public.inventory DROP CONSTRAINT IF EXISTS inventory_pkey;
ALTER TABLE IF EXISTS ONLY public.id_cards DROP CONSTRAINT IF EXISTS id_cards_pkey;
ALTER TABLE IF EXISTS ONLY public.hods DROP CONSTRAINT IF EXISTS hods_pkey;
ALTER TABLE IF EXISTS ONLY public.hod_teachers DROP CONSTRAINT IF EXISTS hod_teachers_pkey;
ALTER TABLE IF EXISTS ONLY public.hod_teachers DROP CONSTRAINT IF EXISTS hod_teachers_hod_id_teacher_id_key;
ALTER TABLE IF EXISTS ONLY public.groups DROP CONSTRAINT IF EXISTS groups_pkey;
ALTER TABLE IF EXISTS ONLY public.group_participants DROP CONSTRAINT IF EXISTS group_participants_pkey;
ALTER TABLE IF EXISTS ONLY public.group_participants DROP CONSTRAINT IF EXISTS group_participants_group_id_user_id_key;
ALTER TABLE IF EXISTS ONLY public.financial_transactions DROP CONSTRAINT IF EXISTS financial_transactions_pkey;
ALTER TABLE IF EXISTS ONLY public.fees DROP CONSTRAINT IF EXISTS fees_pkey;
ALTER TABLE IF EXISTS ONLY public.events DROP CONSTRAINT IF EXISTS events_pkey;
ALTER TABLE IF EXISTS ONLY public.discipline_cases DROP CONSTRAINT IF EXISTS discipline_cases_pkey;
ALTER TABLE IF EXISTS ONLY public.departments DROP CONSTRAINT IF EXISTS departments_pkey;
ALTER TABLE IF EXISTS ONLY public.departments DROP CONSTRAINT IF EXISTS departments_name_key;
ALTER TABLE IF EXISTS ONLY public.db_swap_logs DROP CONSTRAINT IF EXISTS db_swap_logs_pkey;
ALTER TABLE IF EXISTS ONLY public.cnps_preferences DROP CONSTRAINT IF EXISTS cnps_preferences_pkey;
ALTER TABLE IF EXISTS ONLY public.classes DROP CONSTRAINT IF EXISTS classes_pkey;
ALTER TABLE IF EXISTS ONLY public.class_subjects DROP CONSTRAINT IF EXISTS class_subjects_pkey;
ALTER TABLE IF EXISTS ONLY public.class_masters DROP CONSTRAINT IF EXISTS class_masters_pkey;
ALTER TABLE IF EXISTS ONLY public.change_logs DROP CONSTRAINT IF EXISTS change_logs_pkey;
ALTER TABLE IF EXISTS ONLY public.cases DROP CONSTRAINT IF EXISTS cases_pkey;
ALTER TABLE IF EXISTS ONLY public.cases DROP CONSTRAINT IF EXISTS cases_case_number_key;
ALTER TABLE IF EXISTS ONLY public.case_sessions DROP CONSTRAINT IF EXISTS case_sessions_pkey;
ALTER TABLE IF EXISTS ONLY public.case_reports DROP CONSTRAINT IF EXISTS case_reports_pkey;
ALTER TABLE IF EXISTS ONLY public.budget_heads DROP CONSTRAINT IF EXISTS budget_heads_pkey;
ALTER TABLE IF EXISTS ONLY public.budget_heads DROP CONSTRAINT IF EXISTS budget_heads_name_key;
ALTER TABLE IF EXISTS ONLY public.budget_heads DROP CONSTRAINT IF EXISTS budget_heads_code_key;
ALTER TABLE IF EXISTS ONLY public.attendance_sessions DROP CONSTRAINT IF EXISTS attendance_sessions_pkey;
ALTER TABLE IF EXISTS ONLY public.attendance_records DROP CONSTRAINT IF EXISTS attendance_records_session_teacher_unique;
ALTER TABLE IF EXISTS ONLY public.attendance_records DROP CONSTRAINT IF EXISTS attendance_records_session_id_student_id_key;
ALTER TABLE IF EXISTS ONLY public.attendance_records DROP CONSTRAINT IF EXISTS attendance_records_pkey;
ALTER TABLE IF EXISTS ONLY public.asset_depreciation DROP CONSTRAINT IF EXISTS asset_depreciation_pkey;
ALTER TABLE IF EXISTS ONLY public.asset_depreciation DROP CONSTRAINT IF EXISTS asset_depreciation_inventory_id_calculation_date_key;
ALTER TABLE IF EXISTS ONLY public.asset_categories DROP CONSTRAINT IF EXISTS asset_categories_pkey;
ALTER TABLE IF EXISTS ONLY public.asset_categories DROP CONSTRAINT IF EXISTS asset_categories_name_key;
ALTER TABLE IF EXISTS ONLY public.applications DROP CONSTRAINT IF EXISTS applications_pkey;
ALTER TABLE IF EXISTS ONLY public.applications DROP CONSTRAINT IF EXISTS applications_applicant_id_key;
ALTER TABLE IF EXISTS ONLY public.academic_years DROP CONSTRAINT IF EXISTS academic_years_pkey;
ALTER TABLE IF EXISTS ONLY public.academic_bands DROP CONSTRAINT IF EXISTS academic_bands_pkey;
ALTER TABLE IF EXISTS ONLY public."academicYears" DROP CONSTRAINT IF EXISTS "academicYears_pkey";
ALTER TABLE IF EXISTS ONLY public."SequelizeMeta" DROP CONSTRAINT IF EXISTS "SequelizeMeta_pkey";
ALTER TABLE IF EXISTS public.vocational ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.user_sessions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.user_activities ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.timetables ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.timetable_configs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.terms ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.teachers ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.teacher_discipline_cases ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.teacher_assignments ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.subjects ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.subject_coefficients ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.subject_classifications ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.students ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.staff_employment_status ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.staff_attendance_settings ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.staff_attendance_records ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.specialty_classes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.specialties ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.sequences ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.salary_payslip_settings ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.salary_descriptions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.salaries ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.messages ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.marks ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.lessons ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.lesson_plans ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.inventory ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.id_cards ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.hods ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.hod_teachers ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.groups ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.group_participants ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.financial_transactions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.fees ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.events ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.discipline_cases ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.departments ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.db_swap_logs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.classes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.class_subjects ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.class_masters ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.change_logs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.cases ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.case_sessions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.case_reports ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.budget_heads ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.attendance_sessions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.attendance_records ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.asset_depreciation ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.asset_categories ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.applications ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.academic_years ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.academic_bands ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public."academicYears" ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE IF EXISTS public.vocational_id_seq;
DROP TABLE IF EXISTS public.vocational;
DROP SEQUENCE IF EXISTS public.users_id_seq;
DROP TABLE IF EXISTS public.users;
DROP SEQUENCE IF EXISTS public.user_sessions_id_seq;
DROP TABLE IF EXISTS public.user_sessions;
DROP SEQUENCE IF EXISTS public.user_activities_id_seq;
DROP TABLE IF EXISTS public.user_activities;
DROP SEQUENCE IF EXISTS public.timetables_id_seq;
DROP TABLE IF EXISTS public.timetables;
DROP SEQUENCE IF EXISTS public.timetable_configs_id_seq;
DROP TABLE IF EXISTS public.timetable_configs;
DROP SEQUENCE IF EXISTS public.terms_id_seq;
DROP TABLE IF EXISTS public.terms;
DROP SEQUENCE IF EXISTS public.teachers_id_seq;
DROP TABLE IF EXISTS public.teachers;
DROP SEQUENCE IF EXISTS public.teacher_discipline_cases_id_seq;
DROP TABLE IF EXISTS public.teacher_discipline_cases;
DROP SEQUENCE IF EXISTS public.teacher_assignments_id_seq;
DROP TABLE IF EXISTS public.teacher_assignments;
DROP TABLE IF EXISTS public.system_mode;
DROP SEQUENCE IF EXISTS public.subjects_id_seq;
DROP TABLE IF EXISTS public.subjects;
DROP SEQUENCE IF EXISTS public.subject_coefficients_id_seq;
DROP TABLE IF EXISTS public.subject_coefficients;
DROP SEQUENCE IF EXISTS public.subject_classifications_id_seq;
DROP TABLE IF EXISTS public.subject_classifications;
DROP SEQUENCE IF EXISTS public.students_id_seq;
DROP TABLE IF EXISTS public.students;
DROP SEQUENCE IF EXISTS public.staff_employment_status_id_seq;
DROP TABLE IF EXISTS public.staff_employment_status;
DROP SEQUENCE IF EXISTS public.staff_attendance_settings_id_seq;
DROP TABLE IF EXISTS public.staff_attendance_settings;
DROP SEQUENCE IF EXISTS public.staff_attendance_records_id_seq;
DROP TABLE IF EXISTS public.staff_attendance_records;
DROP SEQUENCE IF EXISTS public.specialty_classes_id_seq;
DROP TABLE IF EXISTS public.specialty_classes;
DROP SEQUENCE IF EXISTS public.specialties_id_seq;
DROP TABLE IF EXISTS public.specialties;
DROP SEQUENCE IF EXISTS public.sequences_id_seq;
DROP TABLE IF EXISTS public.sequences;
DROP SEQUENCE IF EXISTS public.salary_payslip_settings_id_seq;
DROP TABLE IF EXISTS public.salary_payslip_settings;
DROP SEQUENCE IF EXISTS public.salary_descriptions_id_seq;
DROP TABLE IF EXISTS public.salary_descriptions;
DROP SEQUENCE IF EXISTS public.salaries_id_seq;
DROP TABLE IF EXISTS public.salaries;
DROP SEQUENCE IF EXISTS public.messages_id_seq;
DROP TABLE IF EXISTS public.messages;
DROP SEQUENCE IF EXISTS public.marks_id_seq;
DROP TABLE IF EXISTS public.marks;
DROP SEQUENCE IF EXISTS public.lessons_id_seq;
DROP TABLE IF EXISTS public.lessons;
DROP SEQUENCE IF EXISTS public.lesson_plans_id_seq;
DROP TABLE IF EXISTS public.lesson_plans;
DROP SEQUENCE IF EXISTS public.inventory_id_seq;
DROP TABLE IF EXISTS public.inventory;
DROP SEQUENCE IF EXISTS public.id_cards_id_seq;
DROP TABLE IF EXISTS public.id_cards;
DROP SEQUENCE IF EXISTS public.hods_id_seq;
DROP TABLE IF EXISTS public.hods;
DROP SEQUENCE IF EXISTS public.hod_teachers_id_seq;
DROP TABLE IF EXISTS public.hod_teachers;
DROP SEQUENCE IF EXISTS public.groups_id_seq;
DROP TABLE IF EXISTS public.groups;
DROP SEQUENCE IF EXISTS public.group_participants_id_seq;
DROP TABLE IF EXISTS public.group_participants;
DROP SEQUENCE IF EXISTS public.financial_transactions_id_seq;
DROP TABLE IF EXISTS public.financial_transactions;
DROP SEQUENCE IF EXISTS public.fees_id_seq;
DROP TABLE IF EXISTS public.fees;
DROP SEQUENCE IF EXISTS public.events_id_seq;
DROP TABLE IF EXISTS public.events;
DROP SEQUENCE IF EXISTS public.discipline_cases_id_seq;
DROP TABLE IF EXISTS public.discipline_cases;
DROP SEQUENCE IF EXISTS public.departments_id_seq;
DROP TABLE IF EXISTS public.departments;
DROP SEQUENCE IF EXISTS public.db_swap_logs_id_seq;
DROP TABLE IF EXISTS public.db_swap_logs;
DROP TABLE IF EXISTS public.cnps_preferences;
DROP SEQUENCE IF EXISTS public.classes_id_seq;
DROP TABLE IF EXISTS public.classes;
DROP SEQUENCE IF EXISTS public.class_subjects_id_seq;
DROP TABLE IF EXISTS public.class_subjects;
DROP SEQUENCE IF EXISTS public.class_masters_id_seq;
DROP TABLE IF EXISTS public.class_masters;
DROP SEQUENCE IF EXISTS public.change_logs_id_seq;
DROP TABLE IF EXISTS public.change_logs;
DROP SEQUENCE IF EXISTS public.cases_id_seq;
DROP TABLE IF EXISTS public.cases;
DROP SEQUENCE IF EXISTS public.case_sessions_id_seq;
DROP TABLE IF EXISTS public.case_sessions;
DROP SEQUENCE IF EXISTS public.case_reports_id_seq;
DROP TABLE IF EXISTS public.case_reports;
DROP SEQUENCE IF EXISTS public.budget_heads_id_seq;
DROP TABLE IF EXISTS public.budget_heads;
DROP SEQUENCE IF EXISTS public.attendance_sessions_id_seq;
DROP TABLE IF EXISTS public.attendance_sessions;
DROP SEQUENCE IF EXISTS public.attendance_records_id_seq;
DROP TABLE IF EXISTS public.attendance_records;
DROP SEQUENCE IF EXISTS public.asset_depreciation_id_seq;
DROP TABLE IF EXISTS public.asset_depreciation;
DROP SEQUENCE IF EXISTS public.asset_categories_id_seq;
DROP TABLE IF EXISTS public.asset_categories;
DROP SEQUENCE IF EXISTS public.applications_id_seq;
DROP TABLE IF EXISTS public.applications;
DROP SEQUENCE IF EXISTS public.academic_years_id_seq;
DROP TABLE IF EXISTS public.academic_years;
DROP SEQUENCE IF EXISTS public.academic_bands_id_seq;
DROP TABLE IF EXISTS public.academic_bands;
DROP SEQUENCE IF EXISTS public."academicYears_id_seq";
DROP TABLE IF EXISTS public."academicYears";
DROP TABLE IF EXISTS public."SequelizeMeta";
DROP TYPE IF EXISTS public.enum_system_mode_mode;
DROP TYPE IF EXISTS public.enum_subjects_category;
DROP TYPE IF EXISTS public.enum_sequences_type;
DROP TYPE IF EXISTS public.enum_db_swap_logs_mode;
DROP TYPE IF EXISTS public.enum_db_swap_logs_action;
DROP TYPE IF EXISTS public.enum_change_logs_source;
DROP TYPE IF EXISTS public.enum_change_logs_change_type;
DROP TYPE IF EXISTS public."enum_academicYears_status";
--
-- Name: enum_academicYears_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."enum_academicYears_status" AS ENUM (
    'active',
    'archived'
);


--
-- Name: enum_change_logs_change_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.enum_change_logs_change_type AS ENUM (
    'INSERT',
    'UPDATE',
    'DELETE'
);


--
-- Name: enum_change_logs_source; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.enum_change_logs_source AS ENUM (
    'local',
    'online'
);


--
-- Name: enum_db_swap_logs_action; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.enum_db_swap_logs_action AS ENUM (
    'backup',
    'restore'
);


--
-- Name: enum_db_swap_logs_mode; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.enum_db_swap_logs_mode AS ENUM (
    'online',
    'offline',
    'maintenance'
);


--
-- Name: enum_sequences_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.enum_sequences_type AS ENUM (
    'sequence',
    'term'
);


--
-- Name: enum_subjects_category; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.enum_subjects_category AS ENUM (
    'general',
    'professional'
);


--
-- Name: enum_system_mode_mode; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.enum_system_mode_mode AS ENUM (
    'online',
    'offline',
    'mirror'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: SequelizeMeta; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."SequelizeMeta" (
    name character varying(255) NOT NULL
);


--
-- Name: academicYears; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."academicYears" (
    id integer NOT NULL,
    name character varying(255),
    start_date timestamp with time zone,
    end_date timestamp with time zone,
    status public."enum_academicYears_status",
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "deletedAt" timestamp with time zone
);


--
-- Name: academicYears_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."academicYears_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: academicYears_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."academicYears_id_seq" OWNED BY public."academicYears".id;


--
-- Name: academic_bands; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.academic_bands (
    id integer NOT NULL,
    band_min double precision NOT NULL,
    band_max double precision NOT NULL,
    comment text NOT NULL,
    academic_year_id integer NOT NULL,
    class_id integer NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


--
-- Name: academic_bands_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.academic_bands_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: academic_bands_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.academic_bands_id_seq OWNED BY public.academic_bands.id;


--
-- Name: academic_years; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.academic_years (
    id integer NOT NULL,
    year_name character varying(50) NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    is_active boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: academic_years_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.academic_years_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: academic_years_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.academic_years_id_seq OWNED BY public.academic_years.id;


--
-- Name: applications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.applications (
    id integer NOT NULL,
    applicant_id integer,
    applicant_name character varying(100) NOT NULL,
    classes text NOT NULL,
    subjects text NOT NULL,
    contact character varying(50) NOT NULL,
    certificate_url character varying(500),
    certificate_name character varying(255),
    status character varying(20) DEFAULT 'pending'::character varying,
    admin_comment text,
    submitted_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    reviewed_at timestamp without time zone,
    reviewed_by integer,
    experience_years integer,
    education_level text,
    current_salary numeric(10,2),
    expected_salary numeric(10,2),
    availability text,
    additional_info text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT applications_status_check CHECK (((status)::text = ANY (ARRAY[('pending'::character varying)::text, ('approved'::character varying)::text, ('rejected'::character varying)::text])))
);


--
-- Name: applications_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.applications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: applications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.applications_id_seq OWNED BY public.applications.id;


--
-- Name: asset_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.asset_categories (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    default_depreciation_rate numeric(5,2) DEFAULT 0,
    useful_life_years integer DEFAULT 5,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: asset_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.asset_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: asset_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.asset_categories_id_seq OWNED BY public.asset_categories.id;


--
-- Name: asset_depreciation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.asset_depreciation (
    id integer NOT NULL,
    inventory_id integer,
    asset_name character varying(255) NOT NULL,
    original_cost numeric(12,2) NOT NULL,
    current_value numeric(12,2) NOT NULL,
    depreciation_rate numeric(5,2) NOT NULL,
    monthly_depreciation numeric(12,2) NOT NULL,
    total_depreciation numeric(12,2) NOT NULL,
    calculation_date date NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: asset_depreciation_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.asset_depreciation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: asset_depreciation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.asset_depreciation_id_seq OWNED BY public.asset_depreciation.id;


--
-- Name: attendance_records; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.attendance_records (
    id integer NOT NULL,
    session_id integer,
    student_id integer,
    status character varying(10) NOT NULL,
    marked_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    teacher_id integer,
    CONSTRAINT attendance_records_status_check CHECK (((status)::text = ANY (ARRAY[('present'::character varying)::text, ('absent'::character varying)::text])))
);


--
-- Name: attendance_records_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.attendance_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: attendance_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.attendance_records_id_seq OWNED BY public.attendance_records.id;


--
-- Name: attendance_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.attendance_sessions (
    id integer NOT NULL,
    type character varying(10) NOT NULL,
    class_id integer,
    taken_by integer,
    session_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT attendance_sessions_type_check CHECK (((type)::text = ANY (ARRAY[('student'::character varying)::text, ('teacher'::character varying)::text])))
);


--
-- Name: attendance_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.attendance_sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: attendance_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.attendance_sessions_id_seq OWNED BY public.attendance_sessions.id;


--
-- Name: budget_heads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.budget_heads (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    code character varying(50),
    category character varying(100) NOT NULL,
    description text,
    allocated_amount numeric(15,2) DEFAULT 0,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: budget_heads_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.budget_heads_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: budget_heads_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.budget_heads_id_seq OWNED BY public.budget_heads.id;


--
-- Name: case_reports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.case_reports (
    id integer NOT NULL,
    case_id integer,
    report_type character varying(50) NOT NULL,
    report_content text NOT NULL,
    report_file_url character varying(255),
    sent_to integer,
    sent_by integer,
    sent_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: case_reports_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.case_reports_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: case_reports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.case_reports_id_seq OWNED BY public.case_reports.id;


--
-- Name: case_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.case_sessions (
    id integer NOT NULL,
    case_id integer,
    session_date date NOT NULL,
    session_time time without time zone NOT NULL,
    session_type character varying(50) NOT NULL,
    session_notes text,
    status character varying(20) DEFAULT 'scheduled'::character varying,
    created_by integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT case_sessions_status_check CHECK (((status)::text = ANY (ARRAY[('scheduled'::character varying)::text, ('completed'::character varying)::text, ('cancelled'::character varying)::text, ('rescheduled'::character varying)::text])))
);


--
-- Name: case_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.case_sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: case_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.case_sessions_id_seq OWNED BY public.case_sessions.id;


--
-- Name: cases; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cases (
    id integer NOT NULL,
    case_number character varying(20) NOT NULL,
    student_id character varying(32),
    class_id integer,
    issue_type character varying(100) NOT NULL,
    issue_description text NOT NULL,
    status character varying(20) DEFAULT 'active'::character varying,
    priority character varying(20) DEFAULT 'medium'::character varying,
    assigned_to integer,
    created_by integer,
    started_date date NOT NULL,
    resolved_date date,
    sessions_completed integer DEFAULT 0,
    sessions_scheduled integer DEFAULT 0,
    notes text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT cases_priority_check CHECK (((priority)::text = ANY (ARRAY[('low'::character varying)::text, ('medium'::character varying)::text, ('high'::character varying)::text, ('urgent'::character varying)::text]))),
    CONSTRAINT cases_status_check CHECK (((status)::text = ANY (ARRAY[('active'::character varying)::text, ('pending'::character varying)::text, ('resolved'::character varying)::text, ('closed'::character varying)::text])))
);


--
-- Name: cases_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cases_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cases_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cases_id_seq OWNED BY public.cases.id;


--
-- Name: change_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.change_logs (
    id integer NOT NULL,
    table_name character varying(255) NOT NULL,
    record_id integer NOT NULL,
    change_type public.enum_change_logs_change_type NOT NULL,
    changed_at timestamp with time zone NOT NULL,
    changed_by integer NOT NULL,
    fields_changed jsonb,
    source public.enum_change_logs_source DEFAULT 'local'::public.enum_change_logs_source NOT NULL,
    synced boolean DEFAULT false NOT NULL
);


--
-- Name: change_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.change_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: change_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.change_logs_id_seq OWNED BY public.change_logs.id;


--
-- Name: class_masters; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.class_masters (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    class_id integer NOT NULL,
    "createdAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: class_masters_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.class_masters_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: class_masters_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.class_masters_id_seq OWNED BY public.class_masters.id;


--
-- Name: class_subjects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.class_subjects (
    id integer NOT NULL,
    class_id integer NOT NULL,
    subject_id integer NOT NULL,
    teacher_id integer NOT NULL,
    "createdAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "deletedAt" timestamp with time zone,
    deleted_at timestamp with time zone,
    department_id integer NOT NULL
);


--
-- Name: class_subjects_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.class_subjects_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: class_subjects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.class_subjects_id_seq OWNED BY public.class_subjects.id;


--
-- Name: classes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.classes (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    registration_fee character varying(50),
    bus_fee character varying(50),
    internship_fee character varying(50),
    remedial_fee character varying(50),
    tuition_fee character varying(50),
    pta_fee character varying(50),
    total_fee character varying(50),
    suspended boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    "createdAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone DEFAULT now() NOT NULL,
    class_master_id integer,
    department_id integer
);


--
-- Name: classes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.classes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: classes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.classes_id_seq OWNED BY public.classes.id;


--
-- Name: cnps_preferences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cnps_preferences (
    user_id integer NOT NULL,
    excluded boolean DEFAULT false NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: db_swap_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.db_swap_logs (
    id integer NOT NULL,
    mode public.enum_db_swap_logs_mode NOT NULL,
    action public.enum_db_swap_logs_action NOT NULL,
    file_name character varying(255) NOT NULL,
    file_path character varying(255) NOT NULL,
    size_bytes bigint,
    created_at timestamp with time zone NOT NULL,
    created_by integer
);


--
-- Name: db_swap_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.db_swap_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: db_swap_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.db_swap_logs_id_seq OWNED BY public.db_swap_logs.id;


--
-- Name: departments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.departments (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    "createdAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: departments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.departments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: departments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.departments_id_seq OWNED BY public.departments.id;


--
-- Name: discipline_cases; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.discipline_cases (
    id integer NOT NULL,
    student_id integer,
    class_id integer,
    case_description text NOT NULL,
    status character varying(20) DEFAULT 'not resolved'::character varying,
    recorded_by integer,
    recorded_at timestamp without time zone DEFAULT now(),
    resolved_at timestamp without time zone,
    resolved_by integer,
    resolution_notes text,
    teacher_id integer,
    case_type character varying(20) DEFAULT 'student'::character varying,
    CONSTRAINT discipline_cases_case_type_check CHECK (((case_type)::text = ANY (ARRAY[('student'::character varying)::text, ('teacher'::character varying)::text]))),
    CONSTRAINT discipline_cases_status_check CHECK (((status)::text = ANY (ARRAY[('resolved'::character varying)::text, ('not resolved'::character varying)::text])))
);


--
-- Name: discipline_cases_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.discipline_cases_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: discipline_cases_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.discipline_cases_id_seq OWNED BY public.discipline_cases.id;


--
-- Name: events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.events (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    event_type character varying(50) NOT NULL,
    event_date date NOT NULL,
    event_time time without time zone NOT NULL,
    participants character varying(255),
    created_by integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT events_event_type_check CHECK (((event_type)::text = ANY (ARRAY[('Meeting'::character varying)::text, ('Class'::character varying)::text, ('Others'::character varying)::text])))
);


--
-- Name: events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.events_id_seq OWNED BY public.events.id;


--
-- Name: fees; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fees (
    id integer NOT NULL,
    student_id integer,
    class_id integer,
    fee_type character varying(50),
    amount numeric,
    paid_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: fees_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fees_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fees_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fees_id_seq OWNED BY public.fees.id;


--
-- Name: financial_transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.financial_transactions (
    id integer NOT NULL,
    transaction_date date NOT NULL,
    type character varying(20) NOT NULL,
    amount numeric(15,2) NOT NULL,
    budget_head_id integer,
    description text NOT NULL,
    reference_type character varying(50),
    reference_id integer,
    department character varying(255),
    created_by integer,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: financial_transactions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.financial_transactions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: financial_transactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.financial_transactions_id_seq OWNED BY public.financial_transactions.id;


--
-- Name: group_participants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.group_participants (
    id integer NOT NULL,
    group_id integer,
    user_id integer,
    joined_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: group_participants_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.group_participants_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: group_participants_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.group_participants_id_seq OWNED BY public.group_participants.id;


--
-- Name: groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.groups (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    creator_id integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: groups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.groups_id_seq OWNED BY public.groups.id;


--
-- Name: hod_teachers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hod_teachers (
    id integer NOT NULL,
    hod_id integer,
    teacher_id integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: hod_teachers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hod_teachers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hod_teachers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hod_teachers_id_seq OWNED BY public.hod_teachers.id;


--
-- Name: hods; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hods (
    id integer NOT NULL,
    department_name character varying(255) NOT NULL,
    hod_user_id integer,
    subject_id integer,
    suspended boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: hods_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hods_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hods_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hods_id_seq OWNED BY public.hods.id;


--
-- Name: id_cards; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.id_cards (
    id integer NOT NULL,
    student_id integer,
    card_number character varying(100),
    issued_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: id_cards_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.id_cards_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: id_cards_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.id_cards_id_seq OWNED BY public.id_cards.id;


--
-- Name: inventory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inventory (
    id integer NOT NULL,
    date date NOT NULL,
    item_name character varying(255) NOT NULL,
    department character varying(255) NOT NULL,
    quantity integer NOT NULL,
    estimated_cost numeric(12,2) NOT NULL,
    type character varying(20) NOT NULL,
    depreciation_rate numeric(5,2),
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    budget_head_id integer,
    asset_category character varying(100),
    purchase_date date,
    supplier character varying(255),
    warranty_expiry date,
    location character varying(255),
    condition character varying(50) DEFAULT 'new'::character varying
);


--
-- Name: inventory_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.inventory_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: inventory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.inventory_id_seq OWNED BY public.inventory.id;


--
-- Name: lesson_plans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lesson_plans (
    id integer NOT NULL,
    user_id integer,
    title character varying(255) NOT NULL,
    period_type character varying(20) NOT NULL,
    file_url character varying(500) NOT NULL,
    status character varying(20) DEFAULT 'pending'::character varying,
    admin_comment text,
    submitted_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    reviewed_at timestamp without time zone,
    reviewed_by integer,
    subject character varying(100),
    class_name character varying(100),
    week character varying(50),
    objectives text,
    content text,
    activities text,
    assessment text,
    resources text,
    file_name character varying(255),
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT lesson_plans_period_type_check CHECK (((period_type)::text = ANY (ARRAY[('weekly'::character varying)::text, ('monthly'::character varying)::text, ('yearly'::character varying)::text]))),
    CONSTRAINT lesson_plans_status_check CHECK (((status)::text = ANY (ARRAY[('pending'::character varying)::text, ('approved'::character varying)::text, ('rejected'::character varying)::text])))
);


--
-- Name: lesson_plans_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.lesson_plans_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: lesson_plans_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.lesson_plans_id_seq OWNED BY public.lesson_plans.id;


--
-- Name: lessons; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lessons (
    id integer NOT NULL,
    user_id integer,
    title character varying(255) NOT NULL,
    subject character varying(100),
    class_name character varying(100),
    week character varying(50),
    period_type character varying(20) DEFAULT 'weekly'::character varying NOT NULL,
    objectives text,
    content text,
    activities text,
    assessment text,
    resources text,
    status character varying(20) DEFAULT 'pending'::character varying,
    admin_comment text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    reviewed_at timestamp without time zone,
    reviewed_by integer,
    CONSTRAINT lessons_period_type_check CHECK (((period_type)::text = ANY (ARRAY[('weekly'::character varying)::text, ('monthly'::character varying)::text, ('yearly'::character varying)::text]))),
    CONSTRAINT lessons_status_check CHECK (((status)::text = ANY (ARRAY[('pending'::character varying)::text, ('approved'::character varying)::text, ('rejected'::character varying)::text])))
);


--
-- Name: lessons_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.lessons_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: lessons_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.lessons_id_seq OWNED BY public.lessons.id;


--
-- Name: marks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.marks (
    id integer NOT NULL,
    student_id integer NOT NULL,
    subject_id integer NOT NULL,
    class_id integer NOT NULL,
    academic_year_id integer NOT NULL,
    term_id integer NOT NULL,
    sequence_id integer NOT NULL,
    score numeric(5,2) NOT NULL,
    uploaded_by integer NOT NULL,
    uploaded_at timestamp with time zone DEFAULT now() NOT NULL,
    "createdAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone DEFAULT now() NOT NULL,
    "deletedAt" timestamp with time zone
);


--
-- Name: marks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.marks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: marks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.marks_id_seq OWNED BY public.marks.id;


--
-- Name: messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.messages (
    id integer NOT NULL,
    sender_id integer,
    receiver_id integer,
    content text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    file_url character varying(255),
    file_name character varying(255),
    file_type character varying(50),
    group_id integer,
    read_at timestamp without time zone,
    read boolean DEFAULT false
);


--
-- Name: messages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.messages_id_seq OWNED BY public.messages.id;


--
-- Name: salaries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.salaries (
    id integer NOT NULL,
    amount numeric(10,2) NOT NULL,
    month character varying(20) NOT NULL,
    paid boolean DEFAULT false,
    paid_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    user_id integer,
    year integer DEFAULT EXTRACT(year FROM CURRENT_DATE) NOT NULL,
    status character varying(20) DEFAULT 'pending'::character varying,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    applicant_id integer,
    CONSTRAINT salaries_status_check CHECK (((status)::text = ANY (ARRAY[('pending'::character varying)::text, ('paid'::character varying)::text])))
);


--
-- Name: salaries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.salaries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: salaries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.salaries_id_seq OWNED BY public.salaries.id;


--
-- Name: salary_descriptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.salary_descriptions (
    id integer NOT NULL,
    description character varying(100) NOT NULL,
    percentage numeric(5,2) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT salary_descriptions_percentage_check CHECK (((percentage >= (0)::numeric) AND (percentage <= (100)::numeric)))
);


--
-- Name: salary_descriptions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.salary_descriptions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: salary_descriptions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.salary_descriptions_id_seq OWNED BY public.salary_descriptions.id;


--
-- Name: salary_payslip_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.salary_payslip_settings (
    id integer NOT NULL,
    settings jsonb NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: salary_payslip_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.salary_payslip_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: salary_payslip_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.salary_payslip_settings_id_seq OWNED BY public.salary_payslip_settings.id;


--
-- Name: sequences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sequences (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    order_number integer NOT NULL,
    academic_year_id integer NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    term_id integer NOT NULL,
    "deletedAt" timestamp with time zone
);


--
-- Name: sequences_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sequences_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sequences_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sequences_id_seq OWNED BY public.sequences.id;


--
-- Name: specialties; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.specialties (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    abbreviation character varying(20),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    "createdAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: specialties_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.specialties_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: specialties_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.specialties_id_seq OWNED BY public.specialties.id;


--
-- Name: specialty_classes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.specialty_classes (
    id integer NOT NULL,
    specialty_id integer,
    class_id integer
);


--
-- Name: specialty_classes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.specialty_classes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: specialty_classes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.specialty_classes_id_seq OWNED BY public.specialty_classes.id;


--
-- Name: staff_attendance_records; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.staff_attendance_records (
    id integer NOT NULL,
    date date NOT NULL,
    staff_name character varying(255) NOT NULL,
    time_in time without time zone,
    time_out time without time zone,
    classes_taught text,
    status character varying(50) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT staff_attendance_records_status_check CHECK (((status)::text = ANY (ARRAY[('Present'::character varying)::text, ('Absent'::character varying)::text, ('Late'::character varying)::text, ('Half Day'::character varying)::text])))
);


--
-- Name: staff_attendance_records_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.staff_attendance_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: staff_attendance_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.staff_attendance_records_id_seq OWNED BY public.staff_attendance_records.id;


--
-- Name: staff_attendance_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.staff_attendance_settings (
    id integer NOT NULL,
    setting_key character varying(50) NOT NULL,
    setting_value character varying(255) NOT NULL,
    description text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: staff_attendance_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.staff_attendance_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: staff_attendance_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.staff_attendance_settings_id_seq OWNED BY public.staff_attendance_settings.id;


--
-- Name: staff_employment_status; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.staff_employment_status (
    id integer NOT NULL,
    staff_name character varying(255) NOT NULL,
    employment_type character varying(20) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT staff_employment_status_employment_type_check CHECK (((employment_type)::text = ANY (ARRAY[('Full Time'::character varying)::text, ('Part Time'::character varying)::text])))
);


--
-- Name: staff_employment_status_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.staff_employment_status_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: staff_employment_status_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.staff_employment_status_id_seq OWNED BY public.staff_employment_status.id;


--
-- Name: students; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.students (
    id integer NOT NULL,
    student_id character varying(32) NOT NULL,
    registration_date date NOT NULL,
    full_name character varying(100) NOT NULL,
    sex character varying(10) NOT NULL,
    date_of_birth date NOT NULL,
    place_of_birth character varying(100) NOT NULL,
    father_name character varying(100),
    mother_name character varying(100),
    class_id integer,
    specialty_id integer,
    guardian_contact character varying(50),
    mother_contact character varying(50),
    photo_url character varying(255),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    photo bytea,
    academic_year_id integer NOT NULL,
    "createdAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "deletedAt" timestamp with time zone
);


--
-- Name: students_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.students_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: students_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.students_id_seq OWNED BY public.students.id;


--
-- Name: subject_classifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.subject_classifications (
    id integer NOT NULL,
    class_id integer,
    subject_id integer,
    classification_type character varying(20) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT subject_classifications_classification_type_check CHECK (((classification_type)::text = ANY (ARRAY[('general'::character varying)::text, ('professional'::character varying)::text])))
);


--
-- Name: subject_classifications_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.subject_classifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: subject_classifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.subject_classifications_id_seq OWNED BY public.subject_classifications.id;


--
-- Name: subject_coefficients; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.subject_coefficients (
    id integer NOT NULL,
    class_id integer,
    subject_id integer,
    coefficient numeric(4,2) DEFAULT 1.00 NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: subject_coefficients_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.subject_coefficients_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: subject_coefficients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.subject_coefficients_id_seq OWNED BY public.subject_coefficients.id;


--
-- Name: subjects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.subjects (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    code character varying(20) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    description text,
    credits integer DEFAULT 0,
    department character varying(100),
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    coefficient double precision,
    category character varying(255),
    "createdAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone DEFAULT now() NOT NULL,
    "deletedAt" timestamp with time zone
);


--
-- Name: subjects_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.subjects_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: subjects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.subjects_id_seq OWNED BY public.subjects.id;


--
-- Name: system_mode; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.system_mode (
    mode public.enum_system_mode_mode DEFAULT 'online'::public.enum_system_mode_mode NOT NULL
);


--
-- Name: teacher_assignments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.teacher_assignments (
    id integer NOT NULL,
    teacher_id integer,
    class_id integer,
    subject_id integer,
    periods_per_week integer DEFAULT 1 NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: teacher_assignments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.teacher_assignments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: teacher_assignments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.teacher_assignments_id_seq OWNED BY public.teacher_assignments.id;


--
-- Name: teacher_discipline_cases; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.teacher_discipline_cases (
    id integer NOT NULL,
    teacher_id integer,
    class_id integer,
    case_description text NOT NULL,
    status character varying(20) DEFAULT 'not resolved'::character varying,
    recorded_by integer,
    recorded_at timestamp without time zone DEFAULT now(),
    resolved_at timestamp without time zone,
    resolved_by integer,
    resolution_notes text,
    case_name character varying(200),
    description text,
    created_by integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT teacher_discipline_cases_status_check CHECK (((status)::text = ANY (ARRAY[('resolved'::character varying)::text, ('not resolved'::character varying)::text])))
);


--
-- Name: teacher_discipline_cases_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.teacher_discipline_cases_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: teacher_discipline_cases_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.teacher_discipline_cases_id_seq OWNED BY public.teacher_discipline_cases.id;


--
-- Name: teachers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.teachers (
    id integer NOT NULL,
    full_name character varying(100) NOT NULL,
    sex character varying(10) NOT NULL,
    id_card character varying(50) NOT NULL,
    dob date NOT NULL,
    pob character varying(100) NOT NULL,
    subjects character varying(255) NOT NULL,
    classes character varying(255),
    contact character varying(50) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    status character varying(20) DEFAULT 'pending'::character varying,
    user_id integer,
    certificate_url character varying(255),
    cv_url character varying(255),
    photo_url character varying(255)
);


--
-- Name: teachers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.teachers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: teachers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.teachers_id_seq OWNED BY public.teachers.id;


--
-- Name: terms; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.terms (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    order_number integer NOT NULL,
    academic_year_id integer NOT NULL,
    "createdAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "deletedAt" timestamp with time zone
);


--
-- Name: terms_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.terms_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: terms_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.terms_id_seq OWNED BY public.terms.id;


--
-- Name: timetable_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.timetable_configs (
    id integer NOT NULL,
    config jsonb NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: timetable_configs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.timetable_configs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: timetable_configs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.timetable_configs_id_seq OWNED BY public.timetable_configs.id;


--
-- Name: timetables; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.timetables (
    id integer NOT NULL,
    class_id integer,
    data jsonb NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: timetables_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.timetables_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: timetables_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.timetables_id_seq OWNED BY public.timetables.id;


--
-- Name: user_activities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_activities (
    id integer NOT NULL,
    user_id integer,
    activity_type character varying(100) NOT NULL,
    activity_description text NOT NULL,
    entity_type character varying(50),
    entity_id integer,
    entity_name character varying(255),
    ip_address character varying(45),
    user_agent text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: user_activities_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_activities_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_activities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_activities_id_seq OWNED BY public.user_activities.id;


--
-- Name: user_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_sessions (
    id integer NOT NULL,
    user_id integer,
    session_start timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    session_end timestamp without time zone,
    ip_address character varying(45),
    user_agent text,
    status character varying(20) DEFAULT 'active'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT user_sessions_status_check CHECK (((status)::text = ANY (ARRAY[('active'::character varying)::text, ('ended'::character varying)::text, ('expired'::character varying)::text])))
);


--
-- Name: user_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_sessions_id_seq OWNED BY public.user_sessions.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(50) NOT NULL,
    contact character varying(50),
    password character varying(255) NOT NULL,
    name character varying(100),
    email character varying(255),
    gender character varying(20),
    role character varying(20) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    suspended boolean DEFAULT false,
    "createdAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone DEFAULT now() NOT NULL,
    profile_image_url character varying(500)
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: vocational; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vocational (
    id integer NOT NULL,
    user_id integer,
    name character varying(100),
    description text,
    picture1 character varying(255),
    picture2 character varying(255),
    picture3 character varying(255),
    picture4 character varying(255),
    year character varying(20),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: vocational_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.vocational_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: vocational_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.vocational_id_seq OWNED BY public.vocational.id;


--
-- Name: academicYears id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."academicYears" ALTER COLUMN id SET DEFAULT nextval('public."academicYears_id_seq"'::regclass);


--
-- Name: academic_bands id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.academic_bands ALTER COLUMN id SET DEFAULT nextval('public.academic_bands_id_seq'::regclass);


--
-- Name: academic_years id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.academic_years ALTER COLUMN id SET DEFAULT nextval('public.academic_years_id_seq'::regclass);


--
-- Name: applications id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.applications ALTER COLUMN id SET DEFAULT nextval('public.applications_id_seq'::regclass);


--
-- Name: asset_categories id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.asset_categories ALTER COLUMN id SET DEFAULT nextval('public.asset_categories_id_seq'::regclass);


--
-- Name: asset_depreciation id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.asset_depreciation ALTER COLUMN id SET DEFAULT nextval('public.asset_depreciation_id_seq'::regclass);


--
-- Name: attendance_records id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_records ALTER COLUMN id SET DEFAULT nextval('public.attendance_records_id_seq'::regclass);


--
-- Name: attendance_sessions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_sessions ALTER COLUMN id SET DEFAULT nextval('public.attendance_sessions_id_seq'::regclass);


--
-- Name: budget_heads id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budget_heads ALTER COLUMN id SET DEFAULT nextval('public.budget_heads_id_seq'::regclass);


--
-- Name: case_reports id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_reports ALTER COLUMN id SET DEFAULT nextval('public.case_reports_id_seq'::regclass);


--
-- Name: case_sessions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_sessions ALTER COLUMN id SET DEFAULT nextval('public.case_sessions_id_seq'::regclass);


--
-- Name: cases id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cases ALTER COLUMN id SET DEFAULT nextval('public.cases_id_seq'::regclass);


--
-- Name: change_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.change_logs ALTER COLUMN id SET DEFAULT nextval('public.change_logs_id_seq'::regclass);


--
-- Name: class_masters id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.class_masters ALTER COLUMN id SET DEFAULT nextval('public.class_masters_id_seq'::regclass);


--
-- Name: class_subjects id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.class_subjects ALTER COLUMN id SET DEFAULT nextval('public.class_subjects_id_seq'::regclass);


--
-- Name: classes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classes ALTER COLUMN id SET DEFAULT nextval('public.classes_id_seq'::regclass);


--
-- Name: db_swap_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.db_swap_logs ALTER COLUMN id SET DEFAULT nextval('public.db_swap_logs_id_seq'::regclass);


--
-- Name: departments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.departments ALTER COLUMN id SET DEFAULT nextval('public.departments_id_seq'::regclass);


--
-- Name: discipline_cases id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.discipline_cases ALTER COLUMN id SET DEFAULT nextval('public.discipline_cases_id_seq'::regclass);


--
-- Name: events id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.events ALTER COLUMN id SET DEFAULT nextval('public.events_id_seq'::regclass);


--
-- Name: fees id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fees ALTER COLUMN id SET DEFAULT nextval('public.fees_id_seq'::regclass);


--
-- Name: financial_transactions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.financial_transactions ALTER COLUMN id SET DEFAULT nextval('public.financial_transactions_id_seq'::regclass);


--
-- Name: group_participants id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_participants ALTER COLUMN id SET DEFAULT nextval('public.group_participants_id_seq'::regclass);


--
-- Name: groups id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.groups ALTER COLUMN id SET DEFAULT nextval('public.groups_id_seq'::regclass);


--
-- Name: hod_teachers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hod_teachers ALTER COLUMN id SET DEFAULT nextval('public.hod_teachers_id_seq'::regclass);


--
-- Name: hods id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hods ALTER COLUMN id SET DEFAULT nextval('public.hods_id_seq'::regclass);


--
-- Name: id_cards id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.id_cards ALTER COLUMN id SET DEFAULT nextval('public.id_cards_id_seq'::regclass);


--
-- Name: inventory id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory ALTER COLUMN id SET DEFAULT nextval('public.inventory_id_seq'::regclass);


--
-- Name: lesson_plans id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lesson_plans ALTER COLUMN id SET DEFAULT nextval('public.lesson_plans_id_seq'::regclass);


--
-- Name: lessons id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lessons ALTER COLUMN id SET DEFAULT nextval('public.lessons_id_seq'::regclass);


--
-- Name: marks id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.marks ALTER COLUMN id SET DEFAULT nextval('public.marks_id_seq'::regclass);


--
-- Name: messages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages ALTER COLUMN id SET DEFAULT nextval('public.messages_id_seq'::regclass);


--
-- Name: salaries id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salaries ALTER COLUMN id SET DEFAULT nextval('public.salaries_id_seq'::regclass);


--
-- Name: salary_descriptions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salary_descriptions ALTER COLUMN id SET DEFAULT nextval('public.salary_descriptions_id_seq'::regclass);


--
-- Name: salary_payslip_settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salary_payslip_settings ALTER COLUMN id SET DEFAULT nextval('public.salary_payslip_settings_id_seq'::regclass);


--
-- Name: sequences id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sequences ALTER COLUMN id SET DEFAULT nextval('public.sequences_id_seq'::regclass);


--
-- Name: specialties id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.specialties ALTER COLUMN id SET DEFAULT nextval('public.specialties_id_seq'::regclass);


--
-- Name: specialty_classes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.specialty_classes ALTER COLUMN id SET DEFAULT nextval('public.specialty_classes_id_seq'::regclass);


--
-- Name: staff_attendance_records id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff_attendance_records ALTER COLUMN id SET DEFAULT nextval('public.staff_attendance_records_id_seq'::regclass);


--
-- Name: staff_attendance_settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff_attendance_settings ALTER COLUMN id SET DEFAULT nextval('public.staff_attendance_settings_id_seq'::regclass);


--
-- Name: staff_employment_status id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff_employment_status ALTER COLUMN id SET DEFAULT nextval('public.staff_employment_status_id_seq'::regclass);


--
-- Name: students id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.students ALTER COLUMN id SET DEFAULT nextval('public.students_id_seq'::regclass);


--
-- Name: subject_classifications id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subject_classifications ALTER COLUMN id SET DEFAULT nextval('public.subject_classifications_id_seq'::regclass);


--
-- Name: subject_coefficients id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subject_coefficients ALTER COLUMN id SET DEFAULT nextval('public.subject_coefficients_id_seq'::regclass);


--
-- Name: subjects id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subjects ALTER COLUMN id SET DEFAULT nextval('public.subjects_id_seq'::regclass);


--
-- Name: teacher_assignments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teacher_assignments ALTER COLUMN id SET DEFAULT nextval('public.teacher_assignments_id_seq'::regclass);


--
-- Name: teacher_discipline_cases id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teacher_discipline_cases ALTER COLUMN id SET DEFAULT nextval('public.teacher_discipline_cases_id_seq'::regclass);


--
-- Name: teachers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teachers ALTER COLUMN id SET DEFAULT nextval('public.teachers_id_seq'::regclass);


--
-- Name: terms id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.terms ALTER COLUMN id SET DEFAULT nextval('public.terms_id_seq'::regclass);


--
-- Name: timetable_configs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.timetable_configs ALTER COLUMN id SET DEFAULT nextval('public.timetable_configs_id_seq'::regclass);


--
-- Name: timetables id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.timetables ALTER COLUMN id SET DEFAULT nextval('public.timetables_id_seq'::regclass);


--
-- Name: user_activities id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_activities ALTER COLUMN id SET DEFAULT nextval('public.user_activities_id_seq'::regclass);


--
-- Name: user_sessions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_sessions ALTER COLUMN id SET DEFAULT nextval('public.user_sessions_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: vocational id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vocational ALTER COLUMN id SET DEFAULT nextval('public.vocational_id_seq'::regclass);


--
-- Data for Name: SequelizeMeta; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."SequelizeMeta" (name) FROM stdin;
20250811070315-create-academicYears.js
20250811072217-add-deletedAt-to-academicYears.js
20250811092440-create-academic-year.js
20250811092502-create-term.js
20250811092544-create-sequence.js
20250811105540-add-deletedAt-to-terms.js
20250811113901-add-deletedAt-to-sequences.js
20250811115727-rename-academicyear-table-to-snake-case.js
20250811124411-update-terms-unique-index.js
20250811134310-create-subjects.js
20250812064302-create-class-subjects.js
20250812083259-add-colums-to-subjects.js
20250812090051-add-deleted-at-to-class-subjects.js
20250812141740-update-class_subjects-table.js
20250812142432-update-class_-table.js
20250812143137-add-timestamps-to-classes.js
20250812143413-add-timestamps-to-users.js
20250812202227-add-timestamps-to-specialties.js
20250813004529-add-department-id-to-class-subjects.js
20250814005357-create-school-schema.js
20250814005638-create-school-schema.js
20250814031305-create-classes-table.js
20250814082437-create-academic-bands.js
20250815001059-add-created-at-updated-at-to-specialties.js
20250815014415-modify_marks_table.js
20250815031703-add-created-at-updated-at-to-specialties.js
20250815095410-fix-academic-year-fk.js
20250815105638-recreate-marks-table.js
20250817080809-add-academic-year-and-timestamps-to-students.js
20250817150815-rename-accademic-year-column.js
20250817151330-rename-accademic-year-column.js
20250823102908-create-academic-bands.js
20250823103000-add-photo-to-students.js
20250823104500-truncate-students.js
20250831130844-add-academic-year-id-to-students.js
20250831131359-add-timestamps-to-students.js
\.


--
-- Data for Name: academicYears; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."academicYears" (id, name, start_date, end_date, status, "createdAt", "updatedAt", "deletedAt") FROM stdin;
1	2025/2026 Academic Year	2025-09-02 01:00:00+01	2026-07-01 01:00:00+01	active	2025-09-11 12:47:08.878+01	2025-09-11 12:47:08.878+01	\N
\.


--
-- Data for Name: academic_bands; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.academic_bands (id, band_min, band_max, comment, academic_year_id, class_id, created_at, updated_at) FROM stdin;
1	3	3	good	1	23	2025-11-14 09:25:41.208+01	2025-11-14 09:25:41.208+01
\.


--
-- Data for Name: academic_years; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.academic_years (id, year_name, start_date, end_date, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: applications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.applications (id, applicant_id, applicant_name, classes, subjects, contact, certificate_url, certificate_name, status, admin_comment, submitted_at, reviewed_at, reviewed_by, experience_years, education_level, current_salary, expected_salary, availability, additional_info, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: asset_categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.asset_categories (id, name, description, default_depreciation_rate, useful_life_years, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: asset_depreciation; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.asset_depreciation (id, inventory_id, asset_name, original_cost, current_value, depreciation_rate, monthly_depreciation, total_depreciation, calculation_date, created_at) FROM stdin;
\.


--
-- Data for Name: attendance_records; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.attendance_records (id, session_id, student_id, status, marked_at, teacher_id) FROM stdin;
1	1	311	present	2025-11-12 09:39:56.239793	\N
2	1	399	present	2025-11-12 09:39:56.239793	\N
3	1	395	present	2025-11-12 09:39:56.239793	\N
4	1	144	present	2025-11-12 09:39:56.239793	\N
5	1	133	present	2025-11-12 09:39:56.239793	\N
6	1	194	present	2025-11-12 09:39:56.239793	\N
7	1	64	present	2025-11-12 09:39:56.239793	\N
8	1	407	absent	2025-11-12 09:39:56.239793	\N
9	1	260	present	2025-11-12 09:39:56.239793	\N
10	1	401	present	2025-11-12 09:39:56.239793	\N
11	1	195	present	2025-11-12 09:39:56.239793	\N
12	1	66	present	2025-11-12 09:39:56.239793	\N
13	1	404	present	2025-11-12 09:39:56.239793	\N
14	1	396	present	2025-11-12 09:39:56.239793	\N
15	1	132	present	2025-11-12 09:39:56.239793	\N
16	1	68	present	2025-11-12 09:39:56.239793	\N
17	1	457	present	2025-11-12 09:39:56.239793	\N
18	1	397	present	2025-11-12 09:39:56.239793	\N
19	1	390	present	2025-11-12 09:39:56.239793	\N
20	1	65	present	2025-11-12 09:39:56.239793	\N
21	1	389	present	2025-11-12 09:39:56.239793	\N
22	1	408	present	2025-11-12 09:39:56.239793	\N
23	1	405	present	2025-11-12 09:39:56.239793	\N
24	1	398	present	2025-11-12 09:39:56.239793	\N
25	1	391	present	2025-11-12 09:39:56.239793	\N
26	1	394	present	2025-11-12 09:39:56.239793	\N
27	1	312	present	2025-11-12 09:39:56.239793	\N
28	1	402	present	2025-11-12 09:39:56.239793	\N
29	1	388	present	2025-11-12 09:39:56.239793	\N
30	1	403	present	2025-11-12 09:39:56.239793	\N
31	1	63	present	2025-11-12 09:39:56.239793	\N
32	1	470	present	2025-11-12 09:39:56.239793	\N
33	1	392	present	2025-11-12 09:39:56.239793	\N
34	1	456	present	2025-11-12 09:39:56.239793	\N
35	1	196	present	2025-11-12 09:39:56.239793	\N
36	1	67	present	2025-11-12 09:39:56.239793	\N
37	1	406	present	2025-11-12 09:39:56.239793	\N
38	1	400	present	2025-11-12 09:39:56.239793	\N
39	1	393	present	2025-11-12 09:39:56.239793	\N
40	2	180	present	2025-11-12 09:42:12.623618	\N
41	2	361	present	2025-11-12 09:42:12.623618	\N
42	2	106	present	2025-11-12 09:42:12.623618	\N
43	3	105	present	2025-11-12 09:43:12.859588	\N
44	3	226	present	2025-11-12 09:43:12.859588	\N
45	3	440	present	2025-11-12 09:43:12.859588	\N
46	3	441	present	2025-11-12 09:43:12.859588	\N
47	3	439	present	2025-11-12 09:43:12.859588	\N
48	3	438	present	2025-11-12 09:43:12.859588	\N
49	3	230	absent	2025-11-12 09:43:12.859588	\N
50	3	231	absent	2025-11-12 09:43:12.859588	\N
51	4	311	present	2025-11-12 09:46:03.459482	\N
52	4	399	present	2025-11-12 09:46:03.459482	\N
53	4	395	present	2025-11-12 09:46:03.459482	\N
54	4	144	present	2025-11-12 09:46:03.459482	\N
55	4	133	present	2025-11-12 09:46:03.459482	\N
56	4	194	present	2025-11-12 09:46:03.459482	\N
57	4	64	present	2025-11-12 09:46:03.459482	\N
58	4	407	absent	2025-11-12 09:46:03.459482	\N
59	4	260	present	2025-11-12 09:46:03.459482	\N
60	4	401	present	2025-11-12 09:46:03.459482	\N
61	4	195	present	2025-11-12 09:46:03.459482	\N
62	4	66	present	2025-11-12 09:46:03.459482	\N
63	4	404	present	2025-11-12 09:46:03.459482	\N
64	4	396	present	2025-11-12 09:46:03.459482	\N
65	4	132	present	2025-11-12 09:46:03.459482	\N
66	4	68	present	2025-11-12 09:46:03.459482	\N
67	4	457	present	2025-11-12 09:46:03.459482	\N
68	4	397	present	2025-11-12 09:46:03.459482	\N
69	4	390	present	2025-11-12 09:46:03.459482	\N
70	4	65	present	2025-11-12 09:46:03.459482	\N
71	4	389	present	2025-11-12 09:46:03.459482	\N
72	4	408	present	2025-11-12 09:46:03.459482	\N
73	4	405	present	2025-11-12 09:46:03.459482	\N
74	4	398	present	2025-11-12 09:46:03.459482	\N
75	4	391	present	2025-11-12 09:46:03.459482	\N
76	4	394	present	2025-11-12 09:46:03.459482	\N
77	4	312	present	2025-11-12 09:46:03.459482	\N
78	4	402	present	2025-11-12 09:46:03.459482	\N
79	4	388	present	2025-11-12 09:46:03.459482	\N
80	4	403	present	2025-11-12 09:46:03.459482	\N
81	4	63	present	2025-11-12 09:46:03.459482	\N
82	4	470	absent	2025-11-12 09:46:03.459482	\N
83	4	392	present	2025-11-12 09:46:03.459482	\N
84	4	456	present	2025-11-12 09:46:03.459482	\N
85	4	196	present	2025-11-12 09:46:03.459482	\N
86	4	67	present	2025-11-12 09:46:03.459482	\N
87	4	406	present	2025-11-12 09:46:03.459482	\N
88	4	400	present	2025-11-12 09:46:03.459482	\N
89	4	393	present	2025-11-12 09:46:03.459482	\N
90	5	436	present	2025-11-12 09:46:46.256345	\N
91	6	322	present	2025-11-12 09:48:18.90612	\N
92	6	327	present	2025-11-12 09:48:18.90612	\N
93	6	385	present	2025-11-12 09:48:18.90612	\N
94	6	323	present	2025-11-12 09:48:18.90612	\N
95	6	315	present	2025-11-12 09:48:18.90612	\N
96	6	146	present	2025-11-12 09:48:18.90612	\N
97	6	326	present	2025-11-12 09:48:18.90612	\N
98	6	148	present	2025-11-12 09:48:18.90612	\N
99	6	442	present	2025-11-12 09:48:18.90612	\N
100	6	460	present	2025-11-12 09:48:18.90612	\N
101	6	145	present	2025-11-12 09:48:18.90612	\N
102	6	202	present	2025-11-12 09:48:18.90612	\N
103	6	324	present	2025-11-12 09:48:18.90612	\N
104	6	321	present	2025-11-12 09:48:18.90612	\N
105	6	249	present	2025-11-12 09:48:18.90612	\N
106	6	147	present	2025-11-12 09:48:18.90612	\N
107	6	476	present	2025-11-12 09:48:18.90612	\N
108	7	270	present	2025-11-12 09:49:41.055088	\N
109	7	271	present	2025-11-12 09:49:41.055088	\N
110	7	197	present	2025-11-12 09:49:41.055088	\N
111	7	73	present	2025-11-12 09:49:41.055088	\N
112	7	472	present	2025-11-12 09:49:41.055088	\N
113	7	259	present	2025-11-12 09:49:41.055088	\N
114	7	269	present	2025-11-12 09:49:41.055088	\N
115	7	71	present	2025-11-12 09:49:41.055088	\N
116	7	200	present	2025-11-12 09:49:41.055088	\N
117	7	267	present	2025-11-12 09:49:41.055088	\N
118	7	471	present	2025-11-12 09:49:41.055088	\N
119	7	72	present	2025-11-12 09:49:41.055088	\N
120	7	445	present	2025-11-12 09:49:41.055088	\N
121	7	475	present	2025-11-12 09:49:41.055088	\N
122	7	142	present	2025-11-12 09:49:41.055088	\N
123	7	75	present	2025-11-12 09:49:41.055088	\N
124	7	141	present	2025-11-12 09:49:41.055088	\N
125	7	74	present	2025-11-12 09:49:41.055088	\N
126	7	54	present	2025-11-12 09:49:41.055088	\N
127	7	143	present	2025-11-12 09:49:41.055088	\N
128	7	268	present	2025-11-12 09:49:41.055088	\N
129	9	137	present	2025-11-12 09:53:43.896205	\N
130	9	328	present	2025-11-12 09:53:43.896205	\N
131	9	198	present	2025-11-12 09:53:43.896205	\N
132	9	69	present	2025-11-12 09:53:43.896205	\N
133	9	263	present	2025-11-12 09:53:43.896205	\N
134	9	140	present	2025-11-12 09:53:43.896205	\N
135	9	122	present	2025-11-12 09:53:43.896205	\N
136	9	251	present	2025-11-12 09:53:43.896205	\N
137	9	211	present	2025-11-12 09:53:43.896205	\N
138	9	313	present	2025-11-12 09:53:43.896205	\N
139	9	264	present	2025-11-12 09:53:43.896205	\N
140	9	314	present	2025-11-12 09:53:43.896205	\N
141	9	31	present	2025-11-12 09:53:43.896205	\N
142	9	227	present	2025-11-12 09:53:43.896205	\N
143	9	262	present	2025-11-12 09:53:43.896205	\N
144	9	135	absent	2025-11-12 09:53:43.896205	\N
145	9	459	present	2025-11-12 09:53:43.896205	\N
146	9	136	present	2025-11-12 09:53:43.896205	\N
147	9	5	present	2025-11-12 09:53:43.896205	\N
148	9	380	present	2025-11-12 09:53:43.896205	\N
149	9	261	present	2025-11-12 09:53:43.896205	\N
150	9	199	present	2025-11-12 09:53:43.896205	\N
151	9	265	present	2025-11-12 09:53:43.896205	\N
152	9	266	present	2025-11-12 09:53:43.896205	\N
153	9	70	present	2025-11-12 09:53:43.896205	\N
154	9	134	present	2025-11-12 09:53:43.896205	\N
155	10	258	present	2025-11-12 09:56:30.639807	\N
156	10	329	present	2025-11-12 09:56:30.639807	\N
157	10	335	present	2025-11-12 09:56:30.639807	\N
158	10	206	present	2025-11-12 09:56:30.639807	\N
159	10	336	present	2025-11-12 09:56:30.639807	\N
160	10	205	present	2025-11-12 09:56:30.639807	\N
161	10	338	present	2025-11-12 09:56:30.639807	\N
162	10	149	present	2025-11-12 09:56:30.639807	\N
163	10	78	present	2025-11-12 09:56:30.639807	\N
164	10	411	present	2025-11-12 09:56:30.639807	\N
165	10	254	present	2025-11-12 09:56:30.639807	\N
166	10	77	present	2025-11-12 09:56:30.639807	\N
167	10	462	present	2025-11-12 09:56:30.639807	\N
168	10	204	present	2025-11-12 09:56:30.639807	\N
169	10	461	present	2025-11-12 09:56:30.639807	\N
170	10	354	present	2025-11-12 09:56:30.639807	\N
171	10	331	present	2025-11-12 09:56:30.639807	\N
172	10	203	present	2025-11-12 09:56:30.639807	\N
173	10	332	present	2025-11-12 09:56:30.639807	\N
174	10	337	present	2025-11-12 09:56:30.639807	\N
175	10	151	present	2025-11-12 09:56:30.639807	\N
176	10	334	present	2025-11-12 09:56:30.639807	\N
177	10	76	present	2025-11-12 09:56:30.639807	\N
178	10	333	present	2025-11-12 09:56:30.639807	\N
179	11	474	present	2025-11-12 09:57:20.726429	\N
180	11	223	present	2025-11-12 09:57:20.726429	\N
181	12	345	present	2025-11-12 10:00:45.795714	\N
182	12	155	present	2025-11-12 10:00:45.795714	\N
183	12	478	present	2025-11-12 10:00:45.795714	\N
184	12	82	present	2025-11-12 10:00:45.795714	\N
185	12	342	present	2025-11-12 10:00:45.795714	\N
186	12	341	present	2025-11-12 10:00:45.795714	\N
187	12	419	present	2025-11-12 10:00:45.795714	\N
188	12	344	present	2025-11-12 10:00:45.795714	\N
189	12	412	present	2025-11-12 10:00:45.795714	\N
190	12	379	present	2025-11-12 10:00:45.795714	\N
191	12	207	present	2025-11-12 10:00:45.795714	\N
192	12	156	present	2025-11-12 10:00:45.795714	\N
193	12	446	present	2025-11-12 10:00:45.795714	\N
194	12	340	present	2025-11-12 10:00:45.795714	\N
195	12	154	present	2025-11-12 10:00:45.795714	\N
196	12	209	present	2025-11-12 10:00:45.795714	\N
197	12	463	present	2025-11-12 10:00:45.795714	\N
198	12	153	present	2025-11-12 10:00:45.795714	\N
199	12	208	present	2025-11-12 10:00:45.795714	\N
200	12	79	present	2025-11-12 10:00:45.795714	\N
201	12	343	present	2025-11-12 10:00:45.795714	\N
202	13	358	present	2025-11-12 10:03:48.272451	\N
203	13	357	present	2025-11-12 10:03:48.272451	\N
204	13	90	absent	2025-11-12 10:03:48.272451	\N
205	13	368	present	2025-11-12 10:03:48.272451	\N
206	13	367	present	2025-11-12 10:03:48.272451	\N
207	13	88	present	2025-11-12 10:03:48.272451	\N
208	13	245	present	2025-11-12 10:03:48.272451	\N
209	13	366	present	2025-11-12 10:03:48.272451	\N
210	13	362	present	2025-11-12 10:03:48.272451	\N
211	13	369	present	2025-11-12 10:03:48.272451	\N
212	13	87	present	2025-11-12 10:03:48.272451	\N
213	13	363	present	2025-11-12 10:03:48.272451	\N
214	13	364	present	2025-11-12 10:03:48.272451	\N
215	13	365	present	2025-11-12 10:03:48.272451	\N
216	13	167	present	2025-11-12 10:03:48.272451	\N
217	13	217	present	2025-11-12 10:03:48.272451	\N
218	13	165	present	2025-11-12 10:03:48.272451	\N
219	13	359	present	2025-11-12 10:03:48.272451	\N
220	13	360	present	2025-11-12 10:03:48.272451	\N
221	13	83	present	2025-11-12 10:03:48.272451	\N
222	13	86	present	2025-11-12 10:03:48.272451	\N
223	13	164	present	2025-11-12 10:03:48.272451	\N
224	13	237	present	2025-11-12 10:03:48.272451	\N
225	13	168	present	2025-11-12 10:03:48.272451	\N
226	13	218	present	2025-11-12 10:03:48.272451	\N
227	13	85	present	2025-11-12 10:03:48.272451	\N
228	13	89	present	2025-11-12 10:03:48.272451	\N
229	13	469	present	2025-11-12 10:03:48.272451	\N
230	13	386	present	2025-11-12 10:03:48.272451	\N
231	13	387	absent	2025-11-12 10:03:48.272451	\N
232	14	219	absent	2025-11-12 10:05:30.273612	\N
233	14	370	present	2025-11-12 10:05:30.273612	\N
234	14	255	present	2025-11-12 10:05:30.273612	\N
235	15	428	present	2025-11-12 10:07:14.61835	\N
236	15	98	present	2025-11-12 10:07:14.61835	\N
237	15	177	present	2025-11-12 10:07:14.61835	\N
238	15	225	present	2025-11-12 10:07:14.61835	\N
239	15	176	present	2025-11-12 10:07:14.61835	\N
240	15	427	present	2025-11-12 10:07:14.61835	\N
241	16	163	present	2025-11-12 10:09:07.944522	\N
242	16	355	present	2025-11-12 10:09:07.944522	\N
243	16	416	present	2025-11-12 10:09:07.944522	\N
244	17	431	present	2025-11-12 10:10:11.787488	\N
245	17	430	present	2025-11-12 10:10:11.787488	\N
246	17	99	present	2025-11-12 10:10:11.787488	\N
247	17	100	present	2025-11-12 10:10:11.787488	\N
248	17	429	present	2025-11-12 10:10:11.787488	\N
249	17	178	present	2025-11-12 10:10:11.787488	\N
250	18	95	absent	2025-11-12 10:13:33.320148	\N
251	18	174	present	2025-11-12 10:13:33.320148	\N
252	18	96	present	2025-11-12 10:13:33.320148	\N
253	18	256	present	2025-11-12 10:13:33.320148	\N
254	18	173	present	2025-11-12 10:13:33.320148	\N
255	18	426	present	2025-11-12 10:13:33.320148	\N
256	18	138	present	2025-11-12 10:13:33.320148	\N
257	18	425	present	2025-11-12 10:13:33.320148	\N
258	18	423	present	2025-11-12 10:13:33.320148	\N
259	18	422	absent	2025-11-12 10:13:33.320148	\N
260	18	424	present	2025-11-12 10:13:33.320148	\N
261	18	421	present	2025-11-12 10:13:33.320148	\N
262	18	97	present	2025-11-12 10:13:33.320148	\N
263	18	420	present	2025-11-12 10:13:33.320148	\N
264	20	468	present	2025-11-12 10:16:40.774521	\N
265	20	356	present	2025-11-12 10:16:40.774521	\N
266	20	215	present	2025-11-12 10:16:40.774521	\N
267	20	152	present	2025-11-12 10:16:40.774521	\N
268	20	467	present	2025-11-12 10:16:40.774521	\N
269	20	482	present	2025-11-12 10:16:40.774521	\N
270	20	417	present	2025-11-12 10:16:40.774521	\N
271	21	464	present	2025-11-12 10:19:11.511101	\N
272	21	346	present	2025-11-12 10:19:11.511101	\N
273	21	348	present	2025-11-12 10:19:11.511101	\N
274	21	159	present	2025-11-12 10:19:11.511101	\N
275	21	158	present	2025-11-12 10:19:11.511101	\N
276	21	157	present	2025-11-12 10:19:11.511101	\N
277	21	347	present	2025-11-12 10:19:11.511101	\N
278	21	443	present	2025-11-12 10:19:11.511101	\N
279	21	444	present	2025-11-12 10:19:11.511101	\N
280	21	413	present	2025-11-12 10:19:11.511101	\N
281	21	349	present	2025-11-12 10:19:11.511101	\N
282	22	339	present	2025-11-12 10:21:03.475359	\N
283	22	415	present	2025-11-12 10:21:03.475359	\N
284	22	466	present	2025-11-12 10:21:03.475359	\N
285	22	414	present	2025-11-12 10:21:03.475359	\N
286	22	465	present	2025-11-12 10:21:03.475359	\N
287	22	201	present	2025-11-12 10:21:03.475359	\N
288	22	352	present	2025-11-12 10:21:03.475359	\N
289	22	81	present	2025-11-12 10:21:03.475359	\N
290	22	212	present	2025-11-12 10:21:03.475359	\N
291	22	214	present	2025-11-12 10:21:03.475359	\N
292	22	378	present	2025-11-12 10:21:03.475359	\N
293	22	161	present	2025-11-12 10:21:03.475359	\N
294	22	447	present	2025-11-12 10:21:03.475359	\N
295	22	160	present	2025-11-12 10:21:03.475359	\N
296	22	351	present	2025-11-12 10:21:03.475359	\N
297	22	162	present	2025-11-12 10:21:03.475359	\N
298	22	350	present	2025-11-12 10:21:03.475359	\N
299	22	213	present	2025-11-12 10:21:03.475359	\N
300	22	353	present	2025-11-12 10:21:03.475359	\N
301	24	436	present	2025-11-12 10:22:45.01136	\N
302	25	175	present	2025-11-12 10:23:38.173582	\N
303	25	224	present	2025-11-12 10:23:38.173582	\N
304	27	371	present	2025-11-12 10:27:35.279342	\N
305	27	172	present	2025-11-12 10:27:35.279342	\N
306	27	372	present	2025-11-12 10:27:35.279342	\N
307	27	384	present	2025-11-12 10:27:35.279342	\N
308	27	375	present	2025-11-12 10:27:35.279342	\N
309	27	107	present	2025-11-12 10:27:35.279342	\N
310	27	383	present	2025-11-12 10:27:35.279342	\N
311	27	91	present	2025-11-12 10:27:35.279342	\N
312	27	374	present	2025-11-12 10:27:35.279342	\N
313	27	222	present	2025-11-12 10:27:35.279342	\N
314	27	376	present	2025-11-12 10:27:35.279342	\N
315	27	373	present	2025-11-12 10:27:35.279342	\N
316	27	221	present	2025-11-12 10:27:35.279342	\N
317	27	381	present	2025-11-12 10:27:35.279342	\N
318	27	171	present	2025-11-12 10:27:35.279342	\N
319	27	169	present	2025-11-12 10:27:35.279342	\N
320	27	220	present	2025-11-12 10:27:35.279342	\N
321	27	92	present	2025-11-12 10:27:35.279342	\N
322	27	418	present	2025-11-12 10:27:35.279342	\N
323	27	382	present	2025-11-12 10:27:35.279342	\N
324	27	93	present	2025-11-12 10:27:35.279342	\N
\.


--
-- Data for Name: attendance_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.attendance_sessions (id, type, class_id, taken_by, session_time) FROM stdin;
1	student	2	46	2025-11-12 10:38:00
2	student	20	46	2025-11-12 10:41:00
3	student	23	46	2025-11-10 10:45:00
4	student	2	46	2025-11-12 10:43:00
5	student	21	46	2025-11-12 11:46:00
6	student	4	46	2025-11-12 09:47:00
7	student	3	46	2025-11-12 10:48:00
8	student	4	46	2025-11-12 09:50:00
9	student	5	46	2025-11-12 10:50:00
10	student	6	46	2025-11-12 11:54:00
11	student	22	46	2025-11-12 09:57:00
12	student	7	46	2025-11-12 10:59:00
13	student	12	46	2025-11-12 11:01:00
14	student	13	46	2025-11-12 11:05:00
15	student	18	46	2025-11-12 11:06:00
16	student	9	46	2025-11-12 10:08:00
17	student	17	46	2025-11-12 11:09:00
18	student	15	46	2025-11-12 11:12:00
19	student	7	46	2025-11-12 11:15:00
20	student	11	46	2025-11-12 10:15:00
21	student	10	46	2025-11-12 11:17:00
22	student	8	46	2025-11-12 11:20:00
23	student	27	46	2025-11-12 11:21:00
24	student	21	46	2025-11-12 11:22:00
25	student	14	46	2025-11-12 10:23:00
26	student	16	46	2025-11-12 11:24:00
27	student	16	46	2025-11-12 11:25:00
\.


--
-- Data for Name: budget_heads; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.budget_heads (id, name, code, category, description, allocated_amount, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: case_reports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.case_reports (id, case_id, report_type, report_content, report_file_url, sent_to, sent_by, sent_at) FROM stdin;
\.


--
-- Data for Name: case_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.case_sessions (id, case_id, session_date, session_time, session_type, session_notes, status, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: cases; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cases (id, case_number, student_id, class_id, issue_type, issue_description, status, priority, assigned_to, created_by, started_date, resolved_date, sessions_completed, sessions_scheduled, notes, created_at, updated_at) FROM stdin;
1	CASE20250001	25-VOT-AFNG-150	4	Health	- To inquire on the school fees situation since she is a special health case and is under scholarship \n-To hand in her medical files and update the school on her health situation	active	high	41	41	2025-10-22	\N	0	0		2025-10-22 07:23:21.549382	2025-10-22 07:23:21.549382
2	CASE20250002	25-VOT-BAAH-021	1	Health	- His mother came to notify the school about his constant headaches and was pleading that we avoid hitting his head	active	medium	41	41	2025-10-22	\N	0	0	The need to notify teachers of the orientation class	2025-10-22 07:40:18.777596	2025-10-22 07:40:18.777596
3	CASE20250003	25-VOT-HAKI-108	24	Academic 	- A new student with serious language issues\n- Orientation on what special programs can work for her since she doesn’t want a regular school program like regular students but just commercial subjects and language 	active	medium	41	41	2025-10-22	\N	0	0	- An individual time table needs to be made for her\n- extra sound and word building lessons for her will help her pickup the basics of reading and writing 	2025-10-22 08:05:54.592504	2025-10-22 08:05:54.592504
4	CASE20250004	25-VOT-HAKI-108	24	Stress related 	-Routine check and encouragement \n- feeling drained and is not sure she can make it in class with children younger than her\n- she is not understanding a thing she writes and doesn’t want to continue the program	active	medium	41	41	2025-10-22	\N	0	0	- constant encouragement and support.\n- Sound and word building lessons beginning with the very basics , letter of the alphabet and two letter words.\n. - proper follow up and constant checking of class notes	2025-10-22 08:50:43.190192	2025-10-22 08:50:43.190192
5	CASE20250005	25-VOT-TERI-147	5	Academic 	-One on one orientation to her and her mother on the various departments to choose from.\n-Constant distraction and little or no attention to details.\n- parents need proper updates always so they know how to manage her at home 	active	medium	41	41	2025-10-22	\N	0	0	- routine checks of her books and notes \n- constant updates of her parents . 	2025-10-22 09:01:29.945206	2025-10-22 09:01:29.945206
\.


--
-- Data for Name: change_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.change_logs (id, table_name, record_id, change_type, changed_at, changed_by, fields_changed, source, synced) FROM stdin;
\.


--
-- Data for Name: class_masters; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.class_masters (id, name, class_id, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: class_subjects; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.class_subjects (id, class_id, subject_id, teacher_id, "createdAt", "updatedAt", "deletedAt", deleted_at, department_id) FROM stdin;
120	7	9	9	2025-09-27 14:03:09.171+01	2025-09-27 14:03:09.171+01	\N	\N	2
121	2	9	9	2025-09-27 14:03:09.171+01	2025-09-27 14:03:09.171+01	\N	\N	2
122	8	9	9	2025-09-27 14:03:09.171+01	2025-09-27 14:03:09.171+01	\N	\N	3
14	2	5	9	2025-09-20 15:58:59.154+01	2025-09-20 15:58:59.154+01	\N	\N	2
15	5	5	9	2025-09-20 15:58:59.154+01	2025-09-20 15:58:59.154+01	\N	\N	5
16	19	5	9	2025-09-20 15:58:59.154+01	2025-09-20 15:58:59.154+01	\N	\N	1
17	6	5	9	2025-09-20 15:58:59.154+01	2025-09-20 15:58:59.154+01	\N	\N	4
18	4	5	9	2025-09-20 15:58:59.154+01	2025-09-20 15:58:59.154+01	\N	\N	6
19	1	5	9	2025-09-20 15:58:59.154+01	2025-09-20 15:58:59.154+01	\N	\N	1
20	3	5	9	2025-09-20 15:58:59.154+01	2025-09-20 15:58:59.154+01	\N	\N	3
21	11	5	9	2025-09-20 15:58:59.154+01	2025-09-20 15:58:59.154+01	\N	\N	4
22	10	5	9	2025-09-20 15:58:59.154+01	2025-09-20 15:58:59.154+01	\N	\N	5
23	8	5	9	2025-09-20 15:58:59.154+01	2025-09-20 15:58:59.154+01	\N	\N	3
24	9	5	9	2025-09-20 15:58:59.154+01	2025-09-20 15:58:59.154+01	\N	\N	6
25	7	5	9	2025-09-20 15:58:59.154+01	2025-09-20 15:58:59.154+01	\N	\N	2
123	3	9	9	2025-09-27 14:03:09.171+01	2025-09-27 14:03:09.171+01	\N	\N	3
124	10	9	9	2025-09-27 14:03:09.171+01	2025-09-27 14:03:09.171+01	\N	\N	5
125	5	9	9	2025-09-27 14:03:09.171+01	2025-09-27 14:03:09.171+01	\N	\N	5
126	9	9	9	2025-09-27 14:03:09.171+01	2025-09-27 14:03:09.171+01	\N	\N	6
127	4	9	9	2025-09-27 14:03:09.171+01	2025-09-27 14:03:09.171+01	\N	\N	6
128	11	9	9	2025-09-27 14:03:09.171+01	2025-09-27 14:03:09.171+01	\N	\N	4
129	6	9	9	2025-09-27 14:03:09.171+01	2025-09-27 14:03:09.171+01	\N	\N	4
37	11	4	13	2025-09-20 16:07:34.434+01	2025-09-20 16:07:34.434+01	\N	\N	4
38	10	4	13	2025-09-20 16:07:34.434+01	2025-09-20 16:07:34.434+01	\N	\N	5
39	2	4	13	2025-09-20 16:07:34.434+01	2025-09-20 16:07:34.434+01	\N	\N	2
40	5	4	13	2025-09-20 16:07:34.434+01	2025-09-20 16:07:34.434+01	\N	\N	5
41	8	4	13	2025-09-20 16:07:34.434+01	2025-09-20 16:07:34.434+01	\N	\N	3
42	6	4	13	2025-09-20 16:07:34.434+01	2025-09-20 16:07:34.434+01	\N	\N	4
43	4	4	13	2025-09-20 16:07:34.434+01	2025-09-20 16:07:34.434+01	\N	\N	6
44	23	4	13	2025-09-20 16:07:34.434+01	2025-09-20 16:07:34.434+01	\N	\N	8
45	3	4	13	2025-09-20 16:07:34.434+01	2025-09-20 16:07:34.434+01	\N	\N	3
46	9	4	13	2025-09-20 16:07:34.434+01	2025-09-20 16:07:34.434+01	\N	\N	6
47	7	4	13	2025-09-20 16:07:34.434+01	2025-09-20 16:07:34.434+01	\N	\N	2
456	7	7	7	2025-11-13 13:26:44.295+01	2025-11-13 13:26:44.295+01	\N	\N	2
457	2	7	7	2025-11-13 13:26:44.295+01	2025-11-13 13:26:44.295+01	\N	\N	2
458	8	7	7	2025-11-13 13:26:44.295+01	2025-11-13 13:26:44.295+01	\N	\N	3
459	5	7	7	2025-11-13 13:26:44.295+01	2025-11-13 13:26:44.295+01	\N	\N	5
460	6	7	7	2025-11-13 13:26:44.295+01	2025-11-13 13:26:44.295+01	\N	\N	4
461	4	7	7	2025-11-13 13:26:44.295+01	2025-11-13 13:26:44.295+01	\N	\N	6
462	3	7	7	2025-11-13 13:26:44.295+01	2025-11-13 13:26:44.295+01	\N	\N	3
463	11	7	7	2025-11-13 13:26:44.295+01	2025-11-13 13:26:44.295+01	\N	\N	4
464	10	7	7	2025-11-13 13:26:44.295+01	2025-11-13 13:26:44.295+01	\N	\N	5
465	9	7	7	2025-11-13 13:26:44.295+01	2025-11-13 13:26:44.295+01	\N	\N	6
466	13	7	7	2025-11-13 13:26:44.295+01	2025-11-13 13:26:44.295+01	\N	\N	2
467	12	7	7	2025-11-13 13:26:44.295+01	2025-11-13 13:26:44.295+01	\N	\N	2
468	16	7	7	2025-11-13 13:26:44.295+01	2025-11-13 13:26:44.295+01	\N	\N	3
469	14	7	7	2025-11-13 13:26:44.295+01	2025-11-13 13:26:44.295+01	\N	\N	5
470	17	7	7	2025-11-13 13:26:44.295+01	2025-11-13 13:26:44.295+01	\N	\N	6
471	18	7	7	2025-11-13 13:26:44.295+01	2025-11-13 13:26:44.295+01	\N	\N	4
472	22	7	7	2025-11-13 13:26:44.295+01	2025-11-13 13:26:44.295+01	\N	\N	5
473	20	7	7	2025-11-13 13:26:44.295+01	2025-11-13 13:26:44.295+01	\N	\N	2
474	21	7	7	2025-11-13 13:26:44.295+01	2025-11-13 13:26:44.295+01	\N	\N	3
475	19	7	7	2025-11-13 13:26:44.295+01	2025-11-13 13:26:44.295+01	\N	\N	1
476	1	7	7	2025-11-13 13:26:44.295+01	2025-11-13 13:26:44.295+01	\N	\N	1
477	15	7	7	2025-11-13 13:26:44.295+01	2025-11-13 13:26:44.295+01	\N	\N	5
478	26	7	7	2025-11-13 13:26:44.295+01	2025-11-13 13:26:44.295+01	\N	\N	3
479	27	7	7	2025-11-13 13:26:44.295+01	2025-11-13 13:26:44.295+01	\N	\N	5
480	25	7	7	2025-11-13 13:26:44.295+01	2025-11-13 13:26:44.295+01	\N	\N	2
491	2	38	42	2025-11-13 13:44:58.284+01	2025-11-13 13:44:58.284+01	\N	\N	2
492	13	38	42	2025-11-13 13:44:58.284+01	2025-11-13 13:44:58.284+01	\N	\N	2
493	12	38	42	2025-11-13 13:44:58.284+01	2025-11-13 13:44:58.284+01	\N	\N	2
494	20	38	42	2025-11-13 13:44:58.284+01	2025-11-13 13:44:58.284+01	\N	\N	2
495	25	38	42	2025-11-13 13:44:58.284+01	2025-11-13 13:44:58.284+01	\N	\N	2
507	8	35	26	2025-11-13 13:51:34.353+01	2025-11-13 13:51:34.353+01	\N	\N	3
508	3	35	26	2025-11-13 13:51:34.353+01	2025-11-13 13:51:34.353+01	\N	\N	3
509	16	35	26	2025-11-13 13:51:34.353+01	2025-11-13 13:51:34.353+01	\N	\N	3
91	7	2	18	2025-09-27 13:51:46.365+01	2025-09-27 13:51:46.365+01	\N	\N	2
92	2	2	18	2025-09-27 13:51:46.365+01	2025-09-27 13:51:46.365+01	\N	\N	2
93	8	2	18	2025-09-27 13:51:46.365+01	2025-09-27 13:51:46.365+01	\N	\N	3
94	3	2	18	2025-09-27 13:51:46.365+01	2025-09-27 13:51:46.365+01	\N	\N	3
95	10	2	18	2025-09-27 13:51:46.365+01	2025-09-27 13:51:46.365+01	\N	\N	5
96	5	2	18	2025-09-27 13:51:46.365+01	2025-09-27 13:51:46.365+01	\N	\N	5
97	9	2	18	2025-09-27 13:51:46.365+01	2025-09-27 13:51:46.365+01	\N	\N	6
98	4	2	18	2025-09-27 13:51:46.365+01	2025-09-27 13:51:46.365+01	\N	\N	6
99	11	2	18	2025-09-27 13:51:46.365+01	2025-09-27 13:51:46.365+01	\N	\N	4
100	6	2	18	2025-09-27 13:51:46.365+01	2025-09-27 13:51:46.365+01	\N	\N	4
101	1	2	18	2025-09-27 13:51:46.365+01	2025-09-27 13:51:46.365+01	\N	\N	1
102	19	2	18	2025-09-27 13:51:46.365+01	2025-09-27 13:51:46.365+01	\N	\N	1
103	13	2	36	2025-09-27 13:51:46.365+01	2025-09-27 13:51:46.365+01	\N	\N	2
104	12	2	36	2025-09-27 13:51:46.365+01	2025-09-27 13:51:46.365+01	\N	\N	2
105	16	2	36	2025-09-27 13:51:46.365+01	2025-09-27 13:51:46.365+01	\N	\N	3
106	15	2	36	2025-09-27 13:51:46.365+01	2025-09-27 13:51:46.365+01	\N	\N	5
107	14	2	36	2025-09-27 13:51:46.365+01	2025-09-27 13:51:46.365+01	\N	\N	5
108	17	2	36	2025-09-27 13:51:46.365+01	2025-09-27 13:51:46.365+01	\N	\N	6
109	18	2	36	2025-09-27 13:51:46.365+01	2025-09-27 13:51:46.365+01	\N	\N	4
181	19	20	23	2025-10-01 03:00:24.061+01	2025-10-01 03:00:24.061+01	\N	\N	1
182	1	20	23	2025-10-01 03:00:24.061+01	2025-10-01 03:00:24.061+01	\N	\N	1
183	6	25	25	2025-10-01 03:04:01.841+01	2025-10-01 03:04:01.841+01	\N	\N	4
184	11	25	23	2025-10-01 03:04:01.841+01	2025-10-01 03:04:01.841+01	\N	\N	4
185	18	25	25	2025-10-01 03:04:01.841+01	2025-10-01 03:04:01.841+01	\N	\N	4
186	6	24	25	2025-10-01 03:08:37.776+01	2025-10-01 03:08:37.776+01	\N	\N	4
187	11	24	23	2025-10-01 03:08:37.776+01	2025-10-01 03:08:37.776+01	\N	\N	4
188	18	24	25	2025-10-01 03:08:37.776+01	2025-10-01 03:08:37.776+01	\N	\N	4
189	6	23	25	2025-10-01 03:11:16.235+01	2025-10-01 03:11:16.235+01	\N	\N	4
190	11	23	23	2025-10-01 03:11:16.235+01	2025-10-01 03:11:16.235+01	\N	\N	4
191	18	23	25	2025-10-01 03:11:16.235+01	2025-10-01 03:11:16.235+01	\N	\N	4
192	6	22	25	2025-10-01 03:15:29.605+01	2025-10-01 03:15:29.605+01	\N	\N	4
193	11	22	23	2025-10-01 03:15:29.605+01	2025-10-01 03:15:29.605+01	\N	\N	4
194	18	22	25	2025-10-01 03:15:29.605+01	2025-10-01 03:15:29.605+01	\N	\N	4
195	1	21	2	2025-10-01 07:48:27.977+01	2025-10-01 07:48:27.977+01	\N	\N	1
213	5	40	19	2025-10-01 08:01:32.555+01	2025-10-01 08:01:32.555+01	\N	\N	5
214	10	40	19	2025-10-01 08:01:32.555+01	2025-10-01 08:01:32.555+01	\N	\N	5
215	15	40	19	2025-10-01 08:01:32.555+01	2025-10-01 08:01:32.555+01	\N	\N	5
216	14	40	19	2025-10-01 08:01:32.555+01	2025-10-01 08:01:32.555+01	\N	\N	5
217	22	40	19	2025-10-01 08:01:32.555+01	2025-10-01 08:01:32.555+01	\N	\N	5
225	19	16	19	2025-10-01 08:11:23.103+01	2025-10-01 08:11:23.103+01	\N	\N	1
226	1	16	19	2025-10-01 08:11:23.103+01	2025-10-01 08:11:23.103+01	\N	\N	1
435	7	6	24	2025-11-13 12:32:31.029+01	2025-11-13 12:32:31.029+01	\N	\N	2
436	2	6	2	2025-11-13 12:32:31.029+01	2025-11-13 12:32:31.029+01	\N	\N	2
233	6	27	22	2025-10-01 08:16:09.384+01	2025-10-01 08:16:09.384+01	\N	\N	4
234	4	27	22	2025-10-01 08:16:09.384+01	2025-10-01 08:16:09.384+01	\N	\N	6
235	11	27	22	2025-10-01 08:16:09.384+01	2025-10-01 08:16:09.384+01	\N	\N	4
236	9	27	22	2025-10-01 08:16:09.384+01	2025-10-01 08:16:09.384+01	\N	\N	6
237	17	27	22	2025-10-01 08:16:09.384+01	2025-10-01 08:16:09.384+01	\N	\N	6
238	18	27	22	2025-10-01 08:16:09.384+01	2025-10-01 08:16:09.384+01	\N	\N	4
239	19	19	15	2025-10-01 08:22:42.311+01	2025-10-01 08:22:42.311+01	\N	\N	1
240	1	19	15	2025-10-01 08:22:42.311+01	2025-10-01 08:22:42.311+01	\N	\N	1
241	19	18	20	2025-10-01 08:24:26.318+01	2025-10-01 08:24:26.318+01	\N	\N	1
242	1	18	20	2025-10-01 08:24:26.318+01	2025-10-01 08:24:26.318+01	\N	\N	1
245	4	29	15	2025-10-01 08:27:37.827+01	2025-10-01 08:27:37.827+01	\N	\N	6
246	4	28	22	2025-10-01 08:29:15.766+01	2025-10-01 08:29:15.766+01	\N	\N	6
247	9	28	15	2025-10-01 08:29:15.766+01	2025-10-01 08:29:15.766+01	\N	\N	6
248	17	28	15	2025-10-01 08:29:15.766+01	2025-10-01 08:29:15.766+01	\N	\N	6
249	7	3	14	2025-10-01 08:36:58.425+01	2025-10-01 08:36:58.425+01	\N	\N	2
250	2	3	14	2025-10-01 08:36:58.425+01	2025-10-01 08:36:58.425+01	\N	\N	2
251	8	3	14	2025-10-01 08:36:58.425+01	2025-10-01 08:36:58.425+01	\N	\N	3
252	5	3	14	2025-10-01 08:36:58.425+01	2025-10-01 08:36:58.425+01	\N	\N	5
253	19	3	14	2025-10-01 08:36:58.425+01	2025-10-01 08:36:58.425+01	\N	\N	1
254	4	3	14	2025-10-01 08:36:58.425+01	2025-10-01 08:36:58.425+01	\N	\N	6
255	6	3	14	2025-10-01 08:36:58.425+01	2025-10-01 08:36:58.425+01	\N	\N	4
256	1	3	14	2025-10-01 08:36:58.425+01	2025-10-01 08:36:58.425+01	\N	\N	1
257	3	3	14	2025-10-01 08:36:58.425+01	2025-10-01 08:36:58.425+01	\N	\N	3
258	10	3	14	2025-10-01 08:36:58.425+01	2025-10-01 08:36:58.425+01	\N	\N	5
259	9	3	14	2025-10-01 08:36:58.425+01	2025-10-01 08:36:58.425+01	\N	\N	6
260	11	3	14	2025-10-01 08:36:58.425+01	2025-10-01 08:36:58.425+01	\N	\N	4
261	16	3	14	2025-10-01 08:36:58.425+01	2025-10-01 08:36:58.425+01	\N	\N	3
262	13	3	14	2025-10-01 08:36:58.425+01	2025-10-01 08:36:58.425+01	\N	\N	2
263	15	3	14	2025-10-01 08:36:58.425+01	2025-10-01 08:36:58.425+01	\N	\N	5
264	12	3	14	2025-10-01 08:36:58.425+01	2025-10-01 08:36:58.425+01	\N	\N	2
265	14	3	14	2025-10-01 08:36:58.425+01	2025-10-01 08:36:58.425+01	\N	\N	5
266	17	3	14	2025-10-01 08:36:58.425+01	2025-10-01 08:36:58.425+01	\N	\N	6
267	18	3	14	2025-10-01 08:36:58.425+01	2025-10-01 08:36:58.425+01	\N	\N	4
268	7	10	9	2025-10-04 09:15:39.254+01	2025-10-04 09:15:39.254+01	\N	\N	2
269	2	10	9	2025-10-04 09:15:39.254+01	2025-10-04 09:15:39.254+01	\N	\N	2
270	8	10	9	2025-10-04 09:15:39.254+01	2025-10-04 09:15:39.254+01	\N	\N	3
271	5	10	9	2025-10-04 09:15:39.254+01	2025-10-04 09:15:39.254+01	\N	\N	5
272	6	10	9	2025-10-04 09:15:39.254+01	2025-10-04 09:15:39.254+01	\N	\N	4
273	4	10	9	2025-10-04 09:15:39.254+01	2025-10-04 09:15:39.254+01	\N	\N	6
274	3	10	9	2025-10-04 09:15:39.254+01	2025-10-04 09:15:39.254+01	\N	\N	3
275	11	10	9	2025-10-04 09:15:39.254+01	2025-10-04 09:15:39.254+01	\N	\N	4
276	10	10	9	2025-10-04 09:15:39.254+01	2025-10-04 09:15:39.254+01	\N	\N	5
277	9	10	9	2025-10-04 09:15:39.254+01	2025-10-04 09:15:39.254+01	\N	\N	6
278	23	10	13	2025-10-04 09:15:39.254+01	2025-10-04 09:15:39.254+01	\N	\N	8
279	16	10	13	2025-10-04 09:15:39.254+01	2025-10-04 09:15:39.254+01	\N	\N	3
280	13	10	13	2025-10-04 09:15:39.254+01	2025-10-04 09:15:39.254+01	\N	\N	2
281	15	10	13	2025-10-04 09:15:39.254+01	2025-10-04 09:15:39.254+01	\N	\N	5
437	8	6	24	2025-11-13 12:32:31.029+01	2025-11-13 12:32:31.029+01	\N	\N	3
438	5	6	2	2025-11-13 12:32:31.029+01	2025-11-13 12:32:31.029+01	\N	\N	5
439	4	6	2	2025-11-13 12:32:31.029+01	2025-11-13 12:32:31.029+01	\N	\N	6
440	3	6	2	2025-11-13 12:32:31.029+01	2025-11-13 12:32:31.029+01	\N	\N	3
441	10	6	24	2025-11-13 12:32:31.029+01	2025-11-13 12:32:31.029+01	\N	\N	5
442	9	6	24	2025-11-13 12:32:31.029+01	2025-11-13 12:32:31.029+01	\N	\N	6
443	13	6	24	2025-11-13 12:32:31.029+01	2025-11-13 12:32:31.029+01	\N	\N	2
444	12	6	24	2025-11-13 12:32:31.029+01	2025-11-13 12:32:31.029+01	\N	\N	2
445	16	6	24	2025-11-13 12:32:31.029+01	2025-11-13 12:32:31.029+01	\N	\N	3
446	15	6	24	2025-11-13 12:32:31.029+01	2025-11-13 12:32:31.029+01	\N	\N	5
447	14	6	24	2025-11-13 12:32:31.029+01	2025-11-13 12:32:31.029+01	\N	\N	5
448	17	6	24	2025-11-13 12:32:31.029+01	2025-11-13 12:32:31.029+01	\N	\N	6
449	18	6	24	2025-11-13 12:32:31.029+01	2025-11-13 12:32:31.029+01	\N	\N	4
450	6	6	2	2025-11-13 12:32:31.029+01	2025-11-13 12:32:31.029+01	\N	\N	4
451	11	6	24	2025-11-13 12:32:31.029+01	2025-11-13 12:32:31.029+01	\N	\N	4
481	8	34	26	2025-11-13 13:36:31.347+01	2025-11-13 13:36:31.347+01	\N	\N	3
482	16	34	26	2025-11-13 13:36:31.347+01	2025-11-13 13:36:31.347+01	\N	\N	3
483	21	34	26	2025-11-13 13:36:31.347+01	2025-11-13 13:36:31.347+01	\N	\N	3
484	3	34	26	2025-11-13 13:36:31.347+01	2025-11-13 13:36:31.347+01	\N	\N	3
485	26	34	26	2025-11-13 13:36:31.347+01	2025-11-13 13:36:31.347+01	\N	\N	3
496	8	41	26	2025-11-13 13:48:10.838+01	2025-11-13 13:48:10.838+01	\N	\N	3
497	21	41	26	2025-11-13 13:48:10.838+01	2025-11-13 13:48:10.838+01	\N	\N	3
498	3	41	26	2025-11-13 13:48:10.838+01	2025-11-13 13:48:10.838+01	\N	\N	3
499	16	41	26	2025-11-13 13:48:10.838+01	2025-11-13 13:48:10.838+01	\N	\N	3
500	26	41	26	2025-11-13 13:48:10.838+01	2025-11-13 13:48:10.838+01	\N	\N	3
510	23	46	21	2025-11-14 04:03:53.819+01	2025-11-14 04:03:53.819+01	\N	\N	8
282	12	10	13	2025-10-04 09:15:39.254+01	2025-10-04 09:15:39.254+01	\N	\N	2
283	14	10	13	2025-10-04 09:15:39.254+01	2025-10-04 09:15:39.254+01	\N	\N	5
284	17	10	13	2025-10-04 09:15:39.254+01	2025-10-04 09:15:39.254+01	\N	\N	6
285	18	10	13	2025-10-04 09:15:39.254+01	2025-10-04 09:15:39.254+01	\N	\N	4
288	19	17	35	2025-10-04 09:23:58.178+01	2025-10-04 09:23:58.178+01	\N	\N	1
289	1	17	35	2025-10-04 09:23:58.178+01	2025-10-04 09:23:58.178+01	\N	\N	1
290	7	37	20	2025-10-04 09:34:14.1+01	2025-10-04 09:34:14.1+01	\N	\N	2
291	2	37	20	2025-10-04 09:34:14.1+01	2025-10-04 09:34:14.1+01	\N	\N	2
292	12	37	20	2025-10-04 09:34:14.1+01	2025-10-04 09:34:14.1+01	\N	\N	2
293	20	37	20	2025-10-04 09:34:14.1+01	2025-10-04 09:34:14.1+01	\N	\N	2
454	17	30	15	2025-11-13 12:52:38.263+01	2025-11-13 12:52:38.263+01	\N	\N	6
455	9	30	15	2025-11-13 12:52:38.263+01	2025-11-13 12:52:38.263+01	\N	\N	6
296	13	14	12	2025-10-04 09:43:00.401+01	2025-10-04 09:43:00.401+01	\N	\N	2
297	7	14	12	2025-10-04 09:43:00.401+01	2025-10-04 09:43:00.401+01	\N	\N	2
298	2	14	12	2025-10-04 09:43:00.401+01	2025-10-04 09:43:00.401+01	\N	\N	2
299	13	13	12	2025-10-04 09:44:02.592+01	2025-10-04 09:44:02.592+01	\N	\N	2
300	7	13	12	2025-10-04 09:44:02.592+01	2025-10-04 09:44:02.592+01	\N	\N	2
301	2	13	12	2025-10-04 09:44:02.592+01	2025-10-04 09:44:02.592+01	\N	\N	2
302	23	44	36	2025-10-04 10:36:36.799+01	2025-10-04 10:36:36.799+01	\N	\N	8
303	20	44	36	2025-10-04 10:36:36.799+01	2025-10-04 10:36:36.799+01	\N	\N	2
304	21	44	36	2025-10-04 10:36:36.799+01	2025-10-04 10:36:36.799+01	\N	\N	3
305	22	44	36	2025-10-04 10:36:36.799+01	2025-10-04 10:36:36.799+01	\N	\N	5
306	7	8	12	2025-10-04 10:47:01.384+01	2025-10-04 10:47:01.384+01	\N	\N	2
307	2	8	20	2025-10-04 10:47:01.384+01	2025-10-04 10:47:01.384+01	\N	\N	2
308	19	8	20	2025-10-04 10:47:01.384+01	2025-10-04 10:47:01.384+01	\N	\N	1
309	6	8	23	2025-10-04 10:47:01.384+01	2025-10-04 10:47:01.384+01	\N	\N	4
310	1	8	20	2025-10-04 10:47:01.384+01	2025-10-04 10:47:01.384+01	\N	\N	1
311	11	8	23	2025-10-04 10:47:01.384+01	2025-10-04 10:47:01.384+01	\N	\N	4
312	13	8	20	2025-10-04 10:47:01.384+01	2025-10-04 10:47:01.384+01	\N	\N	2
313	12	8	20	2025-10-04 10:47:01.384+01	2025-10-04 10:47:01.384+01	\N	\N	2
314	18	8	25	2025-10-04 10:47:01.384+01	2025-10-04 10:47:01.384+01	\N	\N	4
315	20	8	20	2025-10-04 10:47:01.384+01	2025-10-04 10:47:01.384+01	\N	\N	2
336	7	1	24	2025-10-07 09:23:58.993+01	2025-10-07 09:23:58.993+01	\N	\N	2
337	2	1	24	2025-10-07 09:23:58.993+01	2025-10-07 09:23:58.993+01	\N	\N	2
338	8	1	24	2025-10-07 09:23:58.993+01	2025-10-07 09:23:58.993+01	\N	\N	3
339	5	1	24	2025-10-07 09:23:58.993+01	2025-10-07 09:23:58.993+01	\N	\N	5
340	19	1	38	2025-10-07 09:23:58.993+01	2025-10-07 09:23:58.993+01	\N	\N	1
341	6	1	24	2025-10-07 09:23:58.993+01	2025-10-07 09:23:58.993+01	\N	\N	4
342	4	1	24	2025-10-07 09:23:58.993+01	2025-10-07 09:23:58.993+01	\N	\N	6
343	1	1	38	2025-10-07 09:23:58.993+01	2025-10-07 09:23:58.993+01	\N	\N	1
344	3	1	24	2025-10-07 09:23:58.993+01	2025-10-07 09:23:58.993+01	\N	\N	3
345	11	1	24	2025-10-07 09:23:58.993+01	2025-10-07 09:23:58.993+01	\N	\N	4
346	10	1	24	2025-10-07 09:23:58.993+01	2025-10-07 09:23:58.993+01	\N	\N	5
347	9	1	24	2025-10-07 09:23:58.993+01	2025-10-07 09:23:58.993+01	\N	\N	6
348	23	1	24	2025-10-07 09:23:58.993+01	2025-10-07 09:23:58.993+01	\N	\N	8
349	16	1	24	2025-10-07 09:23:58.993+01	2025-10-07 09:23:58.993+01	\N	\N	3
350	13	1	24	2025-10-07 09:23:58.993+01	2025-10-07 09:23:58.993+01	\N	\N	2
351	15	1	24	2025-10-07 09:23:58.993+01	2025-10-07 09:23:58.993+01	\N	\N	5
352	12	1	24	2025-10-07 09:23:58.993+01	2025-10-07 09:23:58.993+01	\N	\N	2
353	14	1	24	2025-10-07 09:23:58.993+01	2025-10-07 09:23:58.993+01	\N	\N	5
354	18	1	24	2025-10-07 09:23:58.993+01	2025-10-07 09:23:58.993+01	\N	\N	4
355	20	1	24	2025-10-07 09:23:58.993+01	2025-10-07 09:23:58.993+01	\N	\N	2
356	21	1	24	2025-10-07 09:23:58.993+01	2025-10-07 09:23:58.993+01	\N	\N	3
357	22	1	24	2025-10-07 09:23:58.993+01	2025-10-07 09:23:58.993+01	\N	\N	5
486	13	15	42	2025-11-13 13:42:44.447+01	2025-11-13 13:42:44.447+01	\N	\N	2
487	12	15	42	2025-11-13 13:42:44.447+01	2025-11-13 13:42:44.447+01	\N	\N	2
488	2	15	42	2025-11-13 13:42:44.447+01	2025-11-13 13:42:44.447+01	\N	\N	2
489	20	15	42	2025-11-13 13:42:44.447+01	2025-11-13 13:42:44.447+01	\N	\N	2
490	25	15	42	2025-11-13 13:42:44.447+01	2025-11-13 13:42:44.447+01	\N	\N	2
504	8	36	26	2025-11-13 13:50:00.861+01	2025-11-13 13:50:00.861+01	\N	\N	3
505	3	36	26	2025-11-13 13:50:00.861+01	2025-11-13 13:50:00.861+01	\N	\N	3
506	16	36	26	2025-11-13 13:50:00.861+01	2025-11-13 13:50:00.861+01	\N	\N	3
371	21	32	39	2025-10-15 13:58:05.291+01	2025-10-15 13:58:05.291+01	\N	\N	3
372	5	33	39	2025-10-15 14:03:46.718+01	2025-10-15 14:03:46.718+01	\N	\N	5
373	10	33	39	2025-10-15 14:03:46.718+01	2025-10-15 14:03:46.718+01	\N	\N	5
374	15	33	39	2025-10-15 14:03:46.718+01	2025-10-15 14:03:46.718+01	\N	\N	5
375	21	33	39	2025-10-15 14:03:46.718+01	2025-10-15 14:03:46.718+01	\N	\N	3
376	5	39	26	2025-11-08 16:01:18.696+01	2025-11-08 16:01:18.696+01	\N	\N	5
377	10	39	26	2025-11-08 16:01:18.696+01	2025-11-08 16:01:18.696+01	\N	\N	5
378	15	39	26	2025-11-08 16:01:18.696+01	2025-11-08 16:01:18.696+01	\N	\N	5
379	14	39	26	2025-11-08 16:01:18.696+01	2025-11-08 16:01:18.696+01	\N	\N	5
385	8	31	26	2025-11-08 16:09:51.368+01	2025-11-08 16:09:51.368+01	\N	\N	3
386	3	31	26	2025-11-08 16:09:51.368+01	2025-11-08 16:09:51.368+01	\N	\N	3
387	16	31	26	2025-11-08 16:09:51.368+01	2025-11-08 16:09:51.368+01	\N	\N	3
388	21	31	26	2025-11-08 16:09:51.368+01	2025-11-08 16:09:51.368+01	\N	\N	3
389	26	31	26	2025-11-08 16:09:51.368+01	2025-11-08 16:09:51.368+01	\N	\N	3
390	5	45	17	2025-11-11 16:29:11.109+01	2025-11-11 16:29:11.109+01	\N	\N	5
391	10	45	17	2025-11-11 16:29:11.109+01	2025-11-11 16:29:11.109+01	\N	\N	5
392	5	43	17	2025-11-12 13:56:36.007+01	2025-11-12 13:56:36.007+01	\N	\N	5
393	14	43	17	2025-11-12 13:56:36.007+01	2025-11-12 13:56:36.007+01	\N	\N	5
394	10	43	17	2025-11-12 13:56:36.007+01	2025-11-12 13:56:36.007+01	\N	\N	5
395	5	42	17	2025-11-12 14:02:53.601+01	2025-11-12 14:02:53.601+01	\N	\N	5
396	10	42	17	2025-11-12 14:02:53.601+01	2025-11-12 14:02:53.601+01	\N	\N	5
397	15	42	17	2025-11-12 14:02:53.601+01	2025-11-12 14:02:53.601+01	\N	\N	5
398	14	42	17	2025-11-12 14:02:53.601+01	2025-11-12 14:02:53.601+01	\N	\N	5
399	22	42	17	2025-11-12 14:02:53.601+01	2025-11-12 14:02:53.601+01	\N	\N	5
400	27	42	17	2025-11-12 14:02:53.601+01	2025-11-12 14:02:53.601+01	\N	\N	5
\.


--
-- Data for Name: classes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.classes (id, name, registration_fee, bus_fee, internship_fee, remedial_fee, tuition_fee, pta_fee, total_fee, suspended, created_at, "createdAt", "updatedAt", class_master_id, department_id) FROM stdin;
9	CERTIFICATION LEVEL TWO HCE	0	0	0	0	100000	0	100000	f	2025-09-15 19:37:48.190125	2025-09-15 20:37:48.189+01	2025-10-29 13:27:26.889+01	26	6
19	ORIENTATION LEVEL B	0	0	0	0	100000	0	100000	f	2025-09-16 08:58:04.426404	2025-09-16 09:58:04.421+01	2025-10-29 16:49:16.867+01	18	1
7	CERTIFICATION LEVEL TWO CE	0	0	0	0	100000	0	100000	f	2025-09-15 19:34:38.329747	2025-09-15 20:34:38.327+01	2025-10-31 11:15:11.247+01	26	2
23	ATVEE COMM	0	0	0	0	123000	0	123000	f	2025-09-17 19:39:53.230141	2025-09-17 20:39:53.228+01	2025-10-31 11:17:09.832+01	9	8
13	ITVEE CJ	0	0	0	0	113000	0	113000	f	2025-09-16 05:33:12.168948	2025-09-16 06:33:12.168+01	2025-10-31 11:17:38.734+01	34	2
12	ITVEE BC	0	0	0	0	113000	0	113000	f	2025-09-16 05:31:45.385861	2025-09-16 06:31:45.384+01	2025-10-31 11:18:12.19+01	34	2
16	ITVEE EPS	0	0	0	0	113000	0	113000	f	2025-09-16 05:37:37.191921	2025-09-16 06:37:37.191+01	2025-10-31 11:18:30.803+01	34	3
15	ITVEE AMR	0	0	0	0	113000	0	113000	f	2025-09-16 05:36:36.549949	2025-09-16 06:36:36.549+01	2025-10-31 11:18:56.448+01	34	5
14	ITVEE SM	0	0	0	0	113000	0	113000	f	2025-09-16 05:35:53.17381	2025-09-16 06:35:53.173+01	2025-10-31 11:19:29.024+01	34	5
17	ITVEE HCE	0	0	0	0	113000	0	113000	f	2025-09-16 05:38:39.312968	2025-09-16 06:38:39.311+01	2025-10-31 11:19:50.457+01	34	6
18	ITVEE TE	0	0	0	0	113000	0	113000	f	2025-09-16 05:40:54.529929	2025-09-16 06:40:54.529+01	2025-10-31 11:20:11.577+01	34	4
22	ATVEE AMR	0	0	0	0	123000	0	123000	f	2025-09-17 19:14:37.463102	2025-09-17 20:14:37.462+01	2025-10-31 11:20:36.863+01	9	5
20	ATVEE BC	0	0	0	0	123000	0	123000	f	2025-09-17 19:12:24.684677	2025-09-17 20:12:24.677+01	2025-10-31 11:21:11.641+01	9	2
21	ATVEE EPS	0	0	0	0	123000	0	123000	f	2025-09-17 19:13:29.229301	2025-09-17 20:13:29.228+01	2025-10-31 11:21:34.798+01	9	3
25	DIPLOMA BC	0	0	0	0	150000	0	150000	f	2025-09-20 14:27:28.05084	2025-09-20 15:27:28.05+01	2025-09-20 15:27:28.05+01	9	2
26	DIPLOMA EPS	0	0	0	0	150000	0	150000	f	2025-09-20 14:29:35.287345	2025-09-20 15:29:35.284+01	2025-09-20 15:29:35.284+01	9	3
27	DIPLOMA AMR	0	0	0	0	150000	0	150000	f	2025-09-20 14:31:18.33218	2025-09-20 15:31:18.33+01	2025-09-20 15:31:18.33+01	9	5
24	DIPLOMA COMM	0	0	0	0	150000	0	150000	f	2025-09-20 14:24:04.685305	2025-09-20 15:24:04.682+01	2025-09-26 14:05:53.824+01	9	8
2	CERTIFICATION LEVEL ONE CE	0	0	0	0	100000	0	100000	f	2025-09-15 04:55:14.318502	2025-09-15 05:55:14.315+01	2025-10-28 16:54:34.708+01	17	2
8	CERTIFICATION LEVEL TWO EE	0	0	0	0	100000	0	100000	f	2025-09-15 19:35:59.452346	2025-09-15 20:35:59.451+01	2025-10-28 16:55:39.059+01	26	3
5	CERTIFICATION LEVEL ONE ME	0	0	0	0	100000	0	100000	f	2025-09-15 18:43:38.247935	2025-09-15 19:43:38.247+01	2025-10-28 17:01:26.433+01	17	5
6	CERTIFICATION LEVEL ONE TEX	0	0	0	0	100000	0	100000	f	2025-09-15 18:49:52.983919	2025-09-15 19:49:52.983+01	2025-10-28 17:01:54.511+01	17	4
4	CERTIFICATION LEVEL ONE HCE	0	0	0	0	100000	0	100000	f	2025-09-15 18:42:47.339789	2025-09-15 19:42:47.339+01	2025-10-29 13:21:32.293+01	17	6
3	CERTIFICATION LEVEL ONE EE	0	0	0	0	100000	0	100000	f	2025-09-15 18:40:49.49587	2025-09-15 19:40:49.493+01	2025-10-29 13:22:21.091+01	17	3
1	ORIENTATION LEVEL A	0	0	0	0	100000	0	100000	f	2025-09-13 22:11:38.697344	2025-09-13 23:11:38.692+01	2025-10-29 13:22:59.812+01	18	1
11	CERTIFICATION LEVEL TWO TE	0	0	0	0	100000	0	100000	f	2025-09-15 19:41:28.957039	2025-09-15 20:41:28.956+01	2025-10-29 13:23:45.382+01	26	4
10	CERTIFICATION LEVEL TWO ME	0	0	0	0	100000	0	100000	f	2025-09-15 19:39:21.047816	2025-09-15 20:39:21.045+01	2025-10-29 13:26:24.962+01	26	5
\.


--
-- Data for Name: cnps_preferences; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cnps_preferences (user_id, excluded, updated_at) FROM stdin;
2	f	2025-10-01 13:50:48.757846
6	t	2025-10-01 13:51:23.919618
25	t	2025-10-01 13:59:17.437848
14	t	2025-10-01 13:59:53.150019
36	t	2025-10-01 14:01:40.183761
9	t	2025-10-01 14:02:07.646747
22	t	2025-10-01 14:04:11.890675
35	t	2025-10-01 14:04:49.0097
24	t	2025-10-01 14:05:08.688344
20	t	2025-10-01 14:05:25.697915
26	t	2025-10-01 14:05:53.930724
13	t	2025-10-01 14:06:30.171668
18	t	2025-10-01 14:07:17.376842
12	t	2025-10-01 14:08:16.409882
33	t	2025-10-01 14:08:46.413439
19	t	2025-10-01 14:09:31.100094
7	t	2025-10-01 14:10:14.188586
3	t	2025-10-01 14:11:09.510233
10	t	2025-10-01 14:11:36.713043
23	t	2025-10-01 14:12:10.764163
4	t	2025-10-01 14:12:38.63761
17	t	2025-10-01 14:13:10.337428
34	t	2025-10-01 14:13:38.171235
15	t	2025-10-01 14:13:57.939483
38	t	2025-10-04 11:06:46.969515
37	t	2025-10-04 11:08:03.919866
\.


--
-- Data for Name: db_swap_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.db_swap_logs (id, mode, action, file_name, file_path, size_bytes, created_at, created_by) FROM stdin;
\.


--
-- Data for Name: departments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.departments (id, name, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: discipline_cases; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.discipline_cases (id, student_id, class_id, case_description, status, recorded_by, recorded_at, resolved_at, resolved_by, resolution_notes, teacher_id, case_type) FROM stdin;
1	167	12	He brought money to school and gave a classmate Samgeah Darlington to keep , then later on removed the money from the bad of the classmate without his notice , then came back later to ask for the money	not resolved	41	2025-10-22 07:59:45.250648	\N	\N	\N	\N	student
\.


--
-- Data for Name: events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.events (id, title, description, event_type, event_date, event_time, participants, created_by, created_at, updated_at) FROM stdin;
1	Submission of Notes	Submission of soft copies of notes for the month of October. Notes should be submitted via WhatsApp to various departmental heads.	Others	2025-09-24	07:30:00	ROSE, Brica, Chem, Steve, Collins , Mr Emile , Gebuin, Mj Mill, Mafain, Manka'a, Mbaliko, Ndicha , Nfor Vitalis , Mary, Vera, Rose, Ramadane, O'Neil	33	2025-09-15 21:40:48.172692	2025-09-15 21:43:38.230673
2	Understanding Proper Prompting and Lesson Plans Development	This webinar is aimed at educating teachers on proper prompting on digital platforms and the development of lesson plans.\nTime: 10:00am - 11:00am	Meeting	2025-09-29	10:00:00	ROSE, Abang, Brica, Chem, Steve, COLLINS, Mr Emile , Gebuin, Mj Mill, Mafain, Manka'a, Mbaliko, Ndicha , TheCareGiver, Nfebe1, Nfor Vitalis, Tina, Mary, Vera, Rose, Ramadane, O'Neil	33	2025-09-26 11:27:48.052874	2025-09-26 11:27:48.052874
3	Workshop (Webinar) On "Project-Based Learning"	Our partners at Teach Connect will be having a seminar (webinar) with the teaching staff on the topic, "Project-Based Learning". The aim of this workshop is to introduce educators to the core principles, benefits and structure of project-based learning. Everyone is hereby encouraged to attend.\n\nDate: Friday (10/10/2025)\nTime: 10:00am - 1:00pm\n\nThe Zoom link will be communicated in the WhatsApp forum subsequently.\n\nThanks.	Meeting	2025-10-10	10:00:00	ROSE, Abang, Admin2, Brica, Che, Chem, Steve, COLLINS, Mr Emile , Gebuin, Madeleine , Mj Mill, Mafain, Manka'a, Mbaliko, Ndicha , TheCareGiver, Nfebe1, Nfor Vitalis, Ngah , Tina, Mary, Vera, Rose, Ramadane, O'Neil	33	2025-10-04 11:38:23.306409	2025-10-04 11:38:23.306409
\.


--
-- Data for Name: fees; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fees (id, student_id, class_id, fee_type, amount, paid_at) FROM stdin;
1	1	1	Registration	20000	2025-09-16 11:38:14.353906
2	2	1	Registration	20000	2025-09-16 11:39:57.056501
4	3	1	Registration	20000	2025-09-16 11:55:20.070912
5	3	1	Tuition	60000	2025-09-16 11:55:53.04193
6	4	1	Registration	20000	2025-09-16 11:56:40.939363
7	5	1	Registration	20000	2025-09-16 11:57:23.75273
8	5	1	Tuition	25000	2025-09-16 11:57:50.09917
9	6	1	Registration	20000	2025-09-16 11:58:27.644546
10	7	1	Registration	20000	2025-09-16 11:59:38.421345
11	7	1	Tuition	30000	2025-09-16 12:00:10.380462
12	8	1	Registration	20000	2025-09-16 12:01:12.892553
13	9	1	Registration	20000	2025-09-16 12:01:50.383561
14	10	1	Registration	20000	2025-09-16 12:02:36.300346
15	11	1	Registration	20000	2025-09-16 12:03:08.269258
16	11	1	Tuition	60000	2025-09-16 12:03:43.296373
22	2	1	Tuition	40000	2025-09-16 12:11:46.635277
23	12	1	Registration	20000	2025-09-16 12:23:17.933689
27	12	1	Tuition	30000	2025-09-16 12:32:25.561668
28	13	1	Registration	20000	2025-09-16 12:35:09.236635
29	14	1	Registration	20000	2025-09-16 12:37:04.039503
30	15	1	Registration	20000	2025-09-16 12:41:22.260722
31	16	1	Registration	20000	2025-09-16 12:48:31.359605
32	16	1	Tuition	30000	2025-09-16 12:49:13.79696
33	17	1	Registration	20000	2025-09-16 12:49:48.966672
34	17	1	Tuition	60000	2025-09-16 12:50:34.974602
35	18	1	Registration	20000	2025-09-16 12:51:45.3381
36	19	1	Registration	20000	2025-09-16 12:54:48.856536
37	19	1	Tuition	30000	2025-09-16 12:55:42.990028
38	20	1	Registration	20000	2025-09-16 12:56:57.569341
39	20	1	Tuition	60000	2025-09-16 12:57:41.579542
40	21	1	Registration	20000	2025-09-16 12:58:36.620685
41	23	1	Registration	20000	2025-09-16 13:00:13.242342
42	22	1	Registration	20000	2025-09-16 13:01:20.521347
43	22	1	Tuition	40000	2025-09-16 13:02:19.080346
44	24	1	Registration	20000	2025-09-16 13:03:00.620346
45	24	1	Tuition	80000	2025-09-16 13:03:46.53969
46	25	1	Registration	20000	2025-09-16 13:04:31.707618
47	25	1	Tuition	40000	2025-09-16 13:05:18.236508
48	26	1	Registration	20000	2025-09-16 15:00:04.820892
49	26	1	Tuition	30000	2025-09-16 15:01:02.870981
50	27	1	Registration	10000	2025-09-16 15:02:11.177347
51	28	1	Registration	10000	2025-09-16 15:03:58.981156
52	29	1	Registration	10000	2025-09-16 15:05:02.77139
53	30	1	Registration	20000	2025-09-16 15:08:49.273529
54	30	1	Tuition	20000	2025-09-16 15:09:51.795745
55	32	1	Registration	20000	2025-09-16 15:11:44.225057
56	32	1	Tuition	40000	2025-09-16 15:12:40.085117
57	33	1	Registration	20000	2025-09-16 15:14:19.530452
58	33	1	Tuition	60000	2025-09-16 15:15:35.488211
59	35	1	Registration	20000	2025-09-16 15:16:46.317719
60	34	1	Registration	20000	2025-09-16 15:17:59.309645
61	31	1	Registration	20000	2025-09-16 15:20:58.259349
62	37	1	Registration	20000	2025-09-16 15:22:59.831836
63	37	1	Tuition	30000	2025-09-16 15:24:09.958388
66	36	1	Registration	20000	2025-09-16 21:04:49.221873
67	36	1	Tuition	30000	2025-09-16 21:05:26.55268
68	50	1	Registration	20000	2025-09-16 21:06:10.962677
69	51	1	Registration	20000	2025-09-16 21:06:53.589533
70	43	1	Registration	20000	2025-09-16 21:07:40.766786
71	43	1	Tuition	40000	2025-09-16 21:08:21.600172
72	42	1	Registration	20000	2025-09-16 21:09:00.575765
73	42	1	Tuition	40000	2025-09-16 21:09:45.51956
74	41	1	Registration	20000	2025-09-16 21:10:30.377341
75	41	1	Tuition	40000	2025-09-16 21:11:02.85768
76	44	1	Registration	20000	2025-09-16 21:12:06.223582
77	40	1	Registration	20000	2025-09-16 21:12:57.836509
78	40	1	Tuition	40000	2025-09-16 21:13:32.749354
79	38	1	Registration	20000	2025-09-16 21:14:36.042645
80	39	1	Registration	20000	2025-09-16 21:15:07.341562
81	45	1	Registration	20000	2025-09-16 21:15:51.968571
83	46	1	Registration	20000	2025-09-16 21:17:14.453119
84	46	1	Tuition	30000	2025-09-16 21:18:00.938606
85	48	1	Registration	20000	2025-09-16 21:18:30.415729
86	48	1	Tuition	30000	2025-09-16 21:19:02.060034
87	47	1	Registration	20000	2025-09-16 21:19:58.384482
88	47	1	Tuition	20000	2025-09-16 21:20:33.199424
89	49	1	Registration	20000	2025-09-16 21:21:26.035503
90	49	1	Tuition	30000	2025-09-16 21:21:54.03694
91	53	1	Registration	20000	2025-09-16 21:22:53.903993
92	53	1	Tuition	40000	2025-09-16 21:23:34.593347
93	54	1	Registration	20000	2025-09-16 21:24:09.803348
94	54	1	Tuition	80000	2025-09-16 21:24:33.632474
95	55	1	Registration	20000	2025-09-16 21:25:04.201613
96	55	1	Tuition	50000	2025-09-16 21:25:31.072157
97	56	1	Registration	20000	2025-09-16 21:26:05.992674
98	56	1	Tuition	30000	2025-09-16 21:26:30.474594
99	57	1	Registration	20000	2025-09-16 21:27:06.715349
100	58	1	Registration	20000	2025-09-16 21:27:45.272698
101	59	1	Registration	20000	2025-09-16 21:28:19.924729
102	59	1	Tuition	10000	2025-09-16 21:28:59.098445
103	60	1	Registration	20000	2025-09-16 21:29:33.254346
104	60	1	Tuition	50000	2025-09-16 21:29:59.881917
105	61	1	Registration	20000	2025-09-16 21:30:38.342569
106	62	1	Registration	20000	2025-09-16 21:31:14.824163
107	62	1	Tuition	30000	2025-09-16 21:31:44.969774
108	52	1	Registration	20000	2025-09-16 21:32:18.218678
109	52	1	Tuition	30000	2025-09-16 21:32:45.562346
110	63	2	Registration	20000	2025-09-20 11:46:06.710645
111	63	2	Tuition	20000	2025-09-20 11:47:32.270558
112	64	2	Registration	20000	2025-09-20 11:49:27.212352
113	64	2	Tuition	40000	2025-09-20 11:54:15.09954
114	65	2	Registration	20000	2025-09-20 11:55:03.782636
115	65	2	Tuition	30000	2025-09-20 11:55:37.147663
116	66	2	Registration	20000	2025-09-20 11:56:06.908697
117	66	2	Tuition	20000	2025-09-20 11:56:36.990556
118	67	2	Registration	20000	2025-09-20 11:57:04.197898
119	67	2	Tuition	40000	2025-09-20 11:57:34.908538
120	68	2	Registration	20000	2025-09-20 11:58:03.443741
121	68	2	Tuition	30000	2025-09-20 11:58:33.876813
122	69	5	Registration	20000	2025-09-20 11:59:04.287435
123	69	5	Tuition	30000	2025-09-20 11:59:39.010386
124	70	5	Registration	20000	2025-09-20 12:00:21.629652
126	70	5	Tuition	20000	2025-09-20 12:03:29.200049
127	71	3	Registration	20000	2025-09-20 12:04:13.905579
128	71	3	Tuition	40000	2025-09-20 12:04:46.736496
129	72	3	Registration	20000	2025-09-20 12:05:14.234645
130	73	3	Registration	20000	2025-09-20 12:05:52.369696
131	73	3	Tuition	40000	2025-09-20 12:06:20.631717
132	75	3	Registration	20000	2025-09-20 12:06:49.331428
133	74	3	Registration	20000	2025-09-20 12:07:22.129522
134	74	3	Tuition	40000	2025-09-20 12:08:00.494064
135	76	4	Registration	20000	2025-09-20 12:08:32.56866
136	76	4	Tuition	20000	2025-09-20 12:09:07.665668
137	77	6	Registration	20000	2025-09-20 12:09:45.203349
138	78	6	Registration	20000	2025-09-20 12:10:12.98335
139	78	6	Tuition	60000	2025-09-20 12:11:06.804756
140	79	7	Registration	20000	2025-09-20 12:11:42.738404
141	79	7	Tuition	60000	2025-09-20 12:12:23.517344
142	82	7	Registration	20000	2025-09-20 12:15:50.962953
143	82	7	Tuition	30000	2025-09-20 12:16:28.656297
144	80	7	Registration	20000	2025-09-20 12:17:08.596349
145	81	7	Registration	20000	2025-09-20 12:17:44.148908
146	81	7	Tuition	40000	2025-09-20 12:18:30.002981
147	84	12	Registration	23000	2025-09-20 12:20:25.524341
148	84	12	Tuition	27000	2025-09-20 12:22:22.920627
149	85	12	Registration	23000	2025-09-20 12:23:15.214301
150	85	12	Tuition	17000	2025-09-20 12:24:04.946827
151	86	12	Registration	23000	2025-09-20 12:26:45.744682
152	86	12	Tuition	7000	2025-09-20 12:27:32.877212
153	87	12	Registration	23000	2025-09-20 12:28:08.013406
154	88	12	Registration	23000	2025-09-20 12:28:39.215311
155	88	12	Tuition	27000	2025-09-20 12:29:23.375683
156	83	12	Registration	23000	2025-09-20 12:30:40.784854
157	83	12	Tuition	45000	2025-09-20 12:31:17.135407
158	90	12	Registration	23000	2025-09-20 12:32:28.495685
159	90	12	Tuition	47000	2025-09-20 12:33:25.39154
160	91	16	Registration	23000	2025-09-20 12:34:32.274678
161	91	16	Tuition	90000	2025-09-20 12:35:21.680273
162	92	16	Registration	23000	2025-09-20 12:36:22.030609
163	92	16	Tuition	27000	2025-09-20 12:37:00.111621
164	93	16	Registration	23000	2025-09-20 12:37:42.029939
165	93	16	Tuition	7000	2025-09-20 12:38:38.768598
166	95	15	Registration	23000	2025-09-20 12:48:43.695895
168	95	15	Tuition	2000	2025-09-20 12:51:04.81265
169	96	15	Registration	23000	2025-09-20 12:51:29.520612
170	97	15	Registration	23000	2025-09-20 12:52:20.838717
171	97	15	Tuition	47000	2025-09-20 12:52:58.957476
172	99	17	Registration	23000	2025-09-20 12:55:56.180354
173	99	17	Tuition	27000	2025-09-20 12:56:36.971187
174	100	17	Registration	23000	2025-09-20 12:57:11.535429
176	98	18	Registration	23000	2025-09-20 12:58:25.35721
177	107	16	Registration	23000	2025-09-24 18:42:14.35483
178	102	25	Tuition	100000	2025-09-26 07:17:25.735058
179	106	20	Registration	23000	2025-09-26 07:28:32.554479
180	106	20	Tuition	30000	2025-09-26 07:29:25.172223
181	105	23	Registration	23000	2025-09-26 13:07:37.859542
182	104	25	Tuition	50000	2025-09-26 13:09:37.613343
183	103	27	Tuition	50000	2025-09-26 13:12:35.361991
184	101	24	Tuition	50000	2025-09-26 13:13:52.768437
185	94	26	Tuition	50000	2025-09-26 13:15:02.453043
186	89	12	Registration	23000	2025-09-27 06:56:18.977446
187	89	12	Tuition	37000	2025-09-27 06:57:58.233846
188	109	19	Registration	20000	2025-10-20 15:51:11.611209
189	109	19	Tuition	30000	2025-10-20 15:53:17.574344
190	1	1	Tuition	100000	2025-10-31 10:28:49.23613
191	53	1	Tuition	20000	2025-10-31 10:30:40.784579
192	2	1	Tuition	20000	2025-10-31 10:31:48.52126
193	54	1	Tuition	20000	2025-10-31 10:32:34.343486
194	55	1	Tuition	20000	2025-10-31 10:33:10.765875
195	3	1	Tuition	20000	2025-10-31 10:33:39.304411
196	191	19	Tuition	80000	2025-10-31 10:35:07.844976
197	5	5	Tuition	20000	2025-10-31 10:36:52.612716
198	6	1	Tuition	20000	2025-10-31 10:37:38.208344
199	56	1	Tuition	20000	2025-10-31 10:38:06.72255
200	7	1	Tuition	20000	2025-10-31 10:38:33.164134
201	8	1	Tuition	80000	2025-10-31 10:41:17.095563
203	9	1	Tuition	20000	2025-10-31 10:44:40.240349
204	10	1	Tuition	20000	2025-10-31 10:46:30.076628
205	11	1	Tuition	20000	2025-10-31 10:51:27.744943
206	12	1	Tuition	20000	2025-10-31 10:51:55.653006
207	13	1	Tuition	20000	2025-10-31 10:52:21.566574
208	58	1	Tuition	20000	2025-10-31 10:52:57.249298
209	59	1	Tuition	20000	2025-10-31 10:53:17.505042
210	14	1	Tuition	20000	2025-10-31 10:53:49.236629
211	60	1	Tuition	20000	2025-10-31 10:54:14.656817
212	15	1	Tuition	20000	2025-10-31 10:54:38.150514
213	61	1	Tuition	20000	2025-10-31 10:55:12.07497
214	16	1	Tuition	20000	2025-10-31 10:55:48.695063
215	17	1	Tuition	20000	2025-10-31 10:56:34.913931
216	62	1	Tuition	20000	2025-10-31 10:57:04.207527
217	18	1	Tuition	20000	2025-10-31 10:57:33.926932
218	19	1	Tuition	20000	2025-10-31 10:58:04.793426
219	20	1	Tuition	20000	2025-10-31 10:58:30.502998
220	21	1	Tuition	20000	2025-10-31 10:58:57.59446
221	52	1	Tuition	20000	2025-10-31 10:59:29.417485
222	23	1	Tuition	20000	2025-10-31 11:15:49.718885
223	22	1	Tuition	20000	2025-10-31 11:16:25.453163
224	24	1	Tuition	20000	2025-10-31 11:16:55.560349
225	25	1	Tuition	20000	2025-10-31 11:17:27.590556
226	26	1	Tuition	20000	2025-10-31 11:17:54.889152
227	27	1	Tuition	10000	2025-10-31 11:18:24.613039
228	29	1	Tuition	10000	2025-10-31 11:18:51.173126
229	28	1	Tuition	10000	2025-10-31 11:19:42.054131
230	30	1	Tuition	20000	2025-10-31 11:20:15.206637
231	32	1	Tuition	20000	2025-10-31 11:20:57.128181
232	33	1	Tuition	20000	2025-10-31 11:21:27.716945
233	35	1	Tuition	20000	2025-10-31 11:21:48.806017
234	34	1	Tuition	20000	2025-10-31 11:22:12.614725
235	37	1	Tuition	20000	2025-10-31 11:23:35.973342
236	377	1	Tuition	20000	2025-10-31 11:25:44.994341
237	36	1	Tuition	20000	2025-10-31 11:26:16.776144
238	50	1	Tuition	20000	2025-10-31 11:26:55.483883
239	51	1	Tuition	20000	2025-10-31 11:27:22.46857
240	43	1	Tuition	20000	2025-10-31 11:28:00.257996
241	42	1	Tuition	20000	2025-10-31 11:28:24.66996
242	41	1	Tuition	20000	2025-10-31 11:28:52.606681
243	44	1	Tuition	20000	2025-10-31 11:29:27.514643
244	40	1	Tuition	20000	2025-10-31 11:29:53.596094
245	38	1	Tuition	20000	2025-10-31 11:30:25.316204
247	46	1	Tuition	20000	2025-10-31 11:32:43.736076
248	48	1	Tuition	20000	2025-10-31 11:33:15.740275
249	47	1	Tuition	20000	2025-10-31 11:33:50.255664
250	49	1	Tuition	20000	2025-10-31 11:34:22.812629
251	109	19	Tuition	20000	2025-10-31 11:34:51.715606
252	108	1	Tuition	40000	2025-10-31 11:38:06.686342
253	111	19	Tuition	60000	2025-10-31 11:40:29.476483
254	110	19	Tuition	50000	2025-10-31 11:41:09.695552
255	113	19	Tuition	50000	2025-10-31 11:41:38.429186
256	117	19	Tuition	35000	2025-10-31 11:42:01.951417
257	114	19	Tuition	55000	2025-10-31 11:42:31.138762
258	115	19	Tuition	20000	2025-10-31 11:43:02.712739
259	116	19	Tuition	20000	2025-10-31 11:43:17.788003
260	118	19	Tuition	60000	2025-10-31 11:43:42.423075
261	119	19	Tuition	50000	2025-10-31 11:45:33.093353
262	125	19	Tuition	100000	2025-10-31 11:47:22.71154
263	123	19	Tuition	20000	2025-10-31 11:50:20.519431
264	122	5	Tuition	50000	2025-10-31 11:50:45.208489
265	121	19	Tuition	50000	2025-10-31 11:51:25.014608
266	126	19	Tuition	60000	2025-10-31 11:51:45.560218
267	127	19	Tuition	20000	2025-10-31 11:52:16.693872
268	128	19	Tuition	20000	2025-10-31 11:52:47.23841
269	131	19	Tuition	90000	2025-10-31 11:55:48.18217
270	182	19	Tuition	50000	2025-10-31 12:00:27.797523
271	184	19	Tuition	30000	2025-10-31 12:00:53.616338
272	183	19	Tuition	60000	2025-10-31 12:01:33.632676
273	189	19	Tuition	60000	2025-10-31 12:02:03.711258
274	188	19	Tuition	50000	2025-10-31 12:02:41.872668
275	187	19	Tuition	20000	2025-10-31 12:03:05.376151
276	186	19	Tuition	60000	2025-10-31 12:03:58.690549
277	181	19	Tuition	30000	2025-10-31 12:58:11.203353
278	272	19	Tuition	30000	2025-10-31 12:58:44.960108
279	273	19	Tuition	30000	2025-10-31 13:02:26.365346
280	210	19	Tuition	40000	2025-10-31 13:03:05.877492
281	229	19	Tuition	50000	2025-10-31 13:03:40.915133
282	241	19	Tuition	40000	2025-10-31 13:04:03.895535
283	239	19	Tuition	40000	2025-10-31 13:04:29.65106
284	236	19	Tuition	30000	2025-10-31 13:05:14.353606
285	238	19	Tuition	30000	2025-10-31 13:05:26.567351
286	240	19	Tuition	50000	2025-10-31 13:05:58.05845
287	112	19	Tuition	60000	2025-10-31 13:06:26.487495
288	235	19	Tuition	50000	2025-10-31 13:06:54.127076
289	232	19	Tuition	40000	2025-10-31 13:07:18.323603
290	233	19	Tuition	30000	2025-10-31 13:07:46.888344
291	234	19	Tuition	50000	2025-10-31 13:08:06.033069
293	250	19	Tuition	45000	2025-10-31 13:08:48.105658
294	257	19	Tuition	50000	2025-10-31 13:09:11.785344
295	291	19	Tuition	35000	2025-10-31 13:10:01.626559
296	274	19	Tuition	40000	2025-10-31 13:10:28.683935
297	289	19	Tuition	60000	2025-10-31 13:11:05.220817
298	290	19	Tuition	60000	2025-10-31 13:11:28.969729
299	287	19	Tuition	60000	2025-10-31 13:13:20.790681
300	288	19	Tuition	60000	2025-10-31 13:16:28.104106
301	286	19	Tuition	60000	2025-10-31 13:16:51.811343
302	275	19	Tuition	40000	2025-10-31 13:17:13.999296
303	285	19	Tuition	20000	2025-10-31 13:17:36.873
304	284	19	Tuition	20000	2025-10-31 13:18:01.611238
305	283	19	Tuition	80000	2025-10-31 13:18:21.802556
306	282	19	Tuition	20000	2025-10-31 13:19:03.585449
307	281	19	Tuition	20000	2025-10-31 13:19:26.80523
308	280	19	Tuition	20000	2025-10-31 13:20:00.170477
309	279	19	Tuition	20000	2025-10-31 13:20:55.08254
310	278	19	Tuition	50000	2025-10-31 13:21:41.641254
311	277	19	Tuition	40000	2025-10-31 13:22:13.312979
312	276	19	Tuition	60000	2025-10-31 13:22:45.896018
313	292	19	Tuition	20000	2025-10-31 13:23:24.457609
314	295	19	Tuition	30000	2025-10-31 13:23:47.529035
315	296	19	Tuition	43000	2025-10-31 13:24:11.242652
316	296	19	Tuition	43000	2025-10-31 13:24:11.849648
317	297	19	Tuition	25000	2025-10-31 13:24:41.805756
318	298	19	Tuition	60000	2025-10-31 13:25:32.396691
319	299	19	Tuition	20000	2025-10-31 13:25:56.810841
320	300	19	Tuition	20000	2025-10-31 13:26:31.093572
321	300	19	Tuition	20000	2025-10-31 13:26:34.030566
323	301	19	Tuition	25000	2025-10-31 13:28:59.791937
324	302	19	Tuition	20000	2025-10-31 13:29:34.583556
325	303	19	Tuition	25000	2025-10-31 13:29:56.223523
326	305	19	Tuition	5000	2025-10-31 13:30:22.704367
327	293	19	Tuition	20000	2025-10-31 13:30:46.800544
328	304	19	Tuition	5000	2025-10-31 13:31:51.568346
329	294	19	Tuition	20000	2025-10-31 13:32:13.037504
330	310	19	Tuition	40000	2025-10-31 13:32:33.029581
331	4	1	Tuition	80000	2025-10-31 13:36:50.41135
332	45	1	Tuition	50000	2025-10-31 13:37:45.263295
333	139	19	Tuition	70000	2025-10-31 13:44:23.006356
334	124	19	Tuition	60000	2025-10-31 13:44:45.616644
335	63	2	Tuition	20000	2025-10-31 13:52:58.534459
336	64	2	Tuition	20000	2025-10-31 13:53:42.398183
337	65	2	Tuition	20000	2025-10-31 13:54:08.316497
338	66	2	Tuition	50000	2025-10-31 13:54:51.887342
339	67	2	Tuition	20000	2025-10-31 13:55:24.673718
340	68	2	Tuition	20000	2025-10-31 13:55:45.89015
341	132	2	Tuition	35000	2025-10-31 13:56:28.926233
342	144	2	Tuition	30000	2025-10-31 13:57:03.544929
343	133	2	Tuition	20000	2025-10-31 13:57:25.14517
344	195	2	Tuition	60000	2025-10-31 13:57:50.776703
345	194	2	Tuition	80000	2025-10-31 13:58:10.095842
346	206	6	Tuition	20000	2025-10-31 13:58:35.064345
347	311	2	Tuition	20000	2025-10-31 13:58:56.175824
348	196	2	Tuition	20000	2025-10-31 13:59:23.927583
349	197	2	Tuition	20000	2025-10-31 13:59:45.474619
350	312	2	Tuition	20000	2025-10-31 14:00:20.120599
351	69	5	Tuition	20000	2025-10-31 14:11:29.402344
352	70	5	Tuition	20000	2025-10-31 14:11:52.313485
353	140	5	Tuition	20000	2025-10-31 14:12:17.820718
354	134	5	Tuition	40000	2025-10-31 14:12:50.810569
355	135	5	Tuition	50000	2025-10-31 14:18:11.646242
356	136	5	Tuition	50000	2025-10-31 14:19:05.592901
357	328	5	Tuition	25000	2025-10-31 14:19:30.04972
358	198	5	Tuition	50000	2025-10-31 14:21:42.152658
359	199	5	Tuition	40000	2025-10-31 14:22:06.227779
360	227	5	Tuition	30000	2025-10-31 14:22:29.40151
361	211	5	Tuition	20000	2025-10-31 14:22:53.467121
362	260	2	Tuition	20000	2025-10-31 14:23:10.211817
363	251	5	Tuition	45000	2025-10-31 14:23:31.072434
364	262	5	Tuition	20000	2025-10-31 14:23:49.596688
365	261	5	Tuition	20000	2025-10-31 14:24:40.242947
366	31	5	Tuition	40000	2025-10-31 14:25:10.616453
367	265	5	Tuition	20000	2025-10-31 14:25:29.948508
368	263	5	Tuition	30000	2025-10-31 14:25:53.1677
369	264	5	Tuition	40000	2025-10-31 14:26:09.986308
370	266	5	Tuition	50000	2025-10-31 14:26:28.665583
371	314	5	Tuition	50000	2025-10-31 14:26:48.320352
372	313	5	Tuition	20000	2025-10-31 14:28:00.027564
373	71	3	Tuition	20000	2025-10-31 14:28:51.22934
374	72	3	Tuition	20000	2025-10-31 14:29:08.215209
375	73	3	Tuition	20000	2025-10-31 14:29:27.259564
376	75	3	Tuition	20000	2025-10-31 14:29:51.011575
377	74	3	Tuition	20000	2025-10-31 14:30:08.410262
378	141	3	Tuition	20000	2025-10-31 14:30:32.861717
379	142	3	Tuition	50000	2025-10-31 14:30:52.895086
380	200	3	Tuition	50000	2025-10-31 14:31:09.786058
381	267	3	Tuition	45000	2025-10-31 14:31:35.801257
382	200	3	Tuition	10000	2025-10-31 14:32:00.184777
383	268	3	Tuition	87000	2025-10-31 14:32:47.385609
384	269	3	Tuition	20000	2025-10-31 14:33:06.467446
385	270	3	Tuition	50000	2025-10-31 14:34:28.2317
386	259	3	Tuition	30000	2025-10-31 14:34:51.9623
387	76	4	Tuition	20000	2025-10-31 14:59:21.925966
388	146	4	Tuition	20000	2025-10-31 14:59:40.35292
389	145	4	Tuition	50000	2025-10-31 15:00:07.236401
390	147	4	Tuition	25000	2025-10-31 15:00:40.295828
391	148	4	Tuition	20000	2025-10-31 15:01:32.021472
392	202	4	Tuition	20000	2025-10-31 15:01:54.774595
393	315	4	Tuition	15000	2025-10-31 15:02:17.20677
394	322	4	Tuition	20000	2025-10-31 15:02:41.98856
395	321	4	Tuition	20000	2025-10-31 15:03:25.015364
396	249	4	Tuition	20000	2025-10-31 15:03:53.61162
397	323	4	Tuition	30000	2025-10-31 15:04:33.734629
398	326	4	Tuition	30000	2025-10-31 15:05:07.049157
399	324	4	Tuition	50000	2025-10-31 15:05:57.74281
400	327	4	Tuition	20000	2025-10-31 15:06:38.442877
401	77	6	Tuition	20000	2025-10-31 15:11:45.702439
402	78	6	Tuition	20000	2025-10-31 15:12:16.377621
403	149	6	Tuition	50000	2025-10-31 15:12:55.948343
404	329	6	Tuition	100000	2025-10-31 15:13:15.398039
405	151	6	Tuition	50000	2025-10-31 15:13:41.66906
406	204	6	Tuition	50000	2025-10-31 15:14:08.378176
407	203	6	Tuition	60000	2025-10-31 15:14:50.916156
408	331	6	Tuition	50000	2025-10-31 15:15:22.946357
409	254	6	Tuition	20000	2025-10-31 15:16:02.150823
410	332	6	Tuition	20000	2025-10-31 15:16:23.086275
411	335	6	Tuition	30000	2025-10-31 15:16:44.940783
412	336	6	Tuition	30000	2025-10-31 15:17:13.254757
413	206	6	Tuition	20000	2025-10-31 15:17:44.394548
414	333	6	Tuition	50000	2025-10-31 15:18:40.330673
415	337	6	Tuition	20000	2025-10-31 15:19:09.416515
416	334	6	Tuition	20000	2025-10-31 15:19:29.99077
417	258	6	Tuition	80000	2025-10-31 15:19:52.585752
418	338	6	Tuition	50000	2025-10-31 15:20:14.129461
419	79	7	Tuition	20000	2025-10-31 15:31:05.480501
420	82	7	Tuition	20000	2025-10-31 15:33:11.744807
421	153	7	Tuition	20000	2025-10-31 15:33:52.829344
422	154	7	Tuition	20000	2025-10-31 15:34:14.991044
423	155	7	Tuition	20000	2025-10-31 15:34:39.044628
424	207	7	Tuition	30000	2025-10-31 15:35:08.912486
425	209	7	Tuition	30000	2025-10-31 15:35:29.767073
426	208	7	Tuition	100000	2025-10-31 15:35:58.468613
427	341	7	Tuition	20000	2025-10-31 15:38:21.205223
428	342	7	Tuition	60000	2025-10-31 15:38:44.470838
429	343	7	Tuition	40000	2025-10-31 15:39:04.868095
430	344	7	Tuition	20000	2025-10-31 15:39:34.451811
431	345	7	Tuition	40000	2025-10-31 15:40:02.965344
432	157	10	Tuition	60000	2025-10-31 15:40:39.876557
433	158	10	Tuition	30000	2025-10-31 15:43:09.755561
434	159	10	Tuition	90000	2025-10-31 15:44:20.055762
435	346	10	Tuition	55000	2025-10-31 15:44:48.393671
438	347	10	Tuition	30000	2025-10-31 15:45:48.32235
439	348	10	Tuition	50000	2025-10-31 15:46:39.138349
440	349	10	Tuition	40000	2025-10-31 15:47:11.219873
441	339	8	Tuition	50000	2025-10-31 15:52:16.81834
442	81	7	Tuition	20000	2025-10-31 15:53:28.457515
443	160	8	Tuition	50000	2025-10-31 15:53:49.167796
444	161	8	Tuition	50000	2025-10-31 15:54:24.273995
445	162	8	Tuition	60000	2025-10-31 15:54:43.902975
446	214	8	Tuition	60000	2025-10-31 15:55:24.304416
447	213	8	Tuition	20000	2025-10-31 15:55:51.736994
448	212	8	Tuition	90000	2025-10-31 15:56:16.384068
449	201	3	Tuition	100000	2025-10-31 15:56:35.692537
450	351	8	Tuition	50000	2025-10-31 15:56:59.760148
453	350	8	Tuition	20000	2025-10-31 15:57:54.141642
454	352	8	Tuition	70000	2025-10-31 15:58:13.13812
455	353	8	Tuition	10000	2025-10-31 15:59:03.695277
456	163	9	Tuition	50000	2025-10-31 16:02:27.797339
457	355	9	Tuition	50000	2025-10-31 16:02:54.283587
458	152	11	Tuition	80000	2025-10-31 16:03:50.127414
459	215	11	Tuition	40000	2025-10-31 16:04:16.377642
460	356	11	Tuition	30000	2025-10-31 16:04:55.896508
461	357	12	Tuition	50000	2025-10-31 16:18:32.787443
462	85	12	Tuition	63000	2025-10-31 16:19:18.893196
463	86	12	Tuition	23000	2025-10-31 16:20:29.090342
464	87	12	Tuition	63000	2025-10-31 16:21:09.889287
465	88	12	Tuition	23000	2025-10-31 16:21:36.157302
466	83	12	Tuition	23000	2025-10-31 16:22:06.686422
467	90	12	Tuition	23000	2025-10-31 16:22:29.974534
468	89	12	Tuition	23000	2025-10-31 16:22:56.125654
469	164	12	Tuition	50000	2025-10-31 16:23:27.693053
470	358	12	Tuition	25000	2025-10-31 16:24:02.131555
471	165	12	Tuition	80000	2025-10-31 16:24:27.970735
472	217	12	Tuition	30000	2025-10-31 16:25:04.276594
473	168	12	Tuition	80000	2025-10-31 16:25:35.808822
474	237	12	Tuition	40000	2025-10-31 16:25:58.606621
475	245	12	Tuition	23000	2025-10-31 16:26:19.483988
476	360	12	Tuition	30000	2025-10-31 16:27:07.886645
477	362	12	Tuition	100000	2025-10-31 16:27:44.845418
478	363	12	Tuition	113000	2025-10-31 16:28:19.115604
479	366	12	Tuition	70000	2025-10-31 16:28:46.533772
480	365	12	Tuition	60000	2025-10-31 16:29:10.116506
481	367	12	Tuition	30000	2025-10-31 16:29:53.541565
482	369	12	Tuition	25000	2025-10-31 16:30:10.733693
483	368	12	Tuition	23000	2025-10-31 16:30:34.398935
484	359	12	Tuition	23000	2025-10-31 16:33:58.884046
485	219	13	Tuition	40000	2025-10-31 18:18:57.20224
486	370	13	Tuition	70000	2025-10-31 18:19:33.200473
487	91	16	Tuition	23000	2025-10-31 18:20:18.435434
488	92	16	Tuition	73000	2025-10-31 18:20:54.61793
489	107	16	Tuition	23000	2025-10-31 18:21:48.906541
490	93	16	Tuition	23000	2025-10-31 18:22:24.158316
491	171	16	Tuition	23000	2025-10-31 18:24:35.860524
492	169	16	Tuition	40000	2025-10-31 18:25:10.01258
493	371	16	Tuition	50000	2025-10-31 18:25:49.874503
494	372	16	Tuition	23000	2025-10-31 18:26:23.665191
495	220	16	Tuition	25000	2025-10-31 18:26:50.379585
496	222	16	Tuition	50000	2025-10-31 18:27:25.256625
497	221	16	Tuition	50000	2025-10-31 18:27:57.098281
498	375	16	Tuition	20000	2025-10-31 18:28:25.27699
499	376	16	Tuition	30000	2025-10-31 18:29:01.826885
500	138	15	Tuition	10000	2025-10-31 18:31:47.849675
501	383	16	Tuition	45000	2025-10-31 18:32:47.524266
502	384	16	Tuition	23000	2025-10-31 18:33:35.967436
503	95	15	Tuition	23000	2025-10-31 18:38:09.054612
504	96	15	Tuition	23000	2025-10-31 18:38:27.974532
505	97	15	Tuition	23000	2025-10-31 18:39:05.429345
506	173	15	Tuition	60000	2025-10-31 18:40:58.954817
507	174	15	Tuition	30000	2025-10-31 18:41:36.555721
508	223	22	Tuition	50000	2025-10-31 18:43:04.392647
509	224	15	Tuition	60000	2025-10-31 18:43:32.433174
510	256	15	Tuition	23000	2025-10-31 18:43:59.697049
511	175	14	Tuition	110000	2025-10-31 18:47:23.940062
512	106	20	Tuition	23000	2025-10-31 18:48:23.920366
513	180	20	Tuition	100000	2025-10-31 18:48:54.501739
514	179	25	Tuition	20000	2025-10-31 18:49:20.456063
515	361	20	Tuition	100000	2025-10-31 18:50:02.818926
516	99	17	Tuition	23000	2025-10-31 18:51:03.605248
519	100	17	Tuition	30000	2025-10-31 18:52:13.708619
520	178	17	Tuition	83000	2025-10-31 18:52:44.884354
521	98	18	Tuition	23000	2025-10-31 18:54:10.123836
522	177	18	Tuition	23000	2025-10-31 18:54:30.23034
523	176	18	Tuition	23000	2025-10-31 18:54:56.65976
524	225	18	Tuition	23000	2025-10-31 18:55:18.345494
525	105	23	Tuition	73000	2025-10-31 18:57:15.174668
526	226	23	Tuition	23000	2025-10-31 18:57:44.586562
527	247	25	Tuition	70000	2025-10-31 19:06:06.873337
528	248	25	Tuition	40000	2025-10-31 19:07:21.43633
529	271	3	Tuition	50000	2025-10-31 19:08:48.884617
530	381	16	Tuition	10000	2025-10-31 19:15:09.779684
531	379	7	Tuition	70000	2025-10-31 19:17:36.229522
532	382	16	Tuition	30000	2025-10-31 19:20:42.517264
533	378	8	Tuition	50000	2025-10-31 19:22:36.706433
534	354	6	Tuition	80000	2025-10-31 19:23:06.948839
535	380	5	Tuition	60000	2025-10-31 19:23:47.361884
536	36	1	Tuition	30000	2025-11-05 13:13:57.150706
537	410	19	Tuition	30000	2025-11-05 13:43:30.817645
538	409	19	Tuition	30000	2025-11-05 13:44:03.53413
539	398	2	Tuition	20000	2025-11-05 13:45:05.155546
542	390	2	Tuition	30000	2025-11-05 13:45:49.455552
543	389	2	Tuition	50000	2025-11-05 13:46:08.742845
544	397	2	Tuition	20000	2025-11-05 13:46:31.947548
545	395	2	Tuition	20000	2025-11-05 13:47:21.915533
546	395	2	Tuition	20000	2025-11-05 13:47:22.114945
547	394	2	Tuition	20000	2025-11-05 13:47:51.496292
548	393	2	Tuition	50000	2025-11-05 13:48:12.557145
549	392	2	Tuition	20000	2025-11-05 13:48:36.562611
550	396	2	Tuition	40000	2025-11-05 13:48:57.595968
551	399	2	Tuition	50000	2025-11-05 13:49:24.404159
552	404	2	Tuition	20000	2025-11-05 13:49:46.781681
553	403	2	Tuition	50000	2025-11-05 13:50:06.548129
554	400	2	Tuition	50000	2025-11-05 13:50:29.08025
555	402	2	Tuition	50000	2025-11-05 13:50:51.812912
556	401	2	Tuition	50000	2025-11-05 14:35:14.396642
557	405	2	Tuition	20000	2025-11-05 14:35:55.428157
558	406	2	Tuition	20000	2025-11-05 14:36:31.338644
559	407	2	Tuition	25000	2025-11-05 14:36:57.745247
560	408	2	Tuition	50000	2025-11-05 14:37:37.761668
561	445	3	Tuition	10000	2025-11-05 14:49:43.387559
562	442	4	Tuition	10000	2025-11-05 14:50:58.189799
563	254	6	Tuition	20000	2025-11-05 14:51:55.553192
564	254	6	Tuition	20000	2025-11-05 14:52:19.423663
565	336	6	Tuition	20000	2025-11-05 14:53:00.769779
566	411	6	Tuition	50000	2025-11-05 14:53:35.606652
567	412	7	Tuition	50000	2025-11-05 14:56:29.935875
568	419	7	Tuition	15000	2025-11-05 14:57:19.322489
571	446	7	Tuition	50000	2025-11-05 14:58:18.329764
572	443	10	Tuition	50000	2025-11-05 14:59:09.843536
575	444	10	Tuition	20000	2025-11-05 15:00:25.975354
576	414	8	Tuition	50000	2025-11-05 15:03:02.565654
577	415	8	Tuition	20000	2025-11-05 15:03:40.477978
578	447	8	Tuition	50000	2025-11-05 15:04:11.392587
579	416	9	Tuition	20000	2025-11-05 15:05:08.089025
580	417	11	Tuition	10000	2025-11-05 15:05:35.220653
581	237	12	Tuition	30000	2025-11-05 15:06:25.122763
582	386	12	Tuition	10000	2025-11-05 15:07:32.793806
583	387	12	Tuition	70000	2025-11-05 15:08:10.358342
584	418	16	Tuition	10000	2025-11-05 15:09:42.638309
585	420	15	Tuition	23000	2025-11-05 15:12:25.091557
586	421	15	Tuition	20000	2025-11-05 15:12:54.243877
587	422	15	Tuition	20000	2025-11-05 15:13:47.078057
588	423	15	Tuition	23000	2025-11-05 15:14:33.121384
589	426	15	Tuition	15000	2025-11-05 15:15:12.563002
590	430	17	Tuition	33000	2025-11-05 15:16:36.186565
591	429	17	Tuition	30000	2025-11-05 15:17:16.04786
594	431	17	Tuition	20000	2025-11-05 15:18:46.987356
595	427	18	Tuition	83000	2025-11-05 15:19:35.599003
596	428	18	Tuition	27000	2025-11-05 15:20:14.59512
597	438	24	Tuition	25000	2025-11-05 15:20:54.302285
598	439	23	Tuition	23000	2025-11-05 15:21:25.632495
599	440	23	Tuition	100000	2025-11-05 15:22:08.399637
602	441	23	Tuition	50000	2025-11-05 15:23:15.112353
603	432	25	Tuition	100000	2025-11-05 15:24:11.502342
604	433	25	Tuition	50000	2025-11-05 15:24:56.162581
605	437	25	Tuition	100000	2025-11-05 15:25:34.045544
606	435	25	Tuition	50000	2025-11-05 15:26:12.987846
607	436	20	Tuition	30000	2025-11-05 15:27:06.291826
608	448	19	Tuition	60000	2025-11-05 15:38:49.376519
609	9	1	Tuition	60000	2025-11-13 10:42:07.173462
610	10	1	Tuition	80000	2025-11-13 10:42:42.788205
611	13	1	Tuition	50000	2025-11-13 10:43:26.411664
612	58	1	Tuition	40000	2025-11-13 10:44:02.059822
613	59	1	Tuition	20000	2025-11-13 10:44:30.605825
614	18	1	Tuition	30000	2025-11-13 10:45:01.329659
615	35	1	Tuition	30000	2025-11-13 10:45:38.10774
616	449	19	Tuition	20000	2025-11-13 10:46:39.009965
617	47	1	Tuition	10000	2025-11-13 10:47:27.684978
618	108	1	Tuition	30000	2025-11-13 10:50:48.971511
619	115	19	Tuition	30000	2025-11-13 10:51:31.10063
620	116	19	Tuition	30000	2025-11-13 10:51:42.969959
621	450	19	Tuition	40000	2025-11-13 10:52:23.139145
622	451	19	Tuition	70000	2025-11-13 10:53:01.488559
623	454	19	Tuition	40000	2025-11-13 10:53:46.288788
624	123	19	Tuition	20000	2025-11-13 10:54:25.166753
625	127	19	Tuition	20000	2025-11-13 10:56:23.376089
626	453	19	Tuition	60000	2025-11-13 10:56:58.747593
627	455	19	Tuition	60000	2025-11-13 10:57:20.417724
628	210	19	Tuition	10000	2025-11-13 10:58:08.520928
629	239	19	Tuition	20000	2025-11-13 10:58:35.940603
630	233	19	Tuition	20000	2025-11-13 10:59:06.781748
631	279	19	Tuition	60000	2025-11-13 10:59:46.978579
632	303	19	Tuition	20000	2025-11-13 11:00:34.137415
633	458	19	Tuition	20000	2025-11-13 11:01:57.917641
634	391	2	Tuition	20000	2025-11-13 11:03:25.817647
635	63	2	Tuition	30000	2025-11-13 11:07:04.199803
636	65	2	Tuition	35000	2025-11-13 11:08:08.169341
637	394	2	Tuition	50000	2025-11-13 11:12:10.319638
638	405	2	Tuition	30000	2025-11-13 11:12:50.997689
639	457	2	Tuition	20000	2025-11-13 11:13:23.072911
640	456	2	Tuition	20000	2025-11-13 11:13:57.104657
641	470	2	Tuition	50000	2025-11-13 11:14:17.043174
642	70	5	Tuition	15000	2025-11-13 11:15:07.784696
643	328	5	Tuition	10000	2025-11-13 11:15:59.185343
644	262	5	Tuition	50000	2025-11-13 11:16:25.726647
645	5	5	Tuition	25000	2025-11-13 11:17:08.052582
646	459	5	Tuition	20000	2025-11-13 11:17:32.168249
647	489	5	Tuition	50000	2025-11-13 11:18:07.903433
648	72	3	Tuition	30000	2025-11-13 11:21:45.213614
649	75	3	Tuition	50000	2025-11-13 11:22:18.561917
650	141	3	Tuition	50000	2025-11-13 11:23:06.435102
651	471	3	Tuition	50000	2025-11-13 11:23:50.577531
652	472	3	Tuition	50000	2025-11-13 11:24:15.308692
653	475	3	Tuition	20000	2025-11-13 11:24:35.099337
654	146	4	Tuition	50000	2025-11-13 11:25:23.870392
655	147	4	Tuition	10000	2025-11-13 11:25:45.469127
656	202	4	Tuition	50000	2025-11-13 11:26:11.440754
657	322	4	Tuition	30000	2025-11-13 11:26:38.443109
658	249	4	Tuition	30000	2025-11-13 11:27:00.663651
659	323	4	Tuition	30000	2025-11-13 11:27:39.632089
660	326	4	Tuition	40000	2025-11-13 11:28:13.29571
661	327	4	Tuition	30000	2025-11-13 11:28:43.604298
662	476	4	Tuition	50000	2025-11-13 11:29:11.824444
663	332	6	Tuition	10000	2025-11-13 11:30:12.353115
664	206	6	Tuition	10000	2025-11-13 11:32:31.299153
665	462	6	Tuition	50000	2025-11-13 11:32:57.982002
666	461	6	Tuition	30000	2025-11-13 11:33:29.920761
667	76	6	Tuition	15000	2025-11-13 11:33:56.965282
668	154	7	Tuition	30000	2025-11-13 11:34:28.771161
669	155	7	Tuition	30000	2025-11-13 11:34:47.698012
670	344	7	Tuition	30000	2025-11-13 11:35:16.554166
671	463	7	Tuition	20000	2025-11-13 11:35:43.507433
672	490	7	Tuition	15000	2025-11-13 11:36:13.612768
673	158	10	Tuition	20000	2025-11-13 11:37:10.01463
674	464	10	Tuition	100000	2025-11-13 11:37:35.181568
675	350	8	Tuition	50000	2025-11-13 11:39:11.101614
676	215	11	Tuition	10000	2025-11-13 11:39:55.873367
677	356	11	Tuition	20000	2025-11-13 11:40:29.596518
678	467	11	Tuition	60000	2025-11-13 11:40:52.015952
679	468	11	Tuition	50000	2025-11-13 11:41:13.910526
680	482	11	Tuition	20000	2025-11-13 11:41:54.263306
681	469	12	Tuition	10000	2025-11-13 11:43:05.698413
682	93	16	Tuition	50000	2025-11-13 11:43:46.19458
683	383	16	Tuition	68000	2025-11-13 11:44:48.891353
684	418	16	Tuition	10000	2025-11-13 11:45:17.969557
685	484	16	Tuition	25000	2025-11-13 11:45:44.827618
686	424	15	Tuition	23000	2025-11-13 11:46:19.452575
687	174	15	Tuition	20000	2025-11-13 11:46:40.006356
688	138	15	Tuition	30000	2025-11-13 11:47:11.777059
689	256	15	Tuition	20000	2025-11-13 11:47:42.210473
690	474	22	Tuition	30000	2025-11-13 11:49:51.050069
691	100	17	Tuition	15000	2025-11-13 11:50:40.48034
692	430	17	Tuition	50000	2025-11-13 11:51:12.42186
693	431	17	Tuition	20000	2025-11-13 11:51:38.377623
694	488	8	Tuition	60000	2025-11-13 11:52:32.487451
695	487	3	Tuition	30000	2025-11-13 11:53:03.575631
696	486	6	Tuition	50000	2025-11-13 11:53:36.882008
697	485	19	Tuition	50000	2025-11-13 11:54:06.143318
698	491	21	Tuition	95000	2025-11-13 11:58:45.503179
699	177	18	Tuition	30000	2025-11-13 12:00:00.387577
700	428	18	Tuition	23000	2025-11-13 12:00:58.662896
701	439	23	Tuition	80000	2025-11-13 12:01:51.357891
702	492	9	Tuition	20000	2025-11-13 12:04:37.4682
\.


--
-- Data for Name: financial_transactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.financial_transactions (id, transaction_date, type, amount, budget_head_id, description, reference_type, reference_id, department, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: group_participants; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.group_participants (id, group_id, user_id, joined_at) FROM stdin;
1	1	33	2025-09-15 20:55:27.95945
2	1	25	2025-09-15 20:55:27.95945
4	1	24	2025-09-15 20:55:27.95945
5	1	20	2025-09-15 20:55:27.95945
6	1	13	2025-09-15 20:55:27.95945
7	1	19	2025-09-15 20:55:27.95945
8	1	34	2025-09-15 20:55:27.95945
9	1	15	2025-09-15 20:55:27.95945
\.


--
-- Data for Name: groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.groups (id, name, creator_id, created_at) FROM stdin;
1	Heads of Departments	33	2025-09-15 20:55:27.95945
\.


--
-- Data for Name: hod_teachers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hod_teachers (id, hod_id, teacher_id, created_at) FROM stdin;
3	2	20	2025-09-24 19:47:33.339528
4	2	12	2025-09-24 19:47:33.339528
5	1	13	2025-09-24 19:48:06.644346
6	1	9	2025-09-24 19:48:06.644346
7	3	35	2025-09-24 19:48:46.669394
8	3	26	2025-09-24 19:48:46.669394
9	4	22	2025-09-24 19:49:53.11936
10	4	15	2025-09-24 19:49:53.11936
11	5	19	2025-09-24 19:50:40.606716
12	5	17	2025-09-24 19:50:40.606716
13	6	25	2025-09-24 19:51:19.031412
14	6	23	2025-09-24 19:51:19.031412
15	7	2	2025-09-24 19:58:17.656999
16	7	24	2025-09-24 19:58:17.656999
17	7	7	2025-09-24 19:58:17.656999
18	7	3	2025-09-24 19:58:17.656999
\.


--
-- Data for Name: hods; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hods (id, department_name, hod_user_id, subject_id, suspended, created_at, updated_at) FROM stdin;
2	Civil Engineering 	20	\N	f	2025-09-24 19:47:33.339528	2025-09-24 19:47:33.339528
1	COMMERCIAL 	13	\N	f	2025-09-24 19:43:36.575004	2025-09-24 19:48:06.644346
3	Electrical Engineering 	35	\N	f	2025-09-24 19:48:46.669394	2025-09-24 19:48:46.669394
4	Health Care Engineering 	15	\N	f	2025-09-24 19:49:53.11936	2025-09-24 19:49:53.11936
5	Mechanical Engineering 	19	\N	f	2025-09-24 19:50:40.606716	2025-09-24 19:50:40.606716
6	Textile Engineering 	25	\N	f	2025-09-24 19:51:19.031412	2025-09-24 19:51:19.031412
7	Science	24	\N	f	2025-09-24 19:58:17.656999	2025-09-24 19:58:17.656999
\.


--
-- Data for Name: id_cards; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.id_cards (id, student_id, card_number, issued_at) FROM stdin;
\.


--
-- Data for Name: inventory; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.inventory (id, date, item_name, department, quantity, estimated_cost, type, depreciation_rate, created_at, updated_at, budget_head_id, asset_category, purchase_date, supplier, warranty_expiry, location, condition) FROM stdin;
\.


--
-- Data for Name: lesson_plans; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.lesson_plans (id, user_id, title, period_type, file_url, status, admin_comment, submitted_at, reviewed_at, reviewed_by, subject, class_name, week, objectives, content, activities, assessment, resources, file_name, updated_at) FROM stdin;
2	22	Chemistry Certification level 2 notes 	monthly	https://st60307.ispot.cc/votechs7academygroup/lesson_plan_1758743565221_CERTIFICATION LEVEL 2 NOTES OF OCTOBER.pdf	rejected	It says "Property of Nyiang Kennet" meaning you did not work on the notes. You have just gotten someone else's notes or part of a workbook or textbook and submitted. And remember to used basic grammar, even with the technical terms involved, for better comprehension on the part of the students. Thanks.	2025-09-24 19:52:48.441343	2025-09-25 16:54:00.883873	33	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-09-24 19:52:48.441343
1	22	Chemistry notes for certification level one 	monthly	https://st60307.ispot.cc/votechs7academygroup/lesson_plan_1758743492442_certification one chemistry notes for october.pdf	rejected	Please, review your notes. My remark will be the same as the previous one, with regard to you working on your notes rather than uploading someone else's notes for verification. Thanks.	2025-09-24 19:51:35.084816	2025-09-25 17:00:37.58637	33	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-09-24 19:51:35.084816
3	2	Lesson plan for the month of October ICT	monthly	https://st60307.ispot.cc/votechs7academygroup/lesson_plan_1759841599186_ICT NOTES FOR THE MONTH OF OCTOBER BY ABANG JUNIOR.pdf	approved	This is good but it does not follow the format as was presented in the WhatsApp forum. I don't see the student-oriented exercises and key take-home notes, for example. Always make sure to follow that format properly. If you can review this and make those corrections it will be great. Thanks	2025-10-07 12:53:21.450755	2025-10-08 19:20:22.084398	33	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-10-07 12:53:21.450755
4	2	Ict notes for the month of September 	monthly	https://st60307.ispot.cc/votechs7academygroup/lesson_plan_1759847029727_ICT NOTES FOR THE MONTH OF SEPTEMBER BY ABANG JUNIOR.pdf	approved	It does not completely follow the format as was presented in the WhatsApp forum. Same comment as the other lesson plan you submitted. Please, review this lesson plan. Thanks	2025-10-07 14:23:51.749949	2025-10-08 19:22:34.642183	33	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-10-07 14:23:51.749949
6	22	Chemistry for ITVEE	monthly	https://st60307.ispot.cc/votechs7academygroup/lesson_plan_1759933010821_ITVEE CHEMMISTRY  FOR OCTOBER- final document-1.pdf	approved	Lesson Plan not complete. Follow the exact format completely as presented in the WhatsApp forum. Thanks	2025-10-08 14:16:52.921233	2025-10-08 19:28:39.932191	33	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-10-08 14:16:52.921233
7	22	Chemistry for CL2	monthly	https://st60307.ispot.cc/votechs7academygroup/lesson_plan_1759933175247_CERTIFICATION 2  OCTOBER NOTES final copy.pdf	approved	Lesson Plan not complete. Follow the complete format as presented in the WhatsApp forum. Thanks	2025-10-08 14:19:37.281346	2025-10-08 19:33:25.723515	33	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-10-08 14:19:37.281346
8	22	Chemistry certification level 1	monthly	https://st60307.ispot.cc/votechs7academygroup/lesson_plan_1759933364102_GAS GENERATION AND COLLECTION; certification level one.pdf	approved	Lesson Plan not complete. Follow the complete format as presented in the WhatsApp forum. Thanks	2025-10-08 14:22:46.135448	2025-10-08 19:41:32.238635	33	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-10-08 14:22:46.135448
9	7	INTRODUCTION TO PHYSICAL PROPERTIES AND QUANTITIES	weekly	https://st60307.ispot.cc/votechs7academygroup/lesson_plan_1759938762071_Eng. Science CL1, L1.pdf	approved	Great work.	2025-10-08 15:52:43.957967	2025-10-08 19:42:12.651731	33	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-10-08 15:52:43.957967
23	18	Comparing Adjectives 	monthly	https://st60307.ispot.cc/votechs7academygroup/lesson_plan_1759948598379_lesson plan 14.pdf	approved	Always go through your lesson plan thoroughly before submitting. And it is not complete. I don't see the key take-home notes, for example, amongst others. Please, review your lesson plan following the exact format as presented in the WhatsApp forum. Thanks 	2025-10-08 18:36:40.357252	2025-10-08 20:08:29.235045	33	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-10-08 18:36:40.357252
22	18	Conditional 	monthly	https://st60307.ispot.cc/votechs7academygroup/lesson_plan_1759948500071_Lesson plan 1.pdf	approved	Lesson plan not complete. Always make sure to follow the exact format as presented in the WhatsApp forum. Please, review your lesson plan. Thanks	2025-10-08 18:35:01.808143	2025-10-08 20:12:21.584839	33	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-10-08 18:35:01.808143
18	18	Verbs	monthly	https://st60307.ispot.cc/votechs7academygroup/lesson_plan_1759947883281_lesson plan 10.pdf	approved	Lesson plan not complete. Always make sure to follow the exact format as presented in the WhatsApp forum. Thanks	2025-10-08 18:24:45.310915	2025-10-08 20:16:11.877448	33	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-10-08 18:24:45.310915
14	18	English language 	monthly	https://st60307.ispot.cc/votechs7academygroup/lesson_plan_1759947708146_lesson plan 7.pdf	approved	Lesson Plan not complete. Follow the exact format as presented in the WhatsApp forum. Thanks	2025-10-08 18:21:50.178639	2025-10-08 20:19:40.151725	33	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-10-08 18:21:50.178639
13	18	English language 	monthly	https://st60307.ispot.cc/votechs7academygroup/lesson_plan_1759947681015_lesson plan 6.pdf	approved	Lesson plan not complete. Make sure to always follow the exact format as presented in the WhatsApp forum. Thanks	2025-10-08 18:21:23.035194	2025-10-08 20:21:20.294646	33	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-10-08 18:21:23.035194
12	18	English language 	monthly	https://st60307.ispot.cc/votechs7academygroup/lesson_plan_1759943034902_lesson plan 5.pdf	approved	Lesson plan not complete. Always make sure to follow the exact format as presented in the WhatsApp forum. Thanks	2025-10-08 17:03:56.896347	2025-10-08 20:22:55.232555	33	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-10-08 17:03:56.896347
24	18	Conditionals	monthly	https://st60307.ispot.cc/votechs7academygroup/lesson_plan_1759954171996_Lesson plan 1.pdf	approved	Lesson plan not complete. Make sure to always follow the exact format as presented in the WhatsApp forum. Thanks	2025-10-08 20:09:33.801997	2025-10-08 20:23:52.980845	33	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-10-08 20:09:33.801997
27	18	Types and uses of nouns 	monthly	https://st60307.ispot.cc/votechs7academygroup/lesson_plan_1759956465946_Lesson plan 3.pdf	approved		2025-10-08 20:47:47.708235	2025-10-09 18:16:52.833048	33	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-10-08 20:47:47.708235
41	35	Lesson notes on Circuits for ATVE students for the Month of October 	monthly	https://st60307.ispot.cc/votechs7academygroup/lesson_plan_1759958578066_Digital Notes Oct_ATVE.pdf	approved	Lesson Plan not complete. Follow the exact format as presented in the WhatsApp forum. Thanks	2025-10-08 21:23:00.171061	2025-10-09 17:53:24.823182	33	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-10-08 21:23:00.171061
40	35	Lesson notes on Digital Circuits for ATVE students for the Month of September	monthly	https://st60307.ispot.cc/votechs7academygroup/lesson_plan_1759958541159_Digital Notes Sep_ATVE.pdf	approved	Lesson Plan not complete. Follow the exact format as presented in the WhatsApp forum. Thanks	2025-10-08 21:22:23.178353	2025-10-09 17:59:54.761905	33	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-10-08 21:22:23.178353
39	35	Lesson notes on Circuits for ITVE students for the Month of October 	monthly	https://st60307.ispot.cc/votechs7academygroup/lesson_plan_1759958458470_Circuit ITVEE Oct.pdf	approved	Lesson Plan not complete. Follow the exact format as presented in the WhatsApp forum. Thanks	2025-10-08 21:21:00.48335	2025-10-09 18:04:44.637973	33	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-10-08 21:21:00.48335
38	35	Lesson notes on Circuits for ITVE students for the Month of September	monthly	https://st60307.ispot.cc/votechs7academygroup/lesson_plan_1759958401540_Circuit ITVE_Sep.pdf	approved	Lesson plan does not follow the exact format as presented in the WhatsApp forum. Do well to review and make the necessary corrections. Thanks	2025-10-08 21:20:03.748133	2025-10-09 18:05:44.867039	33	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-10-08 21:20:03.748133
37	35	Lesson notes on Circuits for Certification Level 2for the Month of September	monthly	https://st60307.ispot.cc/votechs7academygroup/lesson_plan_1759958316101_Circuit CLV2_Sep.pdf	approved		2025-10-08 21:18:38.287348	2025-10-09 18:10:15.506462	33	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-10-08 21:18:38.287348
43	2	October lesson plan update for ict certification level one 	monthly	https://st60307.ispot.cc/votechs7academygroup/lesson_plan_1759961129683_october lesson plan update for ict.pdf	approved		2025-10-08 22:05:31.718341	2025-10-09 18:20:42.005631	33	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-10-08 22:05:31.718341
42	2	September lesson plan update for ict certification level one 	monthly	https://st60307.ispot.cc/votechs7academygroup/lesson_plan_1759961089430_ICT SEPTEMBER LESSON PLAN UPDATE.pdf	approved		2025-10-08 22:04:51.397767	2025-10-09 18:21:28.752509	33	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-10-08 22:04:51.397767
44	18	Conjunctions 	monthly	https://st60307.ispot.cc/votechs7academygroup/lesson_plan_1760037086863_lesson plan 16.pdf	approved		2025-10-09 19:11:28.809139	2025-10-20 14:36:23.222636	33	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-10-09 19:11:28.809139
56	15	Biology ITVEE	monthly	https://st60307.ispot.cc/votechs7academygroup/lesson_plan_1760604785180_Reproduction in plants Biology ITVEE OCTOBER-1.pdf	approved	"Activities" missing.\n"Exercises/Assignments" missing.\nAlso, always allocate time durations for each stage.\nFollow template provided in the WhatsApp forum. 	2025-10-16 08:53:07.215353	2025-10-20 14:40:58.553306	33	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-10-16 08:53:07.215353
55	15	Biology CL2 Continuation 	monthly	https://st60307.ispot.cc/votechs7academygroup/lesson_plan_1760604758947_Biology notes continuation CL2-1.pdf	approved	Lesson Plan does not completely follow template as provided in the WhatsApp forum. Endeavor to make these improvements.	2025-10-16 08:52:40.914599	2025-10-20 14:47:10.284249	33	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-10-16 08:52:40.914599
50	15	Public health CL1	monthly	https://st60307.ispot.cc/votechs7academygroup/lesson_plan_1760604532295_public health CL1.pdf	approved	Lesson Plan does not completely follow the template as provided for in the WhatsApp forum. Endeavor to make these improvements.	2025-10-16 08:48:54.094272	2025-10-20 14:57:53.856099	33	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-10-16 08:48:54.094272
54	15	Biology Notes CL2	monthly	https://st60307.ispot.cc/votechs7academygroup/lesson_plan_1760604709732_Biology notes CL2-1.pdf	approved	Lesson Plan does not completely follow the template as provided for in the WhatsApp forum. Endeavor to make these improvements.	2025-10-16 08:51:51.763001	2025-10-20 14:48:48.714594	33	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-10-16 08:51:51.763001
53	15	Biology notes OL A & B October 	monthly	https://st60307.ispot.cc/votechs7academygroup/lesson_plan_1760604647229_Biology OL A & B October.pdf	approved		2025-10-16 08:50:49.199707	2025-10-20 14:53:03.400015	33	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-10-16 08:50:49.199707
52	15	Biology notes OL A & B	monthly	https://st60307.ispot.cc/votechs7academygroup/lesson_plan_1760604610813_Biology OrL A and B.pdf	approved	Lesson Plan does not completely follow the template as provided for in the WhatsApp forum. Endeavor to make these improvements.	2025-10-16 08:50:12.690664	2025-10-20 14:53:20.31466	33	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-10-16 08:50:12.690664
51	15	Public Health Notes October 	monthly	https://st60307.ispot.cc/votechs7academygroup/lesson_plan_1760604567240_Public health notes October . CL1.pdf	approved	Lesson Plan does not completely follow the template as provided for in the WhatsApp forum. Endeavor to make these improvements.	2025-10-16 08:49:29.142826	2025-10-20 14:57:17.290498	33	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-10-16 08:49:29.142826
45	18	Comparing Adjectives 	monthly	https://st60307.ispot.cc/votechs7academygroup/lesson_plan_1760037251651_lesson plan 15.pdf	approved		2025-10-09 19:14:13.692286	2025-10-24 11:44:24.984496	33	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-10-09 19:14:13.692286
49	15	Human biology notes week 1 CL2	weekly	https://st60307.ispot.cc/votechs7academygroup/lesson_plan_1760604488564_week one human biology notes.pdf	approved	Lesson Plan does not completely follow template as provided for in the WhatsApp forum. Endeavor to make these improvements.	2025-10-16 08:48:10.754027	2025-10-20 15:01:34.375894	33	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-10-16 08:48:10.754027
48	35	Machines notes for CL2 students for the month of October 	monthly	https://st60307.ispot.cc/votechs7academygroup/lesson_plan_1760130913748_Machines.pdf	approved		2025-10-10 21:15:16.019483	2025-10-20 15:04:09.385293	33	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-10-10 21:15:16.019483
47	35	Electrical Engineering notes for the month of October 	monthly	https://st60307.ispot.cc/votechs7academygroup/lesson_plan_1760130829133_Orientation Notes_Oct.pdf	approved		2025-10-10 21:13:51.189899	2025-10-20 15:06:20.028764	33	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-10-10 21:13:51.189899
46	35	Circuit notes for Certification Level 2 students for the month of October 	monthly	https://st60307.ispot.cc/votechs7academygroup/lesson_plan_1760130783968_Circuit CLV2_Oct.pdf	approved		2025-10-10 21:13:06.19423	2025-10-20 15:15:12.376022	33	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-10-10 21:13:06.19423
57	15	Lesson plan Public Health CL1	weekly	https://st60307.ispot.cc/votechs7academygroup/lesson_plan_1761810490676_Lesson plan Public health CL1.pdf	approved		2025-10-30 07:48:12.610343	2025-10-31 11:57:10.625997	33	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-10-30 07:48:12.610343
58	20	Introduction to civil engineering building construction 	weekly	https://st60307.ispot.cc/votechs7academygroup/lesson_plan_1762682245248_CE_orientatin[1].pdf	pending	\N	2025-11-09 09:57:27.276546	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-11-09 09:57:27.276546
59	20	Introduction to soils 	weekly	https://st60307.ispot.cc/votechs7academygroup/lesson_plan_1762682289208_CE FIVE INTRODUCTION TO SOILS.pdf	pending	\N	2025-11-09 09:58:11.285312	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-11-09 09:58:11.285312
60	20	Introduction and basic concept of drawing 	weekly	https://st60307.ispot.cc/votechs7academygroup/lesson_plan_1762683793710_CE drawig cl 1 and 2 (1).pdf	pending	\N	2025-11-09 10:23:15.789042	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-11-09 10:23:15.789042
61	20	Introduction to survey 	weekly	https://st60307.ispot.cc/votechs7academygroup/lesson_plan_1762685250868_Survey ITVEE.pdf	pending	\N	2025-11-09 10:47:32.910036	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-11-09 10:47:32.910036
62	20	Introduction to soils and materials (ITVEE)	weekly	https://st60307.ispot.cc/votechs7academygroup/lesson_plan_1762685375507_ITVEE  CE SOILS MATERIALS  NOTES.pdf	pending	\N	2025-11-09 10:49:37.537173	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-11-09 10:49:37.537173
63	20	Atterberg's limits test/said equivalent test 	weekly	https://st60307.ispot.cc/votechs7academygroup/lesson_plan_1762744507433_Atterberg's limits test and sand equivalent test .pdf	pending	\N	2025-11-10 03:15:10.111944	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-11-10 03:15:10.111944
64	17	Workshop processes ATVEE	monthly	https://st60307.ispot.cc/votechs7academygroup/lesson_plan_1762950097939_ATVEE WSP 1.pdf	pending	\N	2025-11-12 12:21:40.276913	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-11-12 12:21:40.276913
65	17	Workshop processes CL1-ITVEE	monthly	https://st60307.ispot.cc/votechs7academygroup/lesson_plan_1762950148007_WSP ITVEE 1.pdf	pending	\N	2025-11-12 12:22:30.138351	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-11-12 12:22:30.138351
66	17	Sheet metal works CL1-ITVEE 	monthly	https://st60307.ispot.cc/votechs7academygroup/lesson_plan_1762950207771_SMW ITVEE 1.pdf	pending	\N	2025-11-12 12:23:29.857352	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-11-12 12:23:29.857352
67	17	Sheet metal construction drawing CL1-ITVEE 	monthly	https://st60307.ispot.cc/votechs7academygroup/lesson_plan_1762950232987_SMCD ITVEE 1.pdf	pending	\N	2025-11-12 12:23:55.028349	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-11-12 12:23:55.028349
68	25	Lesson plan for textile technology ITVEE	weekly	https://st60307.ispot.cc/votechs7academygroup/lesson_plan_1763121085838_DOC-20251114-WA0007..pdf	pending	\N	2025-11-14 11:51:27.967352	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-11-14 11:51:27.967352
\.


--
-- Data for Name: lessons; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.lessons (id, user_id, title, subject, class_name, week, period_type, objectives, content, activities, assessment, resources, status, admin_comment, created_at, updated_at, reviewed_at, reviewed_by) FROM stdin;
\.


--
-- Data for Name: marks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.marks (id, student_id, subject_id, class_id, academic_year_id, term_id, sequence_id, score, uploaded_by, uploaded_at, "createdAt", "updatedAt", "deletedAt") FROM stdin;
1	159	42	10	1	1	1	14.80	3	2025-11-12 15:26:38.046+01	2025-11-12 15:26:38.052+01	2025-11-12 15:26:38.052+01	\N
2	157	42	10	1	1	1	15.60	3	2025-11-12 15:26:38.047+01	2025-11-12 15:26:38.053+01	2025-11-12 15:26:38.053+01	\N
3	464	42	10	1	1	1	16.80	3	2025-11-12 15:26:38.047+01	2025-11-12 15:26:38.053+01	2025-11-12 15:26:38.053+01	\N
5	348	42	10	1	1	1	14.80	3	2025-11-12 15:26:38.047+01	2025-11-12 15:26:38.053+01	2025-11-12 15:26:38.053+01	\N
4	158	42	10	1	1	1	15.60	3	2025-11-12 15:26:38.047+01	2025-11-12 15:26:38.053+01	2025-11-12 15:26:38.053+01	\N
6	347	42	10	1	1	1	16.00	3	2025-11-12 15:26:38.047+01	2025-11-12 15:26:38.053+01	2025-11-12 15:26:38.053+01	\N
7	346	42	10	1	1	1	14.40	3	2025-11-12 15:26:38.047+01	2025-11-12 15:26:38.053+01	2025-11-12 15:26:38.053+01	\N
8	349	42	10	1	1	1	0.00	3	2025-11-12 15:26:38.047+01	2025-11-12 15:26:38.053+01	2025-11-12 15:26:38.053+01	\N
9	443	42	10	1	1	1	12.80	3	2025-11-12 15:26:38.047+01	2025-11-12 15:26:38.053+01	2025-11-12 15:26:38.053+01	\N
10	413	42	10	1	1	1	13.60	3	2025-11-12 15:26:38.047+01	2025-11-12 15:26:38.053+01	2025-11-12 15:26:38.053+01	\N
11	444	42	10	1	1	1	12.00	3	2025-11-12 15:26:38.047+01	2025-11-12 15:26:38.053+01	2025-11-12 15:26:38.053+01	\N
12	105	46	23	1	1	1	0.00	1	2025-11-14 08:29:19.14+01	2025-11-14 08:29:19.15+01	2025-11-14 08:29:19.15+01	\N
13	226	46	23	1	1	1	0.00	1	2025-11-14 08:29:19.141+01	2025-11-14 08:29:19.15+01	2025-11-14 08:29:19.15+01	\N
14	439	46	23	1	1	1	3.00	1	2025-11-14 08:29:19.141+01	2025-11-14 08:29:19.151+01	2025-11-14 08:29:19.151+01	\N
15	440	46	23	1	1	1	0.00	1	2025-11-14 08:29:19.141+01	2025-11-14 08:29:19.151+01	2025-11-14 08:29:19.151+01	\N
16	441	46	23	1	1	1	0.00	1	2025-11-14 08:29:19.141+01	2025-11-14 08:29:19.151+01	2025-11-14 08:29:19.151+01	\N
17	438	46	23	1	1	1	0.00	1	2025-11-14 08:29:19.141+01	2025-11-14 08:29:19.151+01	2025-11-14 08:29:19.151+01	\N
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.messages (id, sender_id, receiver_id, content, created_at, file_url, file_name, file_type, group_id, read_at, read) FROM stdin;
1	3	2	Hello Sir. 	2025-09-11 20:08:22.860047	\N	\N	\N	\N	\N	f
2	3	2	Have created some subjects especially general 	2025-09-11 20:09:08.0431	\N	\N	\N	\N	\N	f
3	33	\N	Principal added you to Heads of Departments	2025-09-15 20:55:27.95945	\N	\N	\N	1	2025-09-17 03:00:04.437356	f
4	33	\N	Greetings, dear Departmental Heads.	2025-09-15 21:49:11.442795	\N	\N	\N	1	2025-09-17 03:00:04.437356	f
5	33	\N	I urge you all to follow up and ensure that all notes for the month of October be submitted on or before Wednesday, September 24th, 2025.	2025-09-15 21:50:48.922706	\N	\N	\N	1	2025-09-17 03:00:04.437356	f
6	33	\N	Thanks.	2025-09-15 21:50:59.989169	\N	\N	\N	1	2025-09-17 03:00:04.437356	f
7	33	\N	Good evening, esteemed HODs. I hope this meets us all well. This is to remind us all about the submission of notes scheduled for tomorrow. Do inform your teachers that verification they will then have to submit their lesson notes via the Lesson Plans feature on this school management portal, on Thursday 25/09/2025.	2025-09-23 19:43:18.320123	\N	\N	\N	1	2025-09-24 18:42:46.228345	f
8	33	\N	Thank you all for your continuous collaboration.	2025-09-23 19:43:42.852167	\N	\N	\N	1	2025-09-24 18:42:46.228345	f
9	33	\N	***inform your teachers that after verification***	2025-09-23 19:45:06.532667	\N	\N	\N	1	2025-09-24 18:42:46.228345	f
10	2	33	Good day sir	2025-10-07 14:24:52.889879	\N	\N	\N	\N	\N	f
11	2	33	I have submitted ict notes for September and October 	2025-10-07 14:26:00.907344	\N	\N	\N	\N	\N	f
\.


--
-- Data for Name: salaries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.salaries (id, amount, month, paid, paid_at, created_at, user_id, year, status, updated_at, applicant_id) FROM stdin;
11	110000.00	November	f	\N	2025-10-01 13:51:45.069457	6	2025	pending	2025-11-13 12:25:51.761461	\N
38	110000.00	February	f	\N	2025-10-01 14:01:55.662821	36	2025	pending	2025-11-13 12:19:26.446712	\N
39	110000.00	March	f	\N	2025-10-01 14:01:55.66378	36	2025	pending	2025-11-13 12:19:26.447923	\N
40	110000.00	April	f	\N	2025-10-01 14:01:55.664719	36	2025	pending	2025-11-13 12:19:26.448971	\N
41	110000.00	May	f	\N	2025-10-01 14:01:55.665702	36	2025	pending	2025-11-13 12:19:26.449852	\N
42	110000.00	June	f	\N	2025-10-01 14:01:55.666656	36	2025	pending	2025-11-13 12:19:26.450673	\N
43	110000.00	July	f	\N	2025-10-01 14:01:55.667619	36	2025	pending	2025-11-13 12:19:26.451535	\N
44	110000.00	August	f	\N	2025-10-01 14:01:55.66858	36	2025	pending	2025-11-13 12:19:26.452379	\N
45	110000.00	September	t	2025-10-04 10:59:18.195528	2025-10-01 14:01:55.669405	36	2025	pending	2025-11-13 12:19:26.453187	\N
70	90000.00	October	t	2025-11-13 12:31:38.298881	2025-10-01 14:04:27.128245	22	2025	pending	2025-11-13 12:31:38.298881	\N
47	110000.00	November	f	\N	2025-10-01 14:01:55.671194	36	2025	pending	2025-11-13 12:19:26.454675	\N
48	110000.00	December	f	\N	2025-10-01 14:01:55.672107	36	2025	pending	2025-11-13 12:19:26.455633	\N
49	100000.00	January	f	\N	2025-10-01 14:04:04.970095	9	2025	pending	2025-11-13 12:20:10.203486	\N
5	110000.00	May	f	\N	2025-10-01 13:51:45.061205	6	2025	pending	2025-11-13 12:25:51.753946	\N
7	110000.00	July	f	\N	2025-10-01 13:51:45.064437	6	2025	pending	2025-11-13 12:25:51.756538	\N
8	110000.00	August	f	\N	2025-10-01 13:51:45.065952	6	2025	pending	2025-11-13 12:25:51.758039	\N
9	110000.00	September	t	2025-10-01 14:23:44.265901	2025-10-01 13:51:45.067002	6	2025	pending	2025-11-13 12:25:51.759578	\N
34	750000.00	October	t	2025-11-13 12:30:34.074277	2025-10-01 14:01:32.321488	14	2025	pending	2025-11-13 12:30:34.074277	\N
4	110000.00	April	f	\N	2025-10-01 13:51:45.060156	6	2025	pending	2025-11-13 12:25:51.753141	\N
46	110000.00	October	t	2025-11-13 12:30:54.590159	2025-10-01 14:01:55.670223	36	2025	pending	2025-11-13 12:30:54.590159	\N
3	110000.00	March	f	\N	2025-10-01 13:51:45.059429	6	2025	pending	2025-11-13 12:25:51.752164	\N
22	80000.00	October	t	2025-11-13 12:29:23.308133	2025-10-01 13:59:29.110542	25	2025	pending	2025-11-13 12:29:23.308133	\N
58	100000.00	October	t	2025-11-13 12:31:20.917428	2025-10-01 14:04:04.98325	9	2025	pending	2025-11-13 12:31:20.917428	\N
10	110000.00	October	t	2025-11-13 12:40:51.266183	2025-10-01 13:51:45.067886	6	2025	pending	2025-11-13 12:40:51.266183	\N
13	80000.00	January	f	\N	2025-10-01 13:59:29.0995	25	2025	pending	2025-11-13 12:16:55.93934	\N
14	80000.00	February	f	\N	2025-10-01 13:59:29.10242	25	2025	pending	2025-11-13 12:16:55.941757	\N
15	80000.00	March	f	\N	2025-10-01 13:59:29.103646	25	2025	pending	2025-11-13 12:16:55.942688	\N
16	80000.00	April	f	\N	2025-10-01 13:59:29.104598	25	2025	pending	2025-11-13 12:16:55.943561	\N
17	80000.00	May	f	\N	2025-10-01 13:59:29.105441	25	2025	pending	2025-11-13 12:16:55.945182	\N
18	80000.00	June	f	\N	2025-10-01 13:59:29.10622	25	2025	pending	2025-11-13 12:16:55.946118	\N
19	80000.00	July	f	\N	2025-10-01 13:59:29.107591	25	2025	pending	2025-11-13 12:16:55.947714	\N
20	80000.00	August	f	\N	2025-10-01 13:59:29.108831	25	2025	pending	2025-11-13 12:16:55.948688	\N
21	80000.00	September	t	2025-10-04 10:58:20.371548	2025-10-01 13:59:29.109702	25	2025	pending	2025-11-13 12:16:55.949473	\N
23	80000.00	November	f	\N	2025-10-01 13:59:29.111491	25	2025	pending	2025-11-13 12:16:55.951086	\N
24	80000.00	December	f	\N	2025-10-01 13:59:29.112943	25	2025	pending	2025-11-13 12:16:55.951803	\N
25	750000.00	January	f	\N	2025-10-01 14:01:32.311273	14	2025	pending	2025-11-13 12:19:10.564581	\N
26	750000.00	February	f	\N	2025-10-01 14:01:32.31318	14	2025	pending	2025-11-13 12:19:10.567368	\N
27	750000.00	March	f	\N	2025-10-01 14:01:32.314082	14	2025	pending	2025-11-13 12:19:10.568661	\N
28	750000.00	April	f	\N	2025-10-01 14:01:32.31494	14	2025	pending	2025-11-13 12:19:10.569667	\N
29	750000.00	May	f	\N	2025-10-01 14:01:32.315701	14	2025	pending	2025-11-13 12:19:10.570615	\N
30	750000.00	June	f	\N	2025-10-01 14:01:32.317633	14	2025	pending	2025-11-13 12:19:10.571605	\N
31	750000.00	July	f	\N	2025-10-01 14:01:32.319169	14	2025	pending	2025-11-13 12:19:10.572664	\N
32	750000.00	August	f	\N	2025-10-01 14:01:32.319995	14	2025	pending	2025-11-13 12:19:10.573493	\N
33	750000.00	September	t	2025-10-04 10:58:47.905568	2025-10-01 14:01:32.320729	14	2025	pending	2025-11-13 12:19:10.574717	\N
35	750000.00	November	f	\N	2025-10-01 14:01:32.322287	14	2025	pending	2025-11-13 12:19:10.576888	\N
36	750000.00	December	f	\N	2025-10-01 14:01:32.323214	14	2025	pending	2025-11-13 12:19:10.577837	\N
37	110000.00	January	f	\N	2025-10-01 14:01:55.660142	36	2025	pending	2025-11-13 12:19:26.44494	\N
50	100000.00	February	f	\N	2025-10-01 14:04:04.973123	9	2025	pending	2025-11-13 12:20:10.20608	\N
51	100000.00	March	f	\N	2025-10-01 14:04:04.974212	9	2025	pending	2025-11-13 12:20:10.208559	\N
52	100000.00	April	f	\N	2025-10-01 14:04:04.975939	9	2025	pending	2025-11-13 12:20:10.210291	\N
53	100000.00	May	f	\N	2025-10-01 14:04:04.977156	9	2025	pending	2025-11-13 12:20:10.211302	\N
54	100000.00	June	f	\N	2025-10-01 14:04:04.979073	9	2025	pending	2025-11-13 12:20:10.212162	\N
55	100000.00	July	f	\N	2025-10-01 14:04:04.980208	9	2025	pending	2025-11-13 12:20:10.213004	\N
56	100000.00	August	f	\N	2025-10-01 14:04:04.98128	9	2025	pending	2025-11-13 12:20:10.213888	\N
57	100000.00	September	t	2025-10-04 10:59:36.371786	2025-10-01 14:04:04.982262	9	2025	pending	2025-11-13 12:20:10.214842	\N
59	100000.00	November	f	\N	2025-10-01 14:04:04.984521	9	2025	pending	2025-11-13 12:20:10.217681	\N
60	100000.00	December	f	\N	2025-10-01 14:04:04.985539	9	2025	pending	2025-11-13 12:20:10.218634	\N
61	90000.00	January	f	\N	2025-10-01 14:04:27.110125	22	2025	pending	2025-11-13 12:20:26.952069	\N
62	90000.00	February	f	\N	2025-10-01 14:04:27.11583	22	2025	pending	2025-11-13 12:20:26.955338	\N
63	90000.00	March	f	\N	2025-10-01 14:04:27.11699	22	2025	pending	2025-11-13 12:20:26.956259	\N
64	90000.00	April	f	\N	2025-10-01 14:04:27.117991	22	2025	pending	2025-11-13 12:20:26.957473	\N
65	90000.00	May	f	\N	2025-10-01 14:04:27.120074	22	2025	pending	2025-11-13 12:20:26.958194	\N
66	90000.00	June	f	\N	2025-10-01 14:04:27.121716	22	2025	pending	2025-11-13 12:20:26.959807	\N
67	90000.00	July	f	\N	2025-10-01 14:04:27.123116	22	2025	pending	2025-11-13 12:20:26.960693	\N
68	90000.00	August	f	\N	2025-10-01 14:04:27.124447	22	2025	pending	2025-11-13 12:20:26.961665	\N
69	90000.00	September	t	2025-10-04 10:59:58.790839	2025-10-01 14:04:27.126343	22	2025	pending	2025-11-13 12:20:26.962614	\N
71	90000.00	November	f	\N	2025-10-01 14:04:27.129184	22	2025	pending	2025-11-13 12:20:26.96434	\N
72	90000.00	December	f	\N	2025-10-01 14:04:27.130096	22	2025	pending	2025-11-13 12:20:26.9651	\N
73	100000.00	January	f	\N	2025-10-01 14:04:59.555404	35	2025	pending	2025-11-13 12:20:42.136349	\N
74	100000.00	February	f	\N	2025-10-01 14:04:59.557152	35	2025	pending	2025-11-13 12:20:42.138587	\N
75	100000.00	March	f	\N	2025-10-01 14:04:59.559901	35	2025	pending	2025-11-13 12:20:42.139757	\N
76	100000.00	April	f	\N	2025-10-01 14:04:59.561345	35	2025	pending	2025-11-13 12:20:42.141663	\N
78	100000.00	June	f	\N	2025-10-01 14:04:59.565567	35	2025	pending	2025-11-13 12:20:42.148067	\N
79	100000.00	July	f	\N	2025-10-01 14:04:59.567818	35	2025	pending	2025-11-13 12:20:42.149091	\N
80	100000.00	August	f	\N	2025-10-01 14:04:59.568786	35	2025	pending	2025-11-13 12:20:42.150951	\N
81	100000.00	September	t	2025-10-04 11:00:23.904707	2025-10-01 14:04:59.569593	35	2025	pending	2025-11-13 12:20:42.151861	\N
83	100000.00	November	f	\N	2025-10-01 14:04:59.571226	35	2025	pending	2025-11-13 12:20:42.153476	\N
84	100000.00	December	f	\N	2025-10-01 14:04:59.572496	35	2025	pending	2025-11-13 12:20:42.154436	\N
85	80000.00	January	f	\N	2025-10-01 14:05:19.492343	24	2025	pending	2025-11-13 12:20:57.634095	\N
86	80000.00	February	f	\N	2025-10-01 14:05:19.494092	24	2025	pending	2025-11-13 12:20:57.636265	\N
87	80000.00	March	f	\N	2025-10-01 14:05:19.495017	24	2025	pending	2025-11-13 12:20:57.639729	\N
88	80000.00	April	f	\N	2025-10-01 14:05:19.49598	24	2025	pending	2025-11-13 12:20:57.64144	\N
89	80000.00	May	f	\N	2025-10-01 14:05:19.496993	24	2025	pending	2025-11-13 12:20:57.644024	\N
90	80000.00	June	f	\N	2025-10-01 14:05:19.498004	24	2025	pending	2025-11-13 12:20:57.644975	\N
2	110000.00	February	f	\N	2025-10-01 13:51:45.058541	6	2025	pending	2025-11-13 12:25:51.75093	\N
119	80000.00	October	t	2025-11-13 12:36:51.592177	2025-10-01 14:06:06.193032	26	2025	pending	2025-11-13 12:36:51.592177	\N
131	100000.00	October	t	2025-11-13 12:37:11.265947	2025-10-01 14:06:41.933367	13	2025	pending	2025-11-13 12:37:11.265947	\N
143	80000.00	October	t	2025-11-13 12:37:31.345542	2025-10-01 14:07:24.600023	18	2025	pending	2025-11-13 12:37:31.345542	\N
155	60000.00	October	t	2025-11-13 12:38:11.0867	2025-10-01 14:08:24.503022	12	2025	pending	2025-11-13 12:38:11.0867	\N
167	175000.00	October	t	2025-11-13 12:39:24.871408	2025-10-01 14:09:22.086295	33	2025	pending	2025-11-13 12:39:24.871408	\N
179	80000.00	October	t	2025-11-13 12:39:44.625949	2025-10-01 14:09:39.38324	19	2025	pending	2025-11-13 12:39:44.625949	\N
91	80000.00	July	f	\N	2025-10-01 14:05:19.49884	24	2025	pending	2025-11-13 12:20:57.646109	\N
92	80000.00	August	f	\N	2025-10-01 14:05:19.500429	24	2025	pending	2025-11-13 12:20:57.647563	\N
93	80000.00	September	t	2025-10-04 11:01:01.917165	2025-10-01 14:05:19.501206	24	2025	pending	2025-11-13 12:20:57.648651	\N
95	80000.00	November	f	\N	2025-10-01 14:05:19.502895	24	2025	pending	2025-11-13 12:20:57.650382	\N
96	80000.00	December	f	\N	2025-10-01 14:05:19.503938	24	2025	pending	2025-11-13 12:20:57.652449	\N
97	70000.00	January	f	\N	2025-10-01 14:05:38.212579	20	2025	pending	2025-11-13 12:21:16.23237	\N
99	70000.00	March	f	\N	2025-10-01 14:05:38.217221	20	2025	pending	2025-11-13 12:21:16.235851	\N
100	70000.00	April	f	\N	2025-10-01 14:05:38.218136	20	2025	pending	2025-11-13 12:21:16.236691	\N
101	70000.00	May	f	\N	2025-10-01 14:05:38.219609	20	2025	pending	2025-11-13 12:21:16.237519	\N
102	70000.00	June	f	\N	2025-10-01 14:05:38.221044	20	2025	pending	2025-11-13 12:21:16.238213	\N
103	70000.00	July	f	\N	2025-10-01 14:05:38.222633	20	2025	pending	2025-11-13 12:21:16.239074	\N
104	70000.00	August	f	\N	2025-10-01 14:05:38.22355	20	2025	pending	2025-11-13 12:21:16.239871	\N
105	70000.00	September	t	2025-10-04 11:01:21.259657	2025-10-01 14:05:38.224744	20	2025	pending	2025-11-13 12:21:16.240704	\N
107	70000.00	November	f	\N	2025-10-01 14:05:38.227066	20	2025	pending	2025-11-13 12:21:16.242308	\N
108	70000.00	December	f	\N	2025-10-01 14:05:38.228897	20	2025	pending	2025-11-13 12:21:16.243196	\N
109	80000.00	January	f	\N	2025-10-01 14:06:06.164277	26	2025	pending	2025-11-13 12:22:27.555345	\N
111	80000.00	February	f	\N	2025-10-01 14:06:06.170377	26	2025	pending	2025-11-13 12:22:27.556749	\N
112	80000.00	March	f	\N	2025-10-01 14:06:06.182707	26	2025	pending	2025-11-13 12:22:27.557738	\N
113	80000.00	April	f	\N	2025-10-01 14:06:06.184922	26	2025	pending	2025-11-13 12:22:27.558685	\N
114	80000.00	May	f	\N	2025-10-01 14:06:06.186898	26	2025	pending	2025-11-13 12:22:27.559579	\N
115	80000.00	June	f	\N	2025-10-01 14:06:06.189933	26	2025	pending	2025-11-13 12:22:27.560549	\N
116	80000.00	July	f	\N	2025-10-01 14:06:06.190761	26	2025	pending	2025-11-13 12:22:27.561409	\N
117	80000.00	August	f	\N	2025-10-01 14:06:06.1915	26	2025	pending	2025-11-13 12:22:27.562237	\N
118	80000.00	September	t	2025-10-04 11:02:10.161382	2025-10-01 14:06:06.192256	26	2025	pending	2025-11-13 12:22:27.562978	\N
120	80000.00	November	f	\N	2025-10-01 14:06:06.193904	26	2025	pending	2025-11-13 12:22:27.564644	\N
121	80000.00	December	f	\N	2025-10-01 14:06:06.194639	26	2025	pending	2025-11-13 12:22:27.565505	\N
122	100000.00	January	f	\N	2025-10-01 14:06:41.924394	13	2025	pending	2025-11-13 12:22:50.770438	\N
123	100000.00	February	f	\N	2025-10-01 14:06:41.925929	13	2025	pending	2025-11-13 12:22:50.771997	\N
124	100000.00	March	f	\N	2025-10-01 14:06:41.926919	13	2025	pending	2025-11-13 12:22:50.773123	\N
125	100000.00	April	f	\N	2025-10-01 14:06:41.927791	13	2025	pending	2025-11-13 12:22:50.773863	\N
126	100000.00	May	f	\N	2025-10-01 14:06:41.92866	13	2025	pending	2025-11-13 12:22:50.77463	\N
127	100000.00	June	f	\N	2025-10-01 14:06:41.930123	13	2025	pending	2025-11-13 12:22:50.775409	\N
128	100000.00	July	f	\N	2025-10-01 14:06:41.930919	13	2025	pending	2025-11-13 12:22:50.776213	\N
129	100000.00	August	f	\N	2025-10-01 14:06:41.931831	13	2025	pending	2025-11-13 12:22:50.777213	\N
132	100000.00	November	f	\N	2025-10-01 14:06:41.934102	13	2025	pending	2025-11-13 12:22:50.779733	\N
133	100000.00	December	f	\N	2025-10-01 14:06:41.934881	13	2025	pending	2025-11-13 12:22:50.780556	\N
134	80000.00	January	f	\N	2025-10-01 14:07:24.586455	18	2025	pending	2025-11-13 12:23:10.479147	\N
135	80000.00	February	f	\N	2025-10-01 14:07:24.589868	18	2025	pending	2025-11-13 12:23:10.480953	\N
136	80000.00	March	f	\N	2025-10-01 14:07:24.593603	18	2025	pending	2025-11-13 12:23:10.483184	\N
137	80000.00	April	f	\N	2025-10-01 14:07:24.594561	18	2025	pending	2025-11-13 12:23:10.484227	\N
138	80000.00	May	f	\N	2025-10-01 14:07:24.595839	18	2025	pending	2025-11-13 12:23:10.485025	\N
139	80000.00	June	f	\N	2025-10-01 14:07:24.596671	18	2025	pending	2025-11-13 12:23:10.485782	\N
140	80000.00	July	f	\N	2025-10-01 14:07:24.597548	18	2025	pending	2025-11-13 12:23:10.486642	\N
141	80000.00	August	f	\N	2025-10-01 14:07:24.598244	18	2025	pending	2025-11-13 12:23:10.487416	\N
142	80000.00	September	t	2025-10-04 11:02:55.030685	2025-10-01 14:07:24.599258	18	2025	pending	2025-11-13 12:23:10.488138	\N
144	80000.00	November	f	\N	2025-10-01 14:07:24.600753	18	2025	pending	2025-11-13 12:23:10.489757	\N
145	80000.00	December	f	\N	2025-10-01 14:07:24.601802	18	2025	pending	2025-11-13 12:23:10.490801	\N
146	60000.00	January	f	\N	2025-10-01 14:08:24.48605	12	2025	pending	2025-11-13 12:23:25.938481	\N
147	60000.00	February	f	\N	2025-10-01 14:08:24.495027	12	2025	pending	2025-11-13 12:23:25.939763	\N
148	60000.00	March	f	\N	2025-10-01 14:08:24.497674	12	2025	pending	2025-11-13 12:23:25.940619	\N
149	60000.00	April	f	\N	2025-10-01 14:08:24.498461	12	2025	pending	2025-11-13 12:23:25.94144	\N
150	60000.00	May	f	\N	2025-10-01 14:08:24.49921	12	2025	pending	2025-11-13 12:23:25.942218	\N
151	60000.00	June	f	\N	2025-10-01 14:08:24.499951	12	2025	pending	2025-11-13 12:23:25.943125	\N
152	60000.00	July	f	\N	2025-10-01 14:08:24.500732	12	2025	pending	2025-11-13 12:23:25.943911	\N
153	60000.00	August	f	\N	2025-10-01 14:08:24.501456	12	2025	pending	2025-11-13 12:23:25.945427	\N
154	60000.00	September	t	2025-10-04 11:03:28.043031	2025-10-01 14:08:24.502243	12	2025	pending	2025-11-13 12:23:25.946407	\N
156	60000.00	November	f	\N	2025-10-01 14:08:24.503745	12	2025	pending	2025-11-13 12:23:25.948182	\N
157	60000.00	December	f	\N	2025-10-01 14:08:24.504471	12	2025	pending	2025-11-13 12:23:25.949048	\N
158	175000.00	January	f	\N	2025-10-01 14:09:22.076699	33	2025	pending	2025-11-13 12:24:26.976941	\N
159	175000.00	February	f	\N	2025-10-01 14:09:22.079113	33	2025	pending	2025-11-13 12:24:26.979127	\N
161	175000.00	April	f	\N	2025-10-01 14:09:22.081065	33	2025	pending	2025-11-13 12:24:26.98203	\N
162	175000.00	May	f	\N	2025-10-01 14:09:22.0819	33	2025	pending	2025-11-13 12:24:26.982911	\N
163	175000.00	June	f	\N	2025-10-01 14:09:22.08285	33	2025	pending	2025-11-13 12:24:26.98582	\N
164	175000.00	July	f	\N	2025-10-01 14:09:22.083696	33	2025	pending	2025-11-13 12:24:26.986708	\N
165	175000.00	August	f	\N	2025-10-01 14:09:22.084517	33	2025	pending	2025-11-13 12:24:26.987474	\N
168	175000.00	November	f	\N	2025-10-01 14:09:22.087113	33	2025	pending	2025-11-13 12:24:26.989816	\N
169	175000.00	December	f	\N	2025-10-01 14:09:22.087927	33	2025	pending	2025-11-13 12:24:26.990583	\N
170	80000.00	January	f	\N	2025-10-01 14:09:39.367771	19	2025	pending	2025-11-13 12:25:02.743475	\N
171	80000.00	February	f	\N	2025-10-01 14:09:39.370431	19	2025	pending	2025-11-13 12:25:02.745425	\N
172	80000.00	March	f	\N	2025-10-01 14:09:39.375528	19	2025	pending	2025-11-13 12:25:02.747279	\N
173	80000.00	April	f	\N	2025-10-01 14:09:39.377989	19	2025	pending	2025-11-13 12:25:02.748231	\N
174	80000.00	May	f	\N	2025-10-01 14:09:39.379032	19	2025	pending	2025-11-13 12:25:02.749232	\N
175	80000.00	June	f	\N	2025-10-01 14:09:39.379829	19	2025	pending	2025-11-13 12:25:02.750168	\N
176	80000.00	July	f	\N	2025-10-01 14:09:39.380648	19	2025	pending	2025-11-13 12:25:02.752498	\N
177	80000.00	August	f	\N	2025-10-01 14:09:39.381441	19	2025	pending	2025-11-13 12:25:02.753615	\N
178	80000.00	September	t	2025-10-04 11:03:51.308189	2025-10-01 14:09:39.382195	19	2025	pending	2025-11-13 12:25:02.756346	\N
180	80000.00	November	f	\N	2025-10-01 14:09:39.383976	19	2025	pending	2025-11-13 12:25:02.759857	\N
181	80000.00	December	f	\N	2025-10-01 14:09:39.384755	19	2025	pending	2025-11-13 12:25:02.760828	\N
94	80000.00	October	t	2025-11-13 12:32:34.878004	2025-10-01 14:05:19.502113	24	2025	pending	2025-11-13 12:32:34.878004	\N
240	110000.00	November	f	\N	2025-10-01 14:12:53.014809	4	2025	pending	2025-11-13 12:27:30.153758	\N
239	110000.00	October	t	2025-11-13 12:43:08.77761	2025-10-01 14:12:53.013863	4	2025	pending	2025-11-13 12:43:08.77761	\N
251	120000.00	October	t	2025-11-13 12:43:34.550904	2025-10-01 14:13:21.680397	17	2025	pending	2025-11-13 12:43:34.550904	\N
182	250000.00	January	f	\N	2025-10-01 14:10:39.471908	7	2025	pending	2025-11-13 12:25:25.544752	\N
252	120000.00	November	f	\N	2025-10-01 14:13:21.681055	17	2025	pending	2025-11-13 12:27:47.883688	\N
183	250000.00	February	f	\N	2025-10-01 14:10:39.473959	7	2025	pending	2025-11-13 12:25:25.551166	\N
184	250000.00	March	f	\N	2025-10-01 14:10:39.475007	7	2025	pending	2025-11-13 12:25:25.55226	\N
185	250000.00	April	f	\N	2025-10-01 14:10:39.476043	7	2025	pending	2025-11-13 12:25:25.553776	\N
186	250000.00	May	f	\N	2025-10-01 14:10:39.477006	7	2025	pending	2025-11-13 12:25:25.554866	\N
187	250000.00	June	f	\N	2025-10-01 14:10:39.478096	7	2025	pending	2025-11-13 12:25:25.555824	\N
188	250000.00	July	f	\N	2025-10-01 14:10:39.480505	7	2025	pending	2025-11-13 12:25:25.556844	\N
189	250000.00	August	f	\N	2025-10-01 14:10:39.482235	7	2025	pending	2025-11-13 12:25:25.557737	\N
203	70000.00	October	t	2025-11-13 12:41:15.911258	2025-10-01 14:11:23.363979	3	2025	pending	2025-11-13 12:41:15.911258	\N
192	250000.00	November	f	\N	2025-10-01 14:10:39.485944	7	2025	pending	2025-11-13 12:25:25.560158	\N
193	250000.00	December	f	\N	2025-10-01 14:10:39.486788	7	2025	pending	2025-11-13 12:25:25.56112	\N
194	70000.00	January	f	\N	2025-10-01 14:11:23.35461	3	2025	pending	2025-11-13 12:26:18.308345	\N
195	70000.00	February	f	\N	2025-10-01 14:11:23.356451	3	2025	pending	2025-11-13 12:26:18.31003	\N
196	70000.00	March	f	\N	2025-10-01 14:11:23.357536	3	2025	pending	2025-11-13 12:26:18.313477	\N
197	70000.00	April	f	\N	2025-10-01 14:11:23.358488	3	2025	pending	2025-11-13 12:26:18.314278	\N
198	70000.00	May	f	\N	2025-10-01 14:11:23.35937	3	2025	pending	2025-11-13 12:26:18.315779	\N
199	70000.00	June	f	\N	2025-10-01 14:11:23.360313	3	2025	pending	2025-11-13 12:26:18.316817	\N
200	70000.00	July	f	\N	2025-10-01 14:11:23.361247	3	2025	pending	2025-11-13 12:26:18.317583	\N
201	70000.00	August	f	\N	2025-10-01 14:11:23.362059	3	2025	pending	2025-11-13 12:26:18.318402	\N
202	70000.00	September	t	2025-10-04 11:04:31.163751	2025-10-01 14:11:23.362962	3	2025	pending	2025-11-13 12:26:18.319199	\N
204	70000.00	November	f	\N	2025-10-01 14:11:23.364858	3	2025	pending	2025-11-13 12:26:18.320893	\N
205	70000.00	December	f	\N	2025-10-01 14:11:23.365747	3	2025	pending	2025-11-13 12:26:18.321668	\N
218	50000.00	January	f	\N	2025-10-01 14:12:28.330119	23	2025	pending	2025-11-13 12:27:16.835314	\N
219	50000.00	February	f	\N	2025-10-01 14:12:28.331976	23	2025	pending	2025-11-13 12:27:16.836579	\N
220	50000.00	March	f	\N	2025-10-01 14:12:28.333126	23	2025	pending	2025-11-13 12:27:16.837424	\N
221	50000.00	April	f	\N	2025-10-01 14:12:28.334004	23	2025	pending	2025-11-13 12:27:16.838175	\N
222	50000.00	May	f	\N	2025-10-01 14:12:28.334878	23	2025	pending	2025-11-13 12:27:16.838926	\N
223	50000.00	June	f	\N	2025-10-01 14:12:28.336021	23	2025	pending	2025-11-13 12:27:16.839764	\N
224	50000.00	July	f	\N	2025-10-01 14:12:28.33686	23	2025	pending	2025-11-13 12:27:16.840552	\N
225	50000.00	August	f	\N	2025-10-01 14:12:28.337713	23	2025	pending	2025-11-13 12:27:16.84124	\N
226	50000.00	September	t	2025-10-04 11:04:50.915015	2025-10-01 14:12:28.338583	23	2025	pending	2025-11-13 12:27:16.842049	\N
228	50000.00	November	f	\N	2025-10-01 14:12:28.340333	23	2025	pending	2025-11-13 12:27:16.843932	\N
229	50000.00	December	f	\N	2025-10-01 14:12:28.34101	23	2025	pending	2025-11-13 12:27:16.844741	\N
230	110000.00	January	f	\N	2025-10-01 14:12:52.999836	4	2025	pending	2025-11-13 12:27:30.14034	\N
231	110000.00	February	f	\N	2025-10-01 14:12:53.00402	4	2025	pending	2025-11-13 12:27:30.14312	\N
232	110000.00	March	f	\N	2025-10-01 14:12:53.005839	4	2025	pending	2025-11-13 12:27:30.145569	\N
233	110000.00	April	f	\N	2025-10-01 14:12:53.006948	4	2025	pending	2025-11-13 12:27:30.146625	\N
234	110000.00	May	f	\N	2025-10-01 14:12:53.007838	4	2025	pending	2025-11-13 12:27:30.148487	\N
235	110000.00	June	f	\N	2025-10-01 14:12:53.008919	4	2025	pending	2025-11-13 12:27:30.14941	\N
236	110000.00	July	f	\N	2025-10-01 14:12:53.009775	4	2025	pending	2025-11-13 12:27:30.150333	\N
237	110000.00	August	f	\N	2025-10-01 14:12:53.011759	4	2025	pending	2025-11-13 12:27:30.15124	\N
238	110000.00	September	t	2025-10-01 14:34:00.016738	2025-10-01 14:12:53.013054	4	2025	pending	2025-11-13 12:27:30.152088	\N
263	120000.00	October	t	2025-11-13 12:44:12.711349	2025-10-01 14:13:48.090171	34	2025	pending	2025-11-13 12:44:12.711349	\N
241	110000.00	December	f	\N	2025-10-01 14:12:53.015753	4	2025	pending	2025-11-13 12:27:30.154579	\N
242	120000.00	January	f	\N	2025-10-01 14:13:21.668605	17	2025	pending	2025-11-13 12:27:47.869071	\N
243	120000.00	February	f	\N	2025-10-01 14:13:21.670461	17	2025	pending	2025-11-13 12:27:47.871513	\N
244	120000.00	March	f	\N	2025-10-01 14:13:21.671625	17	2025	pending	2025-11-13 12:27:47.873119	\N
245	120000.00	April	f	\N	2025-10-01 14:13:21.673434	17	2025	pending	2025-11-13 12:27:47.876492	\N
246	120000.00	May	f	\N	2025-10-01 14:13:21.674507	17	2025	pending	2025-11-13 12:27:47.877257	\N
247	120000.00	June	f	\N	2025-10-01 14:13:21.675662	17	2025	pending	2025-11-13 12:27:47.879367	\N
248	120000.00	July	f	\N	2025-10-01 14:13:21.677292	17	2025	pending	2025-11-13 12:27:47.880668	\N
249	120000.00	August	f	\N	2025-10-01 14:13:21.678573	17	2025	pending	2025-11-13 12:27:47.881522	\N
250	120000.00	September	t	2025-10-04 11:05:51.225883	2025-10-01 14:13:21.679464	17	2025	pending	2025-11-13 12:27:47.882287	\N
253	120000.00	December	f	\N	2025-10-01 14:13:21.681771	17	2025	pending	2025-11-13 12:27:47.884398	\N
254	120000.00	January	f	\N	2025-10-01 14:13:48.077586	34	2025	pending	2025-11-13 12:28:03.029771	\N
255	120000.00	February	f	\N	2025-10-01 14:13:48.079931	34	2025	pending	2025-11-13 12:28:03.031714	\N
256	120000.00	March	f	\N	2025-10-01 14:13:48.08171	34	2025	pending	2025-11-13 12:28:03.032602	\N
257	120000.00	April	f	\N	2025-10-01 14:13:48.082518	34	2025	pending	2025-11-13 12:28:03.033514	\N
258	120000.00	May	f	\N	2025-10-01 14:13:48.085482	34	2025	pending	2025-11-13 12:28:03.034359	\N
259	120000.00	June	f	\N	2025-10-01 14:13:48.086756	34	2025	pending	2025-11-13 12:28:03.036736	\N
260	120000.00	July	f	\N	2025-10-01 14:13:48.087674	34	2025	pending	2025-11-13 12:28:03.03805	\N
261	120000.00	August	f	\N	2025-10-01 14:13:48.08848	34	2025	pending	2025-11-13 12:28:03.04045	\N
262	120000.00	September	t	2025-10-04 11:06:15.305182	2025-10-01 14:13:48.089381	34	2025	pending	2025-11-13 12:28:03.042639	\N
264	120000.00	November	f	\N	2025-10-01 14:13:48.091521	34	2025	pending	2025-11-13 12:28:03.044607	\N
265	120000.00	December	f	\N	2025-10-01 14:13:48.093657	34	2025	pending	2025-11-13 12:28:03.045474	\N
266	100000.00	January	f	\N	2025-10-01 14:14:11.142796	15	2025	pending	2025-11-13 12:28:35.867333	\N
267	100000.00	February	f	\N	2025-10-01 14:14:11.146708	15	2025	pending	2025-11-13 12:28:35.869413	\N
268	100000.00	March	f	\N	2025-10-01 14:14:11.148908	15	2025	pending	2025-11-13 12:28:35.870439	\N
269	100000.00	April	f	\N	2025-10-01 14:14:11.150069	15	2025	pending	2025-11-13 12:28:35.872755	\N
270	100000.00	May	f	\N	2025-10-01 14:14:11.15109	15	2025	pending	2025-11-13 12:28:35.874682	\N
271	100000.00	June	f	\N	2025-10-01 14:14:11.15203	15	2025	pending	2025-11-13 12:28:35.875677	\N
191	250000.00	October	t	2025-11-13 12:40:08.102486	2025-10-01 14:10:39.484873	7	2025	pending	2025-11-13 12:40:08.102486	\N
227	50000.00	October	t	2025-11-13 12:42:42.89801	2025-10-01 14:12:28.339377	23	2025	pending	2025-11-13 12:42:42.89801	\N
285	100000.00	August	f	\N	2025-10-04 11:07:01.911204	38	2025	pending	2025-11-13 12:26:36.145399	\N
286	100000.00	September	t	2025-10-04 11:09:03.950567	2025-10-04 11:07:01.912357	38	2025	pending	2025-11-13 12:26:36.146926	\N
275	100000.00	October	t	2025-11-13 12:44:34.596099	2025-10-01 14:14:11.15753	15	2025	pending	2025-11-13 12:44:34.596099	\N
288	100000.00	November	f	\N	2025-10-04 11:07:01.914511	38	2025	pending	2025-11-13 12:26:36.149478	\N
336	35000.00	October	t	2025-11-13 12:35:57.586142	2025-11-13 12:33:59.521733	47	2025	pending	2025-11-13 12:35:57.586142	\N
289	100000.00	December	f	\N	2025-10-04 11:07:01.91835	38	2025	pending	2025-11-13 12:26:36.150495	\N
299	70000.00	October	t	2025-11-13 12:36:18.190538	2025-10-04 11:08:19.517768	37	2025	pending	2025-11-13 12:36:18.190538	\N
77	100000.00	May	f	\N	2025-10-01 14:04:59.56434	35	2025	pending	2025-11-13 12:20:42.14289	\N
98	70000.00	February	f	\N	2025-10-01 14:05:38.215196	20	2025	pending	2025-11-13 12:21:16.233966	\N
302	80000.00	January	f	\N	2025-11-13 12:21:52.49008	42	2025	pending	2025-11-13 12:21:52.49008	\N
303	80000.00	February	f	\N	2025-11-13 12:21:52.494739	42	2025	pending	2025-11-13 12:21:52.494739	\N
304	80000.00	March	f	\N	2025-11-13 12:21:52.495959	42	2025	pending	2025-11-13 12:21:52.495959	\N
305	80000.00	April	f	\N	2025-11-13 12:21:52.496751	42	2025	pending	2025-11-13 12:21:52.496751	\N
306	80000.00	May	f	\N	2025-11-13 12:21:52.497509	42	2025	pending	2025-11-13 12:21:52.497509	\N
307	80000.00	June	f	\N	2025-11-13 12:21:52.498441	42	2025	pending	2025-11-13 12:21:52.498441	\N
308	80000.00	July	f	\N	2025-11-13 12:21:52.499383	42	2025	pending	2025-11-13 12:21:52.499383	\N
309	80000.00	August	f	\N	2025-11-13 12:21:52.500186	42	2025	pending	2025-11-13 12:21:52.500186	\N
310	80000.00	September	f	\N	2025-11-13 12:21:52.501003	42	2025	pending	2025-11-13 12:21:52.501003	\N
312	80000.00	November	f	\N	2025-11-13 12:21:52.502523	42	2025	pending	2025-11-13 12:21:52.502523	\N
313	80000.00	December	f	\N	2025-11-13 12:21:52.503316	42	2025	pending	2025-11-13 12:21:52.503316	\N
290	70000.00	January	f	\N	2025-10-04 11:08:19.503958	37	2025	pending	2025-11-13 12:22:09.36245	\N
291	70000.00	February	f	\N	2025-10-04 11:08:19.506954	37	2025	pending	2025-11-13 12:22:09.363844	\N
292	70000.00	March	f	\N	2025-10-04 11:08:19.508108	37	2025	pending	2025-11-13 12:22:09.364746	\N
293	70000.00	April	f	\N	2025-10-04 11:08:19.509041	37	2025	pending	2025-11-13 12:22:09.365548	\N
294	70000.00	May	f	\N	2025-10-04 11:08:19.511655	37	2025	pending	2025-11-13 12:22:09.366333	\N
295	70000.00	June	f	\N	2025-10-04 11:08:19.512679	37	2025	pending	2025-11-13 12:22:09.367114	\N
296	70000.00	July	f	\N	2025-10-04 11:08:19.514052	37	2025	pending	2025-11-13 12:22:09.367878	\N
297	70000.00	August	f	\N	2025-10-04 11:08:19.515716	37	2025	pending	2025-11-13 12:22:09.368661	\N
298	70000.00	September	t	2025-10-04 11:08:37.425754	2025-10-04 11:08:19.51678	37	2025	pending	2025-11-13 12:22:09.369442	\N
300	70000.00	November	f	\N	2025-10-04 11:08:19.518889	37	2025	pending	2025-11-13 12:22:09.371035	\N
301	70000.00	December	f	\N	2025-10-04 11:08:19.519901	37	2025	pending	2025-11-13 12:22:09.3718	\N
130	100000.00	September	t	2025-10-04 11:02:33.27167	2025-10-01 14:06:41.932596	13	2025	pending	2025-11-13 12:22:50.778077	\N
160	175000.00	March	f	\N	2025-10-01 14:09:22.080124	33	2025	pending	2025-11-13 12:24:26.980166	\N
166	175000.00	September	t	2025-10-01 14:37:29.902689	2025-10-01 14:09:22.085241	33	2025	pending	2025-11-13 12:24:26.988217	\N
190	250000.00	September	t	2025-10-01 14:22:26.988119	2025-10-01 14:10:39.483917	7	2025	pending	2025-11-13 12:25:25.558528	\N
1	110000.00	January	f	\N	2025-10-01 13:51:45.052024	6	2025	pending	2025-11-13 12:25:51.748868	\N
6	110000.00	June	f	\N	2025-10-01 13:51:45.062482	6	2025	pending	2025-11-13 12:25:51.754813	\N
314	110000.00	December	f	\N	2025-11-13 12:25:51.762243	6	2025	pending	2025-11-13 12:25:51.762243	\N
278	100000.00	January	f	\N	2025-10-04 11:07:01.895589	38	2025	pending	2025-11-13 12:26:36.134343	\N
279	100000.00	February	f	\N	2025-10-04 11:07:01.903137	38	2025	pending	2025-11-13 12:26:36.135617	\N
280	100000.00	March	f	\N	2025-10-04 11:07:01.904482	38	2025	pending	2025-11-13 12:26:36.138341	\N
281	100000.00	April	f	\N	2025-10-04 11:07:01.905782	38	2025	pending	2025-11-13 12:26:36.139128	\N
282	100000.00	May	f	\N	2025-10-04 11:07:01.906965	38	2025	pending	2025-11-13 12:26:36.140459	\N
283	100000.00	June	f	\N	2025-10-04 11:07:01.908262	38	2025	pending	2025-11-13 12:26:36.141218	\N
284	100000.00	July	f	\N	2025-10-04 11:07:01.909306	38	2025	pending	2025-11-13 12:26:36.142944	\N
315	100000.00	January	f	\N	2025-11-13 12:26:56.303345	41	2025	pending	2025-11-13 12:26:56.303345	\N
316	100000.00	February	f	\N	2025-11-13 12:26:56.304968	41	2025	pending	2025-11-13 12:26:56.304968	\N
317	100000.00	March	f	\N	2025-11-13 12:26:56.305852	41	2025	pending	2025-11-13 12:26:56.305852	\N
318	100000.00	April	f	\N	2025-11-13 12:26:56.306797	41	2025	pending	2025-11-13 12:26:56.306797	\N
319	100000.00	May	f	\N	2025-11-13 12:26:56.308074	41	2025	pending	2025-11-13 12:26:56.308074	\N
320	100000.00	June	f	\N	2025-11-13 12:26:56.308939	41	2025	pending	2025-11-13 12:26:56.308939	\N
321	100000.00	July	f	\N	2025-11-13 12:26:56.309753	41	2025	pending	2025-11-13 12:26:56.309753	\N
322	100000.00	August	f	\N	2025-11-13 12:26:56.310551	41	2025	pending	2025-11-13 12:26:56.310551	\N
323	100000.00	September	f	\N	2025-11-13 12:26:56.311398	41	2025	pending	2025-11-13 12:26:56.311398	\N
325	100000.00	November	f	\N	2025-11-13 12:26:56.313665	41	2025	pending	2025-11-13 12:26:56.313665	\N
326	100000.00	December	f	\N	2025-11-13 12:26:56.314406	41	2025	pending	2025-11-13 12:26:56.314406	\N
272	100000.00	July	f	\N	2025-10-01 14:14:11.153045	15	2025	pending	2025-11-13 12:28:35.876536	\N
273	100000.00	August	f	\N	2025-10-01 14:14:11.155274	15	2025	pending	2025-11-13 12:28:35.877618	\N
274	100000.00	September	t	2025-10-04 11:06:30.547352	2025-10-01 14:14:11.156585	15	2025	pending	2025-11-13 12:28:35.878421	\N
276	100000.00	November	f	\N	2025-10-01 14:14:11.158465	15	2025	pending	2025-11-13 12:28:35.880225	\N
277	100000.00	December	f	\N	2025-10-01 14:14:11.159306	15	2025	pending	2025-11-13 12:28:35.881141	\N
82	100000.00	October	t	2025-11-13 12:32:16.474878	2025-10-01 14:04:59.570431	35	2025	pending	2025-11-13 12:32:16.474878	\N
106	70000.00	October	t	2025-11-13 12:33:08.630943	2025-10-01 14:05:38.226218	20	2025	pending	2025-11-13 12:33:08.630943	\N
311	80000.00	October	t	2025-11-13 12:33:27.920056	2025-11-13 12:21:52.501747	42	2025	pending	2025-11-13 12:33:27.920056	\N
327	35000.00	January	f	\N	2025-11-13 12:33:59.509568	47	2025	pending	2025-11-13 12:33:59.509568	\N
328	35000.00	February	f	\N	2025-11-13 12:33:59.512016	47	2025	pending	2025-11-13 12:33:59.512016	\N
329	35000.00	March	f	\N	2025-11-13 12:33:59.512949	47	2025	pending	2025-11-13 12:33:59.512949	\N
330	35000.00	April	f	\N	2025-11-13 12:33:59.514025	47	2025	pending	2025-11-13 12:33:59.514025	\N
331	35000.00	May	f	\N	2025-11-13 12:33:59.515226	47	2025	pending	2025-11-13 12:33:59.515226	\N
332	35000.00	June	f	\N	2025-11-13 12:33:59.516283	47	2025	pending	2025-11-13 12:33:59.516283	\N
333	35000.00	July	f	\N	2025-11-13 12:33:59.517413	47	2025	pending	2025-11-13 12:33:59.517413	\N
334	35000.00	August	f	\N	2025-11-13 12:33:59.518267	47	2025	pending	2025-11-13 12:33:59.518267	\N
335	35000.00	September	f	\N	2025-11-13 12:33:59.520572	47	2025	pending	2025-11-13 12:33:59.520572	\N
337	35000.00	November	f	\N	2025-11-13 12:33:59.522587	47	2025	pending	2025-11-13 12:33:59.522587	\N
287	100000.00	October	t	2025-11-13 12:41:40.905509	2025-10-04 11:07:01.913473	38	2025	pending	2025-11-13 12:41:40.905509	\N
324	100000.00	October	t	2025-11-13 12:42:04.122261	2025-11-13 12:26:56.312185	41	2025	pending	2025-11-13 12:42:04.122261	\N
338	35000.00	December	f	\N	2025-11-13 12:33:59.523474	47	2025	pending	2025-11-13 12:33:59.523474	\N
339	60000.00	January	f	\N	2025-11-13 12:34:57.096477	39	2025	pending	2025-11-13 12:34:57.096477	\N
340	60000.00	February	f	\N	2025-11-13 12:34:57.099898	39	2025	pending	2025-11-13 12:34:57.099898	\N
341	60000.00	March	f	\N	2025-11-13 12:34:57.100879	39	2025	pending	2025-11-13 12:34:57.100879	\N
342	60000.00	April	f	\N	2025-11-13 12:34:57.101761	39	2025	pending	2025-11-13 12:34:57.101761	\N
343	60000.00	May	f	\N	2025-11-13 12:34:57.10259	39	2025	pending	2025-11-13 12:34:57.10259	\N
344	60000.00	June	f	\N	2025-11-13 12:34:57.103399	39	2025	pending	2025-11-13 12:34:57.103399	\N
345	60000.00	July	f	\N	2025-11-13 12:34:57.104196	39	2025	pending	2025-11-13 12:34:57.104196	\N
346	60000.00	August	f	\N	2025-11-13 12:34:57.104971	39	2025	pending	2025-11-13 12:34:57.104971	\N
347	60000.00	September	f	\N	2025-11-13 12:34:57.105673	39	2025	pending	2025-11-13 12:34:57.105673	\N
349	60000.00	November	f	\N	2025-11-13 12:34:57.107221	39	2025	pending	2025-11-13 12:34:57.107221	\N
350	60000.00	December	f	\N	2025-11-13 12:34:57.107929	39	2025	pending	2025-11-13 12:34:57.107929	\N
351	80000.00	January	f	\N	2025-11-13 12:35:17.630447	44	2025	pending	2025-11-13 12:35:17.630447	\N
352	80000.00	February	f	\N	2025-11-13 12:35:17.63273	44	2025	pending	2025-11-13 12:35:17.63273	\N
353	80000.00	March	f	\N	2025-11-13 12:35:17.633767	44	2025	pending	2025-11-13 12:35:17.633767	\N
354	80000.00	April	f	\N	2025-11-13 12:35:17.636049	44	2025	pending	2025-11-13 12:35:17.636049	\N
355	80000.00	May	f	\N	2025-11-13 12:35:17.637399	44	2025	pending	2025-11-13 12:35:17.637399	\N
356	80000.00	June	f	\N	2025-11-13 12:35:17.638455	44	2025	pending	2025-11-13 12:35:17.638455	\N
357	80000.00	July	f	\N	2025-11-13 12:35:17.639615	44	2025	pending	2025-11-13 12:35:17.639615	\N
358	80000.00	August	f	\N	2025-11-13 12:35:17.640642	44	2025	pending	2025-11-13 12:35:17.640642	\N
359	80000.00	September	f	\N	2025-11-13 12:35:17.641643	44	2025	pending	2025-11-13 12:35:17.641643	\N
361	80000.00	November	f	\N	2025-11-13 12:35:17.643508	44	2025	pending	2025-11-13 12:35:17.643508	\N
362	80000.00	December	f	\N	2025-11-13 12:35:17.644336	44	2025	pending	2025-11-13 12:35:17.644336	\N
348	60000.00	October	t	2025-11-13 12:38:30.272235	2025-11-13 12:34:57.106461	39	2025	pending	2025-11-13 12:38:30.272235	\N
360	80000.00	October	t	2025-11-13 12:38:50.707694	2025-11-13 12:35:17.642651	44	2025	pending	2025-11-13 12:38:50.707694	\N
\.


--
-- Data for Name: salary_descriptions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.salary_descriptions (id, description, percentage, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: salary_payslip_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.salary_payslip_settings (id, settings, updated_at) FROM stdin;
\.


--
-- Data for Name: sequences; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sequences (id, name, order_number, academic_year_id, "createdAt", "updatedAt", term_id, "deletedAt") FROM stdin;
1	1st Sequence	1	1	2025-09-11 12:47:08.959+01	2025-09-11 12:47:08.959+01	1	\N
2	2nd Sequence	2	1	2025-09-11 12:47:08.959+01	2025-09-11 12:47:08.959+01	1	\N
3	3rd Sequence	3	1	2025-09-11 12:47:08.959+01	2025-09-11 12:47:08.959+01	2	\N
4	4th Sequence	4	1	2025-09-11 12:47:08.959+01	2025-09-11 12:47:08.959+01	2	\N
5	5th Sequence	5	1	2025-09-11 12:47:08.959+01	2025-09-11 12:47:08.959+01	3	\N
6	6th Sequence	6	1	2025-09-11 12:47:08.959+01	2025-09-11 12:47:08.959+01	3	\N
\.


--
-- Data for Name: specialties; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.specialties (id, name, abbreviation, created_at, "createdAt", "updatedAt") FROM stdin;
2	Civil Engineering 	CE	2025-09-11 12:15:34.86429	2025-09-11 13:15:34.86429+01	2025-09-11 13:15:34.86429+01
3	Electrical Engineering 	EE	2025-09-11 12:15:45.962079	2025-09-11 13:15:45.962079+01	2025-09-11 13:15:45.962079+01
5	Mechanical Engineering 	ME	2025-09-11 12:16:12.847848	2025-09-11 13:16:12.847848+01	2025-09-11 13:16:12.847848+01
6	Health Care Engineering 	HCE	2025-09-11 12:16:59.386917	2025-09-11 13:16:59.386917+01	2025-09-11 13:16:59.386917+01
8	COMMERCIAL 	COMM	2025-09-17 19:39:04.477825	2025-09-17 20:39:04.477825+01	2025-09-17 20:39:04.477825+01
10	Science	SCI	2025-09-24 19:55:03.278709	2025-09-24 20:55:03.278709+01	2025-09-24 20:55:03.278709+01
4	Textile Engineering 	TE	2025-09-11 12:16:00.887451	2025-09-11 13:16:00.887451+01	2025-09-11 13:16:00.887451+01
1	General 	GEN	2025-09-11 12:15:17.938841	2025-09-11 13:15:17.938841+01	2025-09-11 13:15:17.938841+01
9	Language	LANG	2025-09-24 19:54:26.721004	2025-09-24 20:54:26.721004+01	2025-09-24 20:54:26.721004+01
\.


--
-- Data for Name: specialty_classes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.specialty_classes (id, specialty_id, class_id) FROM stdin;
\.


--
-- Data for Name: staff_attendance_records; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.staff_attendance_records (id, date, staff_name, time_in, time_out, classes_taught, status, created_at, updated_at) FROM stdin;
1	2025-10-14	ABU ROSE MENNYI	07:30:00	03:30:00	ORIENTATION LEVEL, CERTIFICATION LEVEL TWO TE	Present	2025-09-15 09:49:18.531395	2025-10-29 18:33:27.410114
9	2025-10-14	MILLA JOHN-PAUL TEBAH	19:45:00	16:20:00	ATVEE EPS, ITVEE EPS	Present	2025-10-29 18:43:53.935014	2025-10-29 18:43:53.935014
10	2025-10-14	Gebuin Bless Yuknwi	20:41:00	15:30:00	ATVEE BC, ITVEE BC	Present	2025-10-29 18:46:09.313538	2025-10-29 18:46:09.313538
11	2025-10-14	DJIMO DJOMO BEN COLLINS	20:20:00	16:00:00	ATVEE EPS, ITVEE EPS, CERTIFICATION LEVEL TWO EE	Present	2025-10-29 18:49:38.557764	2025-10-29 18:49:38.557764
14	2025-10-14	Manka'a Carine Awah	20:00:00	15:30:00	ORIENTATION LEVEL A, ORIENTATION LEVEL B, CERTIFICATION LEVEL ONE EE, CERTIFICATION LEVEL ONE HCE, CERTIFICATION LEVEL ONE ME, CERTIFICATION LEVEL ONE TEX, CERTIFICATION LEVEL ONE CE	Present	2025-10-29 18:59:31.454362	2025-10-29 19:00:49.133139
18	2025-10-15	Chem Sandra Ntala	19:21:00	15:40:00	ORIENTATION LEVEL A, ORIENTATION LEVEL B, CERTIFICATION LEVEL ONE TEX, CERTIFICATION LEVEL ONE ME, CERTIFICATION LEVEL ONE HCE, CERTIFICATION LEVEL ONE EE, CERTIFICATION LEVEL ONE CE	Present	2025-10-29 19:14:48.710002	2025-10-29 19:14:48.710002
21	2025-10-15	ABU ROSE MENNYI	19:30:00	16:00:00	ITVEE TE, CERTIFICATION LEVEL TWO TE	Present	2025-10-29 19:22:00.536617	2025-10-29 19:22:00.536617
22	2025-10-15	MILLA JOHN-PAUL TEBAH	19:45:00	15:54:00	ITVEE EPS, CERTIFICATION LEVEL TWO EE	Present	2025-10-29 19:24:25.672872	2025-10-29 19:24:25.672872
23	2025-10-15	DJIMO DJOMO BEN COLLINS	20:00:00	13:00:00	ITVEE EPS, CERTIFICATION LEVEL TWO TE, CERTIFICATION LEVEL TWO ME, CERTIFICATION LEVEL TWO HCE, CERTIFICATION LEVEL TWO EE, CERTIFICATION LEVEL TWO CE	Present	2025-10-31 12:54:18.266742	2025-10-31 12:54:18.266742
25	2025-10-15	Ngah Divine 	19:30:00	17:00:00	ORIENTATION LEVEL A, ORIENTATION LEVEL B	Present	2025-10-31 12:57:11.12092	2025-10-31 12:57:11.12092
24	2025-10-15	Emile Awah	08:05:00	14:40:00	ATVEE AMR, ATVEE BC, ATVEE COMM, ATVEE EPS, CERTIFICATION LEVEL ONE CE, CERTIFICATION LEVEL ONE EE, CERTIFICATION LEVEL ONE HCE, CERTIFICATION LEVEL ONE ME, CERTIFICATION LEVEL ONE TEX	Present	2025-10-31 12:56:06.844707	2025-10-31 13:04:53.51834
26	2025-10-15	Gebuin Bless Yuknwi	08:25:00	16:08:00	ATVEE BC, ITVEE BC	Present	2025-10-31 12:58:23.302081	2025-10-31 13:05:25.401172
20	2025-10-15	Mafain Alice Bih	07:27:00	16:00:00	ATVEE COMM, CERTIFICATION LEVEL ONE TEX, CERTIFICATION LEVEL ONE ME, CERTIFICATION LEVEL ONE HCE, CERTIFICATION LEVEL ONE EE, CERTIFICATION LEVEL ONE CE	Present	2025-10-29 19:18:42.051348	2025-10-31 13:05:50.350646
19	2025-10-15	Manka'a Carine Awah	07:27:00	15:30:00	ORIENTATION LEVEL A, ORIENTATION LEVEL B, CERTIFICATION LEVEL ONE TEX, CERTIFICATION LEVEL ONE ME, CERTIFICATION LEVEL ONE HCE, CERTIFICATION LEVEL ONE EE, CERTIFICATION LEVEL ONE CE	Present	2025-10-29 19:16:26.786352	2025-10-31 13:06:09.225371
29	2025-10-15	Wandum O'Neil Nuvaga	08:30:00	15:30:00	CERTIFICATION LEVEL TWO HCE, ITVEE HCE	Present	2025-10-31 13:03:17.652344	2025-10-31 13:07:28.868382
16	2025-10-15	Rose Ntone Chuba	07:00:00	15:44:00	ITVEE SM	Present	2025-10-29 19:11:36.208344	2025-10-31 13:07:50.862123
27	2025-10-15	Ngum Mary 	09:43:00	14:30:00		Present	2025-10-31 12:59:31.863286	2025-10-31 13:08:11.484356
17	2025-10-15	NDICHIA GLEIN FOINMBAM	07:21:00	17:00:00	ORIENTATION LEVEL A, ORIENTATION LEVEL B	Present	2025-10-29 19:12:44.224729	2025-10-31 13:08:51.307352
28	2025-10-15	Mbaliko Prosper Khan	11:15:00	14:30:00	CERTIFICATION LEVEL TWO CE, ITVEE CJ	Present	2025-10-31 13:01:25.16017	2025-10-31 13:09:15.428361
8	2025-10-14	Wandum O'Neil Nuvaga	08:10:00	15:35:00	ITVEE HCE, CERTIFICATION LEVEL TWO HCE	Present	2025-10-29 18:41:43.986151	2025-10-31 13:10:30.958087
3	2025-10-14	Ngum Mary 	07:09:00	14:54:00	CERTIFICATION LEVEL TWO TE	Present	2025-10-29 18:32:37.32447	2025-10-31 13:10:44.116098
15	2025-10-14	Ngah Divine 	07:35:00	15:00:00	ORIENTATION LEVEL A, ORIENTATION LEVEL B	Present	2025-10-29 19:05:37.922351	2025-10-31 13:11:05.068206
12	2025-10-14	Mbaliko Prosper Khan	07:30:00	14:40:00	CERTIFICATION LEVEL TWO CE	Present	2025-10-29 18:55:21.466107	2025-10-31 13:11:20.659291
4	2025-10-14	Mafain Alice Bih	07:25:00	16:10:00	ATVEE COMM	Present	2025-10-29 18:36:23.568009	2025-10-31 13:12:00.515687
30	2025-10-16	Manka'a Carine Awah	07:33:00	15:30:00	CERTIFICATION LEVEL TWO CE, CERTIFICATION LEVEL TWO EE, CERTIFICATION LEVEL TWO HCE, CERTIFICATION LEVEL TWO ME, CERTIFICATION LEVEL TWO TE, ORIENTATION LEVEL A, ORIENTATION LEVEL B	Present	2025-10-31 13:14:34.299639	2025-10-31 13:14:34.299639
31	2025-10-16	Mafain Alice Bih	07:27:00	16:08:00	ATVEE COMM, CERTIFICATION LEVEL TWO CE, CERTIFICATION LEVEL TWO EE, CERTIFICATION LEVEL TWO HCE, CERTIFICATION LEVEL TWO ME, CERTIFICATION LEVEL TWO TE, ITVEE AMR, ITVEE BC, ITVEE CJ, ITVEE EPS, ITVEE HCE, ITVEE SM, ITVEE TE	Present	2025-10-31 13:16:18.066347	2025-10-31 13:16:18.066347
32	2025-10-16	ABU ROSE MENNYI	07:30:00	16:07:00	CERTIFICATION LEVEL ONE TEX	Present	2025-10-31 13:17:11.815597	2025-10-31 13:17:11.815597
33	2025-10-16	Rose Ntone Chuba	07:00:00	15:37:00	CERTIFICATION LEVEL ONE ME	Present	2025-10-31 13:18:19.910358	2025-10-31 13:18:19.910358
34	2025-10-16	Chem Sandra Ntala	07:44:00	15:35:00	ATVEE COMM, CERTIFICATION LEVEL TWO CE, CERTIFICATION LEVEL TWO EE, CERTIFICATION LEVEL TWO HCE, CERTIFICATION LEVEL TWO ME, CERTIFICATION LEVEL TWO TE	Present	2025-10-31 13:19:35.935014	2025-10-31 13:19:35.935014
35	2025-10-16	Emile Awah	07:55:00	15:38:00	ATVEE EPS, ATVEE COMM, ATVEE BC, ATVEE AMR, CERTIFICATION LEVEL TWO CE, CERTIFICATION LEVEL TWO EE, CERTIFICATION LEVEL TWO HCE, CERTIFICATION LEVEL TWO ME, CERTIFICATION LEVEL TWO TE, ITVEE AMR, ITVEE BC, ITVEE CJ, ITVEE EPS, ITVEE HCE, ITVEE SM, ITVEE TE	Present	2025-10-31 13:23:07.709478	2025-10-31 13:23:07.709478
36	2025-10-16	MILLA JOHN-PAUL TEBAH	07:45:00	15:15:00	CERTIFICATION LEVEL TWO EE	Present	2025-10-31 13:24:40.795088	2025-10-31 13:24:40.795088
37	2025-10-16	DJIMO DJOMO BEN COLLINS	08:00:00	15:45:00	ORIENTATION LEVEL A, ORIENTATION LEVEL B, ATVEE EPS	Present	2025-10-31 13:26:31.043941	2025-10-31 13:26:31.043941
38	2025-10-16	Christ Steve 	20:00:00	15:40:00	CERTIFICATION LEVEL ONE HCE	Present	2025-10-31 13:27:27.585058	2025-10-31 13:27:27.585058
39	2025-10-16	Wandum O'Neil Nuvaga	08:00:00	15:40:00	CERTIFICATION LEVEL ONE HCE	Present	2025-10-31 13:28:21.953356	2025-10-31 13:28:21.953356
40	2025-10-16	Ngum Mary 	08:23:00	14:30:00	CERTIFICATION LEVEL ONE TEX, ORIENTATION LEVEL A, ORIENTATION LEVEL B	Present	2025-10-31 13:29:37.365375	2025-10-31 13:29:37.365375
41	2025-10-16	Gebuin Bless Yuknwi	08:39:00	16:09:00	CERTIFICATION LEVEL TWO CE	Present	2025-10-31 13:30:49.46777	2025-10-31 13:30:49.46777
42	2025-10-16	NDICHIA GLEIN FOINMBAM	07:00:00	15:40:00	ITVEE AMR	Present	2025-10-31 13:31:39.327807	2025-10-31 13:31:39.327807
43	2025-10-17	Rose Ntone Chuba	07:00:00	12:50:00	ATVEE AMR	Present	2025-10-31 13:32:39.046935	2025-10-31 13:33:02.817853
44	2025-10-17	NDICHIA GLEIN FOINMBAM	07:24:00	17:30:00	ATVEE AMR, CERTIFICATION LEVEL ONE ME	Present	2025-10-31 13:34:06.329993	2025-10-31 13:34:06.329993
45	2025-10-17	Mafain Alice Bih	07:24:00	15:04:00		Present	2025-10-31 13:35:01.018352	2025-10-31 13:35:01.018352
46	2025-10-17	Chem Sandra Ntala	07:37:00	17:52:00	ATVEE COMM, CERTIFICATION LEVEL TWO CE, CERTIFICATION LEVEL TWO EE, CERTIFICATION LEVEL TWO HCE, CERTIFICATION LEVEL TWO ME, CERTIFICATION LEVEL TWO TE	Present	2025-10-31 13:36:31.972466	2025-10-31 13:36:31.972466
47	2025-10-17	Manka'a Carine Awah	07:37:00	15:30:00	CERTIFICATION LEVEL TWO CE, CERTIFICATION LEVEL TWO EE, CERTIFICATION LEVEL TWO HCE, CERTIFICATION LEVEL TWO ME, CERTIFICATION LEVEL TWO TE, ORIENTATION LEVEL A, ORIENTATION LEVEL B	Present	2025-10-31 13:37:29.896342	2025-10-31 13:37:29.896342
48	2025-10-17	Wandum O'Neil Nuvaga	07:45:00	07:45:00		Present	2025-10-31 13:40:23.892351	2025-10-31 13:40:23.892351
49	2025-10-17	Christ Steve 	07:45:00	15:45:00	CERTIFICATION LEVEL ONE HCE	Present	2025-10-31 13:41:13.532422	2025-10-31 13:41:13.532422
50	2025-10-17	Brica Ngue Fon	07:50:00	07:50:00		Present	2025-10-31 13:42:09.982086	2025-10-31 13:42:09.982086
51	2025-10-17	Emile Awah	07:54:00	15:46:00	CERTIFICATION LEVEL TWO CE, CERTIFICATION LEVEL TWO EE, CERTIFICATION LEVEL TWO ME, CERTIFICATION LEVEL TWO HCE, CERTIFICATION LEVEL TWO TE, ITVEE TE, ITVEE HCE, ITVEE SM, ITVEE EPS, ITVEE CJ, ITVEE BC, ITVEE AMR	Present	2025-10-31 13:44:55.21231	2025-10-31 13:44:55.21231
52	2025-10-14	Kechazi Leonel Nchumi	08:05:00	15:30:00	ATVEE BC, ITVEE CJ	Present	2025-10-31 13:59:33.318601	2025-10-31 13:59:33.318601
53	2025-10-14	Kechazi Leonel Nchumi	08:05:00	15:30:00	ATVEE BC, ITVEE CJ	Present	2025-10-31 13:59:33.422771	2025-10-31 13:59:33.422771
54	2025-10-15	Kechazi Leonel Nchumi	07:40:00	15:39:00	ITVEE CJ, ORIENTATION LEVEL A, ORIENTATION LEVEL B	Present	2025-10-31 14:00:54.359033	2025-10-31 14:00:54.359033
55	2025-10-16	Kechazi Leonel Nchumi	07:27:00	15:31:00	CERTIFICATION LEVEL ONE CE, ATVEE BC	Present	2025-10-31 14:03:15.277269	2025-10-31 14:03:15.277269
56	2025-10-17	Kechazi Leonel Nchumi	07:44:00	15:40:00	ATVEE BC	Present	2025-10-31 14:04:10.644994	2025-10-31 14:04:10.644994
57	2025-10-17	Ngah Divine 	07:55:00	15:30:00		Present	2025-10-31 14:05:08.483163	2025-10-31 14:05:08.483163
58	2025-10-17	Gebuin Bless Yuknwi	08:28:00	15:05:00		Present	2025-10-31 14:06:02.898613	2025-10-31 14:06:02.898613
59	2025-10-17	Mbaliko Prosper Khan	08:28:00	12:00:00	CERTIFICATION LEVEL TWO CE	Present	2025-10-31 14:07:23.332359	2025-10-31 14:07:23.332359
60	2025-10-17	ABU ROSE MENNYI	08:00:00	16:50:00	CERTIFICATION LEVEL ONE TEX	Present	2025-10-31 14:08:31.603234	2025-10-31 14:08:31.603234
61	2025-10-17	DJIMO DJOMO BEN COLLINS	09:50:00	17:15:00	ATVEE EPS	Present	2025-10-31 14:09:25.061909	2025-10-31 14:09:25.061909
62	2025-10-18	Ngah Divine 	07:19:00	14:30:00		Present	2025-10-31 14:10:27.174874	2025-10-31 14:10:27.174874
63	2025-10-18	DJIMO DJOMO BEN COLLINS	09:27:00	14:37:00	ATVEE EPS	Present	2025-10-31 14:11:39.797588	2025-10-31 14:11:39.797588
64	2025-10-18	Brica Ngue Fon	09:16:00	15:30:00		Present	2025-10-31 14:12:23.276981	2025-10-31 14:12:23.276981
65	2025-10-18	Gebuin Bless Yuknwi	09:38:00	17:10:00	CERTIFICATION LEVEL TWO CE, ORIENTATION LEVEL A, ORIENTATION LEVEL B, ATVEE BC	Present	2025-10-31 14:16:47.522355	2025-10-31 14:16:47.522355
66	2025-10-18	Rose Ntone Chuba	10:10:00	15:17:00		Present	2025-10-31 14:18:04.240355	2025-10-31 14:18:04.240355
67	2025-10-18	Kechazi Leonel Nchumi	10:19:00	14:30:00		Present	2025-10-31 14:18:54.076024	2025-10-31 14:18:54.076024
68	2025-10-18	Mafain Alice Bih	10:40:00	14:30:00		Present	2025-10-31 14:19:40.03596	2025-10-31 14:19:40.03596
69	2025-10-18	Emile Awah	10:56:00	14:38:00		Present	2025-10-31 14:20:27.764084	2025-10-31 14:20:27.764084
70	2025-10-18	NDICHIA GLEIN FOINMBAM	10:50:00	14:28:00		Present	2025-10-31 14:22:18.555899	2025-10-31 14:22:18.555899
71	2025-10-18	ABU ROSE MENNYI	10:30:00	02:30:00	CERTIFICATION LEVEL TWO TE	Present	2025-11-01 07:01:12.020389	2025-11-01 07:01:12.020389
72	2025-10-18	Wandum O'Neil Nuvaga	11:00:00	02:30:00	CERTIFICATION LEVEL ONE HCE	Present	2025-11-01 07:05:59.316958	2025-11-01 07:05:59.316958
73	2025-10-18	Christ Steve 	11:00:00	02:30:00		Present	2025-11-01 07:07:19.616346	2025-11-01 07:07:19.616346
74	2025-10-18	MILLA JOHN-PAUL TEBAH	07:45:00	02:37:00	CERTIFICATION LEVEL ONE EE	Present	2025-11-01 07:08:16.659596	2025-11-01 07:08:16.659596
75	2025-10-18	Ngum Mary 	11:00:00	02:30:00		Present	2025-11-01 07:10:25.387835	2025-11-01 07:10:25.387835
76	2025-10-18	Ngum Mary 	11:00:00	02:30:00		Present	2025-11-01 07:10:27.23352	2025-11-01 07:10:27.23352
77	2025-10-18	Chem Sandra Ntala	00:00:00	02:30:00		Present	2025-11-01 07:13:21.79435	2025-11-01 07:13:21.79435
79	2025-10-21	Wandum O'Neil Nuvaga	07:15:00	03:36:00	CERTIFICATION LEVEL TWO HCE, ITVEE HCE	Present	2025-11-01 07:22:02.399282	2025-11-01 07:22:02.399282
105	2025-10-22	Manka'a Carine Awah	07:34:00	03:15:00	CERTIFICATION LEVEL ONE HCE, ORIENTATION LEVEL B, ORIENTATION LEVEL A	Present	2025-11-01 08:19:52.098757	2025-11-01 08:19:52.098757
106	2025-10-23	Rose Ntone Chuba	07:00:00	03:00:00	CERTIFICATION LEVEL ONE ME	Present	2025-11-01 08:21:36.593847	2025-11-01 08:21:36.593847
78	2025-10-21	Rose Ntone Chuba	07:00:00	04:00:00	ITVEE SM, CERTIFICATION LEVEL TWO ME	Present	2025-11-01 07:18:56.987504	2025-11-01 07:23:23.704075
80	2025-09-21	Kechazi Leonel Nchumi	07:40:00	03:30:00	ATVEE BC, ITVEE BC	Present	2025-11-01 07:32:00.565359	2025-11-01 07:32:00.565359
81	2025-10-21	Mbaliko Prosper Khan	07:40:00	02:32:00	CERTIFICATION LEVEL TWO CE	Present	2025-11-01 07:32:57.955734	2025-11-01 07:32:57.955734
82	2025-10-21	Emile Awah	07:41:00	03:42:00	CERTIFICATION LEVEL TWO CE	Present	2025-11-01 07:34:47.599908	2025-11-01 07:35:07.708062
83	2025-10-21	ABU ROSE MENNYI	07:45:00	04:30:00	ITVEE TE	Present	2025-11-01 07:35:46.814657	2025-11-01 07:35:46.814657
84	2025-10-21	Christ Steve 	07:45:00	16:00:00	CERTIFICATION LEVEL TWO HCE, ITVEE HCE	Present	2025-11-01 07:36:47.15774	2025-11-01 07:36:47.15774
85	2025-10-21	Gebuin Bless Yuknwi	07:50:00	05:16:00	ATVEE BC, ITVEE BC	Present	2025-11-01 07:37:38.618671	2025-11-01 07:37:38.618671
86	2025-10-21	Manka'a Carine Awah	07:54:00	03:30:00	ORIENTATION LEVEL B, CERTIFICATION LEVEL ONE TEX	Present	2025-11-01 07:43:21.962788	2025-11-01 07:43:21.962788
87	2025-10-21	Ngum Mary 	07:55:00	03:30:00	CERTIFICATION LEVEL TWO TE	Present	2025-11-01 07:44:32.354073	2025-11-01 07:44:32.354073
88	2025-10-21	MILLA JOHN-PAUL TEBAH	07:58:00	04:38:00	ATVEE EPS, ITVEE EPS	Present	2025-11-01 07:45:20.750963	2025-11-01 07:45:20.750963
89	2025-10-21	Mafain Alice Bih	07:15:00	04:00:00	ATVEE COMM, CERTIFICATION LEVEL ONE HCE	Present	2025-11-01 07:45:58.80335	2025-11-01 07:45:58.80335
90	2025-10-21	Chem Sandra Ntala	07:26:00	03:35:00	ORIENTATION LEVEL A, CERTIFICATION LEVEL ONE ME	Present	2025-11-01 07:47:16.153498	2025-11-01 07:47:16.153498
91	2025-10-21	Ngah Divine 	07:50:00	04:30:00	ORIENTATION LEVEL B	Present	2025-11-01 07:48:10.839402	2025-11-01 07:48:10.839402
92	2025-10-21	NDICHIA GLEIN FOINMBAM	07:12:00	04:50:00	CERTIFICATION LEVEL TWO ME, ITVEE SM	Present	2025-11-01 07:54:39.586726	2025-11-01 07:54:39.586726
93	2025-10-21	DJIMO DJOMO BEN COLLINS	08:23:00	03:03:00	ATVEE EPS, CERTIFICATION LEVEL TWO EE, ITVEE EPS	Present	2025-11-01 07:55:46.19004	2025-11-01 07:55:46.19004
94	2025-10-22	Rose Ntone Chuba	07:00:00	04:00:00	ITVEE SM, CERTIFICATION LEVEL TWO ME	Present	2025-11-01 08:03:28.009061	2025-11-01 08:03:28.009061
95	2025-10-22	Mafain Alice Bih	07:16:00	03:40:00	ATVEE COMM, CERTIFICATION LEVEL ONE ME	Present	2025-11-01 08:04:11.308343	2025-11-01 08:04:11.308343
96	2025-10-22	Chem Sandra Ntala	07:22:00	03:34:00	ORIENTATION LEVEL B, CERTIFICATION LEVEL ONE TEX	Present	2025-11-01 08:04:47.75722	2025-11-01 08:04:47.75722
97	2025-10-22	Ngah Divine 	07:24:00	03:50:00	ORIENTATION LEVEL B, ORIENTATION LEVEL A	Present	2025-11-01 08:05:18.477706	2025-11-01 08:05:18.477706
98	2025-10-22	NDICHIA GLEIN FOINMBAM	07:34:00	04:00:00	ATVEE AMR, ORIENTATION LEVEL B, ORIENTATION LEVEL A	Present	2025-11-01 08:08:05.852921	2025-11-01 08:08:05.852921
99	2025-10-22	Kechazi Leonel Nchumi	07:34:00	03:30:00	ITVEE BC, ORIENTATION LEVEL B, ORIENTATION LEVEL A	Present	2025-11-01 08:11:21.813491	2025-11-01 08:11:21.813491
100	2025-10-22	ABU ROSE MENNYI	07:40:00	03:35:00	CERTIFICATION LEVEL TWO TE, ITVEE TE	Present	2025-11-01 08:12:15.258837	2025-11-01 08:12:15.258837
101	2025-10-22	Emile Awah	07:43:00	02:16:00	ATVEE AMR, CERTIFICATION LEVEL ONE HCE	Present	2025-11-01 08:15:29.724235	2025-11-01 08:15:29.724235
102	2025-10-22	Ngum Mary 	09:20:00	03:30:00	CERTIFICATION LEVEL TWO TE, ITVEE TE	Present	2025-11-01 08:17:03.698203	2025-11-01 08:17:03.698203
103	2025-10-22	Mbaliko Prosper Khan	11:37:00	03:30:00	CERTIFICATION LEVEL TWO CE	Present	2025-11-01 08:18:34.331693	2025-11-01 08:18:34.331693
104	2025-10-22	DJIMO DJOMO BEN COLLINS	08:02:00	02:36:00	CERTIFICATION LEVEL TWO HCE, ITVEE HCE	Present	2025-11-01 08:19:21.198492	2025-11-01 08:19:21.198492
107	2025-10-23	Kechazi Leonel Nchumi	07:42:00	03:30:00	CERTIFICATION LEVEL ONE CE, ATVEE BC	Present	2025-11-01 08:23:31.879639	2025-11-01 08:23:31.879639
108	2025-10-23	Emile Awah	07:22:00	03:40:00	ATVEE AMR, CERTIFICATION LEVEL TWO ME, ITVEE EPS	Present	2025-11-01 08:24:21.845769	2025-11-01 08:24:21.845769
109	2025-10-23	MILLA JOHN-PAUL TEBAH	07:56:00	04:05:00	CERTIFICATION LEVEL ONE EE, CERTIFICATION LEVEL ONE ME	Present	2025-11-01 08:25:10.681955	2025-11-01 08:25:10.681955
110	2025-10-23	Wandum O'Neil Nuvaga	07:15:00	03:45:00	CERTIFICATION LEVEL ONE HCE	Present	2025-11-01 08:25:52.226165	2025-11-01 08:25:52.226165
111	2025-10-23	Chem Sandra Ntala	07:22:00	03:45:00	CERTIFICATION LEVEL ONE TEX, ATVEE COMM	Present	2025-11-01 08:27:09.691025	2025-11-01 08:27:09.691025
112	2025-10-23	Mafain Alice Bih	07:22:00	03:44:00	ATVEE COMM, CERTIFICATION LEVEL TWO ME, ITVEE BC	Present	2025-11-01 08:30:35.790344	2025-11-01 08:30:35.790344
113	2025-10-23	DJIMO DJOMO BEN COLLINS	08:03:00	03:30:00	ATVEE EPS, ORIENTATION LEVEL B, ORIENTATION LEVEL A	Present	2025-11-01 08:31:32.260446	2025-11-01 08:31:32.260446
114	2025-10-23	Manka'a Carine Awah	07:30:00	03:30:00	CERTIFICATION LEVEL TWO EE, ORIENTATION LEVEL B, ORIENTATION LEVEL A	Present	2025-11-01 08:32:23.475704	2025-11-01 08:32:23.475704
115	2025-10-23	Ngah Divine 	08:00:00	05:30:00	ORIENTATION LEVEL B, ORIENTATION LEVEL A	Present	2025-11-01 08:33:16.493446	2025-11-01 08:33:16.493446
116	2025-10-23	Gebuin Bless Yuknwi	08:28:00	05:35:00	CERTIFICATION LEVEL ONE CE	Present	2025-11-01 08:33:58.28511	2025-11-01 08:33:58.28511
117	2025-10-23	Ngum Mary 	08:30:00	03:40:00	CERTIFICATION LEVEL ONE TEX, ORIENTATION LEVEL B, ORIENTATION LEVEL A	Present	2025-11-01 08:35:08.981017	2025-11-01 08:35:08.981017
118	2025-10-23	NDICHIA GLEIN FOINMBAM	07:05:00	04:00:00	CERTIFICATION LEVEL TWO ME	Present	2025-11-01 08:37:12.939849	2025-11-01 08:37:12.939849
119	2025-10-23	ABU ROSE MENNYI	09:28:00	03:46:00	CERTIFICATION LEVEL ONE TEX	Present	2025-11-01 08:37:52.46051	2025-11-01 08:37:52.46051
120	2025-10-23	Brica Ngue Fon	09:56:00	02:40:00	ORIENTATION LEVEL B, ORIENTATION LEVEL A, CERTIFICATION LEVEL ONE EE, ITVEE SM	Present	2025-11-01 08:39:07.47602	2025-11-01 08:39:07.47602
121	2025-10-24	Rose Ntone Chuba	06:30:00	03:00:00	ATVEE AMR	Present	2025-11-01 08:40:47.75773	2025-11-01 08:40:47.75773
122	2025-10-24	Mafain Alice Bih	06:48:00	04:00:00	ATVEE COMM, CERTIFICATION LEVEL TWO TE, ITVEE SM	Present	2025-11-01 08:41:36.494602	2025-11-01 08:41:36.494602
123	2025-10-24	Chem Sandra Ntala	07:16:00	03:59:00	ATVEE COMM, CERTIFICATION LEVEL TWO ME	Present	2025-11-01 08:42:15.147989	2025-11-01 08:42:15.147989
124	2025-10-24	NDICHIA GLEIN FOINMBAM	07:19:00	04:00:00	ATVEE AMR, CERTIFICATION LEVEL ONE ME	Present	2025-11-01 08:43:11.184644	2025-11-01 08:43:11.184644
125	2025-10-24	Ngah Divine 	07:20:00	04:30:00	ORIENTATION LEVEL B, ORIENTATION LEVEL A	Present	2025-11-01 08:43:45.322071	2025-11-01 08:43:45.322071
126	2025-10-24	Wandum O'Neil Nuvaga	07:25:00	03:30:00	CERTIFICATION LEVEL ONE HCE, ORIENTATION LEVEL B, ORIENTATION LEVEL A	Present	2025-11-01 08:44:14.728356	2025-11-01 08:44:14.728356
127	2025-10-24	Gebuin Bless Yuknwi	07:43:00	04:11:00	CERTIFICATION LEVEL ONE CE, ATVEE BC, ORIENTATION LEVEL B, ORIENTATION LEVEL A	Present	2025-11-01 08:45:07.093347	2025-11-01 08:45:07.093347
160	2025-10-30	Gebuin Bless Yuknwi	07:40:00	16:23:00	ATVEE BC, ITVEE BC	Present	2025-11-01 09:52:10.725346	2025-11-01 10:25:41.851101
134	2025-10-30	Mbaliko Prosper Khan	09:30:00	13:45:00	CERTIFICATION LEVEL TWO CE	Present	2025-11-01 09:16:58.51858	2025-11-01 10:25:59.451733
129	2025-10-30	Manka'a Carine Awah	07:50:00	15:30:00		Present	2025-11-01 09:10:38.875346	2025-11-01 10:26:16.030773
135	2025-10-30	MILLA JOHN-PAUL TEBAH	09:54:00	15:54:00	CERTIFICATION LEVEL ONE EE	Present	2025-11-01 09:17:49.987189	2025-11-01 10:26:39.900382
128	2025-10-30	Kechazi Leonel Nchumi	07:44:00	15:32:00	ATVEE BC	Present	2025-11-01 09:09:56.307226	2025-11-01 10:26:54.472361
155	2025-10-29	Chem Sandra Ntala	07:30:00	15:30:00	ORIENTATION LEVEL A, ORIENTATION LEVEL B, CERTIFICATION LEVEL ONE CE, CERTIFICATION LEVEL ONE EE, CERTIFICATION LEVEL ONE HCE, CERTIFICATION LEVEL ONE ME, CERTIFICATION LEVEL ONE TEX	Present	2025-11-01 09:44:53.862072	2025-11-01 11:08:10.502889
136	2025-10-24	DJIMO DJOMO BEN COLLINS	10:18:00	15:03:00	ATVEE EPS	Present	2025-11-01 09:18:37.170345	2025-11-01 11:08:51.103141
132	2025-10-24	Christ Steve 	07:54:00	15:30:00	CERTIFICATION LEVEL ONE HCE	Present	2025-11-01 09:15:12.397875	2025-11-01 11:09:17.21609
131	2025-10-24	Brica Ngue Fon	07:54:00	15:30:00	ITVEE TE, ITVEE SM, ITVEE HCE, ITVEE EPS, ITVEE CJ, ITVEE BC, ITVEE AMR, ORIENTATION LEVEL A, ORIENTATION LEVEL B, CERTIFICATION LEVEL TWO ME, CERTIFICATION LEVEL TWO HCE, CERTIFICATION LEVEL TWO TE, CERTIFICATION LEVEL TWO EE, CERTIFICATION LEVEL TWO CE	Present	2025-11-01 09:14:16.326342	2025-11-01 11:09:41.190949
133	2025-10-24	ABU ROSE MENNYI	08:00:00	15:43:00	CERTIFICATION LEVEL ONE TEX	Present	2025-11-01 09:16:03.547569	2025-11-01 11:10:02.949364
137	2025-10-25	NDICHIA GLEIN FOINMBAM	07:15:00	18:00:00	ITVEE AMR	Present	2025-11-01 09:19:40.09034	2025-11-01 11:10:22.934359
138	2025-10-25	MILLA JOHN-PAUL TEBAH	08:20:00	15:30:00		Present	2025-11-01 09:21:21.896356	2025-11-01 11:10:41.197118
141	2025-10-28	Wandum O'Neil Nuvaga	07:30:00	15:50:00	ITVEE HCE	Present	2025-11-01 09:25:45.233192	2025-11-01 11:10:57.488965
151	2025-10-28	Rose Ntone Chuba	07:29:00	15:30:00		Present	2025-11-01 09:39:18.231461	2025-11-01 11:11:14.945759
142	2025-10-28	Ngum Mary 	08:00:00	15:30:00	CERTIFICATION LEVEL TWO TE, ITVEE TE	Present	2025-11-01 09:27:17.360172	2025-11-01 11:11:29.92127
144	2025-10-28	Ngah Divine 	07:20:00	17:00:00	ORIENTATION LEVEL A, ORIENTATION LEVEL B	Present	2025-11-01 09:29:49.13881	2025-11-01 11:11:47.142354
139	2025-10-28	NDICHIA GLEIN FOINMBAM	07:20:00	16:57:00	CERTIFICATION LEVEL TWO ME, ITVEE AMR	Present	2025-11-01 09:22:47.873888	2025-11-01 11:11:59.743359
152	2025-10-28	Mbaliko Prosper Khan	09:00:00	15:00:00	CERTIFICATION LEVEL TWO CE	Present	2025-11-01 09:40:18.444494	2025-11-01 11:12:09.571363
145	2025-10-28	Manka'a Carine Awah	08:20:00	15:30:00	CERTIFICATION LEVEL ONE CE, CERTIFICATION LEVEL ONE EE, CERTIFICATION LEVEL ONE HCE, CERTIFICATION LEVEL ONE ME, CERTIFICATION LEVEL ONE TEX, ORIENTATION LEVEL A, ORIENTATION LEVEL B	Present	2025-11-01 09:30:48.482769	2025-11-01 11:12:27.985348
146	2025-10-28	Mafain Alice Bih	08:20:00	15:41:00	CERTIFICATION LEVEL ONE CE, CERTIFICATION LEVEL ONE EE, CERTIFICATION LEVEL ONE HCE, CERTIFICATION LEVEL ONE ME, CERTIFICATION LEVEL ONE TEX	Present	2025-11-01 09:32:11.526885	2025-11-01 11:12:42.115951
147	2025-10-28	MILLA JOHN-PAUL TEBAH	08:38:00	16:15:00	ATVEE EPS, ITVEE AMR, ITVEE SM	Present	2025-11-01 09:35:10.658353	2025-11-01 11:12:55.885357
140	2025-10-28	Kechazi Leonel Nchumi	08:03:00	15:30:00	ATVEE BC, DIPLOMA BC, ITVEE CJ	Present	2025-11-01 09:24:23.77857	2025-11-01 11:13:09.736482
154	2025-10-28	Gebuin Bless Yuknwi	07:42:00	17:30:00	ATVEE BC, ITVEE BC	Present	2025-11-01 09:43:25.555245	2025-11-01 11:13:22.805802
149	2025-10-28	DJIMO DJOMO BEN COLLINS	08:47:00	14:42:00	ATVEE EPS, CERTIFICATION LEVEL TWO EE, ITVEE EPS	Present	2025-11-01 09:37:54.275091	2025-11-01 11:13:33.826207
143	2025-10-28	Christ Steve 	07:40:00	15:50:00	CERTIFICATION LEVEL ONE HCE, ITVEE HCE	Present	2025-11-01 09:29:10.748964	2025-11-01 11:13:54.400738
153	2025-10-28	Chem Sandra Ntala	09:00:00	15:29:00	ORIENTATION LEVEL A, ORIENTATION LEVEL B, CERTIFICATION LEVEL ONE CE, CERTIFICATION LEVEL ONE EE, CERTIFICATION LEVEL ONE HCE, CERTIFICATION LEVEL ONE ME, CERTIFICATION LEVEL ONE TEX	Present	2025-11-01 09:41:07.64606	2025-11-01 11:14:04.666249
150	2025-10-28	Brica Ngue Fon	09:40:00	15:30:00		Present	2025-11-01 09:38:41.24292	2025-11-01 11:14:18.263448
148	2025-10-28	ABU ROSE MENNYI	08:40:00	16:00:00	ITVEE TE	Present	2025-11-01 09:36:07.96943	2025-11-01 11:14:31.033361
159	2025-10-29	Christ Steve 	07:33:00	15:50:00	ITVEE HCE, CERTIFICATION LEVEL TWO HCE	Present	2025-11-01 09:49:39.791114	2025-11-01 11:14:55.732113
163	2025-10-29	Kechazi Leonel Nchumi	07:48:00	15:31:00	ITVEE BC, ORIENTATION LEVEL A, ORIENTATION LEVEL B	Present	2025-11-01 09:57:02.857744	2025-11-01 11:16:31.346661
164	2025-10-29	Kechazi Leonel Nchumi	07:48:00	15:31:00	ITVEE BC, ORIENTATION LEVEL A, ORIENTATION LEVEL B	Present	2025-11-01 09:57:03.004861	2025-11-01 11:17:20.1928
162	2025-10-29	MILLA JOHN-PAUL TEBAH	07:45:00	15:44:00	ATVEE EPS, ITVEE EPS, CERTIFICATION LEVEL TWO EE	Present	2025-11-01 09:53:28.482436	2025-11-01 11:17:34.701348
157	2025-10-29	Mafain Alice Bih	07:30:00	15:51:00	CERTIFICATION LEVEL ONE CE, CERTIFICATION LEVEL ONE HCE, CERTIFICATION LEVEL ONE ME, CERTIFICATION LEVEL ONE TEX, ATVEE COMM	Present	2025-11-01 09:47:05.422715	2025-11-01 11:17:46.160992
156	2025-10-29	Manka'a Carine Awah	07:30:00	15:29:00		Present	2025-11-01 09:45:58.751345	2025-11-01 11:18:20.482504
158	2025-10-29	Wandum O'Neil Nuvaga	07:33:00	15:50:00	CERTIFICATION LEVEL TWO HCE, ITVEE HCE	Present	2025-11-01 09:48:38.545416	2025-11-01 11:19:37.048187
191	2025-10-30	Wandum O'Neil Nuvaga	07:20:00	15:42:00	CERTIFICATION LEVEL ONE HCE	Present	2025-11-01 10:22:38.926793	2025-11-01 10:22:38.926793
188	2025-10-30	Ngah Divine 	07:30:00	17:05:00	ORIENTATION LEVEL B, ORIENTATION LEVEL A	Present	2025-11-01 10:17:06.385338	2025-11-01 10:23:48.511018
190	2025-10-30	Mafain Alice Bih	07:30:00	15:40:00	CERTIFICATION LEVEL ONE TEX, CERTIFICATION LEVEL TWO CE, CERTIFICATION LEVEL TWO EE, CERTIFICATION LEVEL TWO HCE, CERTIFICATION LEVEL TWO ME, CERTIFICATION LEVEL TWO TE	Present	2025-11-01 10:21:01.072996	2025-11-01 10:24:12.406253
189	2025-10-30	Ngum Mary 	07:25:00	15:30:00	ORIENTATION LEVEL A, ORIENTATION LEVEL B, CERTIFICATION LEVEL ONE TEX	Present	2025-11-01 10:18:45.417772	2025-11-01 10:24:29.29559
176	2025-10-30	Ngum Mary 	09:25:00	12:30:00	CERTIFICATION LEVEL TWO TE, ITVEE TE	Present	2025-11-01 10:06:27.092635	2025-11-01 10:25:11.2041
161	2025-10-30	Gebuin Bless Yuknwi	07:40:00	16:23:00	ATVEE BC, ITVEE BC	Present	2025-11-01 09:52:10.726875	2025-11-01 10:25:27.722209
130	2025-10-30	Emile Awah	07:51:00	15:31:00	CERTIFICATION LEVEL TWO CE, CERTIFICATION LEVEL TWO EE, CERTIFICATION LEVEL TWO HCE, CERTIFICATION LEVEL TWO ME, CERTIFICATION LEVEL TWO TE, ITVEE AMR, ITVEE BC, ITVEE CJ, ITVEE EPS, ITVEE HCE, ITVEE SM, ITVEE TE	Present	2025-11-01 09:11:56.415842	2025-11-01 10:27:14.877019
187	2025-10-30	Rose Ntone Chuba	07:00:00	15:36:00	CERTIFICATION LEVEL ONE ME	Present	2025-11-01 10:16:00.252685	2025-11-01 10:30:56.487642
192	2025-10-30	Ngah Divine 	07:30:00	17:00:00	ORIENTATION LEVEL A, ORIENTATION LEVEL B	Present	2025-11-01 10:32:18.621384	2025-11-01 10:32:18.621384
193	2025-10-30	Chem Sandra Ntala	07:26:00	15:30:00	CERTIFICATION LEVEL ONE TEX, CERTIFICATION LEVEL TWO CE, CERTIFICATION LEVEL TWO EE, CERTIFICATION LEVEL TWO HCE, CERTIFICATION LEVEL TWO ME, CERTIFICATION LEVEL TWO TE, ATVEE COMM	Present	2025-11-01 10:33:27.24696	2025-11-01 10:33:27.24696
194	2025-10-30	Ngum Mary 	07:25:00	15:30:00	ORIENTATION LEVEL A, ORIENTATION LEVEL B, CERTIFICATION LEVEL ONE TEX	Present	2025-11-01 10:34:33.162681	2025-11-01 10:34:33.162681
195	2025-10-30	Mafain Alice Bih	07:30:00	15:40:00	ATVEE COMM, CERTIFICATION LEVEL TWO CE, CERTIFICATION LEVEL TWO EE, CERTIFICATION LEVEL TWO HCE, CERTIFICATION LEVEL TWO ME, CERTIFICATION LEVEL TWO TE	Present	2025-11-01 10:35:19.25022	2025-11-01 10:35:19.25022
196	2025-10-30	Wandum O'Neil Nuvaga	07:43:00	15:42:00	CERTIFICATION LEVEL ONE HCE	Present	2025-11-01 10:36:34.121746	2025-11-01 10:36:34.121746
197	2025-10-30	Kechazi Leonel Nchumi	07:41:00	15:30:00	CERTIFICATION LEVEL ONE CE, ATVEE BC	Present	2025-11-01 10:37:43.182263	2025-11-01 10:37:43.182263
198	2025-10-30	MILLA JOHN-PAUL TEBAH	07:45:00	15:35:00	CERTIFICATION LEVEL ONE EE, CERTIFICATION LEVEL ONE ME	Present	2025-11-01 10:40:31.842686	2025-11-01 10:40:31.842686
199	2025-10-30	Emile Awah	07:54:00	15:59:00	ATVEE AMR, ATVEE BC, ATVEE EPS, CERTIFICATION LEVEL TWO CE, CERTIFICATION LEVEL TWO EE, CERTIFICATION LEVEL TWO HCE, CERTIFICATION LEVEL TWO ME, CERTIFICATION LEVEL TWO TE, ITVEE TE, ITVEE SM, ITVEE HCE, ITVEE EPS, ITVEE CJ, ITVEE AMR, ITVEE BC	Present	2025-11-01 10:42:08.228401	2025-11-01 10:42:08.228401
200	2025-10-30	Christ Steve 	07:54:00	15:30:00	CERTIFICATION LEVEL ONE HCE	Present	2025-11-01 10:44:58.52375	2025-11-01 10:44:58.52375
201	2025-10-30	Brica Ngue Fon	08:10:00	15:30:00	ORIENTATION LEVEL A, ORIENTATION LEVEL B, ITVEE TE, ITVEE SM, ITVEE HCE, ITVEE EPS, ITVEE CJ, ITVEE AMR, ITVEE BC, CERTIFICATION LEVEL TWO TE, CERTIFICATION LEVEL TWO ME, CERTIFICATION LEVEL TWO HCE, CERTIFICATION LEVEL TWO EE, CERTIFICATION LEVEL TWO CE	Present	2025-11-01 10:46:58.251632	2025-11-01 10:46:58.251632
202	2025-10-30	ABU ROSE MENNYI	09:00:00	15:30:00		Present	2025-11-01 10:47:41.075132	2025-11-01 10:47:41.075132
203	2025-10-30	NDICHIA GLEIN FOINMBAM	07:14:00	17:01:00	ITVEE SM, ITVEE AMR	Present	2025-11-01 10:48:31.638356	2025-11-01 10:48:31.638356
204	2025-10-30	Manka'a Carine Awah	10:00:00	03:30:00		Present	2025-11-01 10:49:04.968813	2025-11-01 10:49:04.968813
205	2025-10-31	Christ Steve 	07:25:00	15:48:00	CERTIFICATION LEVEL ONE HCE	Present	2025-11-01 10:50:05.648383	2025-11-01 10:50:05.648383
206	2025-10-31	Ngah Divine 	07:45:00	15:30:00	ORIENTATION LEVEL A, ORIENTATION LEVEL B	Present	2025-11-01 10:50:41.533936	2025-11-01 10:50:41.533936
183	2025-10-29	Brica Ngue Fon	08:05:00	16:15:00	ORIENTATION LEVEL B, ORIENTATION LEVEL A, CERTIFICATION LEVEL ONE CE, CERTIFICATION LEVEL ONE EE, CERTIFICATION LEVEL ONE HCE, CERTIFICATION LEVEL ONE ME, CERTIFICATION LEVEL ONE TEX	Present	2025-11-01 10:13:46.863128	2025-11-01 11:06:17.715841
182	2025-10-29	Brica Ngue Fon	08:05:00	16:15:00	ORIENTATION LEVEL B, ORIENTATION LEVEL A, CERTIFICATION LEVEL ONE CE, CERTIFICATION LEVEL ONE EE, CERTIFICATION LEVEL ONE HCE, CERTIFICATION LEVEL ONE ME, CERTIFICATION LEVEL ONE TEX	Present	2025-11-01 10:13:46.853471	2025-11-01 11:06:38.372534
184	2025-10-29	Brica Ngue Fon	08:05:00	16:15:00	ORIENTATION LEVEL B, ORIENTATION LEVEL A, CERTIFICATION LEVEL ONE CE, CERTIFICATION LEVEL ONE EE, CERTIFICATION LEVEL ONE HCE, CERTIFICATION LEVEL ONE ME, CERTIFICATION LEVEL ONE TEX	Present	2025-11-01 10:13:46.86716	2025-11-01 11:07:49.623885
175	2025-10-29	DJIMO DJOMO BEN COLLINS	08:16:00	12:23:00	ITVEE EPS, CERTIFICATION LEVEL TWO EE	Present	2025-11-01 10:04:29.425943	2025-11-01 11:15:06.410361
172	2025-10-29	Emile Awah	07:49:00	15:30:00	CERTIFICATION LEVEL ONE CE, ATVEE AMR, ATVEE BC, ATVEE EPS	Present	2025-11-01 10:00:23.252512	2025-11-01 11:15:20.583736
166	2025-10-29	Kechazi Leonel Nchumi	07:48:00	15:31:00	ITVEE BC, ORIENTATION LEVEL A, ORIENTATION LEVEL B	Present	2025-11-01 09:57:03.161301	2025-11-01 11:15:32.302183
167	2025-10-29	Kechazi Leonel Nchumi	07:48:00	15:31:00	ITVEE BC, ORIENTATION LEVEL A, ORIENTATION LEVEL B	Present	2025-11-01 09:57:03.180849	2025-11-01 11:15:43.507033
168	2025-10-29	Kechazi Leonel Nchumi	07:48:00	15:31:00	ITVEE BC, ORIENTATION LEVEL A, ORIENTATION LEVEL B	Present	2025-11-01 09:57:03.247362	2025-11-01 11:15:58.063881
169	2025-10-29	Kechazi Leonel Nchumi	07:48:00	15:31:00	ITVEE BC, ORIENTATION LEVEL A, ORIENTATION LEVEL B	Present	2025-11-01 09:57:03.316168	2025-11-01 11:16:42.889359
186	2025-10-29	Manka'a Carine Awah	07:30:00	15:30:00	ORIENTATION LEVEL B, ORIENTATION LEVEL A, CERTIFICATION LEVEL ONE TEX, CERTIFICATION LEVEL ONE ME, CERTIFICATION LEVEL ONE HCE, CERTIFICATION LEVEL ONE CE, CERTIFICATION LEVEL ONE EE	Present	2025-11-01 10:15:07.10371	2025-11-01 11:18:02.664275
177	2025-10-29	Mbaliko Prosper Khan	11:29:00	14:30:00		Present	2025-11-01 10:09:00.6961	2025-11-01 11:18:39.122104
174	2025-10-29	NDICHIA GLEIN FOINMBAM	07:50:00	16:26:00	ATVEE AMR, ORIENTATION LEVEL A, ORIENTATION LEVEL B	Present	2025-11-01 10:02:58.318339	2025-11-01 11:18:54.347356
171	2025-10-29	Ngah Divine 	07:46:00	17:00:00	ORIENTATION LEVEL A, ORIENTATION LEVEL B	Present	2025-11-01 09:58:27.306851	2025-11-01 11:19:10.296877
178	2025-10-29	Rose Ntone Chuba	07:00:00	16:15:00	ITVEE AMR	Present	2025-11-01 10:12:00.393115	2025-11-01 11:19:23.991252
207	2025-10-31	Manka'a Carine Awah	07:40:00	15:30:00	ORIENTATION LEVEL B, ORIENTATION LEVEL A, CERTIFICATION LEVEL TWO TE, CERTIFICATION LEVEL TWO ME, CERTIFICATION LEVEL TWO HCE, CERTIFICATION LEVEL TWO EE, CERTIFICATION LEVEL TWO CE	Present	2025-11-01 10:52:24.255477	2025-11-01 10:52:24.255477
208	2025-10-31	NDICHIA GLEIN FOINMBAM	07:45:00	16:08:00	ATVEE AMR, CERTIFICATION LEVEL ONE ME	Present	2025-11-01 10:53:25.347401	2025-11-01 10:53:25.347401
209	2025-10-31	Kechazi Leonel Nchumi	07:52:00	16:08:00	ATVEE BC	Present	2025-11-01 10:54:15.119658	2025-11-01 10:54:15.119658
210	2025-10-31	Wandum O'Neil Nuvaga	07:28:00	15:48:00	ORIENTATION LEVEL A, ORIENTATION LEVEL B, CERTIFICATION LEVEL ONE EE	Present	2025-11-01 10:55:34.72835	2025-11-01 10:55:34.72835
211	2025-10-31	Emile Awah	07:52:00	15:40:00	ITVEE AMR, ITVEE CJ, ITVEE BC, ITVEE EPS, ITVEE HCE, ITVEE SM, ITVEE TE, CERTIFICATION LEVEL TWO TE, CERTIFICATION LEVEL TWO ME, CERTIFICATION LEVEL TWO HCE, CERTIFICATION LEVEL TWO EE, CERTIFICATION LEVEL TWO CE	Present	2025-11-01 10:57:24.108345	2025-11-01 10:57:24.108345
212	2025-10-31	Chem Sandra Ntala	07:32:00	03:40:00	CERTIFICATION LEVEL TWO CE, CERTIFICATION LEVEL TWO EE, CERTIFICATION LEVEL TWO HCE, CERTIFICATION LEVEL TWO ME, CERTIFICATION LEVEL TWO TE, ATVEE COMM	Present	2025-11-01 10:58:54.506345	2025-11-01 10:58:54.506345
213	2025-10-31	Brica Ngue Fon	08:00:00	16:03:00	ORIENTATION LEVEL A, ORIENTATION LEVEL B, ITVEE TE, ITVEE HCE, ITVEE SM, ITVEE EPS, ITVEE CJ, ITVEE BC, ITVEE AMR	Present	2025-11-01 11:00:04.265972	2025-11-01 11:00:04.265972
214	2025-10-31	Gebuin Bless Yuknwi	08:11:00	15:30:00	ORIENTATION LEVEL A, ORIENTATION LEVEL B, ATVEE BC	Present	2025-11-01 11:01:05.896774	2025-11-01 11:01:05.896774
215	2025-10-31	Mafain Alice Bih	07:19:00	15:30:00	ATVEE COMM, CERTIFICATION LEVEL TWO CE, CERTIFICATION LEVEL TWO EE, CERTIFICATION LEVEL TWO HCE, CERTIFICATION LEVEL TWO ME, CERTIFICATION LEVEL TWO TE, ITVEE TE, ITVEE SM, ITVEE HCE, ITVEE EPS, ITVEE CJ, ITVEE BC, ITVEE AMR	Present	2025-11-01 11:02:17.052119	2025-11-01 11:02:17.052119
216	2025-10-31	ABU ROSE MENNYI	09:00:00	12:43:00	CERTIFICATION LEVEL ONE EE	Present	2025-11-01 11:03:15.354359	2025-11-01 11:03:15.354359
217	2025-10-31	Mbaliko Prosper Khan	09:43:00	12:00:00	CERTIFICATION LEVEL ONE CE	Present	2025-11-01 11:04:17.878778	2025-11-01 11:04:17.878778
218	2025-10-31	Rose Ntone Chuba	07:00:00	12:00:00	ATVEE AMR	Present	2025-11-01 11:04:58.333557	2025-11-01 11:04:58.333557
173	2025-10-29	ABU ROSE MENNYI	07:40:00	15:55:00	ITVEE TE	Present	2025-11-01 10:01:19.61598	2025-11-01 11:05:50.346052
179	2025-10-29	Brica Ngue Fon	08:05:00	16:15:00	ORIENTATION LEVEL B, ORIENTATION LEVEL A, CERTIFICATION LEVEL ONE CE, CERTIFICATION LEVEL ONE EE, CERTIFICATION LEVEL ONE HCE, CERTIFICATION LEVEL ONE ME, CERTIFICATION LEVEL ONE TEX	Present	2025-11-01 10:13:46.828348	2025-11-01 11:06:04.77614
219	2025-11-01	NDICHIA GLEIN FOINMBAM	08:00:00	13:30:00		Present	2025-11-04 18:51:48.673183	2025-11-04 18:51:48.673183
220	2025-11-01	MILLA JOHN-PAUL TEBAH	07:50:00	15:00:00		Present	2025-11-04 18:52:35.156487	2025-11-04 18:52:35.156487
221	2025-11-04	Rose Ntone Chuba	07:42:00	14:55:00	ITVEE SM, CERTIFICATION LEVEL ONE ME	Present	2025-11-04 18:54:19.670439	2025-11-04 18:54:19.670439
222	2025-11-04	Nfor Vitalis Nfor 	07:42:00	19:00:00		Present	2025-11-04 18:54:55.371091	2025-11-04 18:54:55.371091
223	2025-11-04	Gebuin Bless Yuknwi	07:39:00	17:30:00	ATVEE BC	Present	2025-11-04 18:55:41.588795	2025-11-04 18:55:41.588795
224	2025-11-04	Mirabel fru	07:39:00	13:00:00		Present	2025-11-04 18:56:38.075855	2025-11-04 18:56:38.075855
225	2025-11-04	Kechazi Leonel Nchumi	07:45:00	15:45:00	ITVEE BC	Present	2025-11-04 18:57:23.970374	2025-11-04 18:57:23.970374
226	2025-11-04	ABU ROSE MENNYI	07:30:00	13:00:00		Present	2025-11-04 18:58:03.436354	2025-11-04 18:58:03.436354
227	2025-11-04	Emile Awah	07:47:00	09:00:00	CERTIFICATION LEVEL ONE ME	Present	2025-11-04 18:58:51.716511	2025-11-04 18:58:51.716511
228	2025-11-04	Mbaliko Prosper Khan	07:47:00	14:30:00		Present	2025-11-04 18:59:34.168684	2025-11-04 18:59:34.168684
229	2025-11-04	Manka'a Carine Awah	08:20:00	15:30:00	ORIENTATION LEVEL B, ORIENTATION LEVEL A, CERTIFICATION LEVEL ONE TEX	Present	2025-11-04 19:00:13.237781	2025-11-04 19:00:13.237781
231	2025-11-04	Christ Steve 	07:06:00	15:30:00	ITVEE HCE, CERTIFICATION LEVEL TWO TE	Present	2025-11-04 19:01:41.881238	2025-11-04 19:01:41.881238
232	2025-11-04	Mafain Alice Bih	07:20:00	15:50:00	ATVEE COMM, CERTIFICATION LEVEL ONE TEX	Present	2025-11-04 19:02:30.685474	2025-11-04 19:02:30.685474
234	2025-11-04	MILLA JOHN-PAUL TEBAH	08:56:00	15:40:00	ATVEE EPS, ITVEE EPS	Present	2025-11-04 19:05:10.273159	2025-11-04 19:05:10.273159
235	2025-11-04	NDICHIA GLEIN FOINMBAM	07:03:00	16:25:00	ITVEE AMR, CERTIFICATION LEVEL TWO ME	Present	2025-11-04 19:05:55.705351	2025-11-04 19:05:55.705351
236	2025-11-04	Wandum O'Neil Nuvaga	07:10:00	15:40:00	CERTIFICATION LEVEL ONE HCE, ITVEE HCE	Present	2025-11-04 19:06:35.13569	2025-11-04 19:06:35.13569
237	2025-11-04	Ngum Mary 	07:15:00	15:49:00	CERTIFICATION LEVEL TWO ME	Present	2025-11-04 19:07:18.486057	2025-11-04 19:07:18.486057
239	2025-11-11	Nfor Vitalis Nfor 	07:02:00	16:30:00		Present	2025-11-12 11:18:20.985597	2025-11-12 11:18:20.985597
240	2025-11-11	MILLA JOHN-PAUL TEBAH	07:26:00	15:40:00	ATVEE EPS, ITVEE EPS	Present	2025-11-12 11:19:49.982798	2025-11-12 11:19:49.982798
242	2025-11-11	Wandum O'Neil Nuvaga	07:47:00	16:01:00	ITVEE HCE, CERTIFICATION LEVEL TWO HCE	Present	2025-11-12 11:22:34.872709	2025-11-12 11:22:34.872709
243	2025-11-11	Mbaliko Prosper Khan	07:50:00	14:30:00	CERTIFICATION LEVEL TWO CE	Present	2025-11-12 11:24:55.221084	2025-11-12 11:24:55.221084
244	2025-11-11	Manka'a Carine Awah	07:25:00	15:30:00	ORIENTATION LEVEL A, ORIENTATION LEVEL B, CERTIFICATION LEVEL ONE CE, CERTIFICATION LEVEL ONE EE, CERTIFICATION LEVEL ONE HCE, CERTIFICATION LEVEL ONE ME, CERTIFICATION LEVEL ONE TEX	Present	2025-11-12 11:26:14.664346	2025-11-12 11:26:14.664346
245	2025-11-04	Kimbo Ringo Nfonguang	08:00:00	22:00:00	ATVEE AMR	Half Day	2025-11-12 11:41:08.498346	2025-11-12 11:41:08.498346
246	2025-11-05	Kimbo Ringo Nfonguang	10:00:00	12:00:00	ATVEE AMR	Half Day	2025-11-12 11:42:19.322348	2025-11-12 11:42:19.322348
247	2025-11-06	Kimbo Ringo Nfonguang	12:30:00	14:30:00	ATVEE AMR	Half Day	2025-11-12 11:43:23.406342	2025-11-12 11:43:23.406342
248	2025-11-07	Kimbo Ringo Nfonguang	08:00:00	22:00:00	ATVEE AMR	Present	2025-11-12 11:44:35.617709	2025-11-12 11:44:35.617709
307	2025-11-07	Menemoh Fieze Princely	08:20:00	22:00:00	ATVEE AMR, DIPLOMA AMR	Half Day	2025-11-13 13:18:04.848767	2025-11-13 13:18:04.848767
249	2025-11-05	Mirabel fru	07:10:00	15:30:00		Present	2025-11-12 12:14:42.060347	2025-11-12 12:14:42.060347
250	2025-11-05	Christ Steve 	07:36:00	15:54:00	CERTIFICATION LEVEL TWO HCE, ITVEE HCE	Present	2025-11-12 12:26:07.943189	2025-11-12 12:26:07.943189
251	2025-11-05	Wandum O'Neil Nuvaga	07:36:00	15:54:00	ITVEE HCE, CERTIFICATION LEVEL ONE HCE	Present	2025-11-12 12:27:06.421349	2025-11-12 12:27:06.421349
252	2025-11-05	Chem Sandra Ntala	07:36:00	16:10:00	CERTIFICATION LEVEL ONE CE, CERTIFICATION LEVEL ONE EE, CERTIFICATION LEVEL ONE HCE, CERTIFICATION LEVEL ONE ME, CERTIFICATION LEVEL ONE TEX, CERTIFICATION LEVEL TWO CE, CERTIFICATION LEVEL TWO EE, CERTIFICATION LEVEL TWO HCE, CERTIFICATION LEVEL TWO ME, CERTIFICATION LEVEL TWO TE, ORIENTATION LEVEL A, ORIENTATION LEVEL B	Present	2025-11-12 12:28:33.362995	2025-11-12 12:28:33.362995
253	2025-11-05	Ngah Divine 	07:35:00	16:00:00	ORIENTATION LEVEL A, ORIENTATION LEVEL B	Present	2025-11-12 12:29:17.49835	2025-11-12 12:29:17.49835
254	2025-11-05	Emile Awah	07:40:00	15:44:00	ATVEE AMR, ATVEE BC, ATVEE EPS, CERTIFICATION LEVEL ONE CE, CERTIFICATION LEVEL ONE EE, CERTIFICATION LEVEL ONE HCE, CERTIFICATION LEVEL ONE ME, CERTIFICATION LEVEL ONE TEX	Present	2025-11-12 12:30:50.670788	2025-11-12 12:30:50.670788
255	2025-11-05	MILLA JOHN-PAUL TEBAH	07:44:00	16:08:00	ATVEE EPS, ITVEE EPS	Present	2025-11-12 12:33:48.959358	2025-11-12 12:33:48.959358
256	2025-11-05	Gebuin Bless Yuknwi	07:41:00	16:21:00	ATVEE BC, ITVEE BC	Present	2025-11-12 12:34:42.781104	2025-11-12 12:34:42.781104
230	2025-11-04	Brica Ngue Fon	08:23:00	13:00:00	ORIENTATION LEVEL B, ORIENTATION LEVEL A	Absent	2025-11-04 19:01:06.396067	2025-11-12 12:38:23.912348
233	2025-11-04	Chem Sandra Ntala	08:38:00	15:40:00	CERTIFICATION LEVEL ONE HCE, ORIENTATION LEVEL A	Absent	2025-11-04 19:04:25.115165	2025-11-12 12:40:33.019008
241	2025-11-11	Gebuin Bless Yuknwi	07:48:00	17:00:00	ATVEE BC, ITVEE BC	Present	2025-11-12 11:21:11.593219	2025-11-12 12:45:34.301735
257	2025-11-05	Mafain Alice Bih	07:36:00	16:10:00	ATVEE COMM, CERTIFICATION LEVEL ONE CE, CERTIFICATION LEVEL ONE EE, CERTIFICATION LEVEL ONE HCE, CERTIFICATION LEVEL ONE ME, CERTIFICATION LEVEL ONE TEX	Present	2025-11-12 12:35:41.785454	2025-11-12 12:35:41.785454
259	2025-11-04	Chem Sandra Ntala	08:38:00	15:40:00	CERTIFICATION LEVEL ONE CE, CERTIFICATION LEVEL ONE EE, CERTIFICATION LEVEL ONE HCE, CERTIFICATION LEVEL ONE ME, CERTIFICATION LEVEL ONE TEX	Present	2025-11-12 12:41:59.615275	2025-11-12 12:41:59.615275
260	2025-11-04	Nfor Vitalis Nfor 	07:42:00	16:00:00	ORIENTATION LEVEL A, ORIENTATION LEVEL B	Absent	2025-11-12 12:43:08.67915	2025-11-12 12:43:08.67915
262	2025-11-04	DJIMO DJOMO BEN COLLINS	12:30:00	13:30:00	ORIENTATION LEVEL A	Absent	2025-11-12 12:47:33.703345	2025-11-12 12:47:33.703345
261	2025-11-04	DJIMO DJOMO BEN COLLINS	13:30:00	14:30:00	ORIENTATION LEVEL B	Absent	2025-11-12 12:45:14.459027	2025-11-12 12:48:40.002366
263	2025-11-11	DJIMO DJOMO BEN COLLINS	12:00:00	13:29:00	ORIENTATION LEVEL A	Absent	2025-11-12 12:51:31.603542	2025-11-12 12:51:31.603542
265	2025-11-11	DJIMO DJOMO BEN COLLINS	13:30:00	14:30:00	ORIENTATION LEVEL B	Absent	2025-11-12 12:54:39.72368	2025-11-12 12:54:39.72368
266	2025-11-05	Kechazi Leonel Nchumi	07:50:00	15:40:00	ATVEE BC, ITVEE BC	Present	2025-11-12 12:56:02.813513	2025-11-12 12:56:02.813513
267	2025-11-05	ABU ROSE MENNYI	08:00:00	16:05:00	CERTIFICATION LEVEL TWO TE, ITVEE TE	Present	2025-11-12 12:57:04.845315	2025-11-12 12:57:04.845315
268	2025-11-05	Manka'a Carine Awah	08:03:00	15:55:00	ORIENTATION LEVEL A, ORIENTATION LEVEL B, CERTIFICATION LEVEL ONE TEX, CERTIFICATION LEVEL ONE ME, CERTIFICATION LEVEL ONE HCE, CERTIFICATION LEVEL ONE EE, CERTIFICATION LEVEL ONE CE	Present	2025-11-12 12:58:09.549348	2025-11-12 12:58:09.549348
269	2025-11-05	NDICHIA GLEIN FOINMBAM	07:07:00	16:30:00	ORIENTATION LEVEL A, ORIENTATION LEVEL B, CERTIFICATION LEVEL TWO ME	Present	2025-11-12 12:59:26.952114	2025-11-12 12:59:26.952114
270	2025-11-05	Ngum Mary 	07:18:00	15:55:00	CERTIFICATION LEVEL TWO TE, ITVEE TE	Present	2025-11-12 13:00:28.910548	2025-11-12 13:00:28.910548
271	2025-11-05	Rose Ntone Chuba	07:30:00	15:55:00	CERTIFICATION LEVEL TWO ME, ITVEE AMR	Present	2025-11-12 13:01:26.430361	2025-11-12 13:01:26.430361
272	2025-11-06	MILLA JOHN-PAUL TEBAH	07:49:00	15:53:00	CERTIFICATION LEVEL ONE CE, CERTIFICATION LEVEL ONE ME	Present	2025-11-13 12:06:53.148348	2025-11-13 12:06:53.148348
273	2025-11-06	Kechazi Leonel Nchumi	07:48:00	16:07:00	ATVEE BC, CERTIFICATION LEVEL ONE CE	Present	2025-11-13 12:07:48.01213	2025-11-13 12:07:48.01213
274	2025-11-06	Rose Ntone Chuba	07:00:00	15:00:00	CERTIFICATION LEVEL ONE ME	Present	2025-11-13 12:08:48.145977	2025-11-13 12:08:48.145977
275	2025-11-06	Mafain Alice Bih	07:30:00	15:30:00	ATVEE COMM, CERTIFICATION LEVEL TWO CE, CERTIFICATION LEVEL TWO EE, CERTIFICATION LEVEL TWO HCE, CERTIFICATION LEVEL TWO ME, CERTIFICATION LEVEL TWO TE, ITVEE AMR, ITVEE BC, ITVEE CJ, ITVEE EPS, ITVEE HCE, ITVEE SM, ITVEE TE	Present	2025-11-13 12:10:28.998669	2025-11-13 12:10:28.998669
276	2025-11-06	Emile Awah	07:58:00	15:50:00	ATVEE AMR, ATVEE BC, ATVEE EPS, CERTIFICATION LEVEL TWO CE, CERTIFICATION LEVEL TWO EE, CERTIFICATION LEVEL TWO HCE, CERTIFICATION LEVEL TWO ME, CERTIFICATION LEVEL TWO TE, DIPLOMA AMR, DIPLOMA BC, DIPLOMA EPS, ITVEE AMR, ITVEE BC, ITVEE CJ, ITVEE EPS, ITVEE HCE, ITVEE SM, ITVEE TE	Present	2025-11-13 12:12:16.797623	2025-11-13 12:12:16.797623
277	2025-11-06	Christ Steve 	07:15:00	14:35:00	CERTIFICATION LEVEL ONE HCE	Present	2025-11-13 12:13:13.036351	2025-11-13 12:13:13.036351
278	2025-11-06	Ngah Divine 	07:30:00	16:45:00	ORIENTATION LEVEL A, ORIENTATION LEVEL B	Present	2025-11-13 12:21:24.869068	2025-11-13 12:21:24.869068
279	2025-11-06	Wandum O'Neil Nuvaga	08:12:00	14:35:00	CERTIFICATION LEVEL ONE HCE	Present	2025-11-13 12:22:15.990959	2025-11-13 12:22:15.990959
280	2025-11-06	Manka'a Carine Awah	07:30:00	15:30:00	ORIENTATION LEVEL A, ORIENTATION LEVEL B, CERTIFICATION LEVEL TWO TE, CERTIFICATION LEVEL TWO ME, CERTIFICATION LEVEL TWO HCE, CERTIFICATION LEVEL TWO EE, CERTIFICATION LEVEL TWO CE	Present	2025-11-13 12:23:06.307341	2025-11-13 12:23:06.307341
281	2025-11-06	ABU ROSE MENNYI	08:30:00	16:00:00	CERTIFICATION LEVEL ONE TEX	Present	2025-11-13 12:23:46.913613	2025-11-13 12:23:46.913613
282	2025-11-06	Brica Ngue Fon	09:31:00	15:30:00		Present	2025-11-13 12:25:22.049646	2025-11-13 12:25:22.049646
283	2025-11-06	Chem Sandra Ntala	07:29:00	16:00:00	ATVEE COMM, CERTIFICATION LEVEL TWO CE, CERTIFICATION LEVEL TWO EE, CERTIFICATION LEVEL TWO HCE, CERTIFICATION LEVEL TWO ME, CERTIFICATION LEVEL TWO TE	Present	2025-11-13 12:28:38.671358	2025-11-13 12:28:38.671358
284	2025-11-06	Ngum Mary 	07:26:00	15:30:00	CERTIFICATION LEVEL ONE CE	Present	2025-11-13 12:29:34.412342	2025-11-13 12:29:34.412342
285	2025-11-06	Ngum Mary 	07:00:00	15:15:00	CERTIFICATION LEVEL ONE TEX, ORIENTATION LEVEL A, ORIENTATION LEVEL B	Present	2025-11-13 12:30:36.700122	2025-11-13 12:30:36.700122
286	2025-11-05	Brica Ngue Fon	07:37:00	15:30:00		Present	2025-11-13 12:36:43.348349	2025-11-13 12:36:43.348349
287	2025-11-05	Mbaliko Prosper Khan	00:00:00	17:00:00	CERTIFICATION LEVEL TWO CE	Present	2025-11-13 12:37:37.961357	2025-11-13 12:37:37.961357
264	2025-11-05	Brica Ngue Fon	11:00:00	00:00:00	ORIENTATION LEVEL A	Half Day	2025-11-12 12:53:26.988229	2025-11-13 12:37:51.203765
288	2025-11-08	ABU ROSE MENNYI	08:00:00	16:43:00	CERTIFICATION LEVEL ONE TEX	Present	2025-11-13 12:39:27.271358	2025-11-13 12:39:27.271358
289	2025-11-08	NDICHIA GLEIN FOINMBAM	07:13:00	16:43:00		Present	2025-11-13 12:40:37.547614	2025-11-13 12:40:37.547614
290	2025-11-08	Ngah Divine 	07:30:00	16:45:00		Present	2025-11-13 12:41:13.301648	2025-11-13 12:41:13.301648
291	2025-11-08	Ngum Mary 	00:00:00	16:45:00		Present	2025-11-13 12:41:55.585963	2025-11-13 12:41:55.585963
292	2025-11-08	Mafain Alice Bih	12:15:00	16:45:00		Present	2025-11-13 12:42:33.028346	2025-11-13 12:42:33.028346
293	2025-11-08	Wandum O'Neil Nuvaga	11:50:00	16:45:00		Present	2025-11-13 12:43:16.715319	2025-11-13 12:43:16.715319
294	2025-11-07	Wandum O'Neil Nuvaga	07:28:00	17:00:00	ORIENTATION LEVEL A, ORIENTATION LEVEL B, CERTIFICATION LEVEL ONE HCE	Present	2025-11-13 12:44:22.765351	2025-11-13 12:44:22.765351
295	2025-11-07	Emile Awah	19:32:00	15:30:00	CERTIFICATION LEVEL TWO CE, CERTIFICATION LEVEL TWO EE, CERTIFICATION LEVEL TWO HCE, CERTIFICATION LEVEL TWO ME, CERTIFICATION LEVEL TWO TE, ITVEE AMR, ITVEE BC, ITVEE CJ, ITVEE EPS, ITVEE HCE, ITVEE SM, ITVEE TE	Present	2025-11-13 12:45:26.803051	2025-11-13 12:45:26.803051
296	2025-11-07	Kechazi Leonel Nchumi	07:40:00	16:09:00	ATVEE BC, DIPLOMA BC	Present	2025-11-13 12:46:15.922683	2025-11-13 12:46:15.922683
297	2025-11-07	Chem Sandra Ntala	07:47:00	16:00:00	ATVEE COMM, CERTIFICATION LEVEL TWO CE, CERTIFICATION LEVEL TWO EE, CERTIFICATION LEVEL TWO HCE, CERTIFICATION LEVEL TWO ME, CERTIFICATION LEVEL TWO TE	Present	2025-11-13 12:47:19.265853	2025-11-13 12:47:19.265853
298	2025-11-07	Mafain Alice Bih	07:30:00	16:00:00	ATVEE COMM, CERTIFICATION LEVEL TWO CE, CERTIFICATION LEVEL TWO EE, CERTIFICATION LEVEL TWO HCE, CERTIFICATION LEVEL TWO ME, CERTIFICATION LEVEL TWO TE	Present	2025-11-13 12:48:31.137356	2025-11-13 12:48:31.137356
299	2025-11-07	Gebuin Bless Yuknwi	08:02:00	15:30:00	ORIENTATION LEVEL A, ORIENTATION LEVEL B, CERTIFICATION LEVEL TWO CE, ATVEE BC, DIPLOMA BC	Present	2025-11-13 12:49:31.810924	2025-11-13 12:49:31.810924
300	2025-11-07	Christ Steve 	07:15:00	16:00:00	CERTIFICATION LEVEL ONE HCE	Present	2025-11-13 12:50:07.357359	2025-11-13 12:50:07.357359
301	2025-11-07	Ngah Divine 	07:45:00	15:30:00		Present	2025-11-13 13:00:57.777018	2025-11-13 13:00:57.777018
302	2025-11-07	Manka'a Carine Awah	07:30:00	15:30:00	ORIENTATION LEVEL A, ORIENTATION LEVEL B, CERTIFICATION LEVEL TWO TE, CERTIFICATION LEVEL TWO ME, CERTIFICATION LEVEL TWO HCE, CERTIFICATION LEVEL TWO EE, CERTIFICATION LEVEL TWO CE	Present	2025-11-13 13:03:15.284361	2025-11-13 13:03:15.284361
304	2025-11-07	Mbaliko Prosper Khan	09:00:00	12:00:00	CERTIFICATION LEVEL ONE CE	Half Day	2025-11-13 13:05:41.717112	2025-11-13 13:06:17.557347
305	2025-11-07	NDICHIA GLEIN FOINMBAM	07:08:00	15:30:00		Present	2025-11-13 13:07:10.078746	2025-11-13 13:07:10.078746
306	2025-11-07	Rose Ntone Chuba	07:00:00	15:30:00	ATVEE AMR	Present	2025-11-13 13:08:49.699128	2025-11-13 13:08:49.699128
308	2025-11-11	DJIMO DJOMO BEN COLLINS	08:18:00	14:51:00	ATVEE EPS, ITVEE EPS, CERTIFICATION LEVEL TWO EE	Present	2025-11-13 13:22:42.527675	2025-11-13 13:22:42.527675
309	2025-11-11	Mafain Alice Bih	07:30:00	15:43:00	ATVEE COMM, CERTIFICATION LEVEL ONE CE, CERTIFICATION LEVEL ONE EE, CERTIFICATION LEVEL ONE HCE, CERTIFICATION LEVEL ONE ME, CERTIFICATION LEVEL ONE TEX	Present	2025-11-13 13:24:23.674098	2025-11-13 13:24:23.674098
310	2025-11-11	Menemoh Fieze Princely	07:20:00	11:00:00	CERTIFICATION LEVEL TWO ME	Present	2025-11-13 13:26:12.143747	2025-11-13 13:26:12.143747
258	2025-11-11	Brica Ngue Fon	10:00:00	23:00:00	ORIENTATION LEVEL B	Absent	2025-11-12 12:37:49.104992	2025-11-13 13:26:48.917976
303	2025-11-07	ABU ROSE MENNYI	08:45:00	15:31:00	CERTIFICATION LEVEL ONE TEX	Present	2025-11-13 13:04:12.798578	2025-11-13 13:29:03.366846
311	2025-11-11	ABU ROSE MENNYI	07:51:00	16:00:00	ITVEE TE	Present	2025-11-13 13:32:12.742222	2025-11-13 13:32:12.742222
312	2025-11-11	Ngah Divine 	07:25:00	15:30:00	ORIENTATION LEVEL A, ORIENTATION LEVEL B	Present	2025-11-13 13:34:32.974228	2025-11-13 13:34:32.974228
313	2025-11-11	Ngum Mary 	07:00:00	15:30:00	CERTIFICATION LEVEL TWO TE, ITVEE TE	Present	2025-11-13 13:35:53.106227	2025-11-13 13:35:53.106227
314	2025-11-11	Emile Awah	07:57:00	15:30:00	CERTIFICATION LEVEL ONE CE, CERTIFICATION LEVEL ONE EE, CERTIFICATION LEVEL ONE HCE, CERTIFICATION LEVEL ONE ME, CERTIFICATION LEVEL ONE TEX	Present	2025-11-13 13:36:53.735351	2025-11-13 13:36:53.735351
315	2025-11-11	Rose Ntone Chuba	07:00:00	16:30:00	CERTIFICATION LEVEL TWO ME, ITVEE SM, ITVEE AMR	Present	2025-11-13 13:38:06.142759	2025-11-13 13:38:06.142759
316	2025-11-11	NDICHIA GLEIN FOINMBAM	07:12:00	16:00:00	CERTIFICATION LEVEL TWO ME, ITVEE AMR, ITVEE SM	Present	2025-11-13 13:44:10.577277	2025-11-13 13:44:10.577277
317	2025-11-11	Kimbo Ringo Nfonguang	10:01:00	12:00:00	ITVEE TE, ITVEE SM, ITVEE HCE, ITVEE EPS, ITVEE CJ, ITVEE BC, ITVEE AMR	Present	2025-11-13 13:45:10.819931	2025-11-13 13:45:10.819931
318	2025-11-11	Chem Sandra Ntala	08:03:00	16:00:00	ORIENTATION LEVEL A, ORIENTATION LEVEL B, CERTIFICATION LEVEL ONE TEX, CERTIFICATION LEVEL ONE ME, CERTIFICATION LEVEL ONE HCE, CERTIFICATION LEVEL ONE EE, CERTIFICATION LEVEL ONE CE	Present	2025-11-13 13:46:07.491644	2025-11-13 13:46:07.491644
319	2025-11-12	Christ Steve 	07:15:00	15:43:00	ITVEE HCE, CERTIFICATION LEVEL TWO HCE	Present	2025-11-13 13:56:02.591391	2025-11-13 13:56:02.591391
320	2025-11-12	Wandum O'Neil Nuvaga	07:30:00	15:41:00	ITVEE HCE, CERTIFICATION LEVEL TWO HCE	Present	2025-11-13 13:57:01.186715	2025-11-13 13:57:01.186715
321	2025-11-12	Rose Ntone Chuba	07:00:00	15:45:00	ITVEE SM, ITVEE AMR, CERTIFICATION LEVEL TWO ME	Present	2025-11-13 14:00:54.225806	2025-11-13 14:00:54.225806
322	2025-11-12	Manka'a Carine Awah	07:44:00	15:30:00	ORIENTATION LEVEL A, ORIENTATION LEVEL B, CERTIFICATION LEVEL ONE TEX, CERTIFICATION LEVEL ONE ME, CERTIFICATION LEVEL ONE HCE, CERTIFICATION LEVEL ONE EE, CERTIFICATION LEVEL ONE CE	Present	2025-11-13 14:04:07.157626	2025-11-13 14:04:07.157626
323	2025-11-12	ABU ROSE MENNYI	07:40:00	15:40:00	CERTIFICATION LEVEL TWO TE, ITVEE TE	Present	2025-11-13 14:06:17.264114	2025-11-13 14:06:17.264114
324	2025-11-12	Ngah Divine 	07:42:00	16:40:00	ORIENTATION LEVEL A, ORIENTATION LEVEL B	Present	2025-11-13 14:06:58.047223	2025-11-13 14:06:58.047223
325	2025-11-12	MILLA JOHN-PAUL TEBAH	07:53:00	15:53:00	ATVEE EPS, ITVEE EPS, ITVEE AMR	Present	2025-11-13 14:10:39.544436	2025-11-13 14:10:39.544436
326	2025-11-12	MILLA JOHN-PAUL TEBAH	07:53:00	15:53:00	ATVEE EPS, ITVEE EPS, ITVEE AMR	Present	2025-11-13 14:10:40.449783	2025-11-13 14:10:40.449783
327	2025-11-12	MILLA JOHN-PAUL TEBAH	07:53:00	15:53:00	ATVEE EPS, ITVEE EPS, ITVEE AMR	Present	2025-11-13 14:10:41.305359	2025-11-13 14:10:41.305359
328	2025-11-12	MILLA JOHN-PAUL TEBAH	07:53:00	15:53:00	ATVEE EPS, ITVEE EPS, ITVEE AMR	Present	2025-11-13 14:10:41.321344	2025-11-13 14:10:41.321344
329	2025-11-12	Ngum Mary 	07:50:00	15:00:00		Present	2025-11-13 14:13:12.604153	2025-11-13 14:13:12.604153
330	2025-11-12	Ngum Mary 	07:50:00	15:00:00		Present	2025-11-13 14:14:59.16435	2025-11-13 14:14:59.16435
331	2025-11-12	Emile Awah	07:53:00	15:00:00	ATVEE AMR, ATVEE BC, ATVEE EPS, DIPLOMA EPS, DIPLOMA BC, DIPLOMA AMR, CERTIFICATION LEVEL ONE TEX, CERTIFICATION LEVEL ONE ME, CERTIFICATION LEVEL ONE HCE, CERTIFICATION LEVEL ONE EE, CERTIFICATION LEVEL ONE CE	Present	2025-11-13 14:16:32.508263	2025-11-13 14:16:32.508263
332	2025-11-12	Mafain Alice Bih	07:10:00	15:50:00	CERTIFICATION LEVEL ONE CE, CERTIFICATION LEVEL ONE EE, CERTIFICATION LEVEL ONE HCE, CERTIFICATION LEVEL ONE ME, CERTIFICATION LEVEL ONE TEX, ATVEE COMM	Present	2025-11-13 14:17:53.084984	2025-11-13 14:17:53.084984
333	2025-11-12	Gebuin Bless Yuknwi	08:11:00	15:00:00	ATVEE BC, ITVEE BC, DIPLOMA BC	Present	2025-11-13 14:18:51.755813	2025-11-13 14:18:51.755813
334	2025-11-12	Kimbo Ringo Nfonguang	10:59:00	12:00:00	ATVEE AMR	Half Day	2025-11-13 14:19:44.556643	2025-11-13 14:19:44.556643
335	2025-11-12	DJIMO DJOMO BEN COLLINS	08:35:00	12:02:00	ITVEE EPS, CERTIFICATION LEVEL TWO EE	Present	2025-11-13 14:21:08.763057	2025-11-13 14:21:08.763057
336	2025-11-12	Mbaliko Prosper Khan	00:00:00	14:30:00	CERTIFICATION LEVEL TWO CE	Half Day	2025-11-13 14:22:01.921677	2025-11-13 14:22:33.918009
337	2025-11-12	Chem Sandra Ntala	07:42:00	15:36:00	ORIENTATION LEVEL A, ORIENTATION LEVEL B, CERTIFICATION LEVEL ONE CE, CERTIFICATION LEVEL ONE EE, CERTIFICATION LEVEL ONE HCE, CERTIFICATION LEVEL ONE ME, CERTIFICATION LEVEL ONE TEX	Present	2025-11-13 14:23:24.837061	2025-11-13 14:23:24.837061
338	2025-11-12	Brica Ngue Fon	08:00:00	13:15:00	ORIENTATION LEVEL A, ORIENTATION LEVEL B, CERTIFICATION LEVEL ONE TEX, CERTIFICATION LEVEL ONE ME, CERTIFICATION LEVEL ONE HCE, CERTIFICATION LEVEL ONE EE, CERTIFICATION LEVEL ONE CE	Present	2025-11-14 12:43:48.18469	2025-11-14 12:43:48.18469
339	2025-11-07	Brica Ngue Fon	08:05:00	13:45:00	ORIENTATION LEVEL A, ORIENTATION LEVEL B, CERTIFICATION LEVEL TWO TE, CERTIFICATION LEVEL TWO HCE, CERTIFICATION LEVEL TWO ME, CERTIFICATION LEVEL TWO EE, CERTIFICATION LEVEL TWO CE, ITVEE TE, ITVEE SM, ITVEE EPS, ITVEE HCE, ITVEE CJ, ITVEE BC, ITVEE AMR	Present	2025-11-14 12:46:10.381999	2025-11-14 12:46:10.381999
340	2025-11-13	NDICHIA GLEIN FOINMBAM	07:10:00	17:00:00	ITVEE AMR	Present	2025-11-14 12:50:48.419928	2025-11-14 12:50:48.419928
341	2025-11-13	Chem Sandra Ntala	07:45:00	15:37:00	ATVEE COMM, CERTIFICATION LEVEL TWO CE, CERTIFICATION LEVEL TWO EE, CERTIFICATION LEVEL TWO HCE, CERTIFICATION LEVEL TWO ME, CERTIFICATION LEVEL TWO TE	Present	2025-11-14 12:51:37.574053	2025-11-14 12:51:37.574053
342	2025-11-13	Christ Steve 	07:20:00	15:42:00	CERTIFICATION LEVEL ONE HCE	Present	2025-11-14 12:52:23.728006	2025-11-14 12:52:23.728006
343	2025-11-13	MILLA JOHN-PAUL TEBAH	07:48:00	03:03:00	CERTIFICATION LEVEL ONE EE, CERTIFICATION LEVEL ONE ME	Present	2025-11-14 12:53:32.880841	2025-11-14 12:53:32.880841
344	2025-11-13	Gebuin Bless Yuknwi	07:48:00	17:04:00	CERTIFICATION LEVEL ONE CE	Present	2025-11-14 12:54:21.221078	2025-11-14 12:54:21.221078
345	2025-11-13	Ngah Divine 	07:50:00	17:03:00	ORIENTATION LEVEL A, ORIENTATION LEVEL B	Present	2025-11-14 12:55:05.248346	2025-11-14 12:55:05.248346
346	2025-11-13	ABU ROSE MENNYI	08:30:00	15:12:00	CERTIFICATION LEVEL ONE TEX	Present	2025-11-14 12:55:54.683809	2025-11-14 12:55:54.683809
347	2025-11-13	Manka'a Carine Awah	07:30:00	15:30:00	ORIENTATION LEVEL A, ORIENTATION LEVEL B, CERTIFICATION LEVEL TWO TE, CERTIFICATION LEVEL TWO ME, CERTIFICATION LEVEL TWO HCE, CERTIFICATION LEVEL TWO EE, CERTIFICATION LEVEL TWO CE	Present	2025-11-14 12:57:07.361899	2025-11-14 12:57:07.361899
348	2025-11-13	Mafain Alice Bih	07:20:00	15:46:00	ATVEE COMM, CERTIFICATION LEVEL TWO CE, CERTIFICATION LEVEL TWO EE, CERTIFICATION LEVEL TWO HCE, CERTIFICATION LEVEL TWO ME, CERTIFICATION LEVEL TWO TE, ITVEE AMR, ITVEE CJ, ITVEE BC, ITVEE EPS, ITVEE HCE, ITVEE SM, ITVEE TE	Present	2025-11-14 12:58:49.439348	2025-11-14 12:58:49.439348
350	2025-11-13	Brica Ngue Fon	10:00:00	15:30:00	ORIENTATION LEVEL A, ORIENTATION LEVEL B, CERTIFICATION LEVEL TWO ME, CERTIFICATION LEVEL TWO HCE, CERTIFICATION LEVEL TWO EE, CERTIFICATION LEVEL TWO CE, CERTIFICATION LEVEL TWO TE, ITVEE AMR, ITVEE BC, ITVEE CJ, ITVEE EPS, ITVEE HCE, ITVEE SM, ITVEE TE	Present	2025-11-14 13:01:00.000346	2025-11-14 13:01:00.000346
349	2025-11-13	DJIMO DJOMO BEN COLLINS	08:15:00	15:00:00	ORIENTATION LEVEL A, ORIENTATION LEVEL B, CERTIFICATION LEVEL TWO EE, ATVEE EPS	Present	2025-11-14 12:59:40.429348	2025-11-14 13:01:23.067342
351	2025-11-13	Ngum Mary 	07:30:00	15:30:00	ORIENTATION LEVEL A, ORIENTATION LEVEL B	Present	2025-11-14 13:02:51.83651	2025-11-14 13:02:51.83651
352	2025-11-13	Rose Ntone Chuba	07:00:00	16:30:00	CERTIFICATION LEVEL ONE ME	Present	2025-11-14 13:03:41.441117	2025-11-14 13:03:41.441117
\.


--
-- Data for Name: staff_attendance_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.staff_attendance_settings (id, setting_key, setting_value, description, created_at, updated_at) FROM stdin;
1	full_time_expected_days	19	Expected number of days present per month for full-time staff	2025-11-08 20:06:57.028343	2025-11-12 11:14:30.61561
2	part_time_expected_days	11	Expected number of days present per month for part-time staff	2025-11-08 20:06:57.028343	2025-11-12 11:14:30.619951
3	start_time	07:30	Expected start time for staff (HH:MM format)	2025-11-08 20:20:21.779481	2025-11-12 11:14:30.62098
4	end_time	16:00	Expected end time for staff (HH:MM format)	2025-11-08 20:20:21.779481	2025-11-12 11:14:30.621873
\.


--
-- Data for Name: staff_employment_status; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.staff_employment_status (id, staff_name, employment_type, created_at, updated_at) FROM stdin;
1	ABU ROSE MENNYI	Full Time	2025-11-08 20:07:09.861391	2025-11-08 20:07:29.863126
4	Abang Junior	Full Time	2025-11-08 20:07:31.703291	2025-11-08 20:07:31.703291
6	Chem Sandra Ntala	Full Time	2025-11-08 20:07:36.498158	2025-11-08 20:07:36.498158
8	Mbaliko Prosper Khan	Part Time	2025-11-12 11:10:03.029177	2025-11-12 11:10:03.402137
10	Mirabel fru	Part Time	2025-11-12 11:10:11.34991	2025-11-12 11:10:11.34991
5	Brica Ngue Fon	Full Time	2025-11-08 20:07:34.593469	2025-11-12 11:12:25.147361
12	Menemoh Fieze Princely	Part Time	2025-11-12 11:12:54.563347	2025-11-12 11:12:54.563347
13	Manka'a Carine Awah	Full Time	2025-11-12 11:14:41.734354	2025-11-12 11:14:41.734354
14	Mafain Alice Bih	Full Time	2025-11-12 11:14:44.974734	2025-11-12 11:14:44.974734
15	MILLA JOHN-PAUL TEBAH	Full Time	2025-11-12 11:14:47.763301	2025-11-12 11:14:47.763301
16	Kechazi Leonel Nchumi	Full Time	2025-11-12 11:14:51.23436	2025-11-12 11:14:51.23436
17	Gebuin Bless Yuknwi	Full Time	2025-11-12 11:14:54.773036	2025-11-12 11:14:54.773036
18	Emile Awah	Full Time	2025-11-12 11:14:57.765912	2025-11-12 11:14:57.765912
19	DJIMO DJOMO BEN COLLINS	Full Time	2025-11-12 11:15:00.963354	2025-11-12 11:15:00.963354
20	Christ Steve 	Full Time	2025-11-12 11:15:03.426285	2025-11-12 11:15:03.426285
21	Wandum O'Neil Nuvaga	Full Time	2025-11-12 11:15:13.124352	2025-11-12 11:15:13.124352
22	Rose Ntone Chuba	Full Time	2025-11-12 11:15:19.20358	2025-11-12 11:15:19.20358
23	Ngum Mary 	Full Time	2025-11-12 11:15:23.635002	2025-11-12 11:15:23.635002
24	Nwunjoh Vera 	Full Time	2025-11-12 11:15:31.563273	2025-11-12 11:15:31.563273
25	Ngah Divine 	Full Time	2025-11-12 11:15:33.908008	2025-11-12 11:15:33.908008
26	Nfor Vitalis Nfor 	Full Time	2025-11-12 11:15:36.162896	2025-11-12 11:15:36.162896
27	Nfebe Bless Shu	Full Time	2025-11-12 11:15:38.995899	2025-11-12 11:15:38.995899
28	NDICHIA GLEIN FOINMBAM	Full Time	2025-11-12 11:15:42.642702	2025-11-12 11:15:42.642702
29	Kimbo Ringo Nfonguang	Part Time	2025-11-12 11:35:41.895886	2025-11-12 11:35:41.895886
\.


--
-- Data for Name: students; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.students (id, student_id, registration_date, full_name, sex, date_of_birth, place_of_birth, father_name, mother_name, class_id, specialty_id, guardian_contact, mother_contact, photo_url, created_at, photo, academic_year_id, "createdAt", "updatedAt", "deletedAt") FROM stdin;
372	25-VOT-AFUL-410	2025-11-05	AFUMBOM RAOUL 	M	2007-01-21	Njinikom 	Afumbom	Nkou lizette	16	3	670858327	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762357231946-iq3toey7sfc.jpg	2025-10-31 10:54:23.044698	\N	1	2025-10-31 11:54:23.044698+01	2025-10-31 11:54:23.044698+01	\N
4	25-VOT-TENG-004	2025-09-15	TEMBEI FAITH ENYONG	M	2011-04-25	Kulabei	Enyoung Euphemia	Enyoung	1	1	677786253	\N	\N	2025-09-15 19:49:11.851055	\N	1	2025-09-15 20:49:11.851055+01	2025-09-15 20:49:11.851055+01	\N
326	25-VOT-EKEL-290	2025-10-30	EKOUPOP APOUZA OTHNIEL	M	2010-09-27	Douala 	EKOUPOP	EKOUPOP	4	6	675758962	\N	\N	2025-10-30 14:45:19.457175	\N	1	2025-10-30 15:45:19.457175+01	2025-10-30 15:45:19.457175+01	\N
28	25-VOT-FOOH-436	2025-11-12	FON VENAND  AZOH	M	2010-11-11	Efag village 	Ayong Nestor 	Ayong	1	1	681801131	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761657542521-q1vn1v37jz9.jpg	2025-09-16 13:00:30.265975	\N	1	2025-09-16 14:00:30.265975+01	2025-09-16 14:00:30.265975+01	\N
3	25-VOT-ASEL-008	2025-09-16	ASHU EMMANUEL 	M	2013-11-07	Mankon Bamenda 	Ache 	Ache Racheal 	1	1	677692734	677692734	\N	2025-09-15 19:45:40.300465	\N	1	2025-09-15 20:45:40.300465+01	2025-09-15 20:45:40.300465+01	\N
11	25-VOT-IGGE-446	2025-11-14	IGOR GEROGE	M	2013-08-30	Mankon Bamenda 	Koni Ruth	Ruth	1	1	676787647	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1763079623343-fzakmwllo4c.jpg	2025-09-16 11:37:39.856971	\N	1	2025-09-16 12:37:39.856971+01	2025-09-16 12:37:39.856971+01	\N
18	25-VOT-MBAH-446	2025-11-14	MBA SAMUEL MIRACLE MBAH	M	2013-01-08	Batibo	Tah favor Ridley	Favor 	1	1	676238876	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1763079814150-m2pk7rsksb.jpg	2025-09-16 12:13:09.006212	\N	1	2025-09-16 13:13:09.006212+01	2025-09-16 13:13:09.006212+01	\N
10	25-VOT-SUMA-010	2025-09-16	SUIKA MBING OBAMA	M	2012-01-05	Luh health center 	Enestine Jaah	Ernestine 	1	1	654946088	\N	\N	2025-09-16 11:31:15.88636	\N	1	2025-09-16 12:31:15.88636+01	2025-09-16 12:31:15.88636+01	\N
12	25-VOT-UNFU-012	2025-09-16	UNJI MILDRED YEFU	F	2012-01-18	BAMENDA 	Nwandum Humblely	Nwundum	1	1	671495255	\N	\N	2025-09-16 11:41:32.890935	\N	1	2025-09-16 12:41:32.890935+01	2025-09-16 12:41:32.890935+01	\N
16	25-VOT-ANSY-016	2025-09-16	ANYE KESSY 	M	2014-02-14	Mbeme	Akum margerste	Margerate ENoh	1	1	681738272	\N	\N	2025-09-16 12:03:59.573067	\N	1	2025-09-16 13:03:59.573067+01	2025-09-16 13:03:59.573067+01	\N
17	25-VOT-BAUY-017	2025-09-16	BANLANYUY DESTINY BUOMIYUY	M	2014-08-30	BAMENDA 	Bahlanwi obedient 	Ngalla yvonne	1	1	679302790	\N	\N	2025-09-16 12:09:35.185846	\N	1	2025-09-16 13:09:35.185846+01	2025-09-16 13:09:35.185846+01	\N
33	25-VOT-MBEI-446	2025-11-14	MBAH JESSE MBANWEI	M	2014-08-11	SJc Batibo	Mbenwei Ekom	Mbanwei	1	1	670518840	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1763079974971-4ftbfgsk9my.jpg	2025-09-16 14:14:29.51942	\N	1	2025-09-16 15:14:29.51942+01	2025-09-16 15:14:29.51942+01	\N
42	25-VOT-MEEN-446	2025-11-14	MENYOH NOEL TENGEN	M	2010-08-20	Enyoh	Tegiw Doris Aaben	Doris 	1	1	677684972	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1763080087140-wzgeqckisv.jpg	2025-09-16 14:39:22.755721	\N	1	2025-09-16 15:39:22.755721+01	2025-09-16 15:39:22.755721+01	\N
2	25-VOT-NDUS-446	2025-11-14	NDAGHA AKUROS DARUS 	M	2013-03-09	Mankon Bamenda 	NDAGHA ERNEST	NDAGHA 	1	1	674297973	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1763080403413-8bds81s8eib.jpg	2025-09-15 19:39:50.354891	\N	1	2025-09-15 20:39:50.354891+01	2025-09-15 20:39:50.354891+01	\N
23	25-VOT-YIBA-023	2025-09-16	YIMLAH GODWILL WAMBA	M	2013-09-22	Mankon Bamenda 	Zincha Dominic 	Zincha	1	1	673680346	\N	\N	2025-09-16 12:36:50.696485	\N	1	2025-09-16 13:36:50.696485+01	2025-09-16 13:36:50.696485+01	\N
24	25-VOT-AKNG-024	2025-09-16	AKAH BLAISE TIFANG	M	2014-04-12	Bessom	Agwo Joseph 	Tiffany celvis	1	1	671882880	\N	\N	2025-09-16 12:41:28.990853	\N	1	2025-09-16 13:41:28.990853+01	2025-09-16 13:41:28.990853+01	\N
1	25-VOT-NDER-446	2025-11-14	NDAM PROSPER	M	2012-05-15	Mezam Bamenda 	Tikum Franco	Ndam Shella	1	1	675207290	675207290	https://st60307.ispot.cc/votechs7academygroup/students/photos/1763080599429-c1vl1aofhjd.jpg	2025-09-15 19:03:52.940064	\N	1	2025-09-15 20:03:52.940064+01	2025-09-15 20:03:52.940064+01	\N
14	25-VOT-NDEO-446	2025-11-14	NDIFOR TAMENG ROMEO	M	2014-05-30	Bafut	Fru Cicilia	Cicilia	1	1	674105516	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1763080723554-j1lr71heg5n.jpg	2025-09-16 11:57:09.320096	\N	1	2025-09-16 12:57:09.320096+01	2025-09-16 12:57:09.320096+01	\N
26	25-VOT-CHEX-026	2025-09-16	CHE ALEX	M	2015-02-15	Bafut	Banjo Nirian	Nirian	1	1	676007474	\N	\N	2025-09-16 12:49:50.258036	\N	1	2025-09-16 13:49:50.258036+01	2025-09-16 13:49:50.258036+01	\N
27	25-VOT-AYRI-027	2025-09-16	AYONG RUTH ENGWARI	F	2007-08-15	Efah village 	Ayong Nestor 	Ayong	1	1	681801131	\N	\N	2025-09-16 12:58:08.699839	\N	1	2025-09-16 13:58:08.699839+01	2025-09-16 13:58:08.699839+01	\N
37	25-VOT-CHKA-446	2025-11-14	CHOH PRECIOUS KEKA	M	2012-09-03	Mankon Bamenda 	Bih	Bih mirabell 	1	1	679256446	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1763080910823-34unr425w6r.jpg	2025-09-16 14:25:51.334024	\N	1	2025-09-16 15:25:51.334024+01	2025-09-16 15:25:51.334024+01	\N
30	25-VOT-NGAH-446	2025-11-14	NGU FAVOUR MBAH	M	2004-09-04	Mankon Bamenda 	Bombey 	Bombey melisa	1	1	683169503	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1763080971328-0db8yxy1uwu.jpg	2025-09-16 14:06:59.42791	\N	1	2025-09-16 15:06:59.42791+01	2025-09-16 15:06:59.42791+01	\N
34	25-VOT-YIYU-034	2025-09-16	YINYU MIGHTY NSUNGNYU	M	2013-05-11	Reginal hospital Bamenda 	M. Kongam Kelly 	Kelly 	1	1	681713520	\N	\N	2025-09-16 14:17:01.596773	\N	1	2025-09-16 15:17:01.596773+01	2025-09-16 15:17:01.596773+01	\N
32	25-VOT-PEAH-446	2025-11-14	PENN MACBRIGHT AWAH	M	2013-04-10	Nitop 6	Nkeng	Emerlian nkeng	1	1	671502016	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1763081386054-kv1sz9flar.jpg	2025-09-16 14:12:15.602435	\N	1	2025-09-16 15:12:15.602435+01	2025-09-16 15:12:15.602435+01	\N
36	25-VOT-WACE-036	2025-09-16	WATARD REJOICE	F	2011-03-12	BAMENDA 	Ngainke Nee Josephin	Nee Josephin	1	1	677084706	\N	\N	2025-09-16 14:23:51.296464	\N	1	2025-09-16 15:23:51.296464+01	2025-09-16 15:23:51.296464+01	\N
38	25-VOT-TEIM-038	2025-09-16	TENYONG PRAISE ANIM	F	2012-07-15	Choaba ashong	Acha 	Acha Belinda	1	1	67899836	\N	\N	2025-09-16 14:28:26.503752	\N	1	2025-09-16 15:28:26.503752+01	2025-09-16 15:28:26.503752+01	\N
13	25-VOT-SARY-446	2025-11-14	SAJU JERRY 	M	2011-02-16	BAMENDA 	Victoria Mah	Victoria	1	1	675099481	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1763081445459-fr1mbhjbryi.jpg	2025-09-16 11:50:35.465741	\N	1	2025-09-16 12:50:35.465741+01	2025-09-16 12:50:35.465741+01	\N
25	25-VOT-AKEL-130	2025-10-18	AKWA EMMANUEL 	M	2014-04-28	Douala	Engwari Blessing 	Blessing 	1	1	670722980	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1760777321519-lm9pdhxyrz.jpg	2025-09-16 12:46:21.082135	\N	1	2025-09-16 13:46:21.082135+01	2025-09-16 13:46:21.082135+01	\N
7	25-VOT-BIJI-130	2025-10-18	BIH SHALLOM BRIGHT NJI 	F	2014-02-14	Mankon	Nji Clovis ange	Nen Gisele fru	1	1	651155922	6511559222	https://st60307.ispot.cc/votechs7academygroup/students/photos/1760777849237-l8qhwtgvqx.jpg	2025-09-16 11:04:20.754683	\N	1	2025-09-16 12:04:20.754683+01	2025-09-16 12:04:20.754683+01	\N
15	25-VOT-BUEL-130	2025-10-18	BUMA EMMANUEL 	M	2013-02-24	District health center bali	Keep charles	Tampa melvis 	1	1	676389895	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1760777934163-wsspp748j1.jpg	2025-09-16 12:01:14.952204	\N	1	2025-09-16 13:01:14.952204+01	2025-09-16 13:01:14.952204+01	\N
6	25-VOT-ENOW-242	2025-10-28	ENOW FIJORITO ENOW	M	2014-06-20	Mbeme	Aghast Boniface	ENOW Lynda 	1	1	681569072	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761657130114-2ynlha3x73q.jpg	2025-09-15 19:57:18.794114	\N	1	2025-09-15 20:57:18.794114+01	2025-09-15 20:57:18.794114+01	\N
41	25-VOT-FOWI-242	2025-10-28	FON ALEX TEGWI	M	2012-10-06	Mankon Bamenda 	Legit Doris Aaben	Doris	1	1	677684972	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761657188530-5ydfe29d8j3.jpg	2025-09-16 14:36:07.796842	\N	1	2025-09-16 15:36:07.796842+01	2025-09-16 15:36:07.796842+01	\N
43	25-VOT-FONG-242	2025-10-28	FON EVAN MBATANG	M	2014-09-01	Mankon Bamenda 	Tegiw Doris  Aaben 	Doris 	1	1	677684972	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761657254796-xjrnwzcy79k.jpg	2025-09-16 14:41:33.535549	\N	1	2025-09-16 15:41:33.535549+01	2025-09-16 15:41:33.535549+01	\N
91	25-VOT-DIER-410	2025-11-05	DINGANA JANNET JENNIFER 	F	2010-08-16	Reginal hospital 	Bangu	Langu winifred	16	3	677527079	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762357470676-9urmqzs6l2s.jpg	2025-09-19 10:59:34.736801	\N	1	2025-09-19 11:59:34.736801+01	2025-09-19 11:59:34.736801+01	\N
376	25-VOT-JUUS-410	2025-11-05	JUMANGONG ELIECIOUS 	M	2006-09-10	BAMENDA 	Jumangong Rodof 	JUMANGANG	16	3	677471192	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762357700743-fsyte3pb41d.jpg	2025-10-31 11:03:13.701311	\N	1	2025-10-31 12:03:13.701311+01	2025-10-31 12:03:13.701311+01	\N
321	25-VOT-NGNG-286	2025-10-30	NGONG EMMA NJANG 	F	2010-05-31	Kom	  Andrew Ngong 	Veronica  Tang	4	6	672517469	682401180	\N	2025-10-30 14:08:33.844412	\N	1	2025-10-30 15:08:33.844412+01	2025-10-30 15:08:33.844412+01	\N
35	25-VOT-CHAN-053	2025-09-16	CHINFON MARIE NYUYKIGHAN	M	2025-09-16	VOTECH 	Bih	Bih faustina 	1	1	672841380	\N	\N	2025-09-16 14:20:37.62289	\N	1	2025-09-16 15:20:37.62289+01	2025-09-16 15:20:37.62289+01	\N
456	25-VOT-TAIN-415	2025-11-07	TAYU BRADLY BERIN 	M	2012-06-23	Banso	Tayu	Tayu Violette	2	2	680141350	\N	\N	2025-11-07 08:29:31.724313	\N	1	2025-11-07 09:29:31.724313+01	2025-11-07 09:29:31.724313+01	\N
55	25-VOT-YUUR-055	2025-09-16	YUH DIVINE KING FAVOUR	M	2025-09-16	VOTECH 	Votech 	Votech 	1	1	2000	2000	\N	2025-09-16 15:30:06.677313	\N	1	2025-09-16 16:30:06.677313+01	2025-09-16 16:30:06.677313+01	\N
88	25-VOT-APOH-351	2025-11-04	APUM DESTINY TENOH	M	2012-09-21	BAMENDA 	Votech 	Votech 	12	2	675047141	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762269578358-332yp70g758.jpg	2025-09-17 18:51:24.815799	\N	1	2025-09-17 19:51:24.815799+01	2025-09-17 19:51:24.815799+01	\N
83	25-VOT-NGIA-351	2025-11-04	NGENDE BLESS BOTIA	M	2009-06-06	Limbe	Esambe lawson	Ngende Dorothy 	12	2	653731810	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762270698659-ogekq6vuxil.jpg	2025-09-17 18:44:14.986001	\N	1	2025-09-17 19:44:14.986001+01	2025-09-17 19:44:14.986001+01	\N
60	25-VOT-AKNG-060	2025-09-16	AKWA JOSEPH ELANG	M	2025-09-16	VOTECH 	Votech 	Votech 	1	1	2000	2000	\N	2025-09-16 15:42:42.111017	\N	1	2025-09-16 16:42:42.111017+01	2025-09-16 16:42:42.111017+01	\N
63	25-VOT-NUDY-063	2025-09-17	NUBILA RANDY	F	2009-08-05	HEAD TOUCH	IVO SAMA	IVO	2	2	675963322	\N	\N	2025-09-17 14:26:54.557704	\N	1	2025-09-17 15:26:54.557704+01	2025-09-17 15:26:54.557704+01	\N
64	25-VOT-ATIO-064	2025-09-17	ATAKUETE FAITH ATCHIO	M	2013-10-03	MANKON BAMENDA 	MAKEUNNE	MAKEUNNE PELAGIE	2	2	677969399	\N	\N	2025-09-17 14:33:22.945569	\N	1	2025-09-17 15:33:22.945569+01	2025-09-17 15:33:22.945569+01	\N
65	25-VOT-MI.N-065	2025-09-17	MICAH SMITH NJOMEN .N 	M	2025-09-17	Mankon Bamenda 	Ngainke 	Ngainke Nee Josephin 	2	2	677084706	\N	\N	2025-09-17 14:39:01.854473	\N	1	2025-09-17 15:39:01.854473+01	2025-09-17 15:39:01.854473+01	\N
66	25-VOT-CHRU-066	2025-09-17	CHEO PRINCEWILL FRU	M	2010-10-24	Mankon Bamenda 	Anye Daniel fru	Anye	2	2	675215358	\N	\N	2025-09-17 14:41:17.633355	\N	1	2025-09-17 15:41:17.633355+01	2025-09-17 15:41:17.633355+01	\N
67	25-VOT-TEOH-067	2025-09-17	TETUH BLAISE NGOH	M	2012-07-22	Batibo	Temban chrysantus	Tamban 	2	2	675959326	\N	\N	2025-09-17 14:43:45.886026	\N	1	2025-09-17 15:43:45.886026+01	2025-09-17 15:43:45.886026+01	\N
68	25-VOT-EVJA-068	2025-09-17	EVAN GODWLL FEH KUJA	M	2011-02-03	Elizabeth cm health center 	Beatrice 	Beatrice 	2	2	674408006	\N	\N	2025-09-17 14:46:58.029645	\N	1	2025-09-17 15:46:58.029645+01	2025-09-17 15:46:58.029645+01	\N
85	25-VOT-NYLE-351	2025-11-04	NYEMKUNA GISELLE	F	2010-05-12	VOTECH 	Votech 	Votech 	12	2	670434778	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762271060493-ryqrg0e1mj.jpg	2025-09-17 18:47:25.316187	\N	1	2025-09-17 19:47:25.316187+01	2025-09-17 19:47:25.316187+01	\N
82	25-VOT-DUNE-409	2025-11-05	DUM CHRIST DELTINE	M	2010-12-29	VOTECH 	Votech 	Votech 	7	2	678965700	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762350387884-mh6i33uaasm.jpg	2025-09-17 15:33:52.627824	\N	1	2025-09-17 16:33:52.627824+01	2025-09-17 16:33:52.627824+01	\N
69	25-VOT-AWAN-429	2025-11-07	AWA FOKOU BRIAN	M	2012-03-24	VOTECH 	Votech 	Votech 	5	5	679860385	2000	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762524520794-uzicmitgxos.jpg	2025-09-17 14:49:19.358785	\N	1	2025-09-17 15:49:19.358785+01	2025-09-17 15:49:19.358785+01	\N
81	25-VOT-FOEN-429	2025-11-07	FORMONYUY PRINCE BANVEN 	M	2010-12-29	BAMENDA 	Valentine 	Diana	8	3	675552466	\N	\N	2025-09-17 15:32:02.145528	\N	1	2025-09-17 16:32:02.145528+01	2025-09-17 16:32:02.145528+01	\N
77	25-VOT-NDMA-077	2025-09-17	NDAM THELMA 	F	2013-11-10	BAMENDA 	Ndam	Ndam Edna	6	4	670555959	\N	\N	2025-09-17 15:22:15.161014	\N	1	2025-09-17 16:22:15.161014+01	2025-09-17 16:22:15.161014+01	\N
78	25-VOT-LULA-078	2025-09-17	LUM DANIELA	F	2011-04-28	Akum health center 	Bih	Marceline 	6	4	654044464	\N	\N	2025-09-17 15:26:39.924202	\N	1	2025-09-17 16:26:39.924202+01	2025-09-17 16:26:39.924202+01	\N
58	25-VOT-MIVI-433	2025-11-11	MILAN BRIGHT NUMVI	M	2025-11-11	Bali	NUMVI	Calista lenyonga	1	1	653989670	2000	\N	2025-09-16 15:34:20.521592	\N	1	2025-09-16 16:34:20.521592+01	2025-09-16 16:34:20.521592+01	\N
50	25-VOT-FOIN-446	2025-11-14	FORTEH WHITNEY SHIN	F	2025-11-14	VOTECH 	Votech 	Votech 	1	1	677828418	2000	https://st60307.ispot.cc/votechs7academygroup/students/photos/1763079462226-xrd3244ctll.jpg	2025-09-16 15:12:24.433362	\N	1	2025-09-16 16:12:24.433362+01	2025-09-16 16:12:24.433362+01	\N
48	25-VOT-KEAH-446	2025-11-14	KEHDAALA NELVIS KUJAH	M	2014-01-02	Bali u thc	Nahyuma	Nah Yuma Beatrice 	1	1	674408006	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1763079692376-iyvtfrzl07n.jpg	2025-09-16 15:04:49.102878	\N	1	2025-09-16 16:04:49.102878+01	2025-09-16 16:04:49.102878+01	\N
46	25-VOT-KUTA-446	2025-11-14	KUN DENZEL TATA	M	2025-11-14	VOTECH 	Choo Tata David 	Choo	1	1	670200083	677718309	https://st60307.ispot.cc/votechs7academygroup/students/photos/1763079743732-0sak3iyromu.jpg	2025-09-16 14:57:28.292705	\N	1	2025-09-16 15:57:28.292705+01	2025-09-16 15:57:28.292705+01	\N
62	25-VOT-NJEL-446	2025-11-14	NJI MICAH NOEL 	M	2015-01-09	Mankon Bamenda 	Nde Fru 	Nde 	1	1	674818005	2000	https://st60307.ispot.cc/votechs7academygroup/students/photos/1763081095892-088ohykg3aqq.jpg	2025-09-16 15:47:07.694252	\N	1	2025-09-16 16:47:07.694252+01	2025-09-16 16:47:07.694252+01	\N
61	25-VOT-NJPI-446	2025-11-14	NJINWIE TEWUH NOEL TEPI	M	2025-11-14	VOTECH 	Votech 	Votech 	1	1	675550851	2000	https://st60307.ispot.cc/votechs7academygroup/students/photos/1763081150078-mff9u143a69.jpg	2025-09-16 15:44:24.048624	\N	1	2025-09-16 16:44:24.048624+01	2025-09-16 16:44:24.048624+01	\N
86	25-VOT-NGPI-086	2025-09-17	NGOH TEWUH ROY TEPI	M	2025-09-17	VOTECH 	Votech 	Votech 	12	2	2000	\N	\N	2025-09-17 18:48:37.964633	\N	1	2025-09-17 19:48:37.964633+01	2025-09-17 19:48:37.964633+01	\N
74	25-VOT-PEAN-446	2025-11-14	PENN SAVIOUR KHAN 	M	2012-04-02	Pinyin	Emeilian Nkeng	Emeilian 	3	3	671502016	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1763131064430-8jjewgbafk4.jpg	2025-09-17 15:12:44.670201	\N	1	2025-09-17 16:12:44.670201+01	2025-09-17 16:12:44.670201+01	\N
71	25-VOT-FOEY-446	2025-11-14	FONGONG BRADLEY	M	2012-02-17	VOTECH 	Votech 	Votech 	3	3	678511168	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1763131256676-cbb7dnged0h.jpg	2025-09-17 14:56:29.251351	\N	1	2025-09-17 15:56:29.251351+01	2025-09-17 15:56:29.251351+01	\N
89	25-VOT-PRNU-089	2025-09-17	PRAISES KULITUNNU	F	2008-10-30	CM Health center bali	Beatrice leogal 	Beatrice 	12	2	653568343	\N	\N	2025-09-17 18:54:32.385861	\N	1	2025-09-17 19:54:32.385861+01	2025-09-17 19:54:32.385861+01	\N
90	25-VOT-AKEK-090	2025-09-17	AKENDE EMMANUEL ANDONGCHEK	M	2004-01-15	TEI health center 	ATTUHAP GEORGE 	Attuhap	12	2	676568541	\N	\N	2025-09-17 18:58:33.058405	\N	1	2025-09-17 19:58:33.058405+01	2025-09-17 19:58:33.058405+01	\N
56	25-VOT-CHBI-242	2025-10-28	CHRISTAINE KUCHAMBI	M	2025-10-28	VOTECH 	Votech 	Votech 	1	1	2000	2000	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761657044008-9yqqjncwuha.jpg	2025-09-16 15:31:55.634353	\N	1	2025-09-16 16:31:55.634353+01	2025-09-16 16:31:55.634353+01	\N
52	25-VOT-FOHE-243	2025-10-28	FONCHA DANIEL CHE	M	2025-10-28	VOTECH 	Votech 	Votech 	1	1	676573053	2000	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761657679801-u0lgv0dawyj.jpg	2025-09-16 15:19:05.984619	\N	1	2025-09-16 16:19:05.984619+01	2025-09-16 16:19:05.984619+01	\N
73	25-VOT-ANHT-236	2025-10-29	ANYAH ANLEY-BRIGHT	M	2013-07-25	Congo	Mbah Enih Angelina 	Angelina 	3	3	677318877	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761748694611-puhov77gx3g.jpg	2025-09-17 15:09:23.276347	\N	1	2025-09-17 16:09:23.276347+01	2025-09-17 16:09:23.276347+01	\N
75	25-VOT-NKOU-236	2025-10-29	NKWETA MARK-BRIGHT NTSOU	M	2011-11-16	BAMENDA R H	Nkwenta Gilbert 	Jong festa	3	3	678520533	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761749200825-164mwuv4g0u.jpg	2025-09-17 15:16:27.764778	\N	1	2025-09-17 16:16:27.764778+01	2025-09-17 16:16:27.764778+01	\N
107	25-VOT-ATIN-410	2025-11-05	ATUD KELVIN	M	2008-03-17	Mankon Bamenda 	Atud promise 	Atud	16	3	652019600	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762357328230-5pwqfboi1z9.jpg	2025-09-20 13:30:53.797148	\N	1	2025-09-20 14:30:53.797148+01	2025-09-20 14:30:53.797148+01	\N
8	25-VOT-AZHE-286	2025-10-30	AZONG PRINCEWILL CHE	M	2012-05-29	Mankon Bamenda 	Azong	Azong Irene	1	1	677786253	677786253	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761833357434-63ciqyox26e.jpg	2025-09-16 11:20:41.239479	\N	1	2025-09-16 12:20:41.239479+01	2025-09-16 12:20:41.239479+01	\N
465	25-VOT-CHNG-424	2025-11-07	CHEERFUL TITANG TEWANG 	M	2009-11-09	BAMENDA 	Mbah Rene Tewang 	Mbah Rene Tewang 	8	3	677807497	\N	\N	2025-11-07 08:59:00.748408	\N	1	2025-11-07 09:59:00.748408+01	2025-11-07 09:59:00.748408+01	\N
275	25-VOT-CHEL-287	2025-10-30	CHICK YANICK JOEL 	M	2013-08-01	Batibo 	Chick 	Tebi Miranda	19	1	673202468	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761834003356-fvx5rj1yo5n.jpg	2025-10-30 10:58:32.96904	\N	1	2025-10-30 11:58:32.96904+01	2025-10-30 11:58:32.96904+01	\N
121	25-VOT-DING-287	2025-10-30	DINGA MACHENRY FOWUJANG	M	2014-04-10	Bali	Nkonde  	Giselle	19	1	651229863	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761834257641-3ii9exau3w.jpg	2025-10-17 13:58:14.88666	\N	1	2025-10-17 14:58:14.88666+01	2025-10-17 14:58:14.88666+01	\N
100	25-VOT-NGOH-414	2025-11-06	NGUM CHELSY CHOH	F	2008-03-20	VOTECH 	Votech 	Votech 	17	6	675959011	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762442961223-7j50u7an7si.jpg	2025-09-19 11:22:50.876312	\N	1	2025-09-19 12:22:50.876312+01	2025-09-19 12:22:50.876312+01	\N
131	25-VOT-MBUM-288	2025-10-30	MBA-AKU EMMANUELAR AKUM	F	2012-12-26	Bamenda	Mba-aku 	stella	19	1	675852730	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761834712128-plqazeeocg.jpg	2025-10-18 09:45:59.273293	\N	1	2025-10-18 10:45:59.273293+01	2025-10-18 10:45:59.273293+01	\N
116	25-VOT-MUTA-348	2025-10-31	MUSHI SONITA 	F	2011-12-21	Batibo	Mushi	Mushi Jennifer 	19	1	682416849	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761916944208-x5cq4ibi7cm.jpg	2025-10-17 13:43:51.421816	\N	1	2025-10-17 14:43:51.421816+01	2025-10-17 14:43:51.421816+01	\N
125	25-VOT-TAAH-348	2025-10-31	TAH BLAISE AWAH	M	2010-01-01	Ashong 	Tah clinton	Tah	19	1	650080557	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761919053760-dfe59gy2ypd.jpg	2025-10-17 14:09:31.563823	\N	1	2025-10-17 15:09:31.563823+01	2025-10-17 15:09:31.563823+01	\N
96	25-VOT-AWEL-414	2025-11-06	AWAH EMMANUEL 	M	2009-12-05	Mankon Bamenda 	Nche  Awah 	Nche	15	5	670397734	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762444401343-d7xr8silpta.jpg	2025-09-19 11:17:42.749589	\N	1	2025-09-19 12:17:42.749589+01	2025-09-19 12:17:42.749589+01	\N
119	25-VOT-DETI-348	2025-10-31	DEL GRATIA VOMA NGUTI	M	2015-02-07	Saint Elizabeth health center 	Fidel keh 	Fidel	19	1	650325607	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761920155024-6bvsse11nq.jpg	2025-10-17 13:51:02.549003	\N	1	2025-10-17 14:51:02.549003+01	2025-10-17 14:51:02.549003+01	\N
105	25-VOT-BUAH-413	2025-11-06	BUH DANIELLA EKIAH 	F	2008-12-21	Wum	Felisita	Felisita	23	8	670601161	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762445408614-x88ykr71rx.jpg	2025-09-19 11:35:10.124813	\N	1	2025-09-19 12:35:10.124813+01	2025-09-19 12:35:10.124813+01	\N
93	25-VOT-WIUY-410	2025-11-05	WIYLANYUY EMMANUELA FONYUY	F	2007-12-18	Mankon Bamenda 	Wiylanyuy	Gladies	16	3	652019600	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762357064243-fomhvp8prdm.jpg	2025-09-19 11:04:01.118794	\N	1	2025-09-19 12:04:01.118794+01	2025-09-19 12:04:01.118794+01	\N
95	25-VOT-AKRU-107	2025-09-20	AKUM DANIEL FRU	M	2009-03-23	Douala	Fru Donatos	Doris 	15	5	673095227	\N	\N	2025-09-19 11:08:57.741505	\N	1	2025-09-19 12:08:57.741505+01	2025-09-19 12:08:57.741505+01	\N
104	25-VOT-ANON-108	2025-09-26	ANYE CLINTON 	M	2025-09-26	VOTECH 	Votech 	Votech 	25	2	2000	\N	\N	2025-09-19 11:30:18.188451	\N	1	2025-09-19 12:30:18.188451+01	2025-09-19 12:30:18.188451+01	\N
103	25-VOT-FONG-108	2025-09-26	FOMUM NOEL ANONG	M	2009-06-18	Batibo village 	Fomum	Fomum christening 	27	5	651916812	\N	\N	2025-09-19 11:28:34.24435	\N	1	2025-09-19 12:28:34.24435+01	2025-09-19 12:28:34.24435+01	\N
94	25-VOT-UDKA-108	2025-09-26	UDUCHIKA PRINCE UWAEBUKA	M	2010-10-21	Mankon Bamenda 	Uweabuka	Martha Deberechi uwaebuka	26	3	677727488	\N	\N	2025-09-19 11:07:25.506075	\N	1	2025-09-19 12:07:25.506075+01	2025-09-19 12:07:25.506075+01	\N
101	25-VOT-HAKI-108	2025-09-26	HADIJA BABOUBA IKI	F	2025-09-26	VOTECH 	Votech 	Votech 	24	8	2000	\N	\N	2025-09-19 11:24:26.582629	\N	1	2025-09-19 12:24:26.582629+01	2025-09-19 12:24:26.582629+01	\N
117	25-VOT-FRDI-348	2025-10-31	FRU JOEL NDI 	M	2014-06-21	VOTECH 	Ngang Henry 	Ngang 	19	1	679335158	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761920375392-f3j1s6beno9.jpg	2025-10-17 13:45:47.778599	\N	1	2025-10-17 14:45:47.778599+01	2025-10-17 14:45:47.778599+01	\N
457	25-VOT-FRDE-416	2025-11-07	FRU EDMONPRIDE 	M	2013-10-16	BAMENDA 	 Fru	BIH GRACE	2	2	676822880	\N	\N	2025-11-07 08:31:46.303784	\N	1	2025-11-07 09:31:46.303784+01	2025-11-07 09:31:46.303784+01	\N
123	25-VOT-ANNG-437	2025-11-12	ANJAH BRUNES FOBANG 	F	2012-06-04	VOTECH 	Enjoy Patrick 	Enjoh	19	1	681538770	\N	\N	2025-10-17 14:05:51.608426	\N	1	2025-10-17 15:05:51.608426+01	2025-10-17 15:05:51.608426+01	\N
133	25-VOT-APNG-446	2025-11-13	APIEBUGE REFIND ANONG	M	2010-08-15	Reginal hospital Bamenda 	Apiebuge Elbel 	Apiebuge	2	2	671989619	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1763042994178-bqwtr3j56m7.jpg	2025-10-18 09:55:57.432455	\N	1	2025-10-18 10:55:57.432455+01	2025-10-18 10:55:57.432455+01	\N
108	25-VOT-NJSE-446	2025-11-14	NjI GODWILL TSE	M	2025-11-14	BAMENDA 	Bih	Bih eveyline 	1	1	676247247	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1763081026023-qp4m89d1fgh.jpg	2025-10-17 09:59:14.368007	\N	1	2025-10-17 10:59:14.368007+01	2025-10-17 10:59:14.368007+01	\N
118	25-VOT-MBON-348	2025-10-31	MBAH SEARCH OFON	M	2011-11-06	Bless international health center 	Njiwah Eric 	Classrisse	19	1	674785504	677893718	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761920581484-svhzv43e3ld.jpg	2025-10-17 13:48:12.930929	\N	1	2025-10-17 14:48:12.930929+01	2025-10-17 14:48:12.930929+01	\N
114	25-VOT-PEAH-114	2025-10-17	PENN DESTINY AWAH	M	2010-10-18	Buchi	Penn emmanu	Penn	19	1	653057421	\N	\N	2025-10-17 11:53:43.512255	\N	1	2025-10-17 12:53:43.512255+01	2025-10-17 12:53:43.512255+01	\N
115	25-VOT-MUIA-348	2025-10-31	MUSHI SONIA	F	2011-12-21	Batibo 	Mushi	Mushi Jennifer 	19	1	682416849	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761920749950-2omgccyfnye.jpg	2025-10-17 11:57:15.054064	\N	1	2025-10-17 12:57:15.054064+01	2025-10-17 12:57:15.054064+01	\N
124	25-VOT-NJHA-348	2025-10-31	NJONG ANGEL BRIGHT ACHA	F	2013-09-26	Gusang 	Njin divine 	Njin	19	1	679933028	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761921506102-n0v7dwqe6r.jpg	2025-10-17 14:07:47.892484	\N	1	2025-10-17 15:07:47.892484+01	2025-10-17 15:07:47.892484+01	\N
127	25-VOT-TEWO-348	2025-10-31	TEKE DAISY ANGEL BOBIMWO	F	2015-04-06	BAMENDA 	Ngoh Manavis 	Ngoh	19	1	683181222	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761922025318-fuvidxhhyub.jpg	2025-10-17 14:15:10.279166	\N	1	2025-10-17 15:15:10.279166+01	2025-10-17 15:15:10.279166+01	\N
106	25-VOT-NWDE-351	2025-11-04	NWANA JUDE	M	2009-12-13	Pinyin 	Nwana divine	Nwana	20	2	677963750	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762269647895-fn22wwluchw.jpg	2025-09-19 11:39:42.951094	\N	1	2025-09-19 12:39:42.951094+01	2025-09-19 12:39:42.951094+01	\N
129	25-VOT-AGJI-181	2025-10-21	AGWE PEACE-BROWN NJI	M	2013-04-15	Ngyen mbo	Ngwe	Ngwe janice	19	1	654752767	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761056727338-rds4odakflc.jpg	2025-10-17 14:27:50.569193	\N	1	2025-10-17 15:27:50.569193+01	2025-10-17 15:27:50.569193+01	2025-10-27 08:31:29.23429+01
20	25-VOT-AKCK-130	2025-10-18	AKAH EGLISE ADUCK	M	2013-05-03	Batibo	Akaah Terence 	Akaah	1	1	651099095	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1760777192161-w0gx0xzzp.jpg	2025-09-16 12:22:07.302919	\N	1	2025-09-16 13:22:07.302919+01	2025-09-16 13:22:07.302919+01	\N
22	25-VOT-BIHT-130	2025-10-18	BIEMBUH CALEB BRIGHT 	M	2014-10-03	Mankon Bamenda 	Bingha mbuh	Azah perpetual 	1	1	651238306	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1760777749737-fg3t2gnkn8f.jpg	2025-09-16 12:33:23.615539	\N	1	2025-09-16 13:33:23.615539+01	2025-09-16 13:33:23.615539+01	\N
113	25-VOT-FOCK-181	2025-10-21	FOMUM MICAH AJECK	M	2014-10-23	Ashong	Tebeck	Recheck Susan 	19	1	683131643	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761057054297-zm54l3wq36i.jpg	2025-10-17 11:50:27.088976	\N	1	2025-10-17 12:50:27.088976+01	2025-10-17 12:50:27.088976+01	\N
241	25-VOT-BIIG-287	2025-10-30	BIH WICKNEY GOHGNIG 	F	2014-02-05	Mankon Bamenda 	Gohgnig theo	Gohgnig	19	1	676117057	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761833495776-nhktug04a5.jpg	2025-10-28 07:58:11.121052	\N	1	2025-10-28 08:58:11.121052+01	2025-10-28 08:58:11.121052+01	\N
159	25-VOT-MBCK-348	2025-11-04	MBAAKU MACBRIAN NJECK 	M	2009-08-08	BAMENDA 	MBAH-AKU 	MBAH-AKU STELA	10	5	675852730	\N	\N	2025-10-20 14:15:58.929088	\N	1	2025-10-20 15:15:58.929088+01	2025-10-20 15:15:58.929088+01	\N
132	25-VOT-EPOH-137	2025-10-18	EPONG NASERI NWABOH	M	2013-06-19	Mankon Bamenda 	Tebah	Roslina	2	2	653848240	\N	\N	2025-10-18 09:52:52.197618	\N	1	2025-10-18 10:52:52.197618+01	2025-10-18 10:52:52.197618+01	\N
180	25-VOT-ARSE-351	2025-11-04	ARTHUR BLAISE 	M	2008-10-04	Mbengwi	 wabara	Magdelen wabara	20	2	651622533	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762268965782-0sfpj7rrbvhc.jpg	2025-10-20 15:30:45.754756	\N	1	2025-10-20 16:30:45.754756+01	2025-10-20 16:30:45.754756+01	\N
164	25-VOT-NGOM-351	2025-11-04	NGONG EMMANUEL AKIAMBOM	M	2011-12-07	Mankon Bamenda 	nayeh	Calista nayeh	12	2	670354254	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762270776867-3y98tvjx5l.jpg	2025-10-20 14:34:58.790061	\N	1	2025-10-20 15:34:58.790061+01	2025-10-20 15:34:58.790061+01	\N
168	25-VOT-NKHE-351	2025-11-04	NKWENTI RONNYGLEN KENACHE	M	2009-11-22	BAMENDA 	Atock	Helen atock	12	2	677245465	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762270926535-ji72trncpl.jpg	2025-10-20 14:46:29.930277	\N	1	2025-10-20 15:46:29.930277+01	2025-10-20 15:46:29.930277+01	\N
156	25-VOT-NDES-409	2025-11-05	NDUFONG ALEXIES 	M	2010-08-09	Batibo 	Teku David 	Teku	7	2	672247298	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762352567616-azxobg66buo.jpg	2025-10-20 14:06:52.3254	\N	1	2025-10-20 15:06:52.3254+01	2025-10-20 15:06:52.3254+01	\N
176	25-VOT-KHIE-410	2025-11-05	KHAN ESTHELA MECHIE 	F	2004-04-08	Pinyin 	Nji Edison 	Nji	18	4	670503636	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762356125914-gk93tb38b7r.jpg	2025-10-20 15:16:33.685078	\N	1	2025-10-20 16:16:33.685078+01	2025-10-20 16:16:33.685078+01	\N
177	25-VOT-FOUS-410	2025-11-05	FOMONYUY PRECIOUS 	F	2010-06-06	BAMENDA 	Emmanuel Tumi	Marie Clarice 	18	4	677745512	677745512	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762356909856-ojubm9uuat.jpg	2025-10-20 15:18:57.813823	\N	1	2025-10-20 16:18:57.813823+01	2025-10-20 16:18:57.813823+01	\N
171	25-VOT-MOSE-414	2025-11-06	MOKOM PRAISE 	M	2009-10-31	BAMENDA 	Mokom Enestine 	Mokom	16	3	680301269	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762440062977-c2kqkzgtx1.jpg	2025-10-20 14:58:27.441635	\N	1	2025-10-20 15:58:27.441635+01	2025-10-20 15:58:27.441635+01	\N
163	25-VOT-MARU-414	2025-11-06	MAMBO SHARON FRU 	F	2013-09-17	Mankon Bamenda 	Fru 	FRU EURINE 	9	6	677068794	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762440511116-o21cyvi2c9a.jpg	2025-10-20 14:27:23.904246	\N	1	2025-10-20 15:27:23.904246+01	2025-10-20 15:27:23.904246+01	\N
175	25-VOT-LAUL-414	2025-11-06	LAMFU PAUL 	M	2004-03-22	Ndu	Lamfu	Lamfu aginess	14	5	675585974	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762441880237-y1nkq28oycn.jpg	2025-10-20 15:13:24.059776	\N	1	2025-10-20 16:13:24.059776+01	2025-10-20 16:13:24.059776+01	\N
173	25-VOT-BLBO-414	2025-11-06	BLESS BOTANGBO	M	2007-10-07	Bali	Magdalene	Magdalene	15	5	676405126	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762444489701-4nccjc70wol.jpg	2025-10-20 15:06:28.737828	\N	1	2025-10-20 16:06:28.737828+01	2025-10-20 16:06:28.737828+01	\N
138	25-VOT-FOEP-413	2025-11-06	FOMBI CALEP 	M	2009-03-28	Bamenda General hospital	Fombi	Stirring flovino	15	5	678580933	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762444673976-1hg5079uvyd.jpg	2025-10-18 10:22:08.994091	\N	1	2025-10-18 11:22:08.994091+01	2025-10-18 11:22:08.994091+01	\N
149	25-VOT-KUNE-149	2025-10-20	KUKWA AULINE 	F	2012-03-10	Mankon Bamenda 	Nayeh	Calista nayeh	6	4	670354254	\N	\N	2025-10-20 13:45:36.836813	\N	1	2025-10-20 14:45:36.836813+01	2025-10-20 14:45:36.836813+01	\N
135	25-VOT-NGEL-429	2025-11-07	NGANG LOIS DANIEL 	M	2013-02-02	BAMENDA 	Ngang Henry 	Ngang 	5	5	679335158	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762526184841-p433inthk4d.jpg	2025-10-18 10:05:22.569502	\N	1	2025-10-18 11:05:22.569502+01	2025-10-18 11:05:22.569502+01	\N
151	25-VOT-SAUY-151	2025-10-20	SANDRA TINYUY NKONYUY	F	2013-04-09	BAMENDA 	Bih	Bih oddett	6	4	654101521	\N	\N	2025-10-20 13:50:56.647799	\N	1	2025-10-20 14:50:56.647799+01	2025-10-20 14:50:56.647799+01	\N
136	25-VOT-NJSU-429	2025-11-07	NJIBRIL IDERISU 	M	2010-05-24	Bamenda 	IDERISU	Mrs IDERISU 	5	5	680890366	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762526467380-fybyrum3tih.jpg	2025-10-18 10:07:55.596346	\N	1	2025-10-18 11:07:55.596346+01	2025-10-18 11:07:55.596346+01	\N
134	25-VOT-TIND-446	2025-11-14	TITA JOHN RAYMOND 	M	2010-12-18	VOTECH 	Votech 	Votech 	5	5	670740930	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1763130259097-njngfyt7l7c.jpg	2025-10-18 09:59:20.416942	\N	1	2025-10-18 10:59:20.416942+01	2025-10-18 10:59:20.416942+01	\N
157	25-VOT-NDLE-157	2025-10-20	NDI MACMILLAN TEMNBELE 	M	2025-10-20	BAMENDA 	Votech 	Votech 	10	5	2000	\N	\N	2025-10-20 14:08:54.602524	\N	1	2025-10-20 15:08:54.602524+01	2025-10-20 15:08:54.602524+01	\N
158	25-VOT-MOEN-158	2025-10-20	MOPECHA GISLEN	M	2008-01-27	BAMENDA 	Teneng 	Teneng Edith	10	5	675459582	\N	\N	2025-10-20 14:11:25.070773	\N	1	2025-10-20 15:11:25.070773+01	2025-10-20 15:11:25.070773+01	\N
160	25-VOT-NGEN-160	2025-10-20	NGANG FIELDEN	M	2010-08-08	BAMENDA 	Ngang 	Ngang Eranline 	8	3	677420495	\N	\N	2025-10-20 14:21:15.918234	\N	1	2025-10-20 15:21:15.918234+01	2025-10-20 15:21:15.918234+01	\N
161	25-VOT-MUOH-161	2025-10-20	MUNDU TREASURE MUNOH	M	2011-10-20	BAMENDA 	Mundu Simon 	Mundu	8	3	677022587	\N	\N	2025-10-20 14:23:03.860539	\N	1	2025-10-20 15:23:03.860539+01	2025-10-20 15:23:03.860539+01	\N
162	25-VOT-PEWI-162	2025-10-20	PENN TENENG AZINWI	M	2025-10-20	BAMENDA 	Asaah Eric	Asaah 	8	3	674606274	\N	\N	2025-10-20 14:24:33.680735	\N	1	2025-10-20 15:24:33.680735+01	2025-10-20 15:24:33.680735+01	\N
167	25-VOT-MBEL-167	2025-10-20	MBAH  KELLY NOEL	M	2010-12-08	BAMENDA 	Teke	Teke Doris Tifuh	12	2	676307043	\N	\N	2025-10-20 14:44:30.913521	\N	1	2025-10-20 15:44:30.913521+01	2025-10-20 15:44:30.913521+01	\N
178	25-VOT-YAAN-178	2025-10-20	YAKWO GUILAN 	F	2009-04-21	Health center baligam	Yakwo	Pendeze Lynette 	17	6	681271384	\N	\N	2025-10-20 15:22:54.130958	\N	1	2025-10-20 16:22:54.130958+01	2025-10-20 16:22:54.130958+01	\N
179	25-VOT-NKWA-179	2025-10-20	NKAMCHOR NOEL NKWA 	M	2009-12-10	BAMENDA 	Nchanchou	Nchanchou pemela	25	2	671765313	\N	\N	2025-10-20 15:27:25.326284	\N	1	2025-10-20 16:27:25.326284+01	2025-10-20 16:27:25.326284+01	\N
137	25-VOT-AFHT-137	2025-10-18	AFESEH NEVILL BRIGHT	M	2011-04-05	Gabon	Afeseh	Afeseh mary 	5	5	654371555	\N	\N	2025-10-18 10:17:41.572601	\N	1	2025-10-18 11:17:41.572601+01	2025-10-18 11:17:41.572601+01	2025-10-27 08:18:01.586167+01
172	25-VOT-AFUL-172	2025-10-20	AFUMBOM RAOUL 	M	2007-01-21	Njinikom	Nkou	Nkou lizette	16	3	670858327	\N	\N	2025-10-20 15:01:36.911563	\N	1	2025-10-20 16:01:36.911563+01	2025-10-20 16:01:36.911563+01	2025-10-27 08:31:13.02069+01
146	25-VOT-EJIS-236	2025-10-29	EJAH CLARIS 	F	2010-01-10	VOTECH 	Votech 	Votech 	4	6	677719064	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761746812645-ockddjdhyvq.jpg	2025-10-20 13:37:22.295217	\N	1	2025-10-20 14:37:22.295217+01	2025-10-20 14:37:22.295217+01	\N
148	25-VOT-FOLL-236	2025-10-29	FONDEN NOAMI ABULL	F	2010-11-08	Batibo 	Rachel 	Rachel 	4	6	675851199	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761747192187-dhdftn0b4uc.jpg	2025-10-20 13:42:20.114636	\N	1	2025-10-20 14:42:20.114636+01	2025-10-20 14:42:20.114636+01	\N
145	25-VOT-KIOM-236	2025-10-29	KITU ROY CHIMABOM	M	2013-09-30	BAMENDA 	Calisto nayeh 	Nayeh	4	6	670354254	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761747296781-ilz8lrikohb.jpg	2025-10-20 13:36:07.305658	\N	1	2025-10-20 14:36:07.305658+01	2025-10-20 14:36:07.305658+01	\N
147	25-VOT-TERI-236	2025-10-29	TEPI FAVOUR SIRRI 	F	2012-11-12	BAMENDA 	Mercy 	Mercy 	4	6	654371555	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761748329813-seyw1elbhye.jpg	2025-10-20 13:40:09.031253	\N	1	2025-10-20 14:40:09.031253+01	2025-10-20 14:40:09.031253+01	\N
141	25-VOT-NUET-236	2025-10-29	NUBILA FAVOUR MBIKET 	M	2013-07-04	VOTECH 	Votech 	Votech 	3	3	677719064	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761749148472-11e5e5poxwd.jpg	2025-10-20 13:23:18.491828	\N	1	2025-10-20 14:23:18.491828+01	2025-10-20 14:23:18.491828+01	\N
182	25-VOT-BAWA-287	2025-10-30	BAIYE PRINCESS SAMIRA NGWA 	F	2012-08-27	Kumba	Baiye 	Baiye Cynthia 	19	1	653358350	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761833430437-6oq1uleyxqj.jpg	2025-10-22 06:35:29.213515	\N	1	2025-10-22 07:35:29.213515+01	2025-10-22 07:35:29.213515+01	\N
222	25-VOT-GAZA-410	2025-11-05	GANBOBGA COLLINS TEZA 	M	2011-04-26	BAMENDA 	Gangbongq 	Peckuna vivian	16	3	676379891	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762357600037-qqdxrs3nho.jpg	2025-10-22 13:18:57.328022	\N	1	2025-10-22 14:18:57.328022+01	2025-10-22 14:18:57.328022+01	\N
126	25-VOT-FOLY-181	2025-10-21	FONCHAM WISDOM BRIGHTLY 	M	2014-03-04	VOTECH 	Votech 	Votech 	19	1	676238710	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761057311128-jx83nt9g6cc.jpg	2025-10-17 14:11:46.921874	\N	1	2025-10-17 15:11:46.921874+01	2025-10-17 15:11:46.921874+01	\N
169	25-VOT-NDLB-410	2025-11-05	NDZELAMYUY ROBERTINE-FEH ANGELB	F	2010-09-09	PMI 	Nza 	Nza nyuykwi	16	3	672478162	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762358113332-r05cvwda2ak.jpg	2025-10-20 14:51:40.610844	\N	1	2025-10-20 15:51:40.610844+01	2025-10-20 15:51:40.610844+01	\N
226	25-VOT-CHOH-413	2025-11-06	CHAH BRANDA AWOH 	F	2007-10-04	VOTECH 	Votech 	Votech 	23	8	670388280	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762445557978-0nriog9nj6n.jpg	2025-10-22 13:33:23.449598	\N	1	2025-10-22 14:33:23.449598+01	2025-10-22 14:33:23.449598+01	\N
201	25-VOT-CHTA-415	2025-11-07	CHITABANG PRUDENCE TITA	M	2025-11-07	VOTECH 	Mathias Tita 	Chitabang 	8	3	678093453	\N	\N	2025-10-22 10:14:48.778735	\N	1	2025-10-22 11:14:48.778735+01	2025-10-22 11:14:48.778735+01	\N
221	25-VOT-MBHA-213	2025-10-22	MBOH KINASON TICHA 	M	2010-06-19	BAMENDA 	Mboh	Lum Emelda 	16	3	676118420	\N	\N	2025-10-22 13:14:47.615101	\N	1	2025-10-22 14:14:47.615101+01	2025-10-22 14:14:47.615101+01	2025-11-15 09:31:01.248242+01
211	25-VOT-CHPH-429	2025-11-07	CHEFOR DANIEL  TRIUMPH 	M	2012-03-19	General hospital Bamenda 	Nubila	Nubila hilda	5	5	670345170	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762525436379-g2dtd3oby2r.jpg	2025-10-22 12:02:31.839801	\N	1	2025-10-22 13:02:31.839801+01	2025-10-22 13:02:31.839801+01	\N
227	25-VOT-NAGE-429	2025-11-07	NAHVOMA COURAGE 	F	2011-10-18	Bali nyonga	Kamando	Mahmoh felicitas	5	5	677455387	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762526000841-94n43gxlzv8.jpg	2025-10-22 13:51:04.732717	\N	1	2025-10-22 14:51:04.732717+01	2025-10-22 14:51:04.732717+01	\N
190	25-VOT-AZLL-187	2025-10-22	AZONG PRINCEWILL 	M	2012-05-29	BAMENDA 	Akum 	Akum Irine	19	1	677786253	\N	\N	2025-10-22 07:14:13.179104	\N	1	2025-10-22 08:14:13.179104+01	2025-10-22 08:14:13.179104+01	2025-11-12 10:11:11.626346+01
322	25-VOT-ABRY-287	2025-10-30	ABA HARETT VICTORY 	F	2012-12-29	Memfe	Aba	Taboh shella 	4	6	681122790	\N	\N	2025-10-30 14:28:30.471081	\N	1	2025-10-30 15:28:30.471081+01	2025-10-30 15:28:30.471081+01	\N
194	25-VOT-ASEN-188	2025-10-22	ASEMA HANS KPIVEN	M	2025-10-22	VOTECH 	Elijah Ambua	Ambua	2	2	673742776	\N	\N	2025-10-22 09:20:15.436504	\N	1	2025-10-22 10:20:15.436504+01	2025-10-22 10:20:15.436504+01	\N
195	25-VOT-CHNG-189	2025-10-22	CHENG VALDES CHENG 	M	2013-04-18	BAMENDA 	Teke Samuel 	Cheng	2	2	670274490	\N	\N	2025-10-22 09:22:22.264588	\N	1	2025-10-22 10:22:22.264588+01	2025-10-22 10:22:22.264588+01	\N
196	25-VOT-TEOH-190	2025-10-22	TECHE GIRESS TENJOH	M	2011-05-08	Batibo	Teche	Mme caty	2	2	2000	\N	\N	2025-10-22 09:24:12.138174	\N	1	2025-10-22 10:24:12.138174+01	2025-10-22 10:24:12.138174+01	\N
188	25-VOT-TAON-348	2025-10-31	TAH CHRIS VERON 	M	2015-01-06	VOTECH 	Votech 	Votech 	19	1	679365021	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761918785212-qfe0gyo6xi.jpg	2025-10-22 07:06:36.577157	\N	1	2025-10-22 08:06:36.577157+01	2025-10-22 08:06:36.577157+01	\N
186	25-VOT-ANRA-348	2025-10-31	ANGOH MIRA	F	2012-02-27	VOTECH 	Votech 	Votech 	19	1	679987739	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761919706529-4yqudaypc9y.jpg	2025-10-22 07:00:11.585752	\N	1	2025-10-22 08:00:11.585752+01	2025-10-22 08:00:11.585752+01	\N
183	25-VOT-AYHO-348	2025-10-31	AYIM CHRIS ELIOT NKONFGHO	M	2015-12-12	BAMENDA 	Tohnoh	Petra	19	1	678945728	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761919899230-nx53x9yg48a.jpg	2025-10-22 06:37:33.892486	\N	1	2025-10-22 07:37:33.892486+01	2025-10-22 07:37:33.892486+01	\N
203	25-VOT-NYLA-197	2025-10-22	NYEMKUNA YOLANDNISSI WABILA	F	2012-02-13	Mankon Bamenda 	Njom 	Njom nicoline 	6	4	672 448280	\N	\N	2025-10-22 10:25:30.211532	\N	1	2025-10-22 11:25:30.211532+01	2025-10-22 11:25:30.211532+01	\N
204	25-VOT-NENG-198	2025-10-22	NEBA CHECY AMBONG 	F	2010-11-26	Babaki	Mbaku Emmanuel 	Mbaku 	6	4	650380001	\N	\N	2025-10-22 10:28:54.57549	\N	1	2025-10-22 11:28:54.57549+01	2025-10-22 11:28:54.57549+01	\N
205	25-VOT-CHLL-199	2025-10-22	CHE PRINCEWILL 	M	2025-10-22	BAMENDA 	Anyo Daniel 	Anyo 	6	4	675215358	\N	\N	2025-10-22 10:35:37.954992	\N	1	2025-10-22 11:35:37.954992+01	2025-10-22 11:35:37.954992+01	\N
206	25-VOT-AKJI-200	2025-10-22	AKINIBOM JOY NJI	F	2011-09-18	BAMENDA 	Akinibom	Mih cloudette	6	4	653516476	\N	\N	2025-10-22 10:37:23.97487	\N	1	2025-10-22 11:37:23.97487+01	2025-10-22 11:37:23.97487+01	\N
191	25-VOT-TENG-185	2025-10-22	TEMBE FAITH EYONG 	M	2011-04-25	Batibo	Tembe febe	Tembe	19	1	677786253	\N	\N	2025-10-22 08:41:37.118984	\N	1	2025-10-22 09:41:37.118984+01	2025-10-22 09:41:37.118984+01	2025-11-12 10:38:59.890426+01
187	25-VOT-SAHE-348	2025-10-31	SAM GRACIOUS CHE 	M	2012-02-27	VOTECH 	Votech 	Votech 	19	1	677964705	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761921970076-9ehctwdcv1.jpg	2025-10-22 07:03:53.171551	\N	1	2025-10-22 08:03:53.171551+01	2025-10-22 08:03:53.171551+01	\N
207	25-VOT-NDES-201	2025-10-22	NDUFONG ALEXIES	M	2009-09-08	Batibo	Teku David 	Teku	7	2	672247298	\N	\N	2025-10-22 11:01:30.496634	\N	1	2025-10-22 12:01:30.496634+01	2025-10-22 12:01:30.496634+01	2025-11-05 14:23:49.584357+01
212	25-VOT-LEGA-204	2025-10-22	LEBGA BLAISE TITALANGA 	M	2010-03-06	Manfe	Titalangq	Morine 	8	3	675822941	\N	\N	2025-10-22 12:41:24.869077	\N	1	2025-10-22 13:41:24.869077+01	2025-10-22 13:41:24.869077+01	\N
213	25-VOT-SUHE-205	2025-10-22	SUKWAIN TREASURE CHE 	M	2025-10-22	VOTECH 	Kamasang jeron	Kamasang 	8	3	677205235	\N	\N	2025-10-22 12:44:08.873722	\N	1	2025-10-22 13:44:08.873722+01	2025-10-22 13:44:08.873722+01	\N
214	25-VOT-MAEH-206	2025-10-22	MAH-NA-BIEN ANTONE NTSEH 	M	2025-10-22	VOTECH 	Bongong manaseh	Bongong	8	3	671329450	\N	\N	2025-10-22 12:46:22.889191	\N	1	2025-10-22 13:46:22.889191+01	2025-10-22 13:46:22.889191+01	\N
209	25-VOT-NGUS-409	2025-11-05	NGUM GRACIOUS 	F	2008-04-23	Bamenda Reginal hospital 	Awin 	Awin Vivian 	7	2	676306401	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762352765144-nzisnekq3dm.jpg	2025-10-22 11:39:46.768001	\N	1	2025-10-22 12:39:46.768001+01	2025-10-22 12:39:46.768001+01	\N
200	25-VOT-FRJI-437	2025-11-12	FRU GISLEIN NJI 	M	2011-11-18	Regional hospital Bamenda 	Nwana Ignatius 	Fru	8	3	677412692	\N	\N	2025-10-22 10:11:11.41813	\N	1	2025-10-22 11:11:11.41813+01	2025-10-22 11:11:11.41813+01	\N
218	25-VOT-NKHE-210	2025-10-22	NKWENTI RONNYGLEN KENACHE 	M	2009-11-27	BAMENDA 	Atock 	Helen Atock 	12	2	677245465	\N	\N	2025-10-22 13:07:11.91171	\N	1	2025-10-22 14:07:11.91171+01	2025-10-22 14:07:11.91171+01	\N
219	25-VOT-ENWE-211	2025-10-22	ENOW LEVI EKWE 	M	2025-10-22	Edenwo	Votech 	Votech 	13	2	681718778	\N	\N	2025-10-22 13:09:08.198402	\N	1	2025-10-22 14:09:08.198402+01	2025-10-22 14:09:08.198402+01	\N
199	25-VOT-TEHE-446	2025-11-14	TEKO CALEB NCHE 	M	2014-02-24	BAMENDA 	Teko Hanson 	Teko	5	5	689812817	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1763129906542-15tezxfb85m.jpg	2025-10-22 09:31:23.497357	\N	1	2025-10-22 10:31:23.497357+01	2025-10-22 10:31:23.497357+01	\N
223	25-VOT-NEEL-215	2025-10-22	NEBA ABAM MANUEL 	M	2009-12-12	BAMENDA 	Abam 	Bih Cynthia 	22	5	679137673	\N	\N	2025-10-22 13:21:35.59294	\N	1	2025-10-22 14:21:35.59294+01	2025-10-22 14:21:35.59294+01	\N
197	25-VOT-AMCK-446	2025-11-14	AMON CERDRICK 	M	2009-09-11	Widikum	Amon 	Predencia 	3	3	673042900	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1763130957388-ra1dfu0zupd.jpg	2025-10-22 09:26:38.395349	\N	1	2025-10-22 10:26:38.395349+01	2025-10-22 10:26:38.395349+01	\N
185	25-VOT-CHON-185	2025-10-22	CHIA HARDIson	M	2025-10-22	VOTECH 	Votech 	Votech 	19	1	2000	\N	\N	2025-10-22 06:59:25.114534	\N	1	2025-10-22 07:59:25.114534+01	2025-10-22 07:59:25.114534+01	2025-10-30 11:52:05.021393+01
210	25-VOT-AKEN-283	2025-10-30	AKUM BENARD-BRIGHT ABEN	M	2012-01-08	Batibo	Akum hundred 	Akum	19	1	673936230	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761832385734-dxam6buu3ig.jpg	2025-10-22 11:42:50.131433	\N	1	2025-10-22 12:42:50.131433+01	2025-10-22 12:42:50.131433+01	\N
208	25-VOT-TIOH-409	2025-11-05	TIFANG ISREAL TEMOH	M	2007-09-10	Batibo	Tifang 	Tifang currinate	7	2	678644957	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762352949010-9mg4zwuvtc9.jpg	2025-10-22 11:09:57.176665	\N	1	2025-10-22 12:09:57.176665+01	2025-10-22 12:09:57.176665+01	\N
234	25-VOT-AVOH-285	2025-10-30	AVERY AKONGWI PEMAMBOH	F	2014-06-16	VOTECH 	PEMAMBOH prince 	PEMAMBOH	19	1	677225050	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761833097989-u8glnocmnbs.jpg	2025-10-28 07:33:28.632649	\N	1	2025-10-28 08:33:28.632649+01	2025-10-28 08:33:28.632649+01	\N
139	25-VOT-CHKI-287	2025-10-30	CHIA HARDISON ANYUYKI	M	2015-01-03	BAMENDA 	Mbinda	Hilda Mbinda	19	1	678558249	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761833855561-7k89e6eue1n.jpg	2025-10-20 13:14:08.992146	\N	1	2025-10-20 14:14:08.992146+01	2025-10-20 14:14:08.992146+01	\N
230	25-VOT-TENT-218	2025-10-27	Test Student	M	2025-10-27	Fixing Issue by developers	Fixing Deleting students	Testing	23	8	67000000000	676767676767	\N	2025-10-27 06:43:12.440272	\N	1	2025-10-27 07:43:12.440272+01	2025-10-27 07:43:12.440272+01	2025-10-27 08:38:25.287813+01
231	25-VOT-TE-213	2025-10-27	Testing	M	2025-10-29	Fix	Fixing	Fixing Bugs	23	8	67000000000	5655434343434334	\N	2025-10-27 07:39:55.188078	\N	1	2025-10-27 08:39:55.188078+01	2025-10-27 08:39:55.188078+01	2025-10-27 08:40:38.091779+01
92	25-VOT-NJLL-410	2025-11-05	NJI CHENWI  DIVINE GODWILL	M	2008-12-01	BAMENDA 	Patrick Nji Ngwa 	Nji	16	3	674518303	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762358829754-dj6hbzo50pc.jpg	2025-09-19 11:01:40.778656	\N	1	2025-09-19 12:01:40.778656+01	2025-09-19 12:01:40.778656+01	\N
251	25-VOT-BAOD-429	2025-11-07	BAH CALEB FONBOD 	M	2012-11-07	Meta	Bah	Ejin Sharon 	5	5	677795990	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762525092126-td30mdv93d.jpg	2025-10-28 11:22:17.290102	\N	1	2025-10-28 12:22:17.290102+01	2025-10-28 12:22:17.290102+01	\N
264	25-VOT-FRSS-429	2025-11-07	FRU MIGLENN-BLESS 	M	2014-01-08	BAMENDA 	Fru	Ngum Charlotte 	5	5	653124445	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762525786643-shkdwg1emxt.jpg	2025-10-29 15:03:56.385048	\N	1	2025-10-29 16:03:56.385048+01	2025-10-29 16:03:56.385048+01	\N
250	25-VOT-NDNG-437	2025-11-12	NDI LEVIS FORKANG	M	2009-12-29	BAMENDA 	Ndi christina	Ndi	19	1	678666736	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761921234776-5nzpummttk5.jpg	2025-10-28 11:11:29.774217	\N	1	2025-10-28 12:11:29.774217+01	2025-10-28 12:11:29.774217+01	\N
261	25-VOT-ROEL-446	2025-11-14	ROHI DANIEL 	M	2012-08-15	BAMENDA 	Mundum 	Mundum 	5	5	674747053	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1763129827276-ly21serlchi.jpg	2025-10-29 14:52:30.924422	\N	1	2025-10-29 15:52:30.924422+01	2025-10-29 15:52:30.924422+01	\N
265	25-VOT-TEHO-446	2025-11-14	TEZEH FAVOUR CHO	M	2011-04-12	Santa	Cho khan Asobo	Cho	5	5	676051122	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1763129998353-9y5x20re86g.jpg	2025-10-29 15:17:37.3365	\N	1	2025-10-29 16:17:37.3365+01	2025-10-29 16:17:37.3365+01	\N
238	25-VOT-NKTA-224	2025-10-28	NKAR LYDIA ETTA 	F	2014-05-08	Bakumba	Taker julius	Nkar	19	1	2000	\N	\N	2025-10-28 07:48:34.322586	\N	1	2025-10-28 08:48:34.322586+01	2025-10-28 08:48:34.322586+01	\N
267	25-VOT-KEJI-446	2025-11-14	KECHAWA BLESSING NJENJI	F	2011-07-19	Mankon Bamenda 	Njenji Ferdinand 	Njenji	3	3	677433460	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1763131428954-0vua3ybw3ut.jpg	2025-10-29 15:31:34.062563	\N	1	2025-10-29 16:31:34.062563+01	2025-10-29 16:31:34.062563+01	\N
236	25-VOT-NKNG-348	2025-10-31	NKAR ADOLE EYONG 	M	2015-06-15	Bakumba 	Taker julius	Nkar	19	1	677026866	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761918442138-fid0bt4z1fs.jpg	2025-10-28 07:39:18.759297	\N	1	2025-10-28 08:39:18.759297+01	2025-10-28 08:39:18.759297+01	\N
232	25-VOT-CHDE-348	2025-10-31	CHO RICHIE BRIDE	M	2012-10-10	VOTECH 	Cho	Mange loveline	19	1	670133941	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761920207485-ydq581lgqoo.jpg	2025-10-28 07:23:53.284351	\N	1	2025-10-28 08:23:53.284351+01	2025-10-28 08:23:53.284351+01	\N
247	25-VOT-TENG-233	2025-10-28	TETUH RENALD ANENG 	M	2025-10-28	Batibo	Tetuh	Tetuh Debinash	25	2	673218556	\N	\N	2025-10-28 10:57:45.820089	\N	1	2025-10-28 11:57:45.820089+01	2025-10-28 11:57:45.820089+01	\N
235	25-VOT-KELA-348	2025-10-31	KEHDINGA AUSTEN NOVALLA	M	2014-01-11	Bali	Dinghana	Dinghana valoria	19	1	672759859	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761922235210-wgvr6eezv0g.jpg	2025-10-28 07:36:05.909811	\N	1	2025-10-28 08:36:05.909811+01	2025-10-28 08:36:05.909811+01	\N
245	25-VOT-ASUS-351	2025-11-04	ASENEK PRECIOUS 	M	2007-09-12	BAMENDA 	Asenek	Asenek shantal	12	2	683167335	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762269715021-34pnlr54lty.jpg	2025-10-28 08:47:32.001632	\N	1	2025-10-28 09:47:32.001632+01	2025-10-28 09:47:32.001632+01	\N
254	25-VOT-MBWA-239	2025-10-28	MBUI ASANATU NAWA	F	2010-12-14	BAMENDA 	Alambi Joseph 	Alambi	6	4	673294598	\N	\N	2025-10-28 12:06:56.850355	\N	1	2025-10-28 13:06:56.850355+01	2025-10-28 13:06:56.850355+01	\N
255	25-VOT-FONG-240	2025-10-28	FOBANG MIRATIN BRIGHT ASANG	M	2010-09-01	Mezam Bamenda 	Asang martin	Asang 	13	2	675153450	\N	\N	2025-10-28 12:15:38.193131	\N	1	2025-10-28 13:15:38.193131+01	2025-10-28 13:15:38.193131+01	\N
29	25-VOT-FOOH-242	2025-10-28	FON SANDRA ANOH 	F	2013-05-07	Efag village 	Ayong Nestor 	Ayong	1	1	681801131	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761657311660-wfjdrnubvrd.jpg	2025-09-16 13:03:07.269604	\N	1	2025-09-16 14:03:07.269604+01	2025-09-16 14:03:07.269604+01	\N
257	25-VOT-ATAN-242	2025-10-28	ATAGWO MARKCLEAN 	M	2025-10-28	VOTECH 	Ategwe Rodrick 	Atagwo	19	1	682692157	\N	\N	2025-10-28 13:15:38.947802	\N	1	2025-10-28 14:15:38.947802+01	2025-10-28 14:15:38.947802+01	\N
271	25-VOT-ACEH-374	2025-11-05	ACHIO BLAISE AWEH 	M	2012-11-07	Wum	Akem awen	Ajem	3	3	677658743	\N	\N	2025-10-29 15:46:47.063997	\N	1	2025-10-29 16:46:47.063997+01	2025-10-29 16:46:47.063997+01	\N
258	25-VOT-ACEH-243	2025-10-28	ACHIDI FAVOUR ENJEH	F	2012-09-21	Batibo	Achidi	Ngum Charlotte 	6	4	670588006	\N	\N	2025-10-28 15:28:21.288802	\N	1	2025-10-28 16:28:21.288802+01	2025-10-28 16:28:21.288802+01	\N
260	25-VOT-AZOW-235	2025-10-29	AZOH FABRICE ENOW 	M	2025-10-29	BAMENDA 	Agum 	macceline	2	2	653358350	\N	\N	2025-10-29 11:07:52.551557	\N	1	2025-10-29 12:07:52.551557+01	2025-10-29 12:07:52.551557+01	\N
202	25-VOT-MUUH-236	2025-10-29	MUGUWAM PELAGY MUWUH	F	2009-01-01	Batibo	Votech 	Votech 	4	6	675104400	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761748164161-cyueioqihwn.jpg	2025-10-22 10:22:13.321883	\N	1	2025-10-22 11:22:13.321883+01	2025-10-22 11:22:13.321883+01	\N
249	25-VOT-NYMA-236	2025-10-29	NYE FAVOUR GRACE CHIOMA	F	2010-01-19	Widikum	Fru admira che	Fru	4	6	671930704	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761748246169-ja71n0hqrvj.jpg	2025-10-28 11:05:47.444982	\N	1	2025-10-28 12:05:47.444982+01	2025-10-28 12:05:47.444982+01	\N
259	25-VOT-CHHT-236	2025-10-29	CHIAMO DARLING BRIGHT 	M	2013-01-25	BAMENDA 	Chiamo	Mommy lura	3	3	654377186	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761748791707-kd94qot4xp.jpg	2025-10-28 15:30:42.045231	\N	1	2025-10-28 16:30:42.045231+01	2025-10-28 16:30:42.045231+01	\N
142	25-VOT-NGTH-236	2025-10-29	NGANG ELIJA FAITH 	M	2010-05-05	Mankon Bamenda 	Ngang Henry 	Ngang 	3	3	679335158	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761748966309-u1cu1jzoarm.jpg	2025-10-20 13:26:18.236081	\N	1	2025-10-20 14:26:18.236081+01	2025-10-20 14:26:18.236081+01	\N
72	25-VOT-NDAH-236	2025-10-29	NDAM XAVI JUNIOR MBAH 	M	2010-04-03	BAMENDA 	Ndam Ronate 	Tah fouave  Ridley 	3	3	676272194	676238876	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761749048355-c35d2eoxkq.jpg	2025-09-17 15:05:58.334553	\N	1	2025-09-17 16:05:58.334553+01	2025-09-17 16:05:58.334553+01	\N
143	25-VOT-ROOR-236	2025-10-29	RONALDO CHAMFOR CHAMFOR	M	2013-07-15	BAMENDA 	CHAMFOR philimon 	CHAMFOR 	3	3	673404111	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761749239546-3mcrclrcvzu.jpg	2025-10-20 13:29:51.179016	\N	1	2025-10-20 14:29:51.179016+01	2025-10-20 14:29:51.179016+01	\N
268	25-VOT-TEUM-243	2025-10-29	TEWAN SAMUEL AKUM 	M	2011-05-12	BAMENDA 	Motor Janette 	Motop	3	3	675205176	\N	\N	2025-10-29 15:34:47.405083	\N	1	2025-10-29 16:34:47.405083+01	2025-10-29 16:34:47.405083+01	\N
269	25-VOT-FOUR-244	2025-10-29	FOKWA FAVOUR 	M	2009-11-14	Batibo 	Fokwa Romanus 	Fokwa	3	3	675875267	\N	\N	2025-10-29 15:42:10.680485	\N	1	2025-10-29 16:42:10.680485+01	2025-10-29 16:42:10.680485+01	\N
270	25-VOT-ACHE-245	2025-10-29	ACHENWI SILAS CHE 	M	2008-07-17	BAMENDA 	Achenwi	Alice Aze	3	3	670107013	\N	\N	2025-10-29 15:44:48.321762	\N	1	2025-10-29 16:44:48.321762+01	2025-10-29 16:44:48.321762+01	\N
272	25-VOT-ABAC-247	2025-10-30	ABANG ISAAC 	M	2025-10-30	Edenwo 	Votech 	 Votech 	19	1	681718778	\N	\N	2025-10-30 10:45:45.162709	\N	1	2025-10-30 11:45:45.162709+01	2025-10-30 11:45:45.162709+01	\N
302	25-VOT-AWRU-286	2025-10-30	AWAH DIVINE FAVOUR FRU 	M	2014-10-26	VOTECH 	Awah 	Evelyn maluh	19	1	670236331	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761833273850-a7v2ylimp4j.jpg	2025-10-30 13:01:28.211375	\N	1	2025-10-30 14:01:28.211375+01	2025-10-30 14:01:28.211375+01	\N
449	25-VOT-ACUM-410	2025-11-06	ACHA NOEL NDUM	M	2012-12-11	Bamenda 	Acha 	Acha Belinda	19	1	670899836	\N	\N	2025-11-06 07:25:35.888872	\N	1	2025-11-06 08:25:35.888872+01	2025-11-06 08:25:35.888872+01	\N
288	25-VOT-AGIA-437	2025-11-12	AGHA SYLVIA 	F	2013-12-23	BAMENDA 	Agha Benedict 	Agha	19	1	677843816	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761832165493-54rzjid26pr.jpg	2025-10-30 12:27:10.405898	\N	1	2025-10-30 13:27:10.405898+01	2025-10-30 13:27:10.405898+01	\N
282	25-VOT-ANNE-437	2025-11-12	ANENG JOYCELINE 	F	2012-05-12	Batibo 	Nde angwa	Nde	19	1	683765193	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761832748182-8jic3xeilhe.jpg	2025-10-30 12:03:44.68002	\N	1	2025-10-30 13:03:44.68002+01	2025-10-30 13:03:44.68002+01	\N
276	25-VOT-EYAN-436	2025-11-12	EYEN NARRIDIAN 	F	2012-01-20	VOTECH 	Eyen 	Tembu mercy	19	1	676084411	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761920315350-rr87si9v61f.jpg	2025-10-30 11:00:53.336677	\N	1	2025-10-30 12:00:53.336677+01	2025-10-30 12:00:53.336677+01	\N
278	25-VOT-NGRU-437	2025-11-12	NGUM EMMANUELA FRU 	F	2013-08-13	Mankon Bamenda 	Fru	Ako bih 	19	1	675528750	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761921433205-z6thq11ezd.jpg	2025-10-30 11:26:18.635807	\N	1	2025-10-30 12:26:18.635807+01	2025-10-30 12:26:18.635807+01	\N
312	25-VOT-NGER-437	2025-11-12	NGONG EBENEZER	M	2007-06-11	Kom	Ngong 	Veronica  	2	2	682401180	\N	\N	2025-10-30 13:50:12.184491	\N	1	2025-10-30 14:50:12.184491+01	2025-10-30 14:50:12.184491+01	\N
467	25-VOT-MBCK-426	2025-11-07	MBAH TERANCE ENJECK 	F	2006-03-30	Batibo	Fon lovette	Fon lovette	11	4	679749123	\N	\N	2025-11-07 09:06:15.267745	\N	1	2025-11-07 10:06:15.267745+01	2025-11-07 10:06:15.267745+01	\N
297	25-VOT-CHNE-287	2025-10-30	CHE  LUCINE 	F	2014-09-29	Fudong 	Che	Ngong Priscilla 	19	1	680180925	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761833733696-b2uffw90w7.jpg	2025-10-30 12:48:49.546102	\N	1	2025-10-30 13:48:49.546102+01	2025-10-30 13:48:49.546102+01	\N
286	25-VOT-CHHT-287	2025-10-30	CHI MARK BRIGHT 	M	2010-05-21	BAMENDA 	Chi	Ngum Jecenta 	19	1	674438654	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761833906268-jdgbzi0nnis.jpg	2025-10-30 12:22:51.905873	\N	1	2025-10-30 13:22:51.905873+01	2025-10-30 13:22:51.905873+01	\N
287	25-VOT-CHBA-287	2025-10-30	CHO PRECIOUS KEBA 	M	2012-11-18	Nchouba 	Agha Benedict 	Agha 	19	1	677843816	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761834059821-8b04d73lzg.jpg	2025-10-30 12:25:25.388961	\N	1	2025-10-30 13:25:25.388961+01	2025-10-30 13:25:25.388961+01	\N
284	25-VOT-MOAR-288	2025-10-30	MOHAMADOU HABUBAKAR	M	2013-05-11	BAMENDA 	Abubakar 	Abubakar	19	1	650084856	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761834629206-ikale6j8j3.jpg	2025-10-30 12:14:16.05299	\N	1	2025-10-30 13:14:16.05299+01	2025-10-30 13:14:16.05299+01	\N
294	25-VOT-ATIT-268	2025-10-30	ATONG CELIA DEBIT 	F	2025-10-30	VOTECH 	Atong	Forbuchi peace 	19	1	67636522	\N	\N	2025-10-30 12:40:09.907597	\N	1	2025-10-30 13:40:09.907597+01	2025-10-30 13:40:09.907597+01	\N
323	25-VOT-ABEH-288	2025-10-30	ABIAY TRACY MBONGEH	F	2012-08-27	Bali	Andin	Andin	4	6	679998518	\N	\N	2025-10-30 14:31:15.189971	\N	1	2025-10-30 15:31:15.189971+01	2025-10-30 15:31:15.189971+01	\N
329	25-VOT-AFNG-293	2025-10-30	AFESEH BLESSING 	F	2009-08-11	Gabon	Afeseh	Mme mercy	6	4	654371555	\N	\N	2025-10-30 15:16:56.809028	\N	1	2025-10-30 16:16:56.809028+01	2025-10-30 16:16:56.809028+01	\N
300	25-VOT-NKAN-348	2025-10-31	NKWENTI EL-NATHAN	M	2013-11-03	VOTECH 	Nkwenti valentine 	Nkwenti 	19	1	677359445	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761918361197-vlrcfgcrsqa.jpg	2025-10-30 12:57:22.621351	\N	1	2025-10-30 13:57:22.621351+01	2025-10-30 13:57:22.621351+01	\N
292	25-VOT-ZOEL-348	2025-10-31	ZOHNEPOH ANGELBEL 	M	2014-10-13	Mankon Bamenda 	Fru Godlove 	Fru	19	1	675529423	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761919124783-y6o475d1zr.jpg	2025-10-30 12:35:11.244166	\N	1	2025-10-30 13:35:11.244166+01	2025-10-30 13:35:11.244166+01	\N
299	25-VOT-AWOH-348	2025-10-31	AWA RAYAH NDOH	M	2014-02-07	VOTECH 	Awa	Fosang Doris	19	1	677692787	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761919360063-sp3yecgmsbg.jpg	2025-10-30 12:54:29.798735	\N	1	2025-10-30 13:54:29.798735+01	2025-10-30 13:54:29.798735+01	\N
303	25-VOT-BWIN-348	2025-10-31	BWENE PAVIN	F	2010-03-14	VOTECH 	Votech 	Votech 	19	1	6841424132	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761919504524-oio37b9fnbh.jpg	2025-10-30 13:03:56.8897	\N	1	2025-10-30 14:03:56.8897+01	2025-10-30 14:03:56.8897+01	\N
311	25-VOT-ABAH-281	2025-10-30	ABURI FAITH ENDAH	M	2013-04-18	BAMENDA 	Melia Vitalis 	Aburi	2	2	676687971	\N	\N	2025-10-30 13:39:24.985817	\N	1	2025-10-30 14:39:24.985817+01	2025-10-30 14:39:24.985817+01	\N
273	25-VOT-ABBE-282	2025-10-30	ABANG DOROTHY EGBE	F	2009-02-14	Edenwo 	Votech 	Votech 	19	1	681718778	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761831987101-2i2k6cq4xzq.jpg	2025-10-30 10:47:47.441953	\N	1	2025-10-30 11:47:47.441953+01	2025-10-30 11:47:47.441953+01	\N
289	25-VOT-ABIS-282	2025-10-30	ABOUNANG LERIS 	M	2015-01-11	VOTECH 	ABOUNANG	Fonong Cynthia 	19	1	677589265	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761832106362-twap4w6if8i.jpg	2025-10-30 12:29:11.024355	\N	1	2025-10-30 13:29:11.024355+01	2025-10-30 13:29:11.024355+01	\N
310	25-VOT-AKKO-282	2025-10-30	AKO SILAS TABOKO 	M	2013-01-09	Kendem	Ako	Ako Sandrine 	19	1	679766523	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761832311003-0xb1q2haj8xo.jpg	2025-10-30 13:16:31.794657	\N	1	2025-10-30 14:16:31.794657+01	2025-10-30 14:16:31.794657+01	\N
285	25-VOT-CHOR-348	2025-10-31	CHI SPLENDOUR STANDLY NDIFOR 	M	2013-06-12	Douala 	Ndifor 	Christile 	19	1	674484558	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761920069478-9w7fgrhnecw.jpg	2025-10-30 12:20:49.725001	\N	1	2025-10-30 13:20:49.725001+01	2025-10-30 13:20:49.725001+01	\N
314	25-VOT-FUNG-284	2025-10-30	FUHWI DERICK ASANG 	M	2025-10-30	BAMENDA 	Eric suh asang 	Asang 	5	5	675107287	\N	\N	2025-10-30 13:55:35.703698	\N	1	2025-10-30 14:55:35.703698+01	2025-10-30 14:55:35.703698+01	\N
239	25-VOT-ANEN-284	2025-10-30	ANDONG POLYNET MUYEN 	M	2012-01-25	Hulabei	Andong patrant	Andong 	19	1	651478544	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761832545339-iu24y6l5bc.jpg	2025-10-28 07:53:22.777499	\N	1	2025-10-28 08:53:22.777499+01	2025-10-28 08:53:22.777499+01	\N
281	25-VOT-ANEI-285	2025-10-30	ANENG JOY ANWIEI 	F	2012-12-05	Batibo	Nde angwa 	Nde	19	1	683765193	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761832617073-mebphrtce4m.jpg	2025-10-30 11:59:15.341983	\N	1	2025-10-30 12:59:15.341983+01	2025-10-30 12:59:15.341983+01	\N
229	25-VOT-ANRU-285	2025-10-30	ANGU PEACE NATHAN FRU 	M	2015-02-08	BAMENDA 	Angu	Mme comfort 	19	1	679589455	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761832808331-2dslhy3lrf3.jpg	2025-10-22 14:45:15.833514	\N	1	2025-10-22 15:45:15.833514+01	2025-10-22 15:45:15.833514+01	\N
315	25-VOT-ACGE-285	2025-10-30	ACHIE SOLANGE 	F	2013-01-04	Njinikom	Aphanse 	Aphanse	4	6	683697886	\N	\N	2025-10-30 14:01:38.591815	\N	1	2025-10-30 15:01:38.591815+01	2025-10-30 15:01:38.591815+01	\N
277	25-VOT-MEEL-348	2025-10-31	MEYANUI EMMANUEL 	M	2014-02-17	Bambui	Meyanui	Ngweform Brenda	19	1	678954397	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761920674520-dv7rn1u8v4m.jpg	2025-10-30 11:04:11.085744	\N	1	2025-10-30 12:04:11.085744+01	2025-10-30 12:04:11.085744+01	\N
274	25-VOT-NWAN-348	2025-10-31	NWEKE JEPHTHAN	M	2011-07-11	Bamisin	Nweke 	Kuma blessing 	19	1	674404435	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761921802035-8kj2zk2c9up.jpg	2025-10-30 10:55:52.702514	\N	1	2025-10-30 11:55:52.702514+01	2025-10-30 11:55:52.702514+01	\N
304	25-VOT-TIHA-348	2025-10-31	TINGOM APOLINER TENGHA 	M	2010-05-04	VOTECH 	Votech 	Votech 	19	1	670090951	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761922097381-03z9dsgrnf08.jpg	2025-10-30 13:05:10.038907	\N	1	2025-10-30 14:05:10.038907+01	2025-10-30 14:05:10.038907+01	\N
279	25-VOT-WAWA-348	2025-11-04	WANDI NORA NGWA 	F	2013-10-18	BAMENDA 	Ngwa	Lum natali	19	1	677529963	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761918993444-ogogffn0cf8.jpg	2025-10-30 11:28:50.726762	\N	1	2025-10-30 12:28:50.726762+01	2025-10-30 12:28:50.726762+01	\N
184	25-VOT-KIUR-287	2025-10-30	KIKO FAVOUR 	F	2013-09-04	BAMENDA 	Anwwi	Anwwi vivian	19	1	676306401	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761834555182-c8swt30wgav.jpg	2025-10-22 06:39:08.276458	\N	1	2025-10-22 07:39:08.276458+01	2025-10-22 07:39:08.276458+01	\N
283	25-VOT-MADE-289	2025-10-30	MARY GRATEFUL ADE 	F	2014-11-09	Nchoba	Ade	Ngum Sharon 	19	1	670185660	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761834781829-xg8m602vn6a.jpg	2025-10-30 12:07:10.830777	\N	1	2025-10-30 13:07:10.830777+01	2025-10-30 13:07:10.830777+01	\N
324	25-VOT-NGRY-289	2025-10-30	NGANG GLORY 	F	2011-06-06	BAMENDA 	Ngang 	Ngang Christina 	4	6	672839304	\N	\N	2025-10-30 14:33:15.035864	\N	1	2025-10-30 15:33:15.035864+01	2025-10-30 15:33:15.035864+01	\N
450	25-VOT-NDBI-411	2025-11-06	NDEH BLESSING AKOMBI	F	2012-03-25	Bamenda 	AKOMBI 	AKOMBI lOVERT	19	1	652220107	\N	\N	2025-11-06 08:36:14.521347	\N	1	2025-11-06 09:36:14.521347+01	2025-11-06 09:36:14.521347+01	\N
215	25-VOT-BIIA-414	2025-11-06	BIH MALIA 	F	2012-02-04	BAMENDA 	Bih	Bih Cynthia 	11	4	679137673	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762440289408-4cfvsuzfqaq.jpg	2025-10-22 12:48:44.356408	\N	1	2025-10-22 13:48:44.356408+01	2025-10-22 13:48:44.356408+01	\N
379	25-VOT-NDIN-414	2025-11-06	NDONGEH TISEN NKWAIN 	M	2009-10-27	Bingo 	William 	Ndongeh 	7	2	683678412	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762440792907-gzsb5ig3ejo.jpg	2025-10-31 11:43:44.039355	\N	1	2025-10-31 12:43:44.039355+01	2025-10-31 12:43:44.039355+01	\N
174	25-VOT-AWNN-414	2025-11-06	AWA GERALD PENN	M	2008-06-06	Douala 	Teneng 	Teneng Edith 	15	5	675459582	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762444324323-yy7q5yv4pb.jpg	2025-10-20 15:11:01.821277	\N	1	2025-10-20 16:11:01.821277+01	2025-10-20 16:11:01.821277+01	\N
422	25-VOT-TAGA-413	2025-11-06	TAH CRESSY NDEAGA	M	2009-12-11	Mankon Bamenda 	Tah martine	Tah	15	5	677042484	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762444814931-lckn7yi0lf.jpg	2025-11-05 08:10:43.925358	\N	1	2025-11-05 09:10:43.925358+01	2025-11-05 09:10:43.925358+01	\N
97	25-VOT-WILL-413	2025-11-06	WIRBA PRINCEWILL 	M	2010-04-27	VOTECH 	Wirba cyril 	Wirba	15	5	677684883	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762445098214-rvbuqpuuh5c.jpg	2025-09-19 11:19:16.550013	\N	1	2025-09-19 12:19:16.550013+01	2025-09-19 12:19:16.550013+01	\N
454	25-VOT-TEUH-413	2025-11-07	TEMAH RANDY TIFUH 	M	2010-08-07	Tiben international health center 	Tifuh Titus	Temah Matida	19	1	678278850	\N	\N	2025-11-07 08:17:28.627235	\N	1	2025-11-07 09:17:28.627235+01	2025-11-07 09:17:28.627235+01	\N
458	25-VOT-TAMI-417	2025-11-07	TAHTAH BARACK NDREMIMI	M	2014-05-09	Mbingo	Tahtah	Mariama pongwou	19	1	674603483	\N	\N	2025-11-07 08:36:19.692991	\N	1	2025-11-07 09:36:19.692991+01	2025-11-07 09:36:19.692991+01	\N
462	25-VOT-NDAH-421	2025-11-07	NDEH BLESSING ENDAH 	F	2014-07-09	Batibo	Ako 	Ako Christina 	6	4	650364328	\N	\N	2025-11-07 08:47:56.028874	\N	1	2025-11-07 09:47:56.028874+01	2025-11-07 09:47:56.028874+01	\N
464	25-VOT-CHUM-423	2025-11-07	CHO MARKBRIGHT FONDIKUM 	M	2011-08-22	Mankon Bamenda 	Cho	Cambel Tah	10	5	654467650	\N	\N	2025-11-07 08:56:01.464879	\N	1	2025-11-07 09:56:01.464879+01	2025-11-07 09:56:01.464879+01	\N
416	25-VOT-TEUS-426	2025-11-07	TEGHA PRECIOUS 	F	2010-12-03	BAMENDA 	Tegha Fredrick 	Tegha 	9	6	677587130	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762440680835-kftopal2jo.jpg	2025-11-05 06:12:37.380078	\N	1	2025-11-05 07:12:37.380078+01	2025-11-05 07:12:37.380078+01	\N
468	25-VOT-ABNG-427	2025-11-07	ABWE PRINCESS MESANG 	F	2012-04-12	VOTECH 	Ndong Dione	Ndong Dione	11	4	682461809	\N	\N	2025-11-07 09:12:59.014663	\N	1	2025-11-07 10:12:59.014663+01	2025-11-07 10:12:59.014663+01	\N
436	25-VOT-KASE-429	2025-11-07	KAMWA FOSSA FABRISE 	M	2004-03-21	Limbe	 Kamwa	Bola Dorothy 	21	3	679743818	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762445699559-bpxgrmyove8.jpg	2025-11-05 09:36:27.173251	\N	1	2025-11-05 10:36:27.173251+01	2025-11-05 10:36:27.173251+01	\N
198	25-VOT-ANOW-429	2025-11-07	ANYEH BRIAN ENOW 	M	2009-04-02	Widikum	Anyen 	Anyen Anita 	5	5	682251268	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762524381605-9mw62w067pa.jpg	2025-10-22 09:29:21.492438	\N	1	2025-10-22 10:29:21.492438+01	2025-10-22 10:29:21.492438+01	\N
140	25-VOT-AZYE-429	2025-11-07	AZAH DESMOND  ANGYE	M	2012-08-31	VOTECH 	Votech 	Votech 	5	5	670648032	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762524760577-nss7jefc9z.jpg	2025-10-20 13:19:12.272138	\N	1	2025-10-20 14:19:12.272138+01	2025-10-20 14:19:12.272138+01	\N
313	25-VOT-FOOH-429	2025-11-07	FORKAM PEACE ABOH 	M	2013-01-08	BAMENDA 	Forkam Kenneth 	Forkam	5	5	675429776	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762525621257-0a6lp5wuugoj.jpg	2025-10-30 13:54:07.564937	\N	1	2025-10-30 14:54:07.564937+01	2025-10-30 14:54:07.564937+01	\N
262	25-VOT-NDHA-429	2025-11-07	NDUM ELISHA 	M	2009-11-10	Widikum 	Ndum 	Ndum banice 	5	5	681744156	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762526095122-94cbh3bymxh.jpg	2025-10-29 15:00:17.707667	\N	1	2025-10-29 16:00:17.707667+01	2025-10-29 16:00:17.707667+01	\N
224	25-VOT-TERU-429	2025-11-07	TEKO DANIEL FRU	M	2009-01-23	Preventive	Teko hanson	Teko 	14	5	679812817	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762444935119-826fxc6ijxk.jpg	2025-10-22 13:25:54.084463	\N	1	2025-10-22 14:25:54.084463+01	2025-10-22 14:25:54.084463+01	\N
475	25-VOT-NGNU-433	2025-11-11	NGAI VIANEE YENU	M	2013-03-14	Nkambe 	Fokala Valery Forgham	Fokala	3	3	676391349	\N	\N	2025-11-11 13:41:20.776724	\N	1	2025-11-11 14:41:20.776724+01	2025-11-11 14:41:20.776724+01	\N
59	25-VOT-AKAH-436	2025-11-12	AKWI DANNIELLA TAH	F	2014-02-14	Mankon Bamenda 	Kamsah Norelta	Norelta	1	1	672884016	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1760777488938-fgmpx1o9dv.jpg	2025-09-16 15:40:12.775877	\N	1	2025-09-16 16:40:12.775877+01	2025-09-16 16:40:12.775877+01	\N
480	25-VOT-ACUM-437	2025-11-12	ACHA NOEL NDUM	M	2012-12-11	Choaba ashong 	Acha 	Acha Brenda 	1	1	670899836	\N	\N	2025-11-12 09:00:42.775175	\N	1	2025-11-12 10:00:42.775175+01	2025-11-12 10:00:42.775175+01	\N
21	25-VOT-BAAH-348	2025-10-31	BANGHA MACXINE AFUAH	M	2012-10-27	Mejang	Bangladesh luizette	Luizette	19	1	651369712	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761922326791-2tpuiyac7k4.jpg	2025-09-16 12:24:51.773193	\N	1	2025-09-16 13:24:51.773193+01	2025-09-16 13:24:51.773193+01	2025-11-12 10:07:10.810913+01
482	25-VOT-NGRE-436	2025-11-12	NGONG SINDI NAJRE	F	2005-08-24	Nkom	Bai Ndicha Oliver 	MAFIAN ALICE 	11	4	674007866	\N	\N	2025-11-12 09:29:08.175191	\N	1	2025-11-12 10:29:08.175191+01	2025-11-12 10:29:08.175191+01	\N
484	25-VOT-KWAN-437	2025-11-12	KWESIM BRAYAN 	M	2025-11-12	BAMENDA 	Kwesim Isaac 	Kwesim	16	3	654557746	\N	\N	2025-11-12 12:24:22.56688	\N	1	2025-11-12 13:24:22.56688+01	2025-11-12 13:24:22.56688+01	\N
486	25-VOT-ATSH-439	2025-11-13	ATUD CHERISH  	F	2011-06-05	BAMENDA 	Atud 	Atud Constand 	6	4	651712957	\N	\N	2025-11-13 10:19:11.681709	\N	1	2025-11-13 11:19:11.681709+01	2025-11-13 11:19:11.681709+01	\N
489	25-VOT-KELA-442	2025-11-13	KEBILA BLESS BABILA 	M	2025-11-13	Southwest 	Kebila 	Ncho Bridget	5	5	679338276	\N	\N	2025-11-13 10:30:51.474651	\N	1	2025-11-13 11:30:51.474651+01	2025-11-13 11:30:51.474651+01	\N
144	25-VOT-ANON-446	2025-11-13	ANUH BRANDON 	M	2011-03-15	Batibo	Anyam 	Anyam maceline	2	2	675103019	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1763042899541-by0ts0xkdqo.jpg	2025-10-20 13:32:00.529358	\N	1	2025-10-20 14:32:00.529358+01	2025-10-20 14:32:00.529358+01	\N
53	25-VOT-FUNA-446	2025-11-14	FUPKEH PHINA	F	2025-11-14	VOTECH 	Votech 	Votech 	1	1	678115168	2000	https://st60307.ispot.cc/votechs7academygroup/students/photos/1763079540693-erj9euabq5v.jpg	2025-09-16 15:26:55.06906	\N	1	2025-09-16 16:26:55.06906+01	2025-09-16 16:26:55.06906+01	\N
49	25-VOT-MUCE-446	2025-11-14	MUKUM MARK PRINCE	M	2025-11-14	Bamenda 	Ndum Julius Ndam	Ndam Jennifer 	1	1	678965700	20000	https://st60307.ispot.cc/votechs7academygroup/students/photos/1763080150771-ye0zaj8pyd.jpg	2025-09-16 15:10:12.145454	\N	1	2025-09-16 16:10:12.145454+01	2025-09-16 16:10:12.145454+01	\N
45	25-VOT-NDBI-446	2025-11-14	NDE M'CBRIGHT NTEMBI	M	2014-05-03	BAMENDA 	Fru EMMANUEL 	Fru	1	1	679049772	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1763080661044-vjfwh2ctrw.jpg	2025-09-16 14:54:19.254299	\N	1	2025-09-16 15:54:19.254299+01	2025-09-16 15:54:19.254299+01	\N
44	25-VOT-NKNG-446	2025-11-14	NKONBU JACQUES SONG	M	2015-06-11	BAMENDA 	Asonmua Ernest mencha	Asongmua	1	1	675727733	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1763081290897-pocaznifbzp.jpg	2025-09-16 14:51:18.187823	\N	1	2025-09-16 15:51:18.187823+01	2025-09-16 15:51:18.187823+01	\N
327	25-VOT-ABEN-291	2025-10-30	ABANG LIANZA FERHMEN	F	2012-06-11	Kumba	Abang 	Abang CEline 	4	6	673752323	\N	\N	2025-10-30 14:48:47.823586	\N	1	2025-10-30 15:48:47.823586+01	2025-10-30 15:48:47.823586+01	\N
451	25-VOT-ACRY-412	2025-11-06	ACHU JOHDEN VERIANDRY 	M	2025-11-06	VOTECH 	Achu 	Atoh Pauline 	19	1	677106042	\N	\N	2025-11-06 08:40:10.657035	\N	1	2025-11-06 09:40:10.657035+01	2025-11-06 09:40:10.657035+01	\N
152	25-VOT-CHUM-414	2025-11-06	CHEO BLESSING NGUM 	F	2011-10-24	Otele	Ngwa 	Ngwa aurava	11	4	677590441	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762440357286-nzndpmu0g.jpg	2025-10-20 13:53:08.23507	\N	1	2025-10-20 14:53:08.23507+01	2025-10-20 14:53:08.23507+01	\N
154	25-VOT-NGUS-414	2025-11-06	NGOH BELTUS 	M	2025-11-06	BAMENDA 	Ngoh	Ngoh manavis 	7	2	683181222	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762440841837-19ik0roqpyu.jpg	2025-10-20 14:03:18.565967	\N	1	2025-10-20 15:03:18.565967+01	2025-10-20 15:03:18.565967+01	\N
426	25-VOT-EGBI-414	2025-11-06	EGBE AUSTINE ATUMBI	M	2009-11-06	BAMENDA 	Egbe Didimus	Egbe	15	5	670667620	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762444578750-5zqafa0r5wk.jpg	2025-11-05 08:40:04.658099	\N	1	2025-11-05 09:40:04.658099+01	2025-11-05 09:40:04.658099+01	\N
424	25-VOT-TCAN-413	2025-11-06	TCHEDJE PESSIE RYAN	M	2010-11-16	BAMENDA 	TChedje 	MANDYOU CLARIS 	15	5	675103740	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762444878146-u8jw5t4lzlh.jpg	2025-11-05 08:36:39.17964	\N	1	2025-11-05 09:36:39.17964+01	2025-11-05 09:36:39.17964+01	\N
421	25-VOT-TIYA-413	2025-11-06	TITA ERIC NDAYA 	M	2010-08-20	Mbengwi	MAGRI KINGSLY 	Magri	15	5	675803212	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762445022368-ijpqqt3hj6n.jpg	2025-11-05 08:08:15.939574	\N	1	2025-11-05 09:08:15.939574+01	2025-11-05 09:08:15.939574+01	\N
439	25-VOT-MBCE-413	2025-11-06	MBIANDA LAWRENCE 	M	2005-11-26	Bawork	WATERD EDINE 	WATERD EDINE	23	8	679499565	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762445986375-8i6mb41n849.jpg	2025-11-05 09:43:43.450509	\N	1	2025-11-05 10:43:43.450509+01	2025-11-05 10:43:43.450509+01	\N
455	25-VOT-AGJI-414	2025-11-07	AGWE PEACE-BROWN NJI	M	2013-04-15	Ngyen mbo	Ngwe 	Ngwe janice	19	1	654752767	\N	\N	2025-11-07 08:20:53.08377	\N	1	2025-11-07 09:20:53.08377+01	2025-11-07 09:20:53.08377+01	\N
459	25-VOT-NJHT-418	2025-11-07	NJI ELDYBRIGHT 	M	2013-10-16	BAMENDA 	Nji	BIH GRACE 	5	5	676822880	\N	\N	2025-11-07 08:38:14.387599	\N	1	2025-11-07 09:38:14.387599+01	2025-11-07 09:38:14.387599+01	\N
463	25-VOT-PEHO-422	2025-11-07	PENN TREASURE CHO	M	2011-06-27	BAMENDA 	Penn	Penn Elizabeth 	7	2	679369787	\N	\N	2025-11-07 08:50:55.482844	\N	1	2025-11-07 09:50:55.482844+01	2025-11-07 09:50:55.482844+01	\N
469	25-VOT-SHBI-428	2025-11-07	SHEY BILDAD FAVOUR KIMBI	M	2008-04-04	Ndu	Shey Godlove 	Shey 	12	2	675828786	\N	\N	2025-11-07 11:44:20.626679	\N	1	2025-11-07 12:44:20.626679+01	2025-11-07 12:44:20.626679+01	\N
76	25-VOT-TICE-429	2025-11-07	TITA SHEKINA PEACE 	F	2012-03-06	BAMENDA 	Tita Elvis 	Judith	6	4	677417149	2000	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761748516687-ehg4hjesavh.jpg	2025-09-17 15:18:01.005095	\N	1	2025-09-17 16:18:01.005095+01	2025-09-17 16:18:01.005095+01	\N
328	25-VOT-AFHT-429	2025-11-07	AFESEH NEVILL BRIGHT	M	2011-04-05	Gabon	 Afeseh 	Mme mercy	5	5	654371555	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762524266161-0xoocqoyhi8f.jpg	2025-10-30 15:11:49.140435	\N	1	2025-10-30 16:11:49.140435+01	2025-10-30 16:11:49.140435+01	\N
263	25-VOT-AWSE-429	2025-11-07	AWAH NDIFOR BLAISE	M	2011-11-21	BAMENDA 	NDIFOR Ernest 	Ndifor	5	5	674693278	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762524637239-j7p9y3mbtpo.jpg	2025-10-29 15:02:04.737988	\N	1	2025-10-29 16:02:04.737988+01	2025-10-29 16:02:04.737988+01	\N
122	25-VOT-BANG-429	2025-11-07	BABILA EMMABRYAN FOWAJANG	M	2012-12-30	Bali	Nkonde	Giselle 	5	5	651229863	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762524869136-pvh8f8zynnf.jpg	2025-10-17 14:00:40.83513	\N	1	2025-10-17 15:00:40.83513+01	2025-10-17 15:00:40.83513+01	\N
31	25-VOT-MBDA-429	2025-11-07	MBIAMI CHRIST-BEL MBIANDA	M	2012-12-17	Mile 90	Francis mbianda	Noella ngufor	5	5	651833676	675553381	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762525890112-34dvp6spuxm.jpg	2025-09-16 14:09:53.711204	\N	1	2025-09-16 15:09:53.711204+01	2025-09-16 15:09:53.711204+01	\N
470	25-VOT-PENY-429	2025-11-11	PENN NKENG DESTINY 	M	2011-11-30	Kribi	Penn	Meshi syvie	2	2	673158311	\N	\N	2025-11-11 11:27:34.643066	\N	1	2025-11-11 12:27:34.643066+01	2025-11-11 12:27:34.643066+01	\N
474	25-VOT-BIUY-432	2025-11-11	BINFOLA FIGLE MBIMENYUY 	M	2003-12-27	Shisong	Binfola 	Roseline Kiawan	22	5	650341108	\N	\N	2025-11-11 11:41:59.785849	\N	1	2025-11-11 12:41:59.785849+01	2025-11-11 12:41:59.785849+01	\N
479	25-VOT-BAAH-436	2025-11-12	BANGHA MACXINE AFUAH 	M	2012-01-14	MeJang	BANGHA 	Banghq lizette 	1	1	651369712	\N	\N	2025-11-12 08:55:29.599055	\N	1	2025-11-12 09:55:29.599055+01	2025-11-12 09:55:29.599055+01	\N
293	25-VOT-ENNG-436	2025-11-12	ENECK PRIESTLY GANG 	M	2013-03-16	VOTECH 	Eneck 	Eneck Aime 	19	1	680880173	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761834171904-6eqi6pwsdlt.jpg	2025-10-30 12:37:29.825204	\N	1	2025-10-30 13:37:29.825204+01	2025-10-30 13:37:29.825204+01	\N
483	25-VOT-BANG-436	2025-11-12	BABILA EMMABRYAN FOWAJANG	M	2025-11-12	Bali	Babila	Nkonde Gislle	19	1	651229863	\N	\N	2025-11-12 09:41:09.259523	\N	1	2025-11-12 10:41:09.259523+01	2025-11-12 10:41:09.259523+01	\N
485	25-VOT-ATON-438	2025-11-13	ATUD SHALON 	F	2025-11-13	BAMENDA 	Atud 	Atud Constant 	19	1	651712957	\N	\N	2025-11-13 10:16:23.842946	\N	1	2025-11-13 11:16:23.842946+01	2025-11-13 11:16:23.842946+01	\N
487	25-VOT-NJNG-440	2025-11-13	NJI NEVILLE TEBENG 	M	2008-05-20	Batibo 	Nji	Nji CLOVIS 	3	3	673008401	\N	\N	2025-11-13 10:22:35.032445	\N	1	2025-11-13 11:22:35.032445+01	2025-11-13 11:22:35.032445+01	\N
490	25-VOT-DONG-443	2025-11-13	DOBGIMA VENATIUS NDONG 	M	2025-11-13	VOTECH 	Votech 	Votech 	7	2	2000	\N	\N	2025-11-13 10:34:06.061972	\N	1	2025-11-13 11:34:06.061972+01	2025-11-13 11:34:06.061972+01	\N
492	25-VOT-BOUS-445	2025-11-13	BONKUNG NGASHING DIOYMUS 	M	2006-09-01	Banso	Bonkung 	Chu Judith	9	6	672530080	\N	\N	2025-11-13 12:02:18.567095	\N	1	2025-11-13 13:02:18.567095+01	2025-11-13 13:02:18.567095+01	\N
51	25-VOT-FOOM-446	2025-11-14	FORTEH SHALOM	F	2025-11-14	VOTECH 	Votech 	Votech 	1	1	677828418	2000	https://st60307.ispot.cc/votechs7academygroup/students/photos/1763079375871-jnrgnof2j4b.jpg	2025-09-16 15:17:19.463083	\N	1	2025-09-16 16:17:19.463083+01	2025-09-16 16:17:19.463083+01	\N
9	25-VOT-MBHT-446	2025-11-14	MBAH KERRY BRIGHT	F	2013-12-03	Mankon 	Ajaga MacDonald 	Charlotte Manju	1	1	672527472	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1763079871813-rmt0cpmg058.jpg	2025-09-16 11:25:32.371139	\N	1	2025-09-16 12:25:32.371139+01	2025-09-16 12:25:32.371139+01	\N
19	25-VOT-NAWA-446	2025-11-14	NAUIDJI DAVID LOIR ABONGWA	M	2013-11-24	Mankon Bamenda 	Metem Juliette you 	JULIETTE 	1	1	678837606	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1763080353786-fprb5j9o4od.jpg	2025-09-16 12:17:48.408048	\N	1	2025-09-16 13:17:48.408048+01	2025-09-16 13:17:48.408048+01	\N
40	25-VOT-NFRI-446	2025-11-14	NFONYONG MILDRED ENGWARI 	F	2014-02-05	Kugwle	Forleku	Forleku sandrine 	1	1	653842613	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1763080782881-l54bxyf2uhj.jpg	2025-09-16 14:32:51.592037	\N	1	2025-09-16 15:32:51.592037+01	2025-09-16 15:32:51.592037+01	\N
5	25-VOT-NYEN-446	2025-11-14	NYANGA BERODE TEGHEN	M	2013-05-19	Mankon Bamenda 	Nyanga Fidelise	Nyanga	5	5	675553058	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1763129665564-n8egi2d226.jpg	2025-09-15 19:53:00.169473	\N	1	2025-09-15 20:53:00.169473+01	2025-09-15 20:53:00.169473+01	\N
380	25-VOT-OFTI-446	2025-11-14	OFERTI BRIGHT OFERTI 	M	2011-09-21	BAMENDA 	OFERTI 	OFERTI EMELDA 	5	5	653857514	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1763129749460-6vw0oltk0e2.jpg	2025-10-31 11:45:42.945098	\N	1	2025-10-31 12:45:42.945098+01	2025-10-31 12:45:42.945098+01	\N
266	25-VOT-TIUA-446	2025-11-14	TIKUM  MARKCRIST JOSHUA 	M	2014-01-01	BAMENDA 	Tikum search 	Tikum	5	5	674848716	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1763130098231-pq1dty6pfta.jpg	2025-10-29 15:19:44.886441	\N	1	2025-10-29 16:19:44.886441+01	2025-10-29 16:19:44.886441+01	\N
466	25-VOT-ATON-443	2025-11-15	ATUD ROONEY LOSON	M	2010-04-08	VOTECH 	Atud	Ngwa Delphine	8	3	678003384	\N	\N	2025-11-07 09:01:02.303356	\N	1	2025-11-07 10:01:02.303356+01	2025-11-07 10:01:02.303356+01	\N
371	25-VOT-ACSS-410	2025-11-05	ACHU AMBLESS 	M	2007-08-25	Santa	Atannga Elvis 	Atanga 	16	3	651624609	683021269	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762357163002-98vafrz4pb6.jpg	2025-10-31 10:52:22.017982	\N	1	2025-10-31 11:52:22.017982+01	2025-10-31 11:52:22.017982+01	\N
331	25-VOT-NKCY-294	2025-10-31	NKEMBU  TRACY 	F	2025-04-14	VOTECH 	Nji	Mih cloudette	6	4	681271384	\N	\N	2025-10-31 06:54:38.189486	\N	1	2025-10-31 07:54:38.189486+01	2025-10-31 07:54:38.189486+01	\N
332	25-VOT-PEAP-295	2025-10-31	PENBAGAH RUTH NJIACHAP 	F	2012-04-07	BAMENDA 	NJIACHAP Micheal 	NJIACHAP	6	4	677573309	\N	\N	2025-10-31 07:28:43.097718	\N	1	2025-10-31 08:28:43.097718+01	2025-10-31 08:28:43.097718+01	\N
333	25-VOT-VIUY-296	2025-10-31	VIOLTTE WIYLANYUY 	F	2006-07-17	Kumbo	Bambot Stella 	Bambot Stella	6	4	677355957	\N	\N	2025-10-31 07:31:17.027736	\N	1	2025-10-31 08:31:17.027736+01	2025-10-31 08:31:17.027736+01	\N
334	25-VOT-TEHA-297	2025-10-31	TEMBU CAREERIST WACHA 	F	2025-03-12	Widikum 	Tembu	Amu Jennifer Tambu	6	4	674606368	\N	\N	2025-10-31 07:33:18.930492	\N	1	2025-10-31 08:33:18.930492+01	2025-10-31 08:33:18.930492+01	\N
335	25-VOT-AKNE-298	2025-10-31	AKI GERMAINE 	F	2010-09-28	Konda	Aki	Aki Mispa 	6	4	670281117	\N	\N	2025-10-31 07:38:36.797058	\N	1	2025-10-31 08:38:36.797058+01	2025-10-31 08:38:36.797058+01	\N
248	25-VOT-ATYE-299	2025-10-31	ATANGEH SLYVAIN ANYE	M	2009-04-27	Mezam Bamenda 	Anye peter	Maltina 	25	2	683132762	\N	\N	2025-10-28 10:59:57.084609	\N	1	2025-10-28 11:59:57.084609+01	2025-10-28 11:59:57.084609+01	\N
336	25-VOT-ASRY-299	2025-10-31	ASANGA GLORY 	F	2025-10-31	BAMENDA 	Asanga Solomon 	Asanga	6	4	677126531	\N	\N	2025-10-31 08:02:15.30788	\N	1	2025-10-31 09:02:15.30788+01	2025-10-31 09:02:15.30788+01	\N
337	25-VOT-SAOU-300	2025-10-31	SALAMATOU SALIFOU 	F	2025-01-16	BAMENDA 	Douadu Salifou	Salifou	6	4	677256403	\N	\N	2025-10-31 08:09:43.48983	\N	1	2025-10-31 09:09:43.48983+01	2025-10-31 09:09:43.48983+01	\N
338	25-VOT-KHAL-301	2025-10-31	KHAN FAITH ADMIRAL 	F	2009-01-12	BAMENDA 	Foungwang lanji Jeff	Foungwang	6	4	674761910	\N	\N	2025-10-31 08:11:49.876306	\N	1	2025-10-31 09:11:49.876306+01	2025-10-31 09:11:49.876306+01	\N
375	25-VOT-AMUS-410	2025-11-05	AMBANKUNA PROTUS 	M	2008-06-24	BAMENDA Ngie	Ambanaku	Ambanaku Derus 	16	3	681748005	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762358385992-dp71rdctlzn.jpg	2025-10-31 11:01:14.33516	\N	1	2025-10-31 12:01:14.33516+01	2025-10-31 12:01:14.33516+01	\N
355	25-VOT-TCAN-414	2025-11-06	TCHOFOR BRYAN 	M	2011-04-28	BAMENDA 	Tchofor 	Pendezue Lyzette	9	6	681271384	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762440733231-l5xzhxnx2zo.jpg	2025-10-31 09:21:39.470117	\N	1	2025-10-31 10:21:39.470117+01	2025-10-31 10:21:39.470117+01	\N
99	25-VOT-MISA-414	2025-11-06	MIYAN LISA 	F	2009-08-30	VOTECH 	Votech 	Votech 	17	6	650876468	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762442825636-sijur0a34j.jpg	2025-09-19 11:21:54.410312	\N	1	2025-09-19 12:21:54.410312+01	2025-09-19 12:21:54.410312+01	\N
364	25-VOT-GAMA-445	2025-11-15	GANGBOBGA DIANIC GIMA 	M	2009-07-24	BAMENDA 	GAMBADGA	Billa Rita	12	2	677546392	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762270032790-zj24dj0qd4.jpg	2025-10-31 10:04:08.762346	\N	1	2025-10-31 11:04:08.762346+01	2025-10-31 11:04:08.762346+01	\N
370	25-VOT-FONG-333	2025-10-31	FOBANG MARTIN BRIGHT ASANG 	M	2010-09-01	Mankon Bamenda 	Asang martin	Asang	13	2	675153450	\N	\N	2025-10-31 10:47:26.751723	\N	1	2025-10-31 11:47:26.751723+01	2025-10-31 11:47:26.751723+01	2025-11-15 09:32:06.668107+01
348	25-VOT-LUHO-311	2025-10-31	LUA DANIEL NKONGHO 	M	2010-10-06	Widikum 	Lua	Kolem Reginal 	10	5	677869040	\N	\N	2025-10-31 08:53:06.165272	\N	1	2025-10-31 09:53:06.165272+01	2025-10-31 09:53:06.165272+01	\N
347	25-VOT-NKBA-312	2025-10-31	NKWONJI NISSELY YOBA 	F	2010-04-06	Bawork	Francline yoba	Francline yoba	10	5	677001958	\N	\N	2025-10-31 08:51:10.518089	\N	1	2025-10-31 09:51:10.518089+01	2025-10-31 09:51:10.518089+01	\N
346	25-VOT-FUUL-312	2025-10-31	FUL FERRAND FUL 	M	2007-07-12	Mbessa 	Ful 	Asumta lum	10	5	672647081	\N	\N	2025-10-31 08:49:06.045213	\N	1	2025-10-31 09:49:06.045213+01	2025-10-31 09:49:06.045213+01	\N
349	25-VOT-TIIS-312	2025-10-31	TIMKUM CLOVIS 	M	2007-08-21	Batibo 	Tikum 	Samba theresia 	10	5	682961248	\N	\N	2025-10-31 08:56:23.35977	\N	1	2025-10-31 09:56:23.35977+01	2025-10-31 09:56:23.35977+01	\N
350	25-VOT-SASE-313	2025-10-31	SAHMEN JESSE 	M	2011-02-23	Bawork	Watard Edwine 	Watard Edwine	8	3	679499565	\N	\N	2025-10-31 09:00:47.935128	\N	1	2025-10-31 10:00:47.935128+01	2025-10-31 10:00:47.935128+01	\N
351	25-VOT-NSEL-314	2025-10-31	NSOH EMMANUEL 	M	2011-12-20	BAMENDA 	Nde chi Akenji	Nde chi Akenji	8	3	676410705	\N	\N	2025-10-31 09:02:29.849785	\N	1	2025-10-31 10:02:29.849785+01	2025-10-31 10:02:29.849785+01	\N
352	25-VOT-DOAN-315	2025-10-31	DOGO OCTAVIAN 	M	2013-08-28	BAMENDA 	Ndi Dogo 	Ndi Dogo	8	3	677081014	\N	\N	2025-10-31 09:03:57.506597	\N	1	2025-10-31 10:03:57.506597+01	2025-10-31 10:03:57.506597+01	\N
353	25-VOT-TAEL-316	2025-10-31	TAMBE DENZEL 	M	2025-08-19	BAMENDA 	Mbakwa Ferdinand 	Mbakwa Ferdinand 	8	3	654532025	\N	\N	2025-10-31 09:05:41.648601	\N	1	2025-10-31 10:05:41.648601+01	2025-10-31 10:05:41.648601+01	\N
339	25-VOT-AFMA-317	2025-10-31	AFAYAM SHARMA 	M	2011-11-25	BAMENDA 	Anyi Doligifteen 	Anyi Doligifteen	8	3	672174156	\N	\N	2025-10-31 08:31:42.448188	\N	1	2025-10-31 09:31:42.448188+01	2025-10-31 09:31:42.448188+01	\N
354	25-VOT-NJAH-317	2025-10-31	NJANYI JOYCELINE AWAH 	F	2012-01-21	BAMENDA 	Nganyi 	Marcduvate mbayi	6	4	682985484	\N	\N	2025-10-31 09:15:19.841345	\N	1	2025-10-31 10:15:19.841345+01	2025-10-31 10:15:19.841345+01	\N
366	25-VOT-CHHE-329	2025-10-31	CHE PRINCEWILL  NCHE 	M	2009-10-17	Mankon Bamenda 	Nde Christain 	Nde 	12	2	676426149	\N	\N	2025-10-31 10:08:23.871894	\N	1	2025-10-31 11:08:23.871894+01	2025-10-31 11:08:23.871894+01	\N
367	25-VOT-ANUR-330	2025-10-31	ANYAM FAVOUR 	M	2007-09-11	BAMENDA 	Increase 	Anyam	12	2	651034060	\N	\N	2025-10-31 10:10:12.435834	\N	1	2025-10-31 11:10:12.435834+01	2025-10-31 11:10:12.435834+01	\N
373	25-VOT-MBHA-336	2025-10-31	MBOH KINASON TICHA 	M	2010-06-19	BAMENDA 	Mboh	Lum Emelda	16	3	676118420	\N	\N	2025-10-31 10:56:44.029701	\N	1	2025-10-31 11:56:44.029701+01	2025-10-31 11:56:44.029701+01	\N
374	25-VOT-GAZA-337	2025-10-31	GAMBONGA COLLINS TEZA 	M	2009-07-24	BAMENDA 	Gambonga	Peckuna Vivian 	16	3	676379891	\N	\N	2025-10-31 10:58:50.617184	\N	1	2025-10-31 11:58:50.617184+01	2025-10-31 11:58:50.617184+01	\N
358	25-VOT-ABEL-351	2025-11-04	ABONGWA GILDEL 	M	2009-03-22	BAMENDA 	Awangum Claude	Awangum Claude	12	2	650073377	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762269159540-26zdq388sls.jpg	2025-10-31 09:36:42.66561	\N	1	2025-10-31 10:36:42.66561+01	2025-10-31 10:36:42.66561+01	\N
357	25-VOT-ACDE-351	2025-11-04	ACHU PRIDE	M	2010-03-21	VOTECH 	Votech 	Votech 	12	2	672201065	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762269380985-lzjs2pqils.jpg	2025-10-31 09:33:49.319101	\N	1	2025-10-31 10:33:49.319101+01	2025-10-31 10:33:49.319101+01	\N
362	25-VOT-FOIS-351	2025-11-04	FORKA FORCHOR HARIS 	M	2011-06-16	Mezam Bamenda 	FORKA 	FON CHRISTABEL	12	2	678001645	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762269789796-zps39g9g5tq.jpg	2025-10-31 10:02:09.765927	\N	1	2025-10-31 11:02:09.765927+01	2025-10-31 11:02:09.765927+01	\N
359	25-VOT-MIEL-351	2025-11-04	MIWAN MIKEL 	M	2005-05-27	BAMENDA 	Ebu Cletus 	Ebu Cletus	12	2	671338816	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762270569829-qeq0okvsqs.jpg	2025-10-31 09:54:03.60111	\N	1	2025-10-31 10:54:03.60111+01	2025-10-31 10:54:03.60111+01	\N
360	25-VOT-NDON-351	2025-11-04	NDANGOH CLANSON 	M	2008-08-05	Bali	NDANGOH Joseph 	NDANGOH Joseph 	12	2	670982583	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762270638080-rrw0fna6y8.jpg	2025-10-31 09:57:17.829233	\N	1	2025-10-31 10:57:17.829233+01	2025-10-31 10:57:17.829233+01	\N
340	25-VOT-NGUS-303	2025-10-31	NGAH BELTUS 	M	2025-10-31	VOTECH 	Ngoh Manavis 	Ngoh Manavis	7	2	683181222	\N	\N	2025-10-31 08:35:08.823566	\N	1	2025-10-31 09:35:08.823566+01	2025-10-31 09:35:08.823566+01	2025-11-05 14:22:04.932614+01
342	25-VOT-EBSE-409	2025-11-05	EBAI BLAISE 	M	2010-08-15	BAMENDA 	Ebia DESTINY 	Ebia DESTINY	7	2	652357385	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762350526027-cdeiis4u385.jpg	2025-10-31 08:39:48.229838	\N	1	2025-10-31 09:39:48.229838+01	2025-10-31 09:39:48.229838+01	\N
344	25-VOT-MUNS-409	2025-11-05	MUSI JERRY MARTINS 	M	2010-02-02	Bali	Musi Eric 	Musi Eric 	7	2	677622397	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762352368659-dex1ftz30h.jpg	2025-10-31 08:43:09.440051	\N	1	2025-10-31 09:43:09.440051+01	2025-10-31 09:43:09.440051+01	\N
343	25-VOT-VEOR-409	2025-11-05	VESHEGHO JUNIOR 	M	2009-05-25	BAMENDA 	Tah EMMANUEL 	Tah EMMANUEL	7	2	677408961	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762353117026-jke1uc0t33.jpg	2025-10-31 08:41:35.591497	\N	1	2025-10-31 09:41:35.591497+01	2025-10-31 09:41:35.591497+01	\N
385	25-VOT-ABEH-348	2025-11-04	ABIA TRACY MBEGEH	F	2012-08-28	Bali nyonga 	ABIA	Adin sydoni	4	6	679998518	\N	\N	2025-11-04 13:45:48.507077	\N	1	2025-11-04 14:45:48.507077+01	2025-11-04 14:45:48.507077+01	2025-11-15 09:45:05.276263+01
377	25-VOT-ADSE-340	2025-10-31	ADE  BLAISE 	M	2025-10-31	VOTECH 	Votech 	Votech 	1	1	2000	\N	\N	2025-10-31 11:05:15.691507	\N	1	2025-10-31 12:05:15.691507+01	2025-10-31 12:05:15.691507+01	\N
378	25-VOT-MOOR-341	2025-10-31	MOFO SLYVEN JUNIOR	M	2009-06-17	Douala 	Antoinette 	Mofo	8	3	655341492	\N	\N	2025-10-31 11:39:45.117341	\N	1	2025-10-31 12:39:45.117341+01	2025-10-31 12:39:45.117341+01	\N
381	25-VOT-MBOR-410	2025-11-05	MBUHUCIEKE GODWILL NDIFOR 	M	2010-07-25	BAMENDA 	Elvis Landry 	Elvis Landry	16	3	675126233	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762357847467-m3k4ratygpd.jpg	2025-10-31 11:53:00.574623	\N	1	2025-10-31 12:53:00.574623+01	2025-10-31 12:53:00.574623+01	\N
382	25-VOT-PIKY-410	2025-11-05	PIVAGA ROY BISKY 	M	2008-07-15	BAMENDA 	Pivaga	Lenna Delphine 	16	3	670690487	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762358295922-iopgptf6fr.jpg	2025-10-31 11:54:39.260693	\N	1	2025-10-31 12:54:39.260693+01	2025-10-31 12:54:39.260693+01	\N
298	25-VOT-MAZE-289	2025-10-31	MADUKA CHIBEZE 	M	2015-05-15	BAMENDA 	 Maduka uchana	Maduka	19	1	670649988	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761916762337-f5ap2jff7ad.jpg	2025-10-30 12:51:25.089134	\N	1	2025-10-30 13:51:25.089134+01	2025-10-30 13:51:25.089134+01	\N
109	25-VOT-MUHT-348	2025-10-31	MUKONG CINDY BRIGHT 	F	2014-08-16	BAMENDA 	Mayong celine	Celine	19	1	652195374	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761916818067-3grcg7ua029.jpg	2025-10-17 11:34:51.645684	\N	1	2025-10-17 12:34:51.645684+01	2025-10-17 12:34:51.645684+01	\N
301	25-VOT-NDNG-348	2025-10-31	NDE BLESS ACHIRIZANG 	M	2012-02-19	VOTECH 	Nsoh ACHIRIZANG	Nsoh 	19	1	678004318	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761917014489-jnkz340gk4.jpg	2025-10-30 12:59:29.273348	\N	1	2025-10-30 13:59:29.273348+01	2025-10-30 13:59:29.273348+01	\N
295	25-VOT-NGWE-348	2025-10-31	NGWA JEDIDIAH AGWE	M	2013-09-03	VOTECH 	Votech 	Votech 	19	1	680839418	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761918493217-4tvwtknphog.jpg	2025-10-30 12:42:17.959962	\N	1	2025-10-30 13:42:17.959962+01	2025-10-30 13:42:17.959962+01	\N
233	25-VOT-OKIH-348	2025-10-31	OKEM LIFTED ACHIH 	M	2012-05-25	VOTECH 	Okem	Ma rose 	19	1	675366195	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761918696665-3l9xh13p5x4.jpg	2025-10-28 07:30:44.756984	\N	1	2025-10-28 08:30:44.756984+01	2025-10-28 08:30:44.756984+01	\N
181	25-VOT-TEBO-348	2025-10-31	TETUH CARA TEBO 	M	2013-04-10	Ambo batibo	Tetuh 	Tetuh debreash	19	1	673218556	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761918855952-cg7ncgjm1d7.jpg	2025-10-22 06:32:34.815406	\N	1	2025-10-22 07:32:34.815406+01	2025-10-22 07:32:34.815406+01	\N
290	25-VOT-OMCA-348	2025-10-31	OMENE RANICA 	F	2011-10-27	VOTECH 	Fonong 	Fonong Cynthia 	19	1	677589262	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761919208808-sof2bdmzt0c.jpg	2025-10-30 12:30:48.763932	\N	1	2025-10-30 13:30:48.763932+01	2025-10-30 13:30:48.763932+01	\N
423	25-VOT-PEND-413	2025-11-06	PEFOUFE DESMOND 	M	2009-12-05	BAMENDA 	PEFOUFE 	PEFOUFE Marine 	15	5	6791111165	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762444756536-6563zfn22cx.jpg	2025-11-05 08:34:14.847116	\N	1	2025-11-05 09:34:14.847116+01	2025-11-05 09:34:14.847116+01	\N
110	25-VOT-AS,K-348	2025-10-31	ASHERI RAVENNA K,K	F	2014-12-02	BAMENDA 	Chamber jude	Mespa verla	19	1	670558343	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761919837614-85627yakyd9.jpg	2025-10-17 11:37:35.339463	\N	1	2025-10-17 12:37:35.339463+01	2025-10-17 12:37:35.339463+01	\N
189	25-VOT-CHEN-348	2025-10-31	CHEFOR NKWARA BIEN 	M	2013-12-14	VOTECH 	Votech 	Votech 	19	1	671329450	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761920004934-zy3x4fef2og.jpg	2025-10-22 07:10:02.986639	\N	1	2025-10-22 08:10:02.986639+01	2025-10-22 08:10:02.986639+01	\N
128	25-VOT-GATH-348	2025-10-31	GABILA TEMA BLESSETH 	F	2013-11-14	BAMENDA 	Malvise	Malvise 	19	1	651035895	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761920435036-ggmqpqzjs4h.jpg	2025-10-17 14:23:56.457945	\N	1	2025-10-17 15:23:56.457945+01	2025-10-17 15:23:56.457945+01	\N
305	25-VOT-LOOP-348	2025-10-31	LOH KERRY MBOP	M	2014-04-25	VOTECH 	Votech 	Votech 	19	1	675125517	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761920513930-hedc0x30a74.jpg	2025-10-30 13:07:29.868904	\N	1	2025-10-30 14:07:29.868904+01	2025-10-30 14:07:29.868904+01	\N
280	25-VOT-MUHN-348	2025-10-31	MUYEN ASHLY ABOHN	F	2010-09-03	Batibo	Tembong 	Tembong Monica 	19	1	674 108255	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761920881875-e2yy5q82jak.jpg	2025-10-30 11:42:46.809223	\N	1	2025-10-30 12:42:46.809223+01	2025-10-30 12:42:46.809223+01	\N
111	25-VOT-NELL-348	2025-10-31	NEBA PRINCEWILL PHARELL	M	2014-01-29	VOTECH 	Votech 	Votech 	19	1	699155662	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761921353822-39dknifiwsw.jpg	2025-10-17 11:39:03.123288	\N	1	2025-10-17 12:39:03.123288+01	2025-10-17 12:39:03.123288+01	\N
112	25-VOT-NUGA-348	2025-10-31	NUBIA VANNUEL BODGA	M	2013-05-05	Bali	Emmanculate 	Emmanculate	19	1	678176493	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761921730141-t25h5k8ks3p.jpg	2025-10-17 11:46:20.581838	\N	1	2025-10-17 12:46:20.581838+01	2025-10-17 12:46:20.581838+01	\N
291	25-VOT-KUCE-348	2025-10-31	KUMA REJOYCE 	F	2014-06-12	BAMENDA 	Kuma	Queen take lola	19	1	670725631	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761921889548-qcoeiv4j22.jpg	2025-10-30 12:32:44.112597	\N	1	2025-10-30 13:32:44.112597+01	2025-10-30 13:32:44.112597+01	\N
240	25-VOT-NKHA-348	2025-11-04	NKUMBOH KELLA VICTORIA FORGHA	F	2014-12-12	BAMENDA 	Nkembu	Pendeze  lyzette	19	1	681271384	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761921589295-1k3hewyv74z.jpg	2025-10-28 07:55:21.025057	\N	1	2025-10-28 08:55:21.025057+01	2025-10-28 08:55:21.025057+01	\N
296	25-VOT-AMWI-348	2025-11-04	AMBUGEH JULIET FAHWI	F	2015-10-31	VOTECH 	Votech 	Votech 	19	1	673494316	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1761919613128-flkumqcnov.jpg	2025-10-30 12:43:51.821763	\N	1	2025-10-30 13:43:51.821763+01	2025-10-30 13:43:51.821763+01	\N
460	25-VOT-GWUM-421	2025-11-07	GWE SWEENY FUNKUM	F	2012-05-20	VOTECH 	GWE	Gwe Shella	4	6	682963460	\N	\N	2025-11-07 08:40:51.783075	\N	1	2025-11-07 09:40:51.783075+01	2025-11-07 09:40:51.783075+01	\N
361	25-VOT-CHAN-351	2025-11-04	CHEO CHATEH NGWA KILLIAN 	M	2007-04-07	Yaoude 	Nwa Killian 	Nwa Killian	20	2	679272328	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762268841810-nbo0x4i39r.jpg	2025-10-31 09:59:53.449378	\N	1	2025-10-31 10:59:53.449378+01	2025-10-31 10:59:53.449378+01	\N
368	25-VOT-ANNG-351	2025-11-04	ANTHONY  NGONG	M	2000-11-28	BAMENDA 	Anthony 	Boh clotte 	12	2	677437499	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762269288626-2ckkkkwpnrx.jpg	2025-10-31 10:13:02.322945	\N	1	2025-10-31 11:13:02.322945+01	2025-10-31 11:13:02.322945+01	\N
369	25-VOT-FOWA-351	2025-11-04	FORWA JUNIOR FORWA	M	2005-05-10	Batibo	Tembu omaru	FORWA	12	2	678710216	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762269856288-dq4u4orf92c.jpg	2025-10-31 10:43:10.696506	\N	1	2025-10-31 11:43:10.696506+01	2025-10-31 11:43:10.696506+01	\N
384	25-VOT-AFER-351	2025-11-04	AFUMBOM TANKEU XAVIER 	M	2007-04-16	Bingo	Afumbom	Boh	16	3	677437499	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762271949570-90n13q3itp.jpg	2025-10-31 12:29:19.467746	\N	1	2025-10-31 13:29:19.467746+01	2025-10-31 13:29:19.467746+01	\N
383	25-VOT-AWAH-351	2025-11-04	AWAZI IAN TATAH 	M	2008-06-05	BAMENDA 	Abange Valentine	Abange	16	3	677852395	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762272063583-3h2ba9rs2a8.jpg	2025-10-31 12:06:29.913346	\N	1	2025-10-31 13:06:29.913346+01	2025-10-31 13:06:29.913346+01	\N
476	25-VOT-TIRA-434	2025-11-12	TIFUH PETRA	F	2025-11-12	VOTECH 	Votech 	Votech 	4	6	2000	\N	\N	2025-11-12 08:14:07.496963	\N	1	2025-11-12 09:14:07.496963+01	2025-11-12 09:14:07.496963+01	\N
488	25-VOT-BAON-441	2025-11-13	BAH BETRAND NFON 	M	2008-06-16	Meta	Sema 	Sema Valentine 	8	3	677767346	\N	\N	2025-11-13 10:25:36.31291	\N	1	2025-11-13 11:25:36.31291+01	2025-11-13 11:25:36.31291+01	\N
54	25-VOT-RHHU-446	2025-11-14	RHEMA AFANWI Shu	M	2014-02-25	Buea-fako	Shu Martine	Motorfueh Recheal	3	3	677022127	2000	https://st60307.ispot.cc/votechs7academygroup/students/photos/1763130877944-apq1rwap76l.jpg	2025-09-16 15:28:29.189437	\N	1	2025-09-16 16:28:29.189437+01	2025-09-16 16:28:29.189437+01	\N
87	25-VOT-FRNG-351	2025-11-04	FRU ZIRAH NGONG	M	2004-07-23	VOTECH 	Votech 	Votech 	12	2	677053124	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762269924427-asz5m4972cr.jpg	2025-09-17 18:49:58.559608	\N	1	2025-09-17 19:49:58.559608+01	2025-09-17 19:49:58.559608+01	\N
365	25-VOT-KUOR-351	2025-11-04	KUBONG CLINTON TANIFOR 	M	2008-01-01	VOTECH 	KUBONG	Vanessa  Kubong 	12	2	677615148	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762270103537-lpes8wrpq7.jpg	2025-10-31 10:05:53.973229	\N	1	2025-10-31 11:05:53.973229+01	2025-10-31 11:05:53.973229+01	\N
217	25-VOT-MBEL-351	2025-11-04	MBAH KELLY NOEL 	M	2010-12-08	BAMENDA 	Teke 	Teko DORIS TIFUH	12	2	676307043	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762270174697-otrctg37nhf.jpg	2025-10-22 13:04:58.634615	\N	1	2025-10-22 14:04:58.634615+01	2025-10-22 14:04:58.634615+01	\N
165	25-VOT-MBDI-351	2025-11-04	MBAH RANDI	M	2010-02-01	Southwest 	Mbah	Mbah brenda	12	2	676483157	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762270282168-3kn92q0gx6r.jpg	2025-10-20 14:37:13.972848	\N	1	2025-10-20 15:37:13.972848+01	2025-10-20 15:37:13.972848+01	\N
237	25-VOT-NGNG-351	2025-11-04	NGWA JAMES  SOMBANG 	M	2008-06-10	Bambui  Tubah 	Ngwa 	Asoh nancy	12	2	671821097	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762270847388-oboo0n0w3gn.jpg	2025-10-28 07:44:45.531414	\N	1	2025-10-28 08:44:45.531414+01	2025-10-28 08:44:45.531414+01	\N
387	25-VOT-TCEL-351	2025-11-04	TCHOFFO MENOME FRANK LIONEL	M	2009-03-07	SANTA	TCHIGUEU ODETTE	TCHIGUEU	12	2	675062812	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762271221150-7ampqs1699.jpg	2025-11-04 14:21:52.427455	\N	1	2025-11-04 15:21:52.427455+01	2025-11-04 15:21:52.427455+01	\N
220	25-VOT-NFGU-351	2025-11-04	NFORMI BLAISE ASONGU 	M	2009-11-24	VOTECH 	Bungong Roland Nformi	Informing lefe Gladys 	16	3	671531133	676776100	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762272173328-yz0loruq31f.jpg	2025-10-22 13:12:11.700347	\N	1	2025-10-22 14:12:11.700347+01	2025-10-22 14:12:11.700347+01	\N
47	25-VOT-FOOH-351	2025-11-04	FORKWEN SHILLOH	M	2012-07-08	Fun health 	Muki kelvin	Muki	1	1	67967275	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762284089084-wdad7pft6iq.jpg	2025-09-16 15:01:30.53289	\N	1	2025-09-16 16:01:30.53289+01	2025-09-16 16:01:30.53289+01	\N
388	25-VOT-NJON-351	2025-11-05	NJI BRIGHTLY FON 	M	2025-09-18	Bamenda Reginal hospital 	Fon Akenji	Fon Akenji	2	2	677666265	\N	\N	2025-11-05 03:54:10.902445	\N	1	2025-11-05 04:54:10.902445+01	2025-11-05 04:54:10.902445+01	\N
389	25-VOT-MOAN-352	2025-11-05	MOPECHA PRIDE KHAN	M	2011-09-09	Pinyin 	MOPECHA PENN WILFRED 	MOPECHA PENN WILFRED 	2	2	671668297	\N	\N	2025-11-05 03:56:54.70982	\N	1	2025-11-05 04:56:54.70982+01	2025-11-05 04:56:54.70982+01	\N
390	25-VOT-MBNE-353	2025-11-05	MBENG DIEUDONNE 	M	2009-12-05	Fondong	Mbeng 	Mbeng Emmanuela 	2	2	678458969	\N	\N	2025-11-05 03:59:44.373441	\N	1	2025-11-05 04:59:44.373441+01	2025-11-05 04:59:44.373441+01	\N
391	25-VOT-NDET-354	2025-11-05	NDUM HAMLET 	M	2008-03-24	Batibo	Ndum Killian 	Ndum Killian 	2	2	674131308	\N	\N	2025-11-05 04:02:07.092777	\N	1	2025-11-05 05:02:07.092777+01	2025-11-05 05:02:07.092777+01	\N
392	25-VOT-SAIN-355	2025-11-05	SAMKIA BRAIN 	M	2012-03-24	BAMENDA 	Samkia Patrick 	Samkia Patrick	2	2	670690487	\N	\N	2025-11-05 04:04:26.694107	\N	1	2025-11-05 05:04:26.694107+01	2025-11-05 05:04:26.694107+01	\N
393	25-VOT-WOCK-356	2025-11-05	WORYIHAH FEDRICK 	M	2025-11-05	BAMENDA 	WORYIHAH	WORYIHAH	2	2	670107013	\N	\N	2025-11-05 04:06:11.177955	\N	1	2025-11-05 05:06:11.177955+01	2025-11-05 05:06:11.177955+01	\N
395	25-VOT-ANHA-358	2025-11-05	ANJEI NOEL ACHA	M	2011-05-03	Batibo	Anjei	Acha Racheal 	2	2	671972581	\N	\N	2025-11-05 04:11:14.06904	\N	1	2025-11-05 05:11:14.06904+01	2025-11-05 05:11:14.06904+01	\N
396	25-VOT-DIVE-359	2025-11-05	DIFFOMENE DJOU GODLOVE 	M	2013-02-09	BAMENDA 	Diffomene 	Massop Vegine 	2	2	676386202	\N	\N	2025-11-05 04:13:40.10611	\N	1	2025-11-05 05:13:40.10611+01	2025-11-05 05:13:40.10611+01	\N
397	25-VOT-KAME-360	2025-11-05	KAMI BLESS TUME 	M	2011-08-07	BAMENDA 	Tata Justine 	Tata Justine	2	2	670536863	\N	\N	2025-11-05 04:15:43.681288	\N	1	2025-11-05 05:15:43.681288+01	2025-11-05 05:15:43.681288+01	\N
398	25-VOT-NDEL-361	2025-11-05	NDANJONG JOEL 	M	2011-09-04	BAMENDA 	Ndanjong 	Racheal 	2	2	650080739	\N	\N	2025-11-05 04:18:04.924014	\N	1	2025-11-05 05:18:04.924014+01	2025-11-05 05:18:04.924014+01	\N
399	25-VOT-AFHE-362	2025-11-05	AFUGENWI PAUL CHE 	M	2008-07-01	BAMENDA 	Afugenwi	Alice Aze	2	2	670107013	\N	\N	2025-11-05 04:20:07.184634	\N	1	2025-11-05 05:20:07.184634+01	2025-11-05 05:20:07.184634+01	\N
400	25-VOT-WAAT-363	2025-11-05	WANYE JEPTHAH BABAT 	M	2012-06-06	BAMENDA 	Wanye	Mukwe Linda Atu	2	2	650454330	\N	\N	2025-11-05 04:22:17.023553	\N	1	2025-11-05 05:22:17.023553+01	2025-11-05 05:22:17.023553+01	\N
401	25-VOT-CHYE-364	2025-11-05	CHAMI BRANFORD CHOEKNYE	M	2012-01-01	BAMENDA 	Chocknye Zakios	Chocknye Zakios	2	2	674573788	\N	\N	2025-11-05 04:24:32.435567	\N	1	2025-11-05 05:24:32.435567+01	2025-11-05 05:24:32.435567+01	\N
402	25-VOT-NJYE-365	2025-11-05	NJEMI BRANDON choeknye  	M	2012-01-01	BAMENDA 	Chocknye Zakios	Chocknye Zakios	2	2	674573788	\N	\N	2025-11-05 04:26:15.158659	\N	1	2025-11-05 05:26:15.158659+01	2025-11-05 05:26:15.158659+01	\N
403	25-VOT-NJOH-366	2025-11-05	NJIKEN VERON AKOH 	M	2010-08-27	BAMENDA 	Njiken 	Ntachou Hilda	2	2	653513075	\N	\N	2025-11-05 04:28:14.072078	\N	1	2025-11-05 05:28:14.072078+01	2025-11-05 05:28:14.072078+01	\N
404	25-VOT-DAND-367	2025-11-05	DANG LOUISE FORELAND 	M	2010-08-17	Wum	Dang 	Mme Belta 	2	2	671459422	\N	\N	2025-11-05 04:29:59.245404	\N	1	2025-11-05 05:29:59.245404+01	2025-11-05 05:29:59.245404+01	\N
405	25-VOT-NAOR-368	2025-11-05	NAPA GRACIOUS NGUFOR 	M	2011-09-12	Mbenwi	Napa	Munang Sidney 	2	2	651142474	\N	\N	2025-11-05 04:32:05.709835	\N	1	2025-11-05 05:32:05.709835+01	2025-11-05 05:32:05.709835+01	\N
406	25-VOT-TIIE-369	2025-11-05	TIBONG BRIGHT NJIE 	M	2013-05-05	Batibo 	Tibong 	Tibong Antionate 	2	2	652860327	\N	\N	2025-11-05 04:34:35.87454	\N	1	2025-11-05 05:34:35.87454+01	2025-11-05 05:34:35.87454+01	\N
407	25-VOT-AYHA-370	2025-11-05	AYOKO CHRISTAIN ACHA	M	2025-11-05	VOTECH 	Ayoko Wilson 	Ayoko	2	2	652512840	\N	\N	2025-11-05 04:36:49.280134	\N	1	2025-11-05 05:36:49.280134+01	2025-11-05 05:36:49.280134+01	\N
408	25-VOT-MUEH-371	2025-11-05	MUTAH PRINCEWILL  NJEH 	M	2012-08-12	VOTECH 	Mutah Lawrence 	Mutah 	2	2	675206055	\N	\N	2025-11-05 04:39:12.972293	\N	1	2025-11-05 05:39:12.972293+01	2025-11-05 05:39:12.972293+01	\N
409	25-VOT-AKUM-372	2025-11-05	AKUM GOD-CARE AKUM 	M	2012-01-22	BAMENDA 	Njei Christopher 	Njei	19	1	653826518	\N	\N	2025-11-05 04:41:51.92979	\N	1	2025-11-05 05:41:51.92979+01	2025-11-05 05:41:51.92979+01	\N
410	25-VOT-LEOH-373	2025-11-05	LEBGA MICHEAL DOH	M	2013-02-10	BAMENDA 	Lebga	Talon Consula	19	1	678550071	\N	\N	2025-11-05 04:43:51.08114	\N	1	2025-11-05 05:43:51.08114+01	2025-11-05 05:43:51.08114+01	\N
411	25-VOT-MBOH-374	2025-11-05	MBAH MARIE NOEL ENJOH	F	2025-11-05	VOTECH 	Mbah	Tetuh Antionatte 	6	4	653690770	\N	\N	2025-11-05 04:51:11.399916	\N	1	2025-11-05 05:51:11.399916+01	2025-11-05 05:51:11.399916+01	\N
453	25-VOT-ACAH-413	2025-11-06	ACHA LOYSE KAH 	F	2013-06-13	Kumba	Teboh Amos Teke 	Tibe Clarisse	19	1	677893718	679830580	\N	2025-11-06 09:09:32.024387	\N	1	2025-11-06 10:09:32.024387+01	2025-11-06 10:09:32.024387+01	\N
413	25-VOT-TIIS-376	2025-11-05	TIKUM CLOVIS 	M	2007-08-21	Batibo	Tikum	Samba theresia 	10	5	682961248	\N	\N	2025-11-05 04:56:13.199528	\N	1	2025-11-05 05:56:13.199528+01	2025-11-05 05:56:13.199528+01	\N
415	25-VOT-AGOH-378	2025-11-05	AGINWI EMMANUEL NSOH 	M	2009-03-09	VOTECH 	Aginwi 	MANKA MERCY 	8	3	674917035	\N	\N	2025-11-05 05:00:43.727844	\N	1	2025-11-05 06:00:43.727844+01	2025-11-05 06:00:43.727844+01	\N
418	25-VOT-NJEY-381	2025-11-05	NJINI MILTON SHEY 	M	2005-11-24	VOTECH 	Shey Godlove 	Shey 	16	3	675828786	\N	\N	2025-11-05 06:21:38.30779	\N	1	2025-11-05 07:21:38.30779+01	2025-11-05 07:21:38.30779+01	\N
420	25-VOT-YAPH-413	2025-11-06	YANDE TEDAH RALPH 	M	2010-05-16	Mbengwi	Agwe Robert 	Agwe 	15	5	676287483	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762445159934-fjt0jop43fc.jpg	2025-11-05 08:00:26.79754	\N	1	2025-11-05 09:00:26.79754+01	2025-11-05 09:00:26.79754+01	\N
419	25-VOT-JUIO-409	2025-11-05	JUMBAM BENEDICT PIO	M	2008-08-08	BAMENDA 	FREDRICK JAMBAM	Janette Dulafu	7	2	670537541	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762352296116-vpdejt0s2nn.jpg	2025-11-05 07:17:43.643284	\N	1	2025-11-05 08:17:43.643284+01	2025-11-05 08:17:43.643284+01	\N
461	25-VOT-NGOU-420	2025-11-07	NGANG SONITA MUSOU	F	2009-09-29	Nkom	Ngang 	Gillian 	6	4	681156921	\N	\N	2025-11-07 08:43:37.434888	\N	1	2025-11-07 09:43:37.434888+01	2025-11-07 09:43:37.434888+01	\N
394	25-VOT-NGEI-437	2025-11-12	NGONG  PRINCELY NJEI	M	2010-07-07	Batibo	Ngong Gerald 	Ngong Gerald 	2	2	673508939	\N	\N	2025-11-05 04:08:39.950694	\N	1	2025-11-05 05:08:39.950694+01	2025-11-05 05:08:39.950694+01	\N
442	25-VOT-GWIN-405	2025-11-05	GWE SWEENEY FUNKUIN	F	2025-11-05	VOTECH 	Votech 	Votech 	4	6	2000	\N	\N	2025-11-05 09:54:29.030152	\N	1	2025-11-05 10:54:29.030152+01	2025-11-05 10:54:29.030152+01	2025-11-15 09:46:14.073347+01
386	25-VOT-TAAS-410	2025-11-05	TANGWAH GILDAS	M	2003-04-17	BAFANG	TANGWA	TANGWA	12	2	650299895	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762356647627-mtp16umm9nc.jpg	2025-11-04 14:17:54.974759	\N	1	2025-11-04 15:17:54.974759+01	2025-11-04 15:17:54.974759+01	\N
356	25-VOT-AKEN-414	2025-11-06	AKUM JOYCE ENYEN 	F	2008-08-04	Batibo	Humphrey njang 	Humphrey njang 	11	4	673936230	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762440228661-h1f7arjuha5.jpg	2025-10-31 09:24:41.148297	\N	1	2025-10-31 10:24:41.148297+01	2025-10-31 10:24:41.148297+01	\N
414	25-VOT-CHHT-394	2025-11-05	CHABU MAC-BRIGHT 	M	2012-10-29	VOTECH 	Chuba Julius	Chuba	8	3	677613130	\N	\N	2025-11-05 04:58:40.062337	\N	1	2025-11-05 05:58:40.062337+01	2025-11-05 05:58:40.062337+01	\N
432	25-VOT-ABRO-395	2025-11-05	ABE BAZIL MBORO	M	2005-06-28	Ako	Sama	Sama rose yumbo	25	2	677860501	\N	\N	2025-11-05 09:24:46.820696	\N	1	2025-11-05 10:24:46.820696+01	2025-11-05 10:24:46.820696+01	\N
433	25-VOT-AKOH-396	2025-11-05	AKAH HOSEA MENYOH	M	2005-10-20	Batibo	Aka 	Aka Shambeline	25	2	673039730	\N	\N	2025-11-05 09:28:49.076077	\N	1	2025-11-05 10:28:49.076077+01	2025-11-05 10:28:49.076077+01	\N
434	25-VOT-ATYE-397	2025-11-05	ATANGEH SYVAIN ANYE	M	2009-04-27	Mankon Bamenda 	Anye peter	Anye	25	2	683132762	\N	\N	2025-11-05 09:31:02.771169	\N	1	2025-11-05 10:31:02.771169+01	2025-11-05 10:31:02.771169+01	\N
435	25-VOT-BAEY-398	2025-11-05	BAYIHA !!! ISABELLE NAOMI ASHLEY 	F	2010-02-17	Foumbot	Sama 	FORJINDAM BLANCHE 	25	2	678601332	\N	\N	2025-11-05 09:34:31.591987	\N	1	2025-11-05 10:34:31.591987+01	2025-11-05 10:34:31.591987+01	\N
437	25-VOT-MANS-400	2025-11-05	MANGONG HANS 	M	2007-02-05	Mankon Bamenda 	Mangong 	Rose Angwa	25	2	672884016	\N	\N	2025-11-05 09:38:25.460893	\N	1	2025-11-05 10:38:25.460893+01	2025-11-05 10:38:25.460893+01	\N
443	25-VOT-NYAN-406	2025-11-05	NYANGA SHAMA ASOMBAN	M	2009-04-13	BAMENDA 	Asombang  	Asombang Yvonne	10	5	677968323	\N	\N	2025-11-05 11:50:28.668495	\N	1	2025-11-05 12:50:28.668495+01	2025-11-05 12:50:28.668495+01	\N
444	25-VOT-TEEH-407	2025-11-05	TEBECK STANILSUIS TEKOEH	M	2010-11-05	BAMENDA 	Tanawn Philip Tebeck 	Tanawn Philip Tebeck 	10	5	677333517	\N	\N	2025-11-05 11:54:34.793827	\N	1	2025-11-05 12:54:34.793827+01	2025-11-05 12:54:34.793827+01	\N
447	25-VOT-NGEG-410	2025-11-05	NGAH BRYAN TSHEG	M	2012-08-28	BAMENDA 	Ngah DIVINE 	Ngah DIVINE	8	3	677250989	\N	\N	2025-11-05 12:38:57.831051	\N	1	2025-11-05 13:38:57.831051+01	2025-11-05 13:38:57.831051+01	\N
345	25-VOT-AGCY-409	2025-11-05	AGWA PRAISES MERCY 	F	2012-12-31	BAMENDA Bingo	Angwa 	Agwa Collette 	7	2	6770495719	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762350051087-6j77j4uh0k.jpg	2025-10-31 08:46:07.011419	\N	1	2025-10-31 09:46:07.011419+01	2025-10-31 09:46:07.011419+01	\N
155	25-VOT-ANHT-409	2025-11-05	ANENG MARK BRIGHT 	M	2011-03-15	BAMENDA 	Ngoh 	Ngoh manavis	7	2	683181222	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762350136350-c60bjpox2kh.jpg	2025-10-20 14:04:56.613399	\N	1	2025-10-20 15:04:56.613399+01	2025-10-20 15:04:56.613399+01	\N
341	25-VOT-FOHT-409	2025-11-05	FON MARK BRIGHT 	M	2008-08-05	BAMENDA 	Eric sanga	Eric sanga	7	2	674341064	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762352112516-wz3ryxcjxc9.jpg	2025-10-31 08:37:00.090591	\N	1	2025-10-31 09:37:00.090591+01	2025-10-31 09:37:00.090591+01	\N
412	25-VOT-NDAH-409	2025-11-05	NDE ADONIA SMART AWAH 	M	2012-05-08	BAMENDA 	Nde	Bih Nicoline 	7	2	675125182	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762352464327-wsgorc4cd1.jpg	2025-11-05 04:54:04.646797	\N	1	2025-11-05 05:54:04.646797+01	2025-11-05 05:54:04.646797+01	\N
446	25-VOT-NGAH-409	2025-11-05	NGAH ANIS TIMAH 	M	2010-11-25	BAMENDA 	Ngah divine 	Ngah divine 	7	2	677250989	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762352647596-fw4k8l6qds.jpg	2025-11-05 12:36:59.384917	\N	1	2025-11-05 13:36:59.384917+01	2025-11-05 13:36:59.384917+01	\N
153	25-VOT-TEEL-409	2025-11-05	TEKON MARK NOEL 	M	2010-07-31	VOTECH 	Votech 	Votech 	7	2	675828066	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762352870525-jboa4f80u3e.jpg	2025-10-20 13:55:44.345736	\N	1	2025-10-20 14:55:44.345736+01	2025-10-20 14:55:44.345736+01	\N
79	25-VOT-TING-409	2025-11-05	TIMAH CLOVIS ELANNG 	F	2008-02-28	VOTECH 	Votech 	Votech 	7	2	670757440	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762353025378-xxg0gquv3kd.jpg	2025-09-17 15:28:11.680379	\N	1	2025-09-17 16:28:11.680379+01	2025-09-17 16:28:11.680379+01	\N
448	25-VOT-SANA-409	2025-11-05	SAMGWA BERYL HOPE NWANA	M	2012-09-11	Bali	NWANA	Nagela  Judith 	19	1	678289657	\N	\N	2025-11-05 14:51:57.700042	\N	1	2025-11-05 15:51:57.700042+01	2025-11-05 15:51:57.700042+01	\N
417	25-VOT-OTHI-414	2025-11-06	OTIA CHRISTELLE UCHI	F	2012-05-31	Southwest 	Otia 	Mme macceline 	11	4	673028248	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762440434436-onq4e8jrsi.jpg	2025-11-05 06:15:08.306494	\N	1	2025-11-05 07:15:08.306494+01	2025-11-05 07:15:08.306494+01	\N
431	25-VOT-AMUR-414	2025-11-06	AMEG MAFOR FAVOUR 	M	2008-02-28	BAMENDA 	ZECHA EMMANUEL 	ZECHA EMMANUEL 	17	6	681076276	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762442479531-i16177asn3.jpg	2025-11-05 09:20:12.210466	\N	1	2025-11-05 10:20:12.210466+01	2025-11-05 10:20:12.210466+01	\N
428	25-VOT-ADCE-410	2025-11-05	ADONAI FAVOUR PRUDENCE 	F	2011-04-04	VOTECH 	Votech 	Votech 	18	4	677508932	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762355647246-gaplzbd7dkn.jpg	2025-11-05 08:45:23.966922	\N	1	2025-11-05 09:45:23.966922+01	2025-11-05 09:45:23.966922+01	\N
225	25-VOT-FRNE-410	2025-11-05	FRU JOYCELINE 	F	2008-08-10	Alabokam	Fru	Emeldine neh	18	4	677002488	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762355949107-4n3ghbaof8.jpg	2025-10-22 13:29:00.510463	\N	1	2025-10-22 14:29:00.510463+01	2025-10-22 14:29:00.510463+01	\N
98	25-VOT-CHSI-410	2025-11-05	CHE PRINCELY FOMUSI 	M	2010-08-29	Bafachu	Achi 	Achi Varoline 	18	4	672091777	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762356051175-c38kr3ar3aa.jpg	2025-09-19 11:21:03.71616	\N	1	2025-09-19 12:21:03.71616+01	2025-09-19 12:21:03.71616+01	\N
427	25-VOT-TACK-410	2025-11-05	TAMBETTA BLANDINE OROCK 	M	2004-11-03	Memfe	Tambetta	Tambetta	18	4	674768103	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762356300859-ruequt9tah8.jpg	2025-11-05 08:44:12.503104	\N	1	2025-11-05 09:44:12.503104+01	2025-11-05 09:44:12.503104+01	\N
429	25-VOT-NYNA-414	2025-11-06	NYONLEMUGA ZENA	F	2006-02-10	Bali 	Ndangoh Joseph 	Ndangoh Joseph 	17	6	651512170	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762443041022-0d9ov81cxkz.jpg	2025-11-05 08:49:37.270841	\N	1	2025-11-05 09:49:37.270841+01	2025-11-05 09:49:37.270841+01	\N
425	25-VOT-FOEP-388	2025-11-05	FOMBI CALEP 	M	2009-03-28	BAMENDA 	Fombi 	SIRRI FLOVINO	15	5	678580933	\N	\N	2025-11-05 08:38:20.245371	\N	1	2025-11-05 09:38:20.245371+01	2025-11-05 09:38:20.245371+01	2025-11-06 16:56:49.490781+01
440	25-VOT-CHUM-413	2025-11-06	CHEO BENISE LUM 	F	2010-01-05	Youande 	Ngwa Killian Cheo	Cheo	23	8	679272328	652664892	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762445257725-bl0hexe6rm7.jpg	2025-11-05 09:46:52.032864	\N	1	2025-11-05 10:46:52.032864+01	2025-11-05 10:46:52.032864+01	\N
441	25-VOT-EDYU-413	2025-11-06	EDU ITA NFIENYU	F	2005-04-04	Dumbo Berabe 	Ndofor Nwana 	MME BLANCHE  	23	8	677831863	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762446039095-f2mfg14xhv6.jpg	2025-11-05 09:50:36.288252	\N	1	2025-11-05 10:50:36.288252+01	2025-11-05 10:50:36.288252+01	\N
438	25-VOT-TOBA-429	2025-11-07	TOSI BORIS YAMBA 	M	2007-07-24	Bello	Tosi 	Yuh prudential 	23	8	676243298	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762526342432-rola1n5bgs.jpg	2025-11-05 09:41:26.211362	\N	1	2025-11-05 10:41:26.211362+01	2025-11-05 10:41:26.211362+01	\N
478	25-VOT-DONG-435	2025-11-12	DOBGIMA VENATIUS NDONG 	M	2025-11-12	VOTECH 	Votech 	Votech 	7	2	2000	\N	\N	2025-11-12 08:32:52.908776	\N	1	2025-11-12 09:32:52.908776+01	2025-11-12 09:32:52.908776+01	\N
430	25-VOT-DANG-437	2025-11-12	DABONG  BLESSING  AKWAGANG 	F	2009-05-28	Widikum 	Dabong	Che cyprine	17	6	675407197	\N	\N	2025-11-05 09:00:10.141177	\N	1	2025-11-05 10:00:10.141177+01	2025-11-05 10:00:10.141177+01	\N
256	25-VOT-AFCY-443	2025-11-15	AFOUBOM PERCY	M	2011-07-12	BAMENDA 	Afoubom	Nkwain clarise mbe	15	5	674106433	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1762444259974-55kzow266fe.jpg	2025-10-28 12:40:39.462654	\N	1	2025-10-28 13:40:39.462654+01	2025-10-28 13:40:39.462654+01	\N
70	25-VOT-TIUR-446	2025-11-14	TITA FAVOUR 	M	2011-03-06	VOTECH 	Votech 	Votech 	5	5	677437149	2000	https://st60307.ispot.cc/votechs7academygroup/students/photos/1763130321821-xwx9xdhxzh9.jpg	2025-09-17 14:50:17.230764	\N	1	2025-09-17 15:50:17.230764+01	2025-09-17 15:50:17.230764+01	\N
445	25-VOT-NEWA-446	2025-11-14	NEBA RYAN NGWA	M	2012-02-02	BAMENDA 	NEBA	Janue olivia	3	3	670894220	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1763130542110-3v3u6khqsdh.jpg	2025-11-05 12:02:35.731219	\N	1	2025-11-05 13:02:35.731219+01	2025-11-05 13:02:35.731219+01	\N
472	25-VOT-BESS-446	2025-11-14	BERINYUY AFIF MASUD ABASS 	M	2013-04-30	Kumbo	Abass Sahaba 	Abass 	3	3	679872056	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1763130781694-dpv09vshoru.jpg	2025-11-11 11:32:19.941547	\N	1	2025-11-11 12:32:19.941547+01	2025-11-11 12:32:19.941547+01	\N
471	25-VOT-LAUY-446	2025-11-14	LANTUM RAYAN BERINYUY 	M	2013-08-13	Kumbo	Abass Sahaba	Abass 	3	3	679872056	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1763131542940-1yphschzo2p.jpg	2025-11-11 11:30:22.125969	\N	1	2025-11-11 12:30:22.125969+01	2025-11-11 12:30:22.125969+01	\N
491	25-VOT-MBWE-446	2025-11-14	MBAH JOB MBANWE 	M	2006-04-09	Batibo 	Mbah 	Nagie  Violette 	21	3	680842734	\N	https://st60307.ispot.cc/votechs7academygroup/students/photos/1763132354462-iy2unq1jhu.jpg	2025-11-13 10:41:50.434814	\N	1	2025-11-13 11:41:50.434814+01	2025-11-13 11:41:50.434814+01	\N
363	25-VOT-GAMA-326	2025-10-31	GAMBADGA DIANIC GIMA 	M	2009-09-26	BAMENDA 	GAMBADGA	Billa Rita	12	2	677546392	\N	\N	2025-10-31 10:04:05.235741	\N	1	2025-10-31 11:04:05.235741+01	2025-10-31 11:04:05.235741+01	2025-11-15 09:24:51.143606+01
\.


--
-- Data for Name: subject_classifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.subject_classifications (id, class_id, subject_id, classification_type, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: subject_coefficients; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.subject_coefficients (id, class_id, subject_id, coefficient, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: subjects; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.subjects (id, name, code, created_at, description, credits, department, updated_at, coefficient, category, "createdAt", "updatedAt", "deletedAt") FROM stdin;
1	MATHEMATICS	MATHS	2025-09-11 19:28:28.946278	\N	0	\N	2025-09-11 19:28:28.946278	5	general	2025-09-11 20:28:28.936+01	2025-09-11 20:28:28.936+01	\N
2	ENGLISH LANGUAGE	ENG	2025-09-11 19:30:16.665907	\N	0	\N	2025-09-11 19:30:16.665907	5	general	2025-09-11 20:30:16.663+01	2025-09-11 20:30:16.663+01	\N
3	FRENCH LANGUAGE	FREN	2025-09-11 19:31:57.665852	\N	0	\N	2025-09-11 19:31:57.665852	5	general	2025-09-11 20:31:57.664+01	2025-09-11 20:31:57.664+01	\N
4	ECONOMICS	ECONS	2025-09-11 19:34:14.126875	\N	0	\N	2025-09-11 19:34:14.126875	3	general	2025-09-11 20:34:14.125+01	2025-09-11 20:34:14.125+01	\N
5	COMMERCE	COMM	2025-09-11 19:35:25.95782	\N	0	\N	2025-09-11 19:35:25.95782	3	general	2025-09-11 20:35:25.956+01	2025-09-11 20:35:25.956+01	\N
7	ENGINEERING SCIENCE	ENS	2025-09-11 19:43:55.888876	\N	0	\N	2025-09-11 19:43:55.888876	5	professional	2025-09-11 20:43:55.888+01	2025-09-11 20:43:55.888+01	\N
6	ICT	ICT	2025-09-11 19:41:36.380367	\N	0	\N	2025-09-11 19:41:36.380367	5	professional	2025-09-11 20:41:36.372+01	2025-09-11 20:44:33.107+01	\N
8	TECHNICAL DRAWING	TED	2025-09-11 19:46:49.468684	\N	0	\N	2025-09-11 19:46:49.468684	8	general	2025-09-11 20:46:49.467+01	2025-09-11 20:46:49.467+01	\N
9	MARKETING	MKT	2025-09-11 19:48:13.95409	\N	0	\N	2025-09-11 19:48:13.95409	3	general	2025-09-11 20:48:13.948+01	2025-09-11 20:48:13.948+01	\N
10	ACCOUNTING	ACC	2025-09-11 19:49:22.472032	\N	0	\N	2025-09-11 19:49:22.472032	3	general	2025-09-11 20:49:22.47+01	2025-09-11 20:49:22.47+01	\N
11	HOME ECONOMICS	HECS	2025-09-11 19:51:40.937833	\N	0	\N	2025-09-11 19:51:40.937833	3	general	2025-09-11 20:51:40.936+01	2025-09-11 20:51:40.936+01	\N
12	PRACTICAL	PRAC	2025-09-11 20:15:55.227752	\N	0	\N	2025-09-11 20:15:55.227752	10	professional	2025-09-11 21:15:55.225+01	2025-09-11 21:15:55.225+01	\N
13	JOINERY	JOIN	2025-09-12 11:15:37.873148	\N	0	\N	2025-09-12 11:15:37.873148	5	professional	2025-09-12 12:15:37.866+01	2025-09-12 12:15:37.866+01	\N
14	CARPENTRY	CARP	2025-09-12 11:16:44.960303	\N	0	\N	2025-09-12 11:16:44.960303	5	professional	2025-09-12 12:16:44.959+01	2025-09-12 12:16:44.959+01	\N
15	PROFESSIONAL CALCULATION	PROC	2025-09-12 11:19:29.100037	\N	0	\N	2025-09-12 11:19:29.100037	3	professional	2025-09-12 12:19:29.099+01	2025-09-12 12:19:29.099+01	\N
16	MECHANICAL ENGINEERING	MECH	2025-09-12 11:27:22.82457	\N	0	\N	2025-09-12 11:27:22.82457	5	general	2025-09-12 12:27:22.823+01	2025-09-12 12:27:22.823+01	\N
17	ELECTRICAL ENGINEERING	ELECT	2025-09-12 11:28:35.801403	\N	0	\N	2025-09-12 11:28:35.801403	5	general	2025-09-12 12:28:35.8+01	2025-09-12 12:28:35.8+01	\N
18	CIVIL ENGINEERING	CE	2025-09-12 11:29:38.315086	\N	0	\N	2025-09-12 11:29:38.315086	5	general	2025-09-12 12:29:38.314+01	2025-09-12 12:29:38.314+01	\N
19	HEALTH CARE ENGINEERING	HCE	2025-09-12 11:30:54.653243	\N	0	\N	2025-09-12 11:30:54.653243	5	general	2025-09-12 12:30:54.652+01	2025-09-12 12:30:54.652+01	\N
20	TEXTILE ENGINEERING	TE	2025-09-12 11:31:55.853346	\N	0	\N	2025-09-12 11:31:55.853346	5	general	2025-09-12 12:31:55.852+01	2025-09-12 12:31:55.852+01	\N
21	ICT	ICTOR	2025-09-12 11:32:55.159973	\N	0	\N	2025-09-12 11:32:55.159973	3	general	2025-09-12 12:32:55.159+01	2025-09-12 12:32:55.159+01	\N
22	FASHION DESIGN	FAD	2025-09-12 11:41:57.748657	\N	0	\N	2025-09-12 11:41:57.748657	8	professional	2025-09-12 12:41:57.747+01	2025-09-12 12:41:57.747+01	\N
23	TEXTILE TECHNOLOGY	TEXT	2025-09-12 11:43:38.483254	\N	0	\N	2025-09-12 11:43:38.483254	5	professional	2025-09-12 12:43:38.482+01	2025-09-12 12:43:38.482+01	\N
24	WORK ORGANIZATION	WORK	2025-09-12 11:45:46.030359	\N	0	\N	2025-09-12 11:45:46.030359	5	professional	2025-09-12 12:45:46.029+01	2025-09-12 12:45:46.029+01	\N
25	PATTERN DRAFTING	PAD	2025-09-12 11:48:01.76314	\N	0	\N	2025-09-12 11:48:01.76314	5	professional	2025-09-12 12:48:01.761+01	2025-09-12 12:48:01.761+01	\N
26	PHYSICS	PHY	2025-09-12 11:48:55.478131	\N	0	\N	2025-09-12 11:48:55.478131	5	professional	2025-09-12 12:48:55.477+01	2025-09-12 12:48:55.477+01	\N
27	CHEMISTRY	CHEM	2025-09-12 11:49:47.818757	\N	0	\N	2025-09-12 11:49:47.818757	5	professional	2025-09-12 12:49:47.818+01	2025-09-12 12:49:47.818+01	\N
28	BIOLOGY	BIo	2025-09-12 11:50:38.827998	\N	0	\N	2025-09-12 11:50:38.827998	5	professional	2025-09-12 12:50:38.826+01	2025-09-12 12:50:38.826+01	\N
29	PUBLIC HEALTH	PUH	2025-09-12 11:52:41.31581	\N	0	\N	2025-09-12 11:52:41.31581	3	professional	2025-09-12 12:52:41.315+01	2025-09-12 12:52:41.315+01	\N
30	HUMAN BIOLOGY	HBIO	2025-09-12 11:54:30.798233	\N	0	\N	2025-09-12 11:54:30.798233	3	professional	2025-09-12 12:54:30.797+01	2025-09-12 12:57:23.313+01	\N
31	ENGINEERING DRAWING	END	2025-09-12 12:00:20.578074	\N	0	\N	2025-09-12 12:00:20.578074	8	professional	2025-09-12 13:00:20.576+01	2025-09-12 13:00:20.576+01	\N
32	ELECTRICAL MACHINE	ELM	2025-09-12 12:03:05.023719	\N	0	\N	2025-09-12 12:03:05.023719	5	professional	2025-09-12 13:03:05.023+01	2025-09-12 13:03:05.023+01	\N
34	ELECTRICAL CKTS	ELC	2025-09-12 12:06:25.344697	\N	0	\N	2025-09-12 12:06:25.344697	5	professional	2025-09-12 13:06:25.344+01	2025-09-12 13:06:25.344+01	\N
35	TEST AND MEASUREMENTS	TSM	2025-09-12 12:08:07.191085	\N	0	\N	2025-09-12 12:08:07.191085	5	professional	2025-09-12 13:08:07.19+01	2025-09-12 13:08:07.19+01	\N
36	DIAGRAMS	DIG	2025-09-12 12:09:22.766682	\N	0	\N	2025-09-12 12:09:22.766682	5	professional	2025-09-12 13:09:22.765+01	2025-09-12 13:09:22.765+01	\N
37	SURVEYING SOILS AND MATERIALS	SURV	2025-09-12 12:11:57.192697	\N	0	\N	2025-09-12 12:11:57.192697	5	professional	2025-09-12 13:11:57.191+01	2025-09-12 13:11:57.191+01	\N
38	CONSTRUCTION PROCESSES	CONS	2025-09-12 12:13:15.777431	\N	0	\N	2025-09-12 12:13:15.777431	5	professional	2025-09-12 13:13:15.776+01	2025-09-12 13:13:15.776+01	\N
39	MECHANICAL DRAWING	MED	2025-09-12 12:29:31.852215	\N	0	\N	2025-09-12 12:29:31.852215	8	professional	2025-09-12 13:29:31.851+01	2025-09-12 13:29:31.851+01	\N
40	MECHANICAL TECHNOLOGY	MET	2025-09-12 12:30:58.047817	\N	0	\N	2025-09-12 12:30:58.047817	5	professional	2025-09-12 13:30:58.047+01	2025-09-12 13:30:58.047+01	\N
41	ELECT AND ELECTRONICS	ELEC	2025-09-12 12:33:07.695375	\N	0	\N	2025-09-12 12:33:07.695375	5	professional	2025-09-12 13:33:07.694+01	2025-09-12 13:33:07.694+01	\N
42	WORKSHOP PROCESS AND MATERIALS	WSP	2025-09-12 12:35:47.477792	\N	0	\N	2025-09-12 12:35:47.477792	5	professional	2025-09-12 13:35:47.477+01	2025-09-12 13:35:47.477+01	\N
43	SHEET METAL WORK	SMW	2025-09-12 12:39:43.521082	\N	0	\N	2025-09-12 12:39:43.521082	5	professional	2025-09-12 13:39:43.519+01	2025-09-12 13:39:43.519+01	\N
44	PROFESSIONAL ENGLISH	PENG	2025-09-23 03:04:07.985465	\N	0	\N	2025-09-23 03:04:07.985465	5	general	2025-09-23 04:04:07.981+01	2025-09-23 04:04:07.981+01	\N
33	ELECTRICAL TECHNOLOGY	ECT	2025-09-12 12:04:37.672004	\N	0	\N	2025-09-12 12:04:37.672004	5	professional	2025-09-12 13:04:37.671+01	2025-10-15 13:51:40.669+01	\N
45	Sheet Metal Construction Drawing	SMCD	2025-11-11 15:27:08.397803	\N	0	\N	2025-11-11 15:27:08.397803	5	professional	2025-11-11 16:27:08.387+01	2025-11-11 16:27:08.387+01	\N
46	Test Subject	TSTSBJ	2025-11-14 03:02:05.586627	\N	0	\N	2025-11-14 03:02:05.586627	5	general	2025-11-14 04:02:05.582+01	2025-11-14 04:02:05.582+01	\N
\.


--
-- Data for Name: system_mode; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.system_mode (mode) FROM stdin;
online
\.


--
-- Data for Name: teacher_assignments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.teacher_assignments (id, teacher_id, class_id, subject_id, periods_per_week, created_at, updated_at) FROM stdin;
1	25	6	20	1	2025-09-15 21:05:15.55171	2025-09-15 21:05:16.6623
3	24	6	1	2	2025-09-15 21:35:46.065354	2025-09-15 21:46:44.607356
4	18	6	2	2	2025-09-15 21:35:46.065354	2025-09-15 21:46:44.607356
5	14	6	3	2	2025-09-15 21:35:46.065354	2025-09-15 21:46:44.607356
6	13	6	4	1	2025-09-15 21:35:46.065354	2025-09-15 21:46:44.607356
7	9	6	5	1	2025-09-15 21:35:46.065354	2025-09-15 21:46:44.607356
8	7	6	7	2	2025-09-15 21:35:46.065354	2025-09-15 21:46:44.607356
9	9	6	9	1	2025-09-15 21:35:46.065354	2025-09-15 21:46:44.607356
10	9	6	10	1	2025-09-15 21:35:46.065354	2025-09-15 21:46:44.607356
11	12	6	13	1	2025-09-15 21:35:46.065354	2025-09-15 21:46:44.607356
12	12	6	14	1	2025-09-15 21:35:46.065354	2025-09-15 21:46:44.607356
13	24	6	21	2	2025-09-15 21:35:46.065354	2025-09-15 21:46:44.607356
14	25	6	22	2	2025-09-15 21:35:46.065354	2025-09-15 21:46:44.607356
15	25	6	24	2	2025-09-15 21:35:46.065354	2025-09-15 21:46:44.607356
16	25	6	25	2	2025-09-15 21:35:46.065354	2025-09-15 21:46:44.607356
17	7	6	26	2	2025-09-15 21:35:46.065354	2025-09-15 21:46:44.607356
18	22	6	27	2	2025-09-15 21:35:46.065354	2025-09-15 21:46:44.607356
19	15	6	28	3	2025-09-15 21:35:46.065354	2025-09-15 21:46:44.607356
20	15	6	29	2	2025-09-15 21:35:46.065354	2025-09-15 21:46:44.607356
21	26	6	31	2	2025-09-15 21:35:46.065354	2025-09-15 21:46:44.607356
23	26	6	33	2	2025-09-15 21:35:46.065354	2025-09-15 21:46:44.607356
26	26	6	36	2	2025-09-15 21:35:46.065354	2025-09-15 21:46:44.607356
27	20	6	37	4	2025-09-15 21:35:46.065354	2025-09-15 21:46:44.607356
28	26	6	39	2	2025-09-15 21:35:46.065354	2025-09-15 21:46:44.607356
29	19	6	40	2	2025-09-15 21:35:46.065354	2025-09-15 21:46:44.607356
30	17	6	42	2	2025-09-15 21:35:46.065354	2025-09-15 21:46:44.607356
31	17	6	43	2	2025-09-15 21:35:46.065354	2025-09-15 21:46:44.607356
\.


--
-- Data for Name: teacher_discipline_cases; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.teacher_discipline_cases (id, teacher_id, class_id, case_description, status, recorded_by, recorded_at, resolved_at, resolved_by, resolution_notes, case_name, description, created_by, created_at, updated_at) FROM stdin;
1	37	\N	- General sluggishness from teachers , she thinks teachers should be more proactive and smart\n-The need for more transparency in the functioning of the school\n- The displacement of some offices is not quite strategic to her and she thinks the Dms office should be right beside the secretariat	not resolved	41	2025-10-22 08:12:14.059538	\N	\N	\N	\N	\N	\N	2025-10-22 08:12:14.059538	2025-10-22 08:12:14.059538
\.


--
-- Data for Name: teachers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.teachers (id, full_name, sex, id_card, dob, pob, subjects, classes, contact, created_at, status, user_id, certificate_url, cv_url, photo_url) FROM stdin;
\.


--
-- Data for Name: terms; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.terms (id, name, order_number, academic_year_id, "createdAt", "updatedAt", "deletedAt") FROM stdin;
1	First Term	1	1	2025-09-11 12:47:08.919+01	2025-09-11 12:47:08.919+01	\N
2	Second Term	2	1	2025-09-11 12:47:08.919+01	2025-09-11 12:47:08.919+01	\N
3	Third Term	3	1	2025-09-11 12:47:08.919+01	2025-09-11 12:47:08.919+01	\N
\.


--
-- Data for Name: timetable_configs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.timetable_configs (id, config, created_at, updated_at) FROM stdin;
2	{"days": {"Fri": true, "Mon": false, "Sat": false, "Thu": true, "Tue": true, "Wed": true}, "endTime": "16:00", "startTime": "08:00", "classPlans": {"6": {"1": {"preferred": [1], "teacherIds": ["24"], "weeklyPeriods": 2}, "2": {"preferred": [3, 4], "teacherIds": ["18"], "weeklyPeriods": 2}, "3": {"preferred": [4, 7], "teacherIds": ["14"], "weeklyPeriods": 2}, "4": {"preferred": [2], "teacherIds": ["13"], "weeklyPeriods": 1}, "5": {"preferred": [3], "teacherIds": ["9"], "weeklyPeriods": 1}, "6": {"preferred": [], "teacherIds": [], "weeklyPeriods": 0}, "7": {"preferred": [1, 2], "teacherIds": ["7"], "weeklyPeriods": 2}, "8": {"preferred": [6, 7], "teacherIds": [], "weeklyPeriods": 2}, "9": {"preferred": [7], "teacherIds": ["9"], "weeklyPeriods": 1}, "10": {"preferred": [6], "teacherIds": ["9"], "weeklyPeriods": 1}, "11": {"preferred": [7], "teacherIds": [], "weeklyPeriods": 1}, "12": {"preferred": [], "teacherIds": [], "weeklyPeriods": 0}, "13": {"preferred": [4], "teacherIds": ["12"], "weeklyPeriods": 1}, "14": {"preferred": [3], "teacherIds": ["12"], "weeklyPeriods": 1}, "15": {"preferred": [1], "teacherIds": [], "weeklyPeriods": 1}, "16": {"preferred": [], "teacherIds": [], "weeklyPeriods": 0}, "17": {"preferred": [], "teacherIds": [], "weeklyPeriods": 0}, "18": {"preferred": [], "teacherIds": [], "weeklyPeriods": 0}, "19": {"preferred": [], "teacherIds": [], "weeklyPeriods": 0}, "20": {"preferred": [], "teacherIds": [], "weeklyPeriods": 0}, "21": {"preferred": [2, 6], "teacherIds": ["24"], "weeklyPeriods": 2}, "22": {"preferred": [3, 4], "teacherIds": ["25"], "weeklyPeriods": 2}, "23": {"preferred": [1], "teacherIds": [], "weeklyPeriods": 1}, "24": {"preferred": [3, 4], "teacherIds": ["25"], "weeklyPeriods": 2}, "25": {"preferred": [2, 3, 4], "teacherIds": ["25"], "weeklyPeriods": 2}, "26": {"preferred": [1], "teacherIds": ["7"], "weeklyPeriods": 2}, "27": {"preferred": [4, 6, 7], "teacherIds": ["22"], "weeklyPeriods": 2}, "28": {"preferred": [1, 2, 3], "teacherIds": ["15"], "weeklyPeriods": 3}, "29": {"preferred": [3, 4, 6, 7], "teacherIds": ["15"], "weeklyPeriods": 2}, "30": {"preferred": [], "teacherIds": [], "weeklyPeriods": 0}, "31": {"preferred": [6, 7], "teacherIds": ["26"], "weeklyPeriods": 2}, "32": {"preferred": [1, 6], "teacherIds": ["11"], "weeklyPeriods": 2}, "33": {"preferred": [1, 2, 3], "teacherIds": ["26"], "weeklyPeriods": 2}, "34": {"preferred": [3, 4], "teacherIds": ["11"], "weeklyPeriods": 2}, "35": {"preferred": [3], "teacherIds": ["11"], "weeklyPeriods": 2}, "36": {"preferred": [4], "teacherIds": ["26"], "weeklyPeriods": 2}, "37": {"preferred": [3, 4, 6, 7], "teacherIds": ["20"], "weeklyPeriods": 4}, "38": {"preferred": [2], "teacherIds": [], "weeklyPeriods": 1}, "39": {"preferred": [6, 7], "teacherIds": ["26"], "weeklyPeriods": 2}, "40": {"preferred": [3, 4], "teacherIds": ["19"], "weeklyPeriods": 2}, "42": {"preferred": [3, 4], "teacherIds": ["17"], "weeklyPeriods": 2}, "43": {"preferred": [1, 2], "teacherIds": ["17"], "weeklyPeriods": 2}}}, "breakIndexes": [5], "periodsPerDay": 8, "breakDurationMin": 30, "selectedClassIds": [6], "periodDurationMin": 60}	2025-09-15 21:46:44.002965	2025-09-15 21:46:44.002965
\.


--
-- Data for Name: timetables; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.timetables (id, class_id, data, created_at, updated_at) FROM stdin;
2	6	{"grid": [[{"subjectId": 1, "teacherId": "24", "subjectName": "MATHEMATICS", "teacherName": "Emile Awah"}, {"subjectId": 1, "teacherId": "24", "subjectName": "MATHEMATICS", "teacherName": "Emile Awah"}, {"subjectId": 1, "teacherId": "24", "subjectName": "MATHEMATICS", "teacherName": "Emile Awah"}, {"subjectId": 2, "teacherId": "18", "subjectName": "ENGLISH LANGUAGE", "teacherName": "Manka'a Carine Awah"}, {"isBreak": true}, {"subjectId": 2, "teacherId": "18", "subjectName": "ENGLISH LANGUAGE", "teacherName": "Manka'a Carine Awah"}, {"subjectId": 2, "teacherId": "18", "subjectName": "ENGLISH LANGUAGE", "teacherName": "Manka'a Carine Awah"}, {"subjectId": 3, "teacherId": "14", "subjectName": "FRENCH LANGUAGE", "teacherName": "Brica Ngue Fon"}], [{"subjectId": 7, "teacherId": "7", "subjectName": "ENGINEERING SCIENCE", "teacherName": "Ndofor Nwana Davidson Sama"}, {"subjectId": 4, "teacherId": "13", "subjectName": "ECONOMICS", "teacherName": "Mafain Alice Bih"}, {"subjectId": 5, "teacherId": "9", "subjectName": "COMMERCE", "teacherName": "Chem Sandra Ntala"}, {"subjectId": 3, "teacherId": "14", "subjectName": "FRENCH LANGUAGE", "teacherName": "Brica Ngue Fon"}, {"isBreak": true}, {"subjectId": 7, "teacherId": "7", "subjectName": "ENGINEERING SCIENCE", "teacherName": "Ndofor Nwana Davidson Sama"}, {"subjectId": 3, "teacherId": "14", "subjectName": "FRENCH LANGUAGE", "teacherName": "Brica Ngue Fon"}, {"subjectId": 7, "teacherId": "7", "subjectName": "ENGINEERING SCIENCE", "teacherName": "Ndofor Nwana Davidson Sama"}], [{"subjectId": 21, "teacherId": "24", "subjectName": "ICT", "teacherName": "Emile Awah"}, {"subjectId": 21, "teacherId": "24", "subjectName": "ICT", "teacherName": "Emile Awah"}, {"subjectId": 14, "teacherId": "12", "subjectName": "CARPENTRY", "teacherName": "Mbaliko Prosper Khan"}, {"subjectId": 13, "teacherId": "12", "subjectName": "JOINERY", "teacherName": "Mbaliko Prosper Khan"}, {"isBreak": true}, {"subjectId": 10, "teacherId": "9", "subjectName": "ACCOUNTING", "teacherName": "Chem Sandra Ntala"}, {"subjectId": 9, "teacherId": "9", "subjectName": "MARKETING", "teacherName": "Chem Sandra Ntala"}, {"subjectId": 21, "teacherId": "24", "subjectName": "ICT", "teacherName": "Emile Awah"}], [{"subjectId": 22, "teacherId": "25", "subjectName": "FASHION DESIGN", "teacherName": "ABU ROSE MENNYI"}, {"subjectId": 24, "teacherId": "25", "subjectName": "WORK ORGANIZATION", "teacherName": "ABU ROSE MENNYI"}, {"subjectId": 22, "teacherId": "25", "subjectName": "FASHION DESIGN", "teacherName": "ABU ROSE MENNYI"}, {"subjectId": 22, "teacherId": "25", "subjectName": "FASHION DESIGN", "teacherName": "ABU ROSE MENNYI"}, {"isBreak": true}, {"subjectId": 24, "teacherId": "25", "subjectName": "WORK ORGANIZATION", "teacherName": "ABU ROSE MENNYI"}, {"subjectId": 24, "teacherId": "25", "subjectName": "WORK ORGANIZATION", "teacherName": "ABU ROSE MENNYI"}, {"subjectId": 25, "teacherId": "25", "subjectName": "PATTERN DRAFTING", "teacherName": "ABU ROSE MENNYI"}]]}	2025-09-15 21:44:38.043352	2025-09-15 21:44:47.806642
\.


--
-- Data for Name: user_activities; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_activities (id, user_id, activity_type, activity_description, entity_type, entity_id, entity_name, ip_address, user_agent, created_at) FROM stdin;
124	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	2025-09-15 10:14:08.768161
125	4	delete	Deleted user: Ramadane	user	27	Ramadane	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	2025-09-15 10:14:23.423801
127	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	2025-09-15 10:47:38.320095
131	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	2025-09-15 10:57:28.599869
132	4	delete	Deleted user: Principal 	user	28	Principal 	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	2025-09-15 10:57:48.299478
134	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	2025-09-15 11:04:01.820225
135	4	update	Updated user: Thomas 	user	31	Thomas 	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	2025-09-15 11:04:48.61696
136	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	2025-09-15 11:05:36.376613
137	4	delete	Deleted user: Thomas 	user	31	Thomas 	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	2025-09-15 11:05:47.322061
138	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	2025-09-15 11:19:12.112535
140	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	2025-09-15 11:24:28.507367
142	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	2025-09-15 11:31:59.451899
143	3	update	Updated user: Thomas 	user	32	Thomas 	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	2025-09-15 11:33:00.220733
144	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	2025-09-15 11:34:24.275033
145	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	2025-09-15 11:42:24.027443
146	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	2025-09-15 11:45:08.67467
147	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	2025-09-15 11:48:52.667682
148	4	delete	Deleted user: Thomas 	user	32	Thomas 	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	2025-09-15 11:49:33.890071
149	4	delete	Deleted user: Ramadane	user	30	Ramadane	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	2025-09-15 11:49:39.32074
150	33	create	Created user: Thomas	user	33	Thomas	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	2025-09-15 11:53:11.502602
151	33	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	2025-09-15 11:57:11.433496
152	33	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	2025-09-15 11:58:11.166895
153	33	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (iPhone; CPU iPhone OS 18_6_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/138.0.7204.156 Mobile/15E148 Safari/604.1	2025-09-15 12:01:23.816058
154	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	2025-09-15 12:03:59.245816
155	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	2025-09-15 12:04:15.593444
156	33	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (iPhone; CPU iPhone OS 18_6_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/138.0.7204.156 Mobile/15E148 Safari/604.1	2025-09-15 12:04:23.229523
157	34	create	Created user: Ramadane	user	34	Ramadane	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	2025-09-15 12:06:59.863749
158	34	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	2025-09-15 12:07:44.332865
159	7	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-15 16:38:56.281552
160	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	2025-09-15 18:37:09.330387
161	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	2025-09-15 18:38:53.881522
162	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	2025-09-15 18:48:05.920938
163	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	2025-09-15 18:58:50.502922
164	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	2025-09-15 19:04:24.483332
165	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	2025-09-15 19:30:06.382708
166	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	2025-09-15 19:31:56.74739
167	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	2025-09-15 19:40:25.039979
168	33	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-09-15 20:52:18.824788
169	33	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-09-15 21:52:17.894187
170	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	2025-09-16 05:18:44.003937
171	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	2025-09-16 05:28:33.617596
172	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	2025-09-16 08:23:27.181909
173	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	2025-09-16 08:39:52.065869
174	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	2025-09-16 08:51:57.693701
175	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	2025-09-16 09:04:01.246699
176	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	2025-09-16 09:04:59.591609
177	1	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-16 10:17:27.642961
178	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	2025-09-16 11:11:21.458994
179	6	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 11:15:20.756996
180	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	2025-09-16 11:31:36.021406
181	6	create	Fee payment: Registration - $20000	fees	1	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 11:38:14.366842
182	6	create	Fee payment: Registration - $20000	fees	2	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 11:39:57.058794
183	6	create	Fee payment: Tuition - $40000	fees	2	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 11:41:15.923928
184	6	create	Fee payment: Registration - $20000	fees	3	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 11:55:20.074131
185	6	create	Fee payment: Tuition - $60000	fees	3	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 11:55:53.044904
186	6	create	Fee payment: Registration - $20000	fees	4	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 11:56:40.940259
187	6	create	Fee payment: Registration - $20000	fees	5	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 11:57:23.753596
188	6	create	Fee payment: Tuition - $25000	fees	5	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 11:57:50.102507
189	6	create	Fee payment: Registration - $20000	fees	6	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 11:58:27.646546
190	6	create	Fee payment: Registration - $20000	fees	7	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 11:59:38.423618
191	6	create	Fee payment: Tuition - $30000	fees	7	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 12:00:10.38283
192	6	create	Fee payment: Registration - $20000	fees	8	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 12:01:12.893576
193	6	create	Fee payment: Registration - $20000	fees	9	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 12:01:50.384621
194	6	create	Fee payment: Registration - $20000	fees	10	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 12:02:36.302869
195	6	create	Fee payment: Registration - $20000	fees	11	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 12:03:08.272589
196	6	create	Fee payment: Tuition - $60000	fees	11	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 12:03:43.298527
197	6	create	Fee payment: Tuition - $10000	fees	2	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 12:06:16.94272
198	6	update	Reconciled Tuition to 40000	fees	2	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 12:07:48.410878
199	6	update	Reconciled Tuition to 40000	fees	2	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 12:07:51.908036
200	6	create	Fee payment: Tuition - $10000	fees	2	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 12:09:26.529057
201	6	update	Reconciled Tuition to 40000	fees	2	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 12:11:46.524242
202	6	update	Reconciled Tuition to 40000	fees	2	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 12:11:46.638279
203	6	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 12:22:28.800269
204	6	create	Fee payment: Registration - $20000	fees	12	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 12:23:17.93593
205	6	create	Fee payment: Tuition - $30000	fees	12	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 12:24:12.991337
206	21	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-16 12:26:40.534335
207	6	create	Fee payment: Tuition - $10000	fees	12	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 12:26:42.78858
208	6	update	Reconciled Tuition to 30000	fees	12	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 12:32:24.889049
209	6	update	Reconciled Tuition to 30000	fees	12	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 12:32:25.563234
210	6	create	Fee payment: Registration - $20000	fees	13	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 12:35:09.238884
211	6	create	Fee payment: Registration - $20000	fees	14	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 12:37:04.041606
212	6	create	Fee payment: Registration - $20000	fees	15	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 12:41:22.261918
213	6	create	Fee payment: Registration - $20000	fees	16	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 12:48:31.361769
214	6	create	Fee payment: Tuition - $30000	fees	16	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 12:49:13.79771
215	6	create	Fee payment: Registration - $20000	fees	17	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 12:49:48.967881
216	6	create	Fee payment: Tuition - $60000	fees	17	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 12:50:34.976817
217	6	create	Fee payment: Registration - $20000	fees	18	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 12:51:45.340612
218	6	create	Fee payment: Registration - $20000	fees	19	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 12:54:48.85759
219	6	create	Fee payment: Tuition - $30000	fees	19	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 12:55:42.991755
220	6	create	Fee payment: Registration - $20000	fees	20	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 12:56:57.570697
221	6	create	Fee payment: Tuition - $60000	fees	20	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 12:57:41.581091
222	6	create	Fee payment: Registration - $20000	fees	21	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 12:58:36.622793
223	6	create	Fee payment: Registration - $20000	fees	23	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 13:00:13.244518
224	6	create	Fee payment: Registration - $20000	fees	22	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 13:01:20.524162
225	6	create	Fee payment: Tuition - $40000	fees	22	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 13:02:19.082748
226	6	create	Fee payment: Registration - $20000	fees	24	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 13:03:00.623573
227	6	create	Fee payment: Tuition - $80000	fees	24	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 13:03:46.541752
228	6	create	Fee payment: Registration - $20000	fees	25	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 13:04:31.710931
229	6	create	Fee payment: Tuition - $40000	fees	25	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 13:05:18.238935
230	6	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 14:58:43.339834
231	6	create	Fee payment: Registration - $20000	fees	26	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 15:00:04.826689
232	6	create	Fee payment: Tuition - $30000	fees	26	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 15:01:02.872964
233	6	create	Fee payment: Registration - $10000	fees	27	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 15:02:11.179839
234	6	create	Fee payment: Registration - $10000	fees	28	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 15:03:58.984113
235	6	create	Fee payment: Registration - $10000	fees	29	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 15:05:02.774642
236	6	create	Fee payment: Registration - $20000	fees	30	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 15:08:49.276349
237	6	create	Fee payment: Tuition - $20000	fees	30	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 15:09:51.79869
238	6	create	Fee payment: Registration - $20000	fees	32	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 15:11:44.226526
239	6	create	Fee payment: Tuition - $40000	fees	32	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 15:12:40.085783
240	6	create	Fee payment: Registration - $20000	fees	33	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 15:14:19.535042
241	6	create	Fee payment: Tuition - $60000	fees	33	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 15:15:35.489707
242	6	create	Fee payment: Registration - $20000	fees	35	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 15:16:46.320833
243	6	create	Fee payment: Registration - $20000	fees	34	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 15:17:59.313743
244	6	create	Fee payment: Registration - $20000	fees	31	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 15:20:58.262056
245	6	create	Fee payment: Registration - $20000	fees	37	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 15:22:59.838349
246	6	create	Fee payment: Tuition - $30000	fees	37	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 15:24:09.960684
247	6	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 16:28:20.817096
248	7	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-16 16:30:23.254345
249	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	2025-09-16 16:35:11.031555
250	7	create	Fee payment: Registration - $20000	fees	39	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-16 16:38:25.59351
251	23	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (iPhone; CPU iPhone OS 17_6_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.6 Mobile/15E148 Safari/604.1	2025-09-16 16:39:19.335647
252	6	update	Reconciled Registration to 0	fees	39	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 16:43:15.679088
253	6	update	Reconciled Registration to 0	fees	39	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 16:43:16.456612
254	6	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 16:51:30.353687
255	21	login	User logged in successfully	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-09-16 17:48:16.033104
256	21	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-16 17:48:51.468971
257	21	login	User logged in successfully	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-09-16 18:10:46.187575
258	7	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-16 19:03:52.81963
259	7	login	User logged in successfully	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-09-16 19:21:33.281049
260	21	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-16 20:03:01.868798
261	6	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 20:26:40.146835
262	6	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 20:32:38.451519
263	6	create	Fee payment: Registration - $20000	fees	39	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 20:34:54.831621
264	6	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 20:38:50.960309
265	6	update	Reconciled Registration to 0	fees	39	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 20:39:48.88159
266	7	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 20:45:23.85426
267	6	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 20:48:25.266657
268	6	create	Fee payment: Registration - $20000	fees	36	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 21:04:49.226343
269	6	create	Fee payment: Tuition - $30000	fees	36	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 21:05:26.553729
270	6	create	Fee payment: Registration - $20000	fees	50	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 21:06:10.964762
271	6	create	Fee payment: Registration - $20000	fees	51	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 21:06:53.590337
272	6	create	Fee payment: Registration - $20000	fees	43	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 21:07:40.767963
273	6	create	Fee payment: Tuition - $40000	fees	43	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 21:08:21.604677
274	6	create	Fee payment: Registration - $20000	fees	42	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 21:09:00.578687
275	6	create	Fee payment: Tuition - $40000	fees	42	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 21:09:45.520525
276	6	create	Fee payment: Registration - $20000	fees	41	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 21:10:30.380587
277	6	create	Fee payment: Tuition - $40000	fees	41	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 21:11:02.859865
278	6	create	Fee payment: Registration - $20000	fees	44	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 21:12:06.224821
279	6	create	Fee payment: Registration - $20000	fees	40	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 21:12:57.838285
280	6	create	Fee payment: Tuition - $40000	fees	40	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 21:13:32.753027
281	6	create	Fee payment: Registration - $20000	fees	38	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 21:14:36.04495
282	6	create	Fee payment: Registration - $20000	fees	39	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 21:15:07.344031
283	6	create	Fee payment: Registration - $20000	fees	45	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 21:15:51.971585
284	6	create	Fee payment: Tuition - $30000	fees	45	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 21:16:36.795665
285	6	create	Fee payment: Registration - $20000	fees	46	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 21:17:14.45561
286	6	create	Fee payment: Tuition - $30000	fees	46	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 21:18:00.94185
287	6	create	Fee payment: Registration - $20000	fees	48	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 21:18:30.428514
288	6	create	Fee payment: Tuition - $30000	fees	48	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 21:19:02.064609
289	6	create	Fee payment: Registration - $20000	fees	47	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 21:19:58.387084
290	6	create	Fee payment: Tuition - $20000	fees	47	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 21:20:33.201735
291	6	create	Fee payment: Registration - $20000	fees	49	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 21:21:26.037774
292	6	create	Fee payment: Tuition - $30000	fees	49	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 21:21:54.038897
293	6	create	Fee payment: Registration - $20000	fees	53	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 21:22:53.905568
294	6	create	Fee payment: Tuition - $40000	fees	53	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 21:23:34.59581
295	6	create	Fee payment: Registration - $20000	fees	54	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 21:24:09.804447
296	6	create	Fee payment: Tuition - $80000	fees	54	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 21:24:33.633478
297	6	create	Fee payment: Registration - $20000	fees	55	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 21:25:04.203796
298	6	create	Fee payment: Tuition - $50000	fees	55	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 21:25:31.073112
299	6	create	Fee payment: Registration - $20000	fees	56	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 21:26:05.993686
300	6	create	Fee payment: Tuition - $30000	fees	56	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 21:26:30.475334
301	6	create	Fee payment: Registration - $20000	fees	57	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 21:27:06.716573
302	6	create	Fee payment: Registration - $20000	fees	58	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 21:27:45.273806
303	6	create	Fee payment: Registration - $20000	fees	59	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 21:28:19.930918
304	6	create	Fee payment: Tuition - $10000	fees	59	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 21:28:59.100743
305	6	create	Fee payment: Registration - $20000	fees	60	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 21:29:33.2566
306	6	create	Fee payment: Tuition - $50000	fees	60	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 21:29:59.883708
307	6	create	Fee payment: Registration - $20000	fees	61	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 21:30:38.345939
308	6	create	Fee payment: Registration - $20000	fees	62	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 21:31:14.825532
309	6	create	Fee payment: Tuition - $30000	fees	62	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 21:31:44.976364
310	6	create	Fee payment: Registration - $20000	fees	52	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 21:32:18.220403
311	6	create	Fee payment: Tuition - $30000	fees	52	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-16 21:32:45.565674
312	7	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-16 23:05:54.088502
313	1	update	Password reset	user	1	default	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-17 01:36:01.852333
314	1	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-17 01:36:27.248123
315	34	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1	2025-09-17 02:58:05.763195
316	7	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-17 08:07:49.855532
317	7	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-17 08:20:39.566598
318	7	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-17 08:29:09.15437
319	7	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-17 08:37:54.029351
320	7	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-17 09:12:44.921243
321	6	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-17 11:03:24.017247
322	6	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-17 14:17:06.46538
323	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	2025-09-17 14:18:50.002702
324	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	2025-09-17 15:53:01.304712
325	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	2025-09-17 19:11:08.258133
326	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	2025-09-17 19:19:10.808116
327	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	2025-09-17 19:36:36.218863
328	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	2025-09-17 19:55:08.662196
329	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	2025-09-17 19:59:39.099691
330	9	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-09-17 20:07:15.716239
331	7	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-18 07:35:12.011311
332	33	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-09-18 09:42:53.165873
333	7	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-18 10:45:01.052397
334	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	2025-09-18 19:49:07.674431
335	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	2025-09-19 10:56:59.447709
336	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	2025-09-19 11:19:32.313837
337	6	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-19 12:11:28.361019
338	6	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-19 12:11:40.837728
339	6	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-19 12:11:57.971237
340	6	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-19 12:26:38.131483
341	6	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-20 07:12:05.550381
342	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	2025-09-20 07:32:01.150034
343	25	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-20 08:00:21.279848
344	25	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-20 08:01:10.066624
345	25	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-20 08:02:02.611341
346	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	2025-09-20 09:23:24.23765
347	4	delete	Deleted user: Collins 	user	11	Collins 	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	2025-09-20 09:23:52.735037
348	35	create	Created user: COLLINS	user	35	COLLINS	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	2025-09-20 09:26:32.570238
349	35	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-20 09:27:16.336364
350	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	2025-09-20 10:07:23.35838
351	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	2025-09-20 11:07:22.447858
352	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	2025-09-20 11:09:05.383624
353	6	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-09-20 11:30:58.421567
354	6	create	Fee payment: Registration - $20000	fees	63	Registration	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-09-20 11:46:06.721275
355	6	create	Fee payment: Tuition - $20000	fees	63	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-09-20 11:47:32.272807
356	6	create	Fee payment: Registration - $20000	fees	64	Registration	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-09-20 11:49:27.216201
357	6	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-20 11:52:49.67977
358	6	create	Fee payment: Tuition - $40000	fees	64	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-20 11:54:15.101148
359	6	create	Fee payment: Registration - $20000	fees	65	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-20 11:55:03.788698
360	6	create	Fee payment: Tuition - $30000	fees	65	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-20 11:55:37.14894
361	6	create	Fee payment: Registration - $20000	fees	66	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-20 11:56:06.911799
362	6	create	Fee payment: Tuition - $20000	fees	66	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-20 11:56:36.995234
363	6	create	Fee payment: Registration - $20000	fees	67	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-20 11:57:04.200919
364	6	create	Fee payment: Tuition - $40000	fees	67	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-20 11:57:34.909748
365	6	create	Fee payment: Registration - $20000	fees	68	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-20 11:58:03.445237
366	6	create	Fee payment: Tuition - $30000	fees	68	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-20 11:58:33.882855
367	6	create	Fee payment: Registration - $20000	fees	69	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-20 11:59:04.288771
368	6	create	Fee payment: Tuition - $30000	fees	69	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-20 11:59:39.015011
369	6	create	Fee payment: Registration - $20000	fees	70	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-20 12:00:21.630712
370	6	create	Fee payment: Tuition - $40000	fees	70	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-20 12:00:52.509842
371	6	update	Reconciled Tuition to 20000	fees	70	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-20 12:03:29.203693
372	6	create	Fee payment: Registration - $20000	fees	71	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-20 12:04:13.906394
373	6	create	Fee payment: Tuition - $40000	fees	71	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-20 12:04:46.741024
374	6	create	Fee payment: Registration - $20000	fees	72	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-20 12:05:14.235553
375	6	create	Fee payment: Registration - $20000	fees	73	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-20 12:05:52.370674
376	6	create	Fee payment: Tuition - $40000	fees	73	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-20 12:06:20.633077
377	6	create	Fee payment: Registration - $20000	fees	75	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-20 12:06:49.334143
378	6	create	Fee payment: Registration - $20000	fees	74	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-20 12:07:22.132182
379	6	create	Fee payment: Tuition - $40000	fees	74	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-20 12:08:00.497583
380	6	create	Fee payment: Registration - $20000	fees	76	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-20 12:08:32.570873
381	6	create	Fee payment: Tuition - $20000	fees	76	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-20 12:09:07.666384
382	6	create	Fee payment: Registration - $20000	fees	77	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-20 12:09:45.205745
383	6	create	Fee payment: Registration - $20000	fees	78	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-20 12:10:12.98783
384	6	create	Fee payment: Tuition - $60000	fees	78	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-20 12:11:06.806839
385	6	create	Fee payment: Registration - $20000	fees	79	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-20 12:11:42.740704
386	6	create	Fee payment: Tuition - $60000	fees	79	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-20 12:12:23.519753
387	6	create	Fee payment: Registration - $20000	fees	82	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-20 12:15:50.964767
388	6	create	Fee payment: Tuition - $30000	fees	82	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-20 12:16:28.657685
389	6	create	Fee payment: Registration - $20000	fees	80	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-20 12:17:08.597559
390	6	create	Fee payment: Registration - $20000	fees	81	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-20 12:17:44.150041
391	6	create	Fee payment: Tuition - $40000	fees	81	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-20 12:18:30.006607
392	6	create	Fee payment: Registration - $23000	fees	84	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-20 12:20:25.5272
393	6	create	Fee payment: Tuition - $27000	fees	84	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-20 12:22:22.925291
394	6	create	Fee payment: Registration - $23000	fees	85	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-20 12:23:15.21527
395	6	create	Fee payment: Tuition - $17000	fees	85	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-20 12:24:04.948821
396	6	create	Fee payment: Registration - $23000	fees	86	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-20 12:26:45.746281
397	6	create	Fee payment: Tuition - $7000	fees	86	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-20 12:27:32.878207
398	6	create	Fee payment: Registration - $23000	fees	87	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-20 12:28:08.015517
399	6	create	Fee payment: Registration - $23000	fees	88	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-20 12:28:39.216512
400	6	create	Fee payment: Tuition - $27000	fees	88	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-20 12:29:23.377729
401	6	create	Fee payment: Registration - $23000	fees	83	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-20 12:30:40.786825
402	6	create	Fee payment: Tuition - $45000	fees	83	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-20 12:31:17.138639
403	6	create	Fee payment: Registration - $23000	fees	90	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-20 12:32:28.497757
404	6	create	Fee payment: Tuition - $47000	fees	90	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-20 12:33:25.393821
405	6	create	Fee payment: Registration - $23000	fees	91	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-20 12:34:32.28151
406	6	create	Fee payment: Tuition - $90000	fees	91	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-20 12:35:21.683522
407	6	create	Fee payment: Registration - $23000	fees	92	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-20 12:36:22.032742
408	6	create	Fee payment: Tuition - $27000	fees	92	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-20 12:37:00.113704
409	6	create	Fee payment: Registration - $23000	fees	93	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-20 12:37:42.032809
410	6	create	Fee payment: Tuition - $7000	fees	93	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-20 12:38:38.771931
411	6	create	Fee payment: Registration - $23000	fees	95	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-20 12:48:43.698778
412	6	create	Fee payment: Tuition - $3000	fees	95	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-20 12:49:36.686646
413	6	update	Reconciled Tuition to 2000	fees	95	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-20 12:51:04.818117
414	6	create	Fee payment: Registration - $23000	fees	96	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-20 12:51:29.522518
415	6	create	Fee payment: Registration - $23000	fees	97	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-20 12:52:20.841696
416	6	create	Fee payment: Tuition - $47000	fees	97	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-20 12:52:58.958797
417	6	create	Fee payment: Registration - $23000	fees	99	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-20 12:55:56.183391
418	6	create	Fee payment: Tuition - $27000	fees	99	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-20 12:56:36.972002
419	6	create	Fee payment: Registration - $23000	fees	100	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-20 12:57:11.537862
420	6	create	Fee payment: Tuition - $7000	fees	100	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-20 12:57:50.095344
421	6	create	Fee payment: Registration - $23000	fees	98	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-20 12:58:25.359521
422	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	2025-09-20 14:00:13.307002
423	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	2025-09-20 14:22:48.440615
424	2	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	2025-09-21 12:58:45.429043
425	23	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (iPhone; CPU iPhone OS 17_6_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.6 Mobile/15E148 Safari/604.1	2025-09-21 13:20:39.794797
426	7	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-21 20:26:49.92303
427	33	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-09-22 16:28:31.439838
428	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	2025-09-23 03:02:43.965371
429	6	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-23 08:29:53.659071
430	35	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-23 14:53:33.246736
431	33	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-09-23 19:39:17.68089
432	22	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	2025-09-23 20:01:11.477388
433	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	2025-09-24 08:54:04.086639
434	17	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-24 09:05:18.101743
435	33	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-09-24 10:06:03.392618
436	33	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-09-24 11:56:46.586508
437	1	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-24 12:05:59.812463
438	33	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36 OPR/120.0.0.0	2025-09-24 12:46:18.086128
439	33	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36 OPR/120.0.0.0	2025-09-24 12:46:48.770996
440	33	login	User logged in successfully	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-09-24 12:47:12.117447
441	7	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-24 15:01:50.790043
442	22	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	2025-09-24 18:04:40.526547
443	33	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-24 18:09:05.414006
444	33	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-24 18:10:33.885997
445	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	2025-09-24 18:21:25.604937
446	7	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-24 18:26:51.884545
447	6	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-24 18:27:04.908349
448	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	2025-09-24 18:28:30.739276
449	20	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-24 18:36:17.443496
450	20	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-24 18:37:37.292643
451	20	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-24 18:40:53.820186
452	6	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-24 18:41:13.67887
453	6	create	Fee payment: Registration - $23000	fees	107	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-24 18:42:14.359501
454	6	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-24 19:25:18.342898
455	33	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-09-24 19:34:03.097367
456	22	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	2025-09-24 19:44:20.495842
457	22	create	Uploaded lesson plan: Chemistry notes for certification level one 	lesson_plan	1	Chemistry notes for certification level one 	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	2025-09-24 19:51:35.088896
458	22	create	Uploaded lesson plan: Chemistry Certification level 2 notes 	lesson_plan	2	Chemistry Certification level 2 notes 	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	2025-09-24 19:52:48.443964
459	22	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	2025-09-25 04:26:36.454535
460	33	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-09-25 10:58:18.578084
461	33	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-09-25 15:12:14.622959
462	6	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-25 16:27:29.710669
463	33	update	rejected lesson plan: Chemistry Certification level 2 notes 	lesson_plan	2	Chemistry Certification level 2 notes 	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-09-25 16:54:00.887311
464	33	update	rejected lesson plan: Chemistry notes for certification level one 	lesson_plan	1	Chemistry notes for certification level one 	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-09-25 17:00:37.589205
465	6	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-25 17:08:47.552868
466	22	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	2025-09-25 18:01:42.881848
467	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	2025-09-25 18:33:17.004412
468	6	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-26 06:52:49.276502
469	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	2025-09-26 06:56:30.456588
470	6	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-26 06:59:13.498602
471	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	2025-09-26 07:10:02.284503
472	6	create	Fee payment: Tuition - $100000	fees	102	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-26 07:17:25.742966
473	6	create	Fee payment: Registration - $23000	fees	106	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-26 07:28:32.555546
474	6	create	Fee payment: Tuition - $30000	fees	106	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-26 07:29:25.173165
475	1	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-26 11:11:10.014971
476	7	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-26 11:19:28.944868
477	33	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-09-26 11:21:19.343338
478	6	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-26 12:57:51.24121
479	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	2025-09-26 13:00:55.333182
480	6	create	Fee payment: Registration - $23000	fees	105	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-26 13:07:37.866997
481	6	create	Fee payment: Tuition - $50000	fees	104	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-26 13:09:37.614421
482	6	create	Fee payment: Tuition - $50000	fees	103	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-26 13:12:35.374245
483	6	create	Fee payment: Tuition - $50000	fees	101	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-26 13:13:52.770724
484	6	create	Fee payment: Tuition - $50000	fees	94	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-26 13:15:02.457411
485	6	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-27 06:43:00.773615
486	6	create	Fee payment: Registration - $23000	fees	89	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-27 06:56:18.990861
487	6	create	Fee payment: Tuition - $37000	fees	89	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-27 06:57:58.235444
488	1	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36 OPR/120.0.0.0	2025-09-27 07:34:47.058197
489	2	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	2025-09-27 07:57:53.245617
490	23	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (iPhone; CPU iPhone OS 17_6_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.6 Mobile/15E148 Safari/604.1	2025-09-27 08:35:20.438007
491	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	2025-09-27 09:25:47.041256
492	20	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	2025-09-27 09:30:18.972787
493	36	create	Created user: Che	user	36	Che	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	2025-09-27 09:43:32.139006
494	36	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	2025-09-27 09:44:25.865362
495	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	2025-09-27 09:57:40.841292
496	4	update	Updated user: Che	user	36	Che	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	2025-09-27 09:59:32.556412
497	36	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	2025-09-27 09:59:56.560497
498	18	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-27 10:35:56.831492
499	18	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-27 10:37:13.870937
500	18	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-27 10:38:50.929106
501	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	2025-09-27 12:41:46.383799
502	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	2025-09-27 13:22:20.356107
503	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	2025-09-28 05:26:05.892036
504	7	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-28 15:45:37.634727
505	15	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-09-29 10:09:09.754279
506	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	2025-09-30 12:53:37.41753
507	6	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-30 18:22:40.361248
508	21	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-30 18:33:34.15855
509	21	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-09-30 19:02:17.832364
510	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	2025-10-01 01:58:14.819158
511	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	2025-10-01 06:47:04.088215
512	6	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-01 13:50:07.279525
513	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-01 14:35:28.448378
514	6	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-01 14:36:32.581418
515	7	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-01 14:45:26.5199
516	21	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-01 14:49:15.505656
517	21	login	User logged in successfully	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-01 14:54:14.057915
518	6	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-01 15:49:30.436479
519	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-01 15:51:11.094712
520	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-10-01 15:55:31.679566
521	6	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-01 15:56:35.530894
522	21	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36 OPR/120.0.0.0	2025-10-01 16:19:27.58601
523	21	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-01 21:30:32.831217
524	21	login	User logged in successfully	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-02 11:07:28.410399
525	21	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36 OPR/120.0.0.0	2025-10-02 11:32:41.58806
526	9	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-03 13:13:48.077808
527	18	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-04 05:51:22.223716
528	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	2025-10-04 08:05:17.181228
529	2	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	2025-10-04 08:34:09.333622
530	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	2025-10-04 09:33:10.458135
531	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-04 09:37:14.64801
532	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-04 10:20:05.032978
533	37	create	Created user: Madeleine 	user	37	Madeleine 	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-04 10:24:19.091473
534	38	create	Created user: Ngah 	user	38	Ngah 	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-04 10:30:01.33579
535	2	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	2025-10-04 10:43:44.161373
536	6	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-04 10:54:15.803926
537	33	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-04 11:08:18.741204
538	18	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-04 13:33:01.346429
539	15	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/28.0 Chrome/130.0.0.0 Mobile Safari/537.36	2025-10-04 20:53:36.440178
540	9	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-05 09:45:01.934053
541	33	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-06 09:35:25.491922
542	7	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-06 15:36:57.811143
543	7	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-06 15:37:27.822531
544	6	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-06 23:35:09.81174
545	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	2025-10-07 08:07:14.55751
546	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	2025-10-07 08:12:54.11404
547	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	2025-10-07 08:14:43.458254
548	2	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	2025-10-07 12:51:45.227659
549	2	create	Uploaded lesson plan: Lesson plan for the month of October ICT	lesson_plan	3	Lesson plan for the month of October ICT	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	2025-10-07 12:53:21.455471
550	2	create	Uploaded lesson plan: Ict notes for the month of September 	lesson_plan	4	Ict notes for the month of September 	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	2025-10-07 14:23:51.753592
551	2	create	Sent message to user	message	10	Good day sir	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	2025-10-07 14:24:52.89491
552	2	create	Sent message to user	message	11	I have submitted ict notes for September and Octob	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	2025-10-07 14:26:00.908656
553	7	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-07 14:33:03.012426
554	7	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-07 14:36:51.024822
555	33	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (iPhone; CPU iPhone OS 18_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1	2025-10-07 14:43:36.390086
556	7	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0	2025-10-07 14:45:24.354566
557	7	create	Uploaded lesson plan: Physical Properties and Quantities	lesson_plan	5	Physical Properties and Quantities	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0	2025-10-07 14:55:41.550042
558	7	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-07 14:56:19.085035
559	22	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	2025-10-08 07:39:49.892348
560	23	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (iPhone; CPU iPhone OS 17_6_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.6 Mobile/15E148 Safari/604.1	2025-10-08 08:49:58.118044
561	7	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-08 08:52:43.314259
562	23	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (iPhone; CPU iPhone OS 17_6_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.6 Mobile/15E148 Safari/604.1	2025-10-08 08:59:13.298826
563	22	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	2025-10-08 14:13:54.993111
564	22	create	Uploaded lesson plan: Chemistry for ITVEE	lesson_plan	6	Chemistry for ITVEE	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	2025-10-08 14:16:52.925621
565	22	create	Uploaded lesson plan: Chemistry for CL2	lesson_plan	7	Chemistry for CL2	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	2025-10-08 14:19:37.285694
566	22	create	Uploaded lesson plan: Chemistry certification level 1	lesson_plan	8	Chemistry certification level 1	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	2025-10-08 14:22:46.139362
567	7	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-08 15:30:20.71837
568	7	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-10-08 15:32:48.455231
569	7	delete	Deleted lesson plan: Physical Properties and Quantities	lesson_plan	5	Physical Properties and Quantities	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-10-08 15:34:19.65535
570	6	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-08 15:35:13.608295
571	7	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0	2025-10-08 15:50:20.060878
572	7	create	Uploaded lesson plan: INTRODUCTION TO PHYSICAL PROPERTIES AND QUANTITIES	lesson_plan	9	INTRODUCTION TO PHYSICAL PROPERTIES AND QUANTITIES	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0	2025-10-08 15:52:43.960919
573	2	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	2025-10-08 16:48:08.914122
574	18	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-08 16:59:21.06472
575	18	create	Uploaded lesson plan: English Language 	lesson_plan	10	English Language 	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-08 17:02:27.472085
576	18	create	Uploaded lesson plan: English language 	lesson_plan	11	English language 	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-08 17:03:07.739568
577	18	create	Uploaded lesson plan: English language 	lesson_plan	12	English language 	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-08 17:03:56.899193
578	18	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-08 17:06:40.170539
579	22	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	2025-10-08 17:08:52.204143
580	18	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-08 17:56:30.016587
581	33	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (iPhone; CPU iPhone OS 18_6_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/138.0.7204.156 Mobile/15E148 Safari/604.1	2025-10-08 18:06:57.332963
582	18	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-08 18:16:12.273602
583	18	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-08 18:20:13.975932
584	18	create	Uploaded lesson plan: English language 	lesson_plan	13	English language 	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-08 18:21:23.038958
585	18	create	Uploaded lesson plan: English language 	lesson_plan	14	English language 	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-08 18:21:50.18087
586	18	create	Uploaded lesson plan: Adjectives 	lesson_plan	15	Adjectives 	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-08 18:22:57.880729
587	18	create	Uploaded lesson plan: Conjunctions 	lesson_plan	16	Conjunctions 	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-08 18:23:32.349003
588	18	create	Uploaded lesson plan: Interjections 	lesson_plan	17	Interjections 	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-08 18:24:14.999703
589	18	create	Uploaded lesson plan: Verbs	lesson_plan	18	Verbs	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-08 18:24:45.313588
590	18	create	Uploaded lesson plan: Plurals of nouns 	lesson_plan	19	Plurals of nouns 	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-08 18:25:16.21794
591	18	create	Uploaded lesson plan: Tenses	lesson_plan	20	Tenses	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-08 18:25:52.703661
592	18	create	Uploaded lesson plan: Regular and Irregular verbs 	lesson_plan	21	Regular and Irregular verbs 	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-08 18:26:40.276763
593	22	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	2025-10-08 18:28:34.727691
594	18	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-08 18:29:43.603164
595	18	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-08 18:34:22.264312
596	18	create	Uploaded lesson plan: Conditional 	lesson_plan	22	Conditional 	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-08 18:35:01.812181
597	18	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-08 18:36:04.107337
598	18	create	Uploaded lesson plan: Comparing Adjectives 	lesson_plan	23	Comparing Adjectives 	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-08 18:36:40.361018
599	35	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-08 19:07:58.527759
600	33	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-08 19:12:23.452175
601	7	login	User logged in successfully	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-10-08 19:13:38.069959
602	7	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-08 19:16:52.759187
603	33	update	approved lesson plan: Lesson plan for the month of October ICT	lesson_plan	3	Lesson plan for the month of October ICT	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-08 19:20:22.087554
604	33	update	approved lesson plan: Ict notes for the month of September 	lesson_plan	4	Ict notes for the month of September 	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-08 19:22:34.643842
605	33	update	approved lesson plan: Chemistry for ITVEE	lesson_plan	6	Chemistry for ITVEE	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-08 19:28:39.935434
606	33	update	approved lesson plan: Chemistry for CL2	lesson_plan	7	Chemistry for CL2	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-08 19:33:25.725403
607	33	update	approved lesson plan: Chemistry certification level 1	lesson_plan	8	Chemistry certification level 1	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-08 19:41:32.241222
608	33	update	approved lesson plan: INTRODUCTION TO PHYSICAL PROPERTIES AND QUANTITIES	lesson_plan	9	INTRODUCTION TO PHYSICAL PROPERTIES AND QUANTITIES	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-08 19:42:12.653289
609	33	delete	Admin deleted lesson plan: English Language 	lesson_plan	10	English Language 	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-08 19:49:32.077688
610	33	delete	Admin deleted lesson plan: English language 	lesson_plan	11	English language 	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-08 19:49:44.634335
611	18	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-08 20:07:44.137202
612	33	update	approved lesson plan: Comparing Adjectives 	lesson_plan	23	Comparing Adjectives 	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-08 20:08:29.23686
613	18	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-08 20:08:36.718525
614	18	create	Uploaded lesson plan: Conditionals	lesson_plan	24	Conditionals	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-08 20:09:33.806414
615	33	update	approved lesson plan: Conditional 	lesson_plan	22	Conditional 	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-08 20:12:21.588917
616	33	delete	Admin deleted lesson plan: Regular and Irregular verbs 	lesson_plan	21	Regular and Irregular verbs 	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-08 20:14:10.262255
617	33	delete	Admin deleted lesson plan: Tenses	lesson_plan	20	Tenses	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-08 20:14:37.395548
618	33	delete	Admin deleted lesson plan: Plurals of nouns 	lesson_plan	19	Plurals of nouns 	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-08 20:14:58.034612
619	33	update	approved lesson plan: Verbs	lesson_plan	18	Verbs	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-08 20:16:11.879399
620	33	delete	Admin deleted lesson plan: Interjections 	lesson_plan	17	Interjections 	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-08 20:16:46.699856
621	33	delete	Admin deleted lesson plan: Conjunctions 	lesson_plan	16	Conjunctions 	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-08 20:17:17.918106
622	33	delete	Admin deleted lesson plan: Adjectives 	lesson_plan	15	Adjectives 	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-08 20:18:01.593356
623	33	update	approved lesson plan: English language 	lesson_plan	14	English language 	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-08 20:19:40.153658
624	33	update	approved lesson plan: English language 	lesson_plan	13	English language 	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-08 20:21:20.297501
625	33	update	approved lesson plan: English language 	lesson_plan	12	English language 	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-08 20:22:55.234821
626	33	update	approved lesson plan: Conditionals	lesson_plan	24	Conditionals	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-08 20:23:52.982507
627	9	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-08 20:43:59.038005
628	18	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-08 20:45:38.186916
629	18	create	Uploaded lesson plan: Conditionals	lesson_plan	25	Conditionals	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-08 20:46:23.125554
630	18	create	Uploaded lesson plan: Plural Formation of Nouns 	lesson_plan	26	Plural Formation of Nouns 	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-08 20:47:04.726764
1423	7	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:144.0) Gecko/20100101 Firefox/144.0	2025-11-09 14:52:52.913069
631	18	create	Uploaded lesson plan: Types and uses of nouns 	lesson_plan	27	Types and uses of nouns 	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-08 20:47:47.711026
632	18	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-08 20:53:45.063548
633	18	create	Uploaded lesson plan: Nouns 	lesson_plan	28	Nouns 	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-08 20:54:39.760048
634	18	create	Uploaded lesson plan: Future Tenses	lesson_plan	29	Future Tenses	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-08 20:55:27.791298
635	18	create	Uploaded lesson plan: Regular and irregular verbs 	lesson_plan	30	Regular and irregular verbs 	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-08 20:56:00.056933
636	18	create	Uploaded lesson plan: Prepositions 	lesson_plan	31	Prepositions 	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-08 20:56:26.947993
637	18	create	Uploaded lesson plan: Regular and irregular verbs 	lesson_plan	32	Regular and irregular verbs 	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-08 20:59:35.78336
638	18	create	Uploaded lesson plan: Adverbs 	lesson_plan	33	Adverbs 	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-08 21:00:07.652283
639	18	create	Uploaded lesson plan: Affirmative,negative and interrogative sentences 	lesson_plan	34	Affirmative,negative and interrogative sentences 	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-08 21:01:25.02127
640	18	create	Uploaded lesson plan: Conjunctions 	lesson_plan	35	Conjunctions 	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-08 21:01:49.623489
641	18	create	Uploaded lesson plan: Comparing Adjectives 	lesson_plan	36	Comparing Adjectives 	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-08 21:02:52.207361
642	2	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	2025-10-08 21:07:15.480074
643	18	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-08 21:07:29.801357
644	18	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-08 21:08:32.020562
645	18	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-08 21:11:30.93441
646	35	create	Uploaded lesson plan: Lesson notes on Circuits for Certification Level 2for the Month of September	lesson_plan	37	Lesson notes on Circuits for Certification Level 2for the Month of September	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-08 21:18:38.292819
647	35	create	Uploaded lesson plan: Lesson notes on Circuits for ITVE students for the Month of September	lesson_plan	38	Lesson notes on Circuits for ITVE students for the Month of September	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-08 21:20:03.752503
648	35	create	Uploaded lesson plan: Lesson notes on Circuits for ITVE students for the Month of October 	lesson_plan	39	Lesson notes on Circuits for ITVE students for the Month of October 	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-08 21:21:00.487971
649	35	create	Uploaded lesson plan: Lesson notes on Digital Circuits for ATVE students for the Month of September	lesson_plan	40	Lesson notes on Digital Circuits for ATVE students for the Month of September	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-08 21:22:23.181462
650	35	create	Uploaded lesson plan: Lesson notes on Circuits for ATVE students for the Month of October 	lesson_plan	41	Lesson notes on Circuits for ATVE students for the Month of October 	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-08 21:23:00.174272
651	22	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	2025-10-08 21:55:30.678422
652	2	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	2025-10-08 22:03:51.161059
653	2	create	Uploaded lesson plan: September lesson plan update for ict certification level one 	lesson_plan	42	September lesson plan update for ict certification level one 	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	2025-10-08 22:04:51.400717
654	2	create	Uploaded lesson plan: October lesson plan update for ict certification level one 	lesson_plan	43	October lesson plan update for ict certification level one 	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	2025-10-08 22:05:31.721941
655	7	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-09 06:17:11.867374
656	7	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-09 07:14:39.219029
657	7	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-09 08:49:26.440806
658	7	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0	2025-10-09 09:36:30.590679
659	33	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (iPhone; CPU iPhone OS 18_6_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/138.0.7204.156 Mobile/15E148 Safari/604.1	2025-10-09 09:47:10.29757
660	34	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1	2025-10-09 10:07:14.879103
661	18	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-09 10:12:38.791282
662	7	login	User logged in successfully	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-10-09 10:39:26.97414
663	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	2025-10-09 12:48:31.298282
664	2	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	2025-10-09 13:44:47.118979
665	33	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-09 17:48:48.078487
666	33	update	approved lesson plan: Lesson notes on Circuits for ATVE students for the Month of October 	lesson_plan	41	Lesson notes on Circuits for ATVE students for the Month of October 	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-09 17:53:24.826198
667	33	update	approved lesson plan: Lesson notes on Digital Circuits for ATVE students for the Month of September	lesson_plan	40	Lesson notes on Digital Circuits for ATVE students for the Month of September	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-09 17:59:54.765437
668	33	update	approved lesson plan: Lesson notes on Circuits for ITVE students for the Month of October 	lesson_plan	39	Lesson notes on Circuits for ITVE students for the Month of October 	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-09 18:04:44.639695
669	33	update	approved lesson plan: Lesson notes on Circuits for ITVE students for the Month of September	lesson_plan	38	Lesson notes on Circuits for ITVE students for the Month of September	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-09 18:05:44.869564
670	33	update	approved lesson plan: Lesson notes on Circuits for Certification Level 2for the Month of September	lesson_plan	37	Lesson notes on Circuits for Certification Level 2for the Month of September	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-09 18:10:15.509169
671	33	delete	Admin deleted lesson plan: Comparing Adjectives 	lesson_plan	36	Comparing Adjectives 	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-09 18:10:41.730897
672	33	delete	Admin deleted lesson plan: Conjunctions 	lesson_plan	35	Conjunctions 	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-09 18:11:24.288177
673	33	delete	Admin deleted lesson plan: Affirmative,negative and interrogative sentences 	lesson_plan	34	Affirmative,negative and interrogative sentences 	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-09 18:11:56.689817
674	33	delete	Admin deleted lesson plan: Adverbs 	lesson_plan	33	Adverbs 	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-09 18:12:29.659106
675	33	delete	Admin deleted lesson plan: Regular and irregular verbs 	lesson_plan	32	Regular and irregular verbs 	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-09 18:12:55.175908
676	33	delete	Admin deleted lesson plan: Prepositions 	lesson_plan	31	Prepositions 	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-09 18:13:26.19011
677	33	delete	Admin deleted lesson plan: Regular and irregular verbs 	lesson_plan	30	Regular and irregular verbs 	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-09 18:13:46.870957
678	33	delete	Admin deleted lesson plan: Future Tenses	lesson_plan	29	Future Tenses	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-09 18:14:10.511526
679	33	delete	Admin deleted lesson plan: Nouns 	lesson_plan	28	Nouns 	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-09 18:15:20.257109
680	33	update	approved lesson plan: Types and uses of nouns 	lesson_plan	27	Types and uses of nouns 	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-09 18:16:52.835056
681	33	delete	Admin deleted lesson plan: Plural Formation of Nouns 	lesson_plan	26	Plural Formation of Nouns 	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-09 18:17:18.004682
682	33	delete	Admin deleted lesson plan: Conditionals	lesson_plan	25	Conditionals	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-09 18:17:40.631733
683	33	update	approved lesson plan: October lesson plan update for ict certification level one 	lesson_plan	43	October lesson plan update for ict certification level one 	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-09 18:20:42.008261
684	33	update	approved lesson plan: September lesson plan update for ict certification level one 	lesson_plan	42	September lesson plan update for ict certification level one 	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-10-09 18:21:28.754289
685	18	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-09 19:09:26.573414
686	18	create	Uploaded lesson plan: Conjunctions 	lesson_plan	44	Conjunctions 	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-09 19:11:28.813018
687	18	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-09 19:13:29.998984
688	18	create	Uploaded lesson plan: Comparing Adjectives 	lesson_plan	45	Comparing Adjectives 	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-09 19:14:13.695567
689	7	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-10 11:55:39.586868
690	1	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36 OPR/122.0.0.0	2025-10-10 15:48:08.975161
691	7	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-10 15:50:57.750879
692	7	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-10 20:20:12.03507
693	1	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-10 20:24:38.842596
694	35	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-10 21:09:45.960243
695	35	create	Uploaded lesson plan: Circuit notes for Certification Level 2 students for the month of October 	lesson_plan	46	Circuit notes for Certification Level 2 students for the month of October 	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-10 21:13:06.199798
696	35	create	Uploaded lesson plan: Electrical Engineering notes for the month of October 	lesson_plan	47	Electrical Engineering notes for the month of October 	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-10 21:13:51.194427
697	35	create	Uploaded lesson plan: Machines notes for CL2 students for the month of October 	lesson_plan	48	Machines notes for CL2 students for the month of October 	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-10 21:15:16.02356
698	35	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-10 22:30:28.980631
699	2	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	2025-10-12 19:04:12.680701
700	35	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-13 07:13:34.39118
701	6	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-14 13:37:05.161844
702	7	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-14 19:33:10.442696
703	1	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-14 19:33:28.404188
704	35	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-14 20:18:59.642706
705	6	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-15 09:16:56.36168
706	35	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-15 10:54:06.385191
707	2	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	2025-10-15 12:31:39.038793
708	39	create	Created user: Menemoh	user	39	Menemoh	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	2025-10-15 12:34:44.778826
709	39	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-15 12:42:16.773978
710	2	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	2025-10-15 12:43:04.965596
711	39	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-15 12:57:08.514417
712	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	2025-10-15 13:14:13.292316
713	33	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (iPhone; CPU iPhone OS 18_6_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/138.0.7204.156 Mobile/15E148 Safari/604.1	2025-10-15 18:05:25.360572
714	7	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-15 18:13:40.704607
715	35	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-15 19:18:16.193569
716	7	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-16 07:12:46.629507
717	15	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-10-16 08:44:00.15669
718	15	create	Uploaded lesson plan: Human biology notes week 1 CL2	lesson_plan	49	Human biology notes week 1 CL2	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-10-16 08:48:10.758364
719	15	create	Uploaded lesson plan: Public health CL1	lesson_plan	50	Public health CL1	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-10-16 08:48:54.097216
720	15	create	Uploaded lesson plan: Public Health Notes October 	lesson_plan	51	Public Health Notes October 	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-10-16 08:49:29.147171
721	15	create	Uploaded lesson plan: Biology notes OL A & B	lesson_plan	52	Biology notes OL A & B	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-10-16 08:50:12.694271
722	15	create	Uploaded lesson plan: Biology notes OL A & B October 	lesson_plan	53	Biology notes OL A & B October 	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-10-16 08:50:49.202979
723	15	create	Uploaded lesson plan: Biology Notes CL2	lesson_plan	54	Biology Notes CL2	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-10-16 08:51:51.766626
724	15	create	Uploaded lesson plan: Biology CL2 Continuation 	lesson_plan	55	Biology CL2 Continuation 	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-10-16 08:52:40.918696
725	15	create	Uploaded lesson plan: Biology ITVEE	lesson_plan	56	Biology ITVEE	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-10-16 08:53:07.218262
726	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	2025-10-16 12:11:19.92764
727	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	2025-10-16 12:11:46.909183
728	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	2025-10-16 12:15:55.451692
729	7	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-16 19:00:18.324465
730	34	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1	2025-10-17 07:10:29.036797
731	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-17 09:47:25.856618
732	2	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	2025-10-17 15:20:50.840301
733	15	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-10-17 15:38:09.534833
734	7	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-17 19:26:06.805148
735	2	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	2025-10-18 07:49:17.797845
736	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-18 09:38:45.383627
737	33	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-10-18 10:19:22.507944
738	15	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-10-18 11:44:55.298746
739	9	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-10-18 12:26:07.837714
740	7	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-18 18:40:02.654481
741	7	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-19 09:07:29.488571
742	6	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-19 11:40:01.211604
743	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	2025-10-20 04:27:39.175858
744	2	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	2025-10-20 11:03:31.994116
745	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-20 13:10:03.257507
746	7	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-20 14:25:05.850028
747	33	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-10-20 14:29:46.15151
748	33	update	approved lesson plan: Conjunctions 	lesson_plan	44	Conjunctions 	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-10-20 14:36:23.224811
749	33	update	approved lesson plan: Biology ITVEE	lesson_plan	56	Biology ITVEE	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-10-20 14:40:58.555879
750	33	update	approved lesson plan: Biology CL2 Continuation 	lesson_plan	55	Biology CL2 Continuation 	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-10-20 14:47:10.287209
751	33	update	approved lesson plan: Biology Notes CL2	lesson_plan	54	Biology Notes CL2	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-10-20 14:48:19.495739
752	33	update	approved lesson plan: Biology Notes CL2	lesson_plan	54	Biology Notes CL2	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-10-20 14:48:48.716594
753	33	update	approved lesson plan: Biology notes OL A & B October 	lesson_plan	53	Biology notes OL A & B October 	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-10-20 14:53:03.40311
754	33	update	approved lesson plan: Biology notes OL A & B	lesson_plan	52	Biology notes OL A & B	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-10-20 14:53:20.316347
755	33	update	approved lesson plan: Public Health Notes October 	lesson_plan	51	Public Health Notes October 	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-10-20 14:57:17.292914
756	33	update	approved lesson plan: Public health CL1	lesson_plan	50	Public health CL1	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-10-20 14:57:31.212242
757	33	update	approved lesson plan: Public health CL1	lesson_plan	50	Public health CL1	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-10-20 14:57:53.857441
758	33	update	approved lesson plan: Human biology notes week 1 CL2	lesson_plan	49	Human biology notes week 1 CL2	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-10-20 15:01:34.378693
759	33	update	approved lesson plan: Machines notes for CL2 students for the month of October 	lesson_plan	48	Machines notes for CL2 students for the month of October 	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-10-20 15:04:09.386925
796	33	update	approved lesson plan: Comparing Adjectives 	lesson_plan	45	Comparing Adjectives 	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-10-24 11:44:24.988809
760	33	update	approved lesson plan: Electrical Engineering notes for the month of October 	lesson_plan	47	Electrical Engineering notes for the month of October 	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-10-20 15:06:20.03076
761	33	update	approved lesson plan: Circuit notes for Certification Level 2 students for the month of October 	lesson_plan	46	Circuit notes for Certification Level 2 students for the month of October 	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-10-20 15:15:12.378231
762	6	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-20 15:45:15.860585
763	6	create	Fee payment: Registration - $20000	fees	109	Registration	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-20 15:51:11.617772
764	6	create	Fee payment: Tuition - $30000	fees	109	Tuition	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-20 15:53:17.578626
765	9	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-10-21 06:53:31.053317
766	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-21 09:46:37.102537
767	4	delete	Deleted user: Tina	user	10	Tina	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-21 09:47:47.099605
769	4	update	Updated user: Tina 	user	40	Tina 	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-21 09:54:32.759703
770	35	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-21 12:53:56.582433
771	2	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	2025-10-21 13:26:33.725059
772	2	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-21 14:02:17.464121
773	7	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-21 14:44:45.857334
774	2	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (iPhone; CPU iPhone OS 18_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1	2025-10-21 15:22:57.027698
775	2	delete	Deleted user: Tina 	user	40	Tina 	31.97.113.198	Mozilla/5.0 (iPhone; CPU iPhone OS 18_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1	2025-10-21 15:23:53.618204
776	41	create	Created user: Tina	user	41	Tina	31.97.113.198	Mozilla/5.0 (iPhone; CPU iPhone OS 18_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1	2025-10-21 15:24:41.617462
777	41	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (iPhone; CPU iPhone OS 18_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1	2025-10-21 15:25:11.22446
778	41	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (iPhone; CPU iPhone OS 18_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1	2025-10-21 15:25:51.317469
779	2	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-21 15:26:28.315046
780	2	update	Updated user: Gebuin	user	20	Gebuin	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-21 15:28:03.179122
781	20	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-21 15:29:02.222715
782	1	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-22 05:56:32.990257
783	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-22 06:25:42.536671
784	41	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (iPhone; CPU iPhone OS 18_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1	2025-10-22 07:15:20.683485
785	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-22 08:37:44.420739
786	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-22 10:57:41.726513
787	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-22 15:21:39.509821
788	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-22 15:28:39.790937
789	41	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (iPhone; CPU iPhone OS 18_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1	2025-10-22 16:21:08.033598
790	7	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-22 17:01:06.874055
791	7	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0	2025-10-22 17:05:37.70799
792	7	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-22 21:19:48.997368
793	7	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-23 18:47:02.078293
794	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-24 08:13:47.750335
795	33	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-10-24 11:41:43.027861
797	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-24 11:56:40.104744
798	7	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-24 21:01:53.118509
799	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-25 07:07:29.407133
800	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-25 07:46:58.269742
801	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-25 07:47:24.198195
802	22	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	2025-10-25 16:27:05.84898
803	33	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-10-26 09:59:21.906906
804	7	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-26 15:49:11.041643
805	1	login	User logged in successfully	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-10-27 06:41:30.669391
806	6	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-27 07:31:32.301565
807	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-27 07:34:01.418654
808	7	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-27 12:16:05.088678
809	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-28 07:20:08.902002
810	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-28 12:00:36.622262
811	2	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	2025-10-28 13:09:51.938901
812	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-28 13:34:25.354966
813	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-28 13:42:46.696466
814	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-28 15:19:49.090723
815	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-28 15:35:37.026744
816	2	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-10-28 15:40:42.18752
817	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	2025-10-28 15:48:37.127876
818	7	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-29 03:55:04.839969
819	35	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-10-29 06:35:13.273128
820	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-29 11:00:26.413697
821	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	2025-10-29 12:19:18.228391
822	2	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	2025-10-29 13:38:45.66529
823	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-29 13:44:18.923342
824	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-29 13:46:13.851993
825	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-29 14:04:19.908
826	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-29 14:05:46.973694
827	2	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-29 14:11:16.458087
828	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	2025-10-29 14:32:20.931909
829	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-29 14:37:35.814942
830	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	2025-10-29 14:40:41.093396
831	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-29 14:52:04.225468
832	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.114 Safari/537.36	2025-10-29 15:02:23.67696
833	2	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	2025-10-29 15:05:53.101755
834	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	2025-10-29 15:12:44.361706
835	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.114 Safari/537.36	2025-10-29 15:44:02.892349
836	7	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-29 18:27:08.69677
837	7	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-30 05:57:38.225778
838	15	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-30 07:33:33.528773
839	15	create	Uploaded lesson plan: Lesson plan Public Health CL1	lesson_plan	57	Lesson plan Public Health CL1	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-30 07:48:12.618786
840	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-30 09:11:20.023153
841	36	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-30 09:14:12.194627
842	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-30 10:17:15.131098
843	7	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0	2025-10-30 10:35:26.785062
844	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-30 13:16:50.528733
845	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-30 13:30:50.798845
846	2	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-30 13:43:52.647229
847	7	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-30 16:29:16.08209
848	1	login	User logged in successfully	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-10-30 18:41:14.140097
849	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-31 06:51:45.375314
850	22	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	2025-10-31 06:53:28.834692
851	6	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 09:51:11.555349
852	6	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-31 09:55:58.016123
853	6	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 10:01:58.517608
854	6	create	Fee payment: Tuition - $100000	fees	1	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 10:28:49.249093
855	6	create	Fee payment: Tuition - $20000	fees	53	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 10:30:40.7888
856	6	create	Fee payment: Tuition - $20000	fees	2	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 10:31:48.524575
857	6	create	Fee payment: Tuition - $20000	fees	54	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 10:32:34.345796
858	6	create	Fee payment: Tuition - $20000	fees	55	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 10:33:10.767814
859	6	create	Fee payment: Tuition - $20000	fees	3	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 10:33:39.307033
860	6	create	Fee payment: Tuition - $80000	fees	191	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 10:35:07.849914
861	6	create	Fee payment: Tuition - $20000	fees	5	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 10:36:52.615557
862	6	create	Fee payment: Tuition - $20000	fees	6	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 10:37:38.211664
863	6	create	Fee payment: Tuition - $20000	fees	56	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 10:38:06.724833
864	6	create	Fee payment: Tuition - $20000	fees	7	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 10:38:33.16514
865	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-31 10:39:08.87362
866	6	create	Fee payment: Tuition - $80000	fees	8	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 10:41:17.099836
867	6	create	Fee payment: Tuition - $100000	fees	9	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 10:42:01.801912
868	6	update	Reconciled Tuition to 20000	fees	9	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 10:44:40.244074
869	6	create	Fee payment: Tuition - $20000	fees	10	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 10:46:30.078679
870	6	create	Fee payment: Tuition - $20000	fees	11	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 10:51:27.74715
871	6	create	Fee payment: Tuition - $20000	fees	12	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 10:51:55.653733
1446	7	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:144.0) Gecko/20100101 Firefox/144.0	2025-11-11 10:13:56.128657
872	6	create	Fee payment: Tuition - $20000	fees	13	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 10:52:21.568699
873	6	create	Fee payment: Tuition - $20000	fees	58	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 10:52:57.250869
874	6	create	Fee payment: Tuition - $20000	fees	59	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 10:53:17.505856
875	6	create	Fee payment: Tuition - $20000	fees	14	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 10:53:49.237384
876	6	create	Fee payment: Tuition - $20000	fees	60	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 10:54:14.65889
877	6	create	Fee payment: Tuition - $20000	fees	15	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 10:54:38.152777
878	6	create	Fee payment: Tuition - $20000	fees	61	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 10:55:12.076759
879	6	create	Fee payment: Tuition - $20000	fees	16	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 10:55:48.698529
880	6	create	Fee payment: Tuition - $20000	fees	17	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 10:56:34.915689
881	6	create	Fee payment: Tuition - $20000	fees	62	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 10:57:04.208503
882	6	create	Fee payment: Tuition - $20000	fees	18	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 10:57:33.928697
883	6	create	Fee payment: Tuition - $20000	fees	19	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 10:58:04.798556
884	6	create	Fee payment: Tuition - $20000	fees	20	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 10:58:30.503746
885	6	create	Fee payment: Tuition - $20000	fees	21	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 10:58:57.595677
886	6	create	Fee payment: Tuition - $20000	fees	52	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 10:59:29.41969
887	33	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-10-31 11:12:14.859926
888	6	create	Fee payment: Tuition - $20000	fees	23	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 11:15:49.72312
889	6	create	Fee payment: Tuition - $20000	fees	22	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 11:16:25.454796
890	6	create	Fee payment: Tuition - $20000	fees	24	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 11:16:55.563594
891	6	create	Fee payment: Tuition - $20000	fees	25	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 11:17:27.592587
892	6	create	Fee payment: Tuition - $20000	fees	26	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 11:17:54.889971
893	6	create	Fee payment: Tuition - $10000	fees	27	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 11:18:24.613699
894	6	create	Fee payment: Tuition - $10000	fees	29	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 11:18:51.173923
895	6	create	Fee payment: Tuition - $10000	fees	28	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 11:19:42.059081
896	6	create	Fee payment: Tuition - $20000	fees	30	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 11:20:15.20885
897	6	create	Fee payment: Tuition - $20000	fees	32	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 11:20:57.129201
898	6	create	Fee payment: Tuition - $20000	fees	33	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 11:21:27.717661
899	6	create	Fee payment: Tuition - $20000	fees	35	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 11:21:48.806843
900	6	create	Fee payment: Tuition - $20000	fees	34	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 11:22:12.615343
901	6	create	Fee payment: Tuition - $20000	fees	37	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 11:23:35.975589
902	6	create	Fee payment: Tuition - $20000	fees	377	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 11:25:45.006355
903	6	create	Fee payment: Tuition - $20000	fees	36	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 11:26:16.777026
904	6	create	Fee payment: Tuition - $20000	fees	50	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 11:26:55.484968
905	6	create	Fee payment: Tuition - $20000	fees	51	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 11:27:22.471716
906	6	create	Fee payment: Tuition - $20000	fees	43	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 11:28:00.261627
1583	7	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:144.0) Gecko/20100101 Firefox/144.0	2025-11-13 15:47:14.099267
907	6	create	Fee payment: Tuition - $20000	fees	42	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 11:28:24.670712
908	6	create	Fee payment: Tuition - $20000	fees	41	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 11:28:52.607381
909	6	create	Fee payment: Tuition - $20000	fees	44	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 11:29:27.515653
910	6	create	Fee payment: Tuition - $20000	fees	40	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 11:29:53.597941
911	6	create	Fee payment: Tuition - $20000	fees	38	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 11:30:25.317093
912	6	create	Fee payment: Tuition - $20000	fees	45	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 11:32:04.961764
913	6	create	Fee payment: Tuition - $20000	fees	46	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 11:32:43.739488
914	6	create	Fee payment: Tuition - $20000	fees	48	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 11:33:15.741582
915	6	create	Fee payment: Tuition - $20000	fees	47	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 11:33:50.256479
916	6	create	Fee payment: Tuition - $20000	fees	49	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 11:34:22.815307
917	6	create	Fee payment: Tuition - $20000	fees	109	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 11:34:51.716378
918	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-31 11:37:29.430932
919	6	create	Fee payment: Tuition - $40000	fees	108	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 11:38:06.688346
920	6	create	Fee payment: Tuition - $60000	fees	111	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 11:40:29.479546
921	6	create	Fee payment: Tuition - $50000	fees	110	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 11:41:09.69645
922	6	create	Fee payment: Tuition - $50000	fees	113	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 11:41:38.430934
923	6	create	Fee payment: Tuition - $35000	fees	117	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 11:42:01.952276
924	6	create	Fee payment: Tuition - $55000	fees	114	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 11:42:31.139448
925	6	create	Fee payment: Tuition - $20000	fees	115	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 11:43:02.713826
926	6	create	Fee payment: Tuition - $20000	fees	116	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 11:43:17.788698
927	6	create	Fee payment: Tuition - $60000	fees	118	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 11:43:42.424061
928	6	create	Fee payment: Tuition - $50000	fees	119	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 11:45:33.096506
929	6	create	Fee payment: Tuition - $100000	fees	125	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 11:47:22.713976
930	6	create	Fee payment: Tuition - $20000	fees	123	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 11:50:20.521819
931	6	create	Fee payment: Tuition - $50000	fees	122	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 11:50:45.209732
932	6	create	Fee payment: Tuition - $50000	fees	121	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 11:51:25.015309
933	6	create	Fee payment: Tuition - $60000	fees	126	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 11:51:45.562543
934	6	create	Fee payment: Tuition - $20000	fees	127	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 11:52:16.694589
935	6	create	Fee payment: Tuition - $20000	fees	128	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 11:52:47.239638
936	6	create	Fee payment: Tuition - $90000	fees	131	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 11:55:48.183713
937	33	update	approved lesson plan: Lesson plan Public Health CL1	lesson_plan	57	Lesson plan Public Health CL1	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-10-31 11:57:10.6382
938	6	create	Fee payment: Tuition - $50000	fees	182	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 12:00:27.800882
939	6	create	Fee payment: Tuition - $30000	fees	184	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 12:00:53.617414
940	6	create	Fee payment: Tuition - $60000	fees	183	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 12:01:33.634841
941	6	create	Fee payment: Tuition - $60000	fees	189	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 12:02:03.715753
942	6	create	Fee payment: Tuition - $50000	fees	188	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 12:02:41.873682
943	6	create	Fee payment: Tuition - $20000	fees	187	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 12:03:05.377071
944	6	create	Fee payment: Tuition - $60000	fees	186	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 12:03:58.691418
945	6	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 12:37:14.160825
946	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-31 12:47:31.320061
947	6	create	Fee payment: Tuition - $30000	fees	181	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 12:58:11.206184
948	6	create	Fee payment: Tuition - $30000	fees	272	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 12:58:44.960973
949	6	create	Fee payment: Tuition - $30000	fees	273	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:02:26.369006
950	6	create	Fee payment: Tuition - $40000	fees	210	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:03:05.878237
951	6	create	Fee payment: Tuition - $50000	fees	229	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:03:40.918572
952	6	create	Fee payment: Tuition - $40000	fees	241	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:04:03.896414
953	6	create	Fee payment: Tuition - $40000	fees	239	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:04:29.652701
954	6	create	Fee payment: Tuition - $30000	fees	236	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:05:14.354895
955	6	create	Fee payment: Tuition - $30000	fees	238	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:05:26.568253
956	6	create	Fee payment: Tuition - $50000	fees	240	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:05:58.059673
957	6	create	Fee payment: Tuition - $60000	fees	112	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:06:26.489981
958	6	create	Fee payment: Tuition - $50000	fees	235	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:06:54.128012
959	6	create	Fee payment: Tuition - $40000	fees	232	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:07:18.324711
960	6	create	Fee payment: Tuition - $30000	fees	233	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:07:46.890758
961	6	create	Fee payment: Tuition - $50000	fees	234	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:08:06.033771
962	6	create	Fee payment: Tuition - $50000	fees	250	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:08:25.09874
963	6	update	Reconciled Tuition to 45000	fees	250	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:08:48.107908
964	6	create	Fee payment: Tuition - $50000	fees	257	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:09:11.787806
965	6	create	Fee payment: Tuition - $35000	fees	291	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:10:01.628178
966	6	create	Fee payment: Tuition - $40000	fees	274	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:10:28.685742
967	6	create	Fee payment: Tuition - $60000	fees	289	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:11:05.226927
968	6	create	Fee payment: Tuition - $60000	fees	290	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:11:28.970454
969	6	create	Fee payment: Tuition - $60000	fees	287	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:13:20.792724
970	6	create	Fee payment: Tuition - $60000	fees	288	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:16:28.108937
971	6	create	Fee payment: Tuition - $60000	fees	286	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:16:51.812185
972	6	create	Fee payment: Tuition - $40000	fees	275	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:17:14.005349
973	6	create	Fee payment: Tuition - $20000	fees	285	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:17:36.874196
974	6	create	Fee payment: Tuition - $20000	fees	284	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:18:01.613552
975	6	create	Fee payment: Tuition - $80000	fees	283	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:18:21.804716
976	6	create	Fee payment: Tuition - $20000	fees	282	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:19:03.586398
977	6	create	Fee payment: Tuition - $20000	fees	281	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:19:26.806343
978	6	create	Fee payment: Tuition - $20000	fees	280	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:20:00.172651
979	6	create	Fee payment: Tuition - $20000	fees	279	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:20:55.083721
980	6	create	Fee payment: Tuition - $50000	fees	278	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:21:41.643728
981	6	create	Fee payment: Tuition - $40000	fees	277	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:22:13.314258
982	6	create	Fee payment: Tuition - $60000	fees	276	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:22:45.896694
983	6	create	Fee payment: Tuition - $20000	fees	292	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:23:24.45843
984	6	create	Fee payment: Tuition - $30000	fees	295	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:23:47.529828
985	6	create	Fee payment: Tuition - $43000	fees	296	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:24:11.245251
986	6	create	Fee payment: Tuition - $43000	fees	296	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:24:11.850677
987	6	create	Fee payment: Tuition - $25000	fees	297	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:24:41.807599
988	6	create	Fee payment: Tuition - $60000	fees	298	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:25:32.397747
989	6	create	Fee payment: Tuition - $20000	fees	299	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:25:56.811692
990	6	create	Fee payment: Tuition - $20000	fees	300	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:26:31.094341
991	6	create	Fee payment: Tuition - $20000	fees	300	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:26:34.032884
992	6	update	Reconciled Tuition to 25000	fees	45	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:27:35.823747
993	6	update	Reconciled Tuition to 0	fees	45	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:28:12.464558
994	6	update	Reconciled Tuition to 0	fees	45	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:28:15.598709
995	6	update	Reconciled Tuition to 0	fees	45	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:28:16.748897
996	6	update	Reconciled Tuition to 0	fees	45	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:28:17.37818
997	6	update	Reconciled Tuition to 0	fees	45	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:28:18.129591
998	6	update	Reconciled Tuition to 0	fees	45	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:28:20.510284
999	6	update	Reconciled Tuition to 0	fees	45	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:28:21.998511
1000	6	create	Fee payment: Tuition - $25000	fees	301	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:28:59.793127
1001	6	create	Fee payment: Tuition - $20000	fees	302	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:29:34.588235
1002	6	create	Fee payment: Tuition - $25000	fees	303	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:29:56.224534
1003	6	create	Fee payment: Tuition - $5000	fees	305	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:30:22.706523
1004	6	create	Fee payment: Tuition - $20000	fees	293	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:30:46.801786
1005	6	create	Fee payment: Tuition - $5000	fees	304	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:31:51.571236
1006	6	create	Fee payment: Tuition - $20000	fees	294	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:32:13.038704
1007	6	create	Fee payment: Tuition - $40000	fees	310	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:32:33.030238
1008	6	create	Fee payment: Tuition - $80000	fees	4	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:36:50.422483
1009	6	create	Fee payment: Tuition - $50000	fees	45	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:37:45.264759
1010	6	create	Fee payment: Tuition - $70000	fees	139	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:44:23.012472
1011	6	create	Fee payment: Tuition - $60000	fees	124	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:44:45.61746
1012	2	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-31 13:45:02.745437
1013	42	create	Created user: Kechazi	user	42	Kechazi	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-31 13:52:58.218126
1014	6	create	Fee payment: Tuition - $20000	fees	63	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:52:58.5356
1015	6	create	Fee payment: Tuition - $20000	fees	64	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:53:42.399711
1016	6	create	Fee payment: Tuition - $20000	fees	65	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:54:08.321792
1017	6	create	Fee payment: Tuition - $50000	fees	66	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:54:51.889552
1018	6	create	Fee payment: Tuition - $20000	fees	67	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:55:24.674944
1019	6	create	Fee payment: Tuition - $20000	fees	68	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:55:45.891107
1020	6	create	Fee payment: Tuition - $35000	fees	132	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:56:28.929368
1021	6	create	Fee payment: Tuition - $30000	fees	144	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:57:03.546757
1022	6	create	Fee payment: Tuition - $20000	fees	133	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:57:25.145928
1023	6	create	Fee payment: Tuition - $60000	fees	195	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:57:50.778723
1024	6	create	Fee payment: Tuition - $80000	fees	194	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:58:10.097777
1025	6	create	Fee payment: Tuition - $20000	fees	206	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:58:35.065147
1026	6	create	Fee payment: Tuition - $20000	fees	311	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:58:56.176649
1027	6	create	Fee payment: Tuition - $20000	fees	196	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:59:23.934629
1028	6	create	Fee payment: Tuition - $20000	fees	197	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 13:59:45.476724
1029	6	create	Fee payment: Tuition - $20000	fees	312	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 14:00:20.121301
1030	6	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 14:05:24.36527
1031	6	create	Fee payment: Tuition - $20000	fees	69	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 14:11:29.406562
1032	6	create	Fee payment: Tuition - $20000	fees	70	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 14:11:52.316668
1033	6	create	Fee payment: Tuition - $20000	fees	140	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 14:12:17.821902
1034	6	create	Fee payment: Tuition - $40000	fees	134	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 14:12:50.811787
1035	6	create	Fee payment: Tuition - $50000	fees	135	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 14:18:11.64917
1036	6	create	Fee payment: Tuition - $50000	fees	136	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 14:19:05.596942
1037	6	create	Fee payment: Tuition - $25000	fees	328	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 14:19:30.050393
1038	6	create	Fee payment: Tuition - $50000	fees	198	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 14:21:42.154766
1039	6	create	Fee payment: Tuition - $40000	fees	199	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 14:22:06.22895
1040	6	create	Fee payment: Tuition - $30000	fees	227	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 14:22:29.40257
1041	6	create	Fee payment: Tuition - $20000	fees	211	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 14:22:53.46865
1042	6	create	Fee payment: Tuition - $20000	fees	260	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 14:23:10.212654
1043	6	create	Fee payment: Tuition - $45000	fees	251	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 14:23:31.075124
1044	6	create	Fee payment: Tuition - $20000	fees	262	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 14:23:49.597572
1045	6	create	Fee payment: Tuition - $20000	fees	261	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 14:24:40.245726
1046	6	create	Fee payment: Tuition - $40000	fees	31	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 14:25:10.619529
1047	6	create	Fee payment: Tuition - $20000	fees	265	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 14:25:29.94931
1048	6	create	Fee payment: Tuition - $30000	fees	263	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 14:25:53.168402
1049	6	create	Fee payment: Tuition - $40000	fees	264	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 14:26:09.987725
1050	6	create	Fee payment: Tuition - $50000	fees	266	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 14:26:28.66621
1051	6	create	Fee payment: Tuition - $50000	fees	314	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 14:26:48.324351
1052	6	create	Fee payment: Tuition - $20000	fees	313	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 14:28:00.028688
1053	6	create	Fee payment: Tuition - $20000	fees	71	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 14:28:51.230223
1054	6	create	Fee payment: Tuition - $20000	fees	72	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 14:29:08.219922
1055	6	create	Fee payment: Tuition - $20000	fees	73	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 14:29:27.26034
1056	6	create	Fee payment: Tuition - $20000	fees	75	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 14:29:51.013793
1057	6	create	Fee payment: Tuition - $20000	fees	74	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 14:30:08.411815
1058	6	create	Fee payment: Tuition - $20000	fees	141	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 14:30:32.862636
1059	6	create	Fee payment: Tuition - $50000	fees	142	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 14:30:52.896001
1060	6	create	Fee payment: Tuition - $50000	fees	200	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 14:31:09.787659
1061	6	create	Fee payment: Tuition - $45000	fees	267	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 14:31:35.803972
1062	6	create	Fee payment: Tuition - $10000	fees	200	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 14:32:00.185483
1063	6	create	Fee payment: Tuition - $87000	fees	268	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 14:32:47.386754
1064	6	create	Fee payment: Tuition - $20000	fees	269	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 14:33:06.468237
1065	6	create	Fee payment: Tuition - $50000	fees	270	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 14:34:28.233842
1066	6	create	Fee payment: Tuition - $30000	fees	259	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 14:34:51.964001
1067	6	create	Fee payment: Tuition - $20000	fees	76	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 14:59:21.931818
1068	6	create	Fee payment: Tuition - $20000	fees	146	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 14:59:40.353528
1069	6	create	Fee payment: Tuition - $50000	fees	145	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 15:00:07.237343
1070	6	create	Fee payment: Tuition - $25000	fees	147	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 15:00:40.296542
1071	6	create	Fee payment: Tuition - $20000	fees	148	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 15:01:32.023831
1072	6	create	Fee payment: Tuition - $20000	fees	202	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 15:01:54.775359
1073	6	create	Fee payment: Tuition - $15000	fees	315	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 15:02:17.207529
1074	6	create	Fee payment: Tuition - $20000	fees	322	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 15:02:41.989665
1075	6	create	Fee payment: Tuition - $20000	fees	321	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 15:03:25.02007
1076	6	create	Fee payment: Tuition - $20000	fees	249	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 15:03:53.612506
1077	6	create	Fee payment: Tuition - $30000	fees	323	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 15:04:33.739881
1078	6	create	Fee payment: Tuition - $30000	fees	326	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 15:05:07.049992
1079	6	create	Fee payment: Tuition - $50000	fees	324	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 15:05:57.745516
1080	6	create	Fee payment: Tuition - $20000	fees	327	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 15:06:38.44395
1081	6	create	Fee payment: Tuition - $20000	fees	77	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 15:11:45.706757
1082	6	create	Fee payment: Tuition - $20000	fees	78	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 15:12:16.378279
1083	6	create	Fee payment: Tuition - $50000	fees	149	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 15:12:55.949204
1084	6	create	Fee payment: Tuition - $100000	fees	329	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 15:13:15.398687
1085	6	create	Fee payment: Tuition - $50000	fees	151	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 15:13:41.669788
1086	6	create	Fee payment: Tuition - $50000	fees	204	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 15:14:08.382707
1087	6	create	Fee payment: Tuition - $60000	fees	203	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 15:14:50.917655
1088	6	create	Fee payment: Tuition - $50000	fees	331	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 15:15:22.953466
1089	6	create	Fee payment: Tuition - $20000	fees	254	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 15:16:02.154074
1090	6	create	Fee payment: Tuition - $20000	fees	332	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 15:16:23.087112
1091	6	create	Fee payment: Tuition - $30000	fees	335	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 15:16:44.941435
1092	6	create	Fee payment: Tuition - $30000	fees	336	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 15:17:13.257509
1093	6	create	Fee payment: Tuition - $20000	fees	206	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 15:17:44.395513
1094	6	create	Fee payment: Tuition - $50000	fees	333	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 15:18:40.333575
1095	6	create	Fee payment: Tuition - $20000	fees	337	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 15:19:09.421283
1096	6	create	Fee payment: Tuition - $20000	fees	334	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 15:19:29.99152
1097	6	create	Fee payment: Tuition - $80000	fees	258	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 15:19:52.586825
1098	6	create	Fee payment: Tuition - $50000	fees	338	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 15:20:14.131757
1099	2	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	2025-10-31 15:25:09.284686
1100	6	create	Fee payment: Tuition - $20000	fees	79	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 15:31:05.484756
1101	6	create	Fee payment: Tuition - $20000	fees	82	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 15:33:11.746737
1102	6	create	Fee payment: Tuition - $20000	fees	153	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 15:33:52.830221
1103	6	create	Fee payment: Tuition - $20000	fees	154	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 15:34:14.994807
1104	6	create	Fee payment: Tuition - $20000	fees	155	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 15:34:39.04533
1105	6	create	Fee payment: Tuition - $30000	fees	207	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 15:35:08.913139
1106	6	create	Fee payment: Tuition - $30000	fees	209	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 15:35:29.769663
1107	6	create	Fee payment: Tuition - $100000	fees	208	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 15:35:58.469645
1108	6	create	Fee payment: Tuition - $20000	fees	341	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 15:38:21.206165
1109	6	create	Fee payment: Tuition - $60000	fees	342	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 15:38:44.472581
1110	6	create	Fee payment: Tuition - $40000	fees	343	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 15:39:04.868886
1111	6	create	Fee payment: Tuition - $20000	fees	344	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 15:39:34.453759
1112	6	create	Fee payment: Tuition - $40000	fees	345	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 15:40:02.968752
1113	6	create	Fee payment: Tuition - $60000	fees	157	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 15:40:39.878743
1114	6	create	Fee payment: Tuition - $30000	fees	158	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 15:43:09.757753
1115	6	create	Fee payment: Tuition - $90000	fees	159	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 15:44:20.057084
1116	6	create	Fee payment: Tuition - $55000	fees	346	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 15:44:48.39449
1117	6	create	Fee payment: Tuition - $30000	fees	347	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 15:45:17.594511
1118	6	create	Fee payment: Tuition - $30000	fees	347	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 15:45:17.954704
1119	6	update	Reconciled Tuition to 30000	fees	347	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 15:45:48.326351
1120	6	create	Fee payment: Tuition - $50000	fees	348	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 15:46:39.139246
1121	6	create	Fee payment: Tuition - $40000	fees	349	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 15:47:11.221819
1122	6	create	Fee payment: Tuition - $50000	fees	339	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 15:52:16.8219
1123	6	create	Fee payment: Tuition - $20000	fees	81	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 15:53:28.458697
1124	6	create	Fee payment: Tuition - $50000	fees	160	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 15:53:49.172593
1125	6	create	Fee payment: Tuition - $50000	fees	161	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 15:54:24.275647
1126	6	create	Fee payment: Tuition - $60000	fees	162	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 15:54:43.903685
1127	6	create	Fee payment: Tuition - $60000	fees	214	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 15:55:24.305311
1128	6	create	Fee payment: Tuition - $20000	fees	213	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 15:55:51.738566
1129	6	create	Fee payment: Tuition - $90000	fees	212	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 15:56:16.385567
1130	6	create	Fee payment: Tuition - $100000	fees	201	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 15:56:35.693552
1131	6	create	Fee payment: Tuition - $50000	fees	351	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 15:56:59.760953
1132	6	create	Fee payment: Tuition - $20000	fees	350	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 15:57:24.642347
1133	6	create	Fee payment: Tuition - $20000	fees	350	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 15:57:25.636536
1134	6	update	Reconciled Tuition to 20000	fees	350	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 15:57:54.144039
1135	6	create	Fee payment: Tuition - $70000	fees	352	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 15:58:13.138891
1136	6	create	Fee payment: Tuition - $10000	fees	353	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 15:59:03.698334
1137	6	create	Fee payment: Tuition - $50000	fees	163	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 16:02:27.805729
1138	6	create	Fee payment: Tuition - $50000	fees	355	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 16:02:54.285767
1139	6	create	Fee payment: Tuition - $80000	fees	152	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 16:03:50.130563
1140	6	create	Fee payment: Tuition - $40000	fees	215	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 16:04:16.380339
1141	6	create	Fee payment: Tuition - $30000	fees	356	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 16:04:55.898853
1142	6	create	Fee payment: Tuition - $50000	fees	357	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 16:18:32.792553
1143	6	create	Fee payment: Tuition - $63000	fees	85	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 16:19:18.895692
1144	6	create	Fee payment: Tuition - $23000	fees	86	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 16:20:29.093671
1145	6	create	Fee payment: Tuition - $63000	fees	87	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 16:21:09.890865
1146	6	create	Fee payment: Tuition - $23000	fees	88	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 16:21:36.159887
1147	6	create	Fee payment: Tuition - $23000	fees	83	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 16:22:06.687087
1148	6	create	Fee payment: Tuition - $23000	fees	90	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 16:22:29.975688
1149	6	create	Fee payment: Tuition - $23000	fees	89	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 16:22:56.126401
1150	6	create	Fee payment: Tuition - $50000	fees	164	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 16:23:27.694765
1151	6	create	Fee payment: Tuition - $25000	fees	358	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 16:24:02.134018
1152	6	create	Fee payment: Tuition - $80000	fees	165	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 16:24:27.973814
1153	6	create	Fee payment: Tuition - $30000	fees	217	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 16:25:04.277674
1154	6	create	Fee payment: Tuition - $80000	fees	168	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 16:25:35.80969
1155	6	create	Fee payment: Tuition - $40000	fees	237	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 16:25:58.607527
1156	6	create	Fee payment: Tuition - $23000	fees	245	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 16:26:19.48552
1157	6	create	Fee payment: Tuition - $30000	fees	360	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 16:27:07.887813
1158	6	create	Fee payment: Tuition - $100000	fees	362	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 16:27:44.846679
1159	6	create	Fee payment: Tuition - $113000	fees	363	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 16:28:19.116703
1160	6	create	Fee payment: Tuition - $70000	fees	366	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 16:28:46.536558
1161	6	create	Fee payment: Tuition - $60000	fees	365	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 16:29:10.121029
1162	6	create	Fee payment: Tuition - $30000	fees	367	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 16:29:53.543678
1163	6	create	Fee payment: Tuition - $25000	fees	369	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 16:30:10.73572
1164	6	create	Fee payment: Tuition - $23000	fees	368	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 16:30:34.399743
1165	6	create	Fee payment: Tuition - $23000	fees	359	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 16:33:58.886682
1166	6	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 18:16:09.104804
1167	6	create	Fee payment: Tuition - $40000	fees	219	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 18:18:57.205057
1168	6	create	Fee payment: Tuition - $70000	fees	370	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 18:19:33.201646
1169	6	create	Fee payment: Tuition - $23000	fees	91	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 18:20:18.438536
1170	6	create	Fee payment: Tuition - $73000	fees	92	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 18:20:54.619519
1171	6	create	Fee payment: Tuition - $23000	fees	107	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 18:21:48.90856
1172	6	create	Fee payment: Tuition - $23000	fees	93	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 18:22:24.159974
1173	6	create	Fee payment: Tuition - $23000	fees	171	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 18:24:35.863414
1174	6	create	Fee payment: Tuition - $40000	fees	169	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 18:25:10.015637
1175	6	create	Fee payment: Tuition - $50000	fees	371	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 18:25:49.876716
1176	6	create	Fee payment: Tuition - $23000	fees	372	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 18:26:23.666643
1177	6	create	Fee payment: Tuition - $25000	fees	220	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 18:26:50.380373
1178	6	create	Fee payment: Tuition - $50000	fees	222	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 18:27:25.257577
1179	6	create	Fee payment: Tuition - $50000	fees	221	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 18:27:57.099764
1180	6	create	Fee payment: Tuition - $20000	fees	375	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 18:28:25.277715
1181	6	create	Fee payment: Tuition - $30000	fees	376	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 18:29:01.827659
1182	7	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-31 18:29:10.792477
1183	6	create	Fee payment: Tuition - $10000	fees	138	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 18:31:47.855466
1184	6	create	Fee payment: Tuition - $45000	fees	383	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 18:32:47.527833
1185	6	create	Fee payment: Tuition - $23000	fees	384	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 18:33:35.968668
1186	6	create	Fee payment: Tuition - $23000	fees	95	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 18:38:09.057905
1187	6	create	Fee payment: Tuition - $23000	fees	96	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 18:38:27.976554
1188	6	create	Fee payment: Tuition - $23000	fees	97	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 18:39:05.430148
1189	6	create	Fee payment: Tuition - $60000	fees	173	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 18:40:58.956667
1190	6	create	Fee payment: Tuition - $30000	fees	174	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 18:41:36.560608
1191	6	create	Fee payment: Tuition - $50000	fees	223	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 18:43:04.394122
1192	6	create	Fee payment: Tuition - $60000	fees	224	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 18:43:32.435622
1193	6	create	Fee payment: Tuition - $23000	fees	256	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 18:43:59.697817
1194	6	create	Fee payment: Tuition - $110000	fees	175	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 18:47:23.942761
1195	6	create	Fee payment: Tuition - $23000	fees	106	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 18:48:23.922762
1196	6	create	Fee payment: Tuition - $100000	fees	180	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 18:48:54.502473
1197	6	create	Fee payment: Tuition - $20000	fees	179	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 18:49:20.457636
1198	6	create	Fee payment: Tuition - $100000	fees	361	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 18:50:02.821869
1199	6	create	Fee payment: Tuition - $23000	fees	99	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 18:51:03.607888
1200	6	create	Fee payment: Tuition - $23000	fees	100	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 18:51:35.06856
1201	6	create	Fee payment: Tuition - $23000	fees	100	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 18:51:35.43963
1202	6	update	Reconciled Tuition to 30000	fees	100	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 18:52:13.713927
1203	6	create	Fee payment: Tuition - $83000	fees	178	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 18:52:44.885139
1204	6	create	Fee payment: Tuition - $23000	fees	98	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 18:54:10.128549
1205	6	create	Fee payment: Tuition - $23000	fees	177	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 18:54:30.232548
1206	6	create	Fee payment: Tuition - $23000	fees	176	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 18:54:56.662683
1207	6	create	Fee payment: Tuition - $23000	fees	225	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 18:55:18.346233
1208	6	create	Fee payment: Tuition - $73000	fees	105	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 18:57:15.175683
1209	6	create	Fee payment: Tuition - $23000	fees	226	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 18:57:44.589347
1210	6	create	Fee payment: Tuition - $70000	fees	247	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 19:06:06.876096
1211	6	create	Fee payment: Tuition - $40000	fees	248	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 19:07:21.438714
1212	6	create	Fee payment: Tuition - $50000	fees	271	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 19:08:48.887792
1213	6	create	Fee payment: Tuition - $10000	fees	381	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 19:15:09.782214
1214	6	create	Fee payment: Tuition - $70000	fees	379	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 19:17:36.232547
1215	6	create	Fee payment: Tuition - $30000	fees	382	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 19:20:42.52026
1216	6	create	Fee payment: Tuition - $50000	fees	378	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 19:22:36.707392
1217	6	create	Fee payment: Tuition - $80000	fees	354	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 19:23:06.950704
1218	6	create	Fee payment: Tuition - $60000	fees	380	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-10-31 19:23:47.36372
1219	7	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-10-31 21:55:58.82866
1220	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	2025-11-01 00:11:19.709309
1221	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	2025-11-01 00:15:13.545742
1222	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	2025-11-01 00:50:58.108258
1223	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	2025-11-01 00:52:22.337316
1224	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36	2025-11-01 00:57:57.443907
1225	2	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	2025-11-01 06:55:14.52056
1226	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-11-01 09:08:36.525245
1227	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-11-01 11:25:41.9199
1228	2	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36	2025-11-01 11:30:24.921833
1229	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-11-01 11:33:08.158148
1230	7	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-11-01 14:56:59.68901
1231	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	2025-11-02 14:27:57.513368
1232	20	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-11-02 15:07:38.998776
1233	20	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-11-02 15:09:28.893212
1234	33	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-11-03 08:17:35.155667
1235	7	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-11-03 08:44:53.321637
1236	6	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-11-03 08:46:27.229238
1237	7	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-11-03 08:47:12.388763
1238	22	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	2025-11-03 11:07:42.033258
1239	1	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-11-03 11:37:57.487958
1240	43	create	Created user: Tester	user	43	Tester	127.0.0.1	axios/1.13.1	2025-11-03 13:04:29.776859
1241	43	login	User logged in successfully	\N	\N	\N	127.0.0.1	axios/1.13.1	2025-11-03 13:04:43.415684
1242	43	login	User logged in successfully	\N	\N	\N	127.0.0.1	axios/1.13.1	2025-11-03 13:04:43.971666
1243	43	login	User logged in successfully	\N	\N	\N	127.0.0.1	axios/1.13.1	2025-11-03 13:04:44.581251
1244	43	login	User logged in successfully	\N	\N	\N	127.0.0.1	axios/1.13.1	2025-11-03 13:04:45.137365
1245	43	login	User logged in successfully	\N	\N	\N	127.0.0.1	axios/1.13.1	2025-11-03 13:04:45.784449
1246	43	login	User logged in successfully	\N	\N	\N	127.0.0.1	axios/1.13.1	2025-11-03 13:04:46.352089
1247	43	login	User logged in successfully	\N	\N	\N	127.0.0.1	axios/1.13.1	2025-11-03 13:04:46.943607
1248	43	login	User logged in successfully	\N	\N	\N	127.0.0.1	axios/1.13.1	2025-11-03 13:04:47.520199
1249	43	login	User logged in successfully	\N	\N	\N	127.0.0.1	axios/1.13.1	2025-11-03 13:04:48.14509
1250	43	login	User logged in successfully	\N	\N	\N	127.0.0.1	axios/1.13.1	2025-11-03 13:04:48.693358
1251	43	login	User logged in successfully	\N	\N	\N	127.0.0.1	axios/1.13.1	2025-11-03 13:04:49.256478
1252	43	login	User logged in successfully	\N	\N	\N	127.0.0.1	axios/1.13.1	2025-11-03 13:04:49.812695
1253	43	login	User logged in successfully	\N	\N	\N	127.0.0.1	axios/1.13.1	2025-11-03 13:04:50.359468
1254	43	login	User logged in successfully	\N	\N	\N	127.0.0.1	axios/1.13.1	2025-11-03 13:04:58.713082
1255	43	login	User logged in successfully	\N	\N	\N	127.0.0.1	axios/1.13.1	2025-11-03 13:05:18.475051
1256	43	login	User logged in successfully	\N	\N	\N	127.0.0.1	axios/1.13.1	2025-11-03 13:09:44.166408
1257	43	login	User logged in successfully	\N	\N	\N	127.0.0.1	axios/1.13.1	2025-11-03 13:10:36.425958
1258	43	login	User logged in successfully	\N	\N	\N	127.0.0.1	axios/1.13.1	2025-11-03 13:21:10.966358
1259	15	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-11-03 16:12:22.830116
1260	33	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-11-03 18:00:28.14903
1261	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-11-04 07:27:38.052556
1262	44	create	Created user: Mimi	user	44	Mimi	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-11-04 07:41:06.443501
1263	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-11-04 10:05:51.656478
1264	15	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-11-04 11:23:49.875931
1265	2	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	2025-11-04 12:52:48.404935
1266	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-11-04 13:00:53.688429
1267	2	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	2025-11-04 13:01:30.369041
1268	2	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-11-04 13:16:10.263782
1269	2	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	2025-11-04 13:26:27.974547
1270	2	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-11-04 14:51:35.180954
1271	2	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-11-04 16:08:55.495913
1272	2	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	2025-11-04 18:50:08.47998
1273	2	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	2025-11-04 19:20:08.730947
1274	7	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-11-04 20:56:40.360306
1275	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-11-05 03:50:10.542762
1276	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-11-05 04:26:20.630208
1277	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-11-05 04:30:27.85474
1278	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-11-05 04:34:07.497052
1279	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.5060.114 Safari/537.36 Edg/103.0.1264.62	2025-11-05 04:42:34.42079
1280	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-11-05 06:10:13.794004
1281	33	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-11-05 07:10:11.110639
1282	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-11-05 10:55:37.258082
1283	4	update	Updated user: Foinmbam	user	19	Foinmbam	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-11-05 11:45:38.764637
1284	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-11-05 11:47:14.027573
1285	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-11-05 12:35:15.472472
1286	6	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 12:36:56.804024
1287	6	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 12:37:15.399004
1288	2	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-11-05 13:10:55.533672
1289	6	create	Fee payment: Tuition - $30000	fees	36	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 13:13:57.155796
1290	6	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-11-05 13:15:27.251944
1291	6	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 13:16:48.286176
1292	2	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	2025-11-05 13:19:21.123835
1293	2	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-11-05 13:30:56.842203
1294	6	create	Fee payment: Tuition - $30000	fees	410	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 13:43:30.819156
1295	6	create	Fee payment: Tuition - $30000	fees	409	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 13:44:03.534978
1296	6	create	Fee payment: Tuition - $20000	fees	398	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 13:45:05.157831
1297	6	create	Fee payment: Tuition - $20000	fees	391	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 13:45:27.408621
1298	6	create	Fee payment: Tuition - $20000	fees	391	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 13:45:28.772071
1299	6	create	Fee payment: Tuition - $30000	fees	390	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 13:45:49.456751
1300	6	create	Fee payment: Tuition - $50000	fees	389	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 13:46:08.744784
1301	6	create	Fee payment: Tuition - $20000	fees	397	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 13:46:31.949596
1302	6	create	Fee payment: Tuition - $20000	fees	395	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 13:47:21.917598
1303	6	create	Fee payment: Tuition - $20000	fees	395	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 13:47:22.115661
1304	6	create	Fee payment: Tuition - $20000	fees	394	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 13:47:51.498689
1305	6	create	Fee payment: Tuition - $50000	fees	393	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 13:48:12.558709
1306	6	create	Fee payment: Tuition - $20000	fees	392	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 13:48:36.56325
1307	6	create	Fee payment: Tuition - $40000	fees	396	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 13:48:57.596685
1308	6	create	Fee payment: Tuition - $50000	fees	399	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 13:49:24.404902
1309	6	create	Fee payment: Tuition - $20000	fees	404	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 13:49:46.78375
1310	6	create	Fee payment: Tuition - $50000	fees	403	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 13:50:06.549696
1311	6	create	Fee payment: Tuition - $50000	fees	400	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 13:50:29.083344
1312	6	create	Fee payment: Tuition - $50000	fees	402	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 13:50:51.819568
1313	2	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-11-05 14:09:39.352977
1314	6	create	Fee payment: Tuition - $50000	fees	401	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 14:35:14.39892
1315	6	create	Fee payment: Tuition - $20000	fees	405	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 14:35:55.429715
1316	6	create	Fee payment: Tuition - $20000	fees	406	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 14:36:31.339388
1317	6	create	Fee payment: Tuition - $25000	fees	407	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 14:36:57.747912
1318	6	create	Fee payment: Tuition - $50000	fees	408	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 14:37:37.762534
1319	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-11-05 14:49:16.764581
1320	6	create	Fee payment: Tuition - $10000	fees	445	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 14:49:43.390989
1321	6	create	Fee payment: Tuition - $10000	fees	442	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 14:50:58.191767
1322	6	create	Fee payment: Tuition - $20000	fees	254	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 14:51:55.554386
1323	6	create	Fee payment: Tuition - $20000	fees	254	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 14:52:19.42438
1324	6	create	Fee payment: Tuition - $20000	fees	336	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 14:53:00.770438
1325	6	create	Fee payment: Tuition - $50000	fees	411	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 14:53:35.607425
1326	6	create	Fee payment: Tuition - $50000	fees	412	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 14:56:29.941155
1327	6	create	Fee payment: Tuition - $15000	fees	419	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 14:57:19.323204
1328	6	create	Fee payment: Tuition - $50000	fees	446	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 14:57:49.319444
1329	6	create	Fee payment: Tuition - $50000	fees	446	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 14:57:54.390552
1330	6	update	Reconciled Tuition to 50000	fees	446	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 14:58:18.33161
1331	6	create	Fee payment: Tuition - $50000	fees	443	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 14:59:09.844534
1332	6	create	Fee payment: Tuition - $20000	fees	444	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 15:00:03.922053
1333	6	create	Fee payment: Tuition - $20000	fees	444	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 15:00:09.858981
1334	6	update	Reconciled Tuition to 20000	fees	444	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 15:00:25.976891
1335	6	create	Fee payment: Tuition - $50000	fees	414	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 15:03:02.569398
1336	6	create	Fee payment: Tuition - $20000	fees	415	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 15:03:40.479706
1337	6	create	Fee payment: Tuition - $50000	fees	447	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 15:04:11.394917
1338	6	create	Fee payment: Tuition - $20000	fees	416	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 15:05:08.095644
1339	6	create	Fee payment: Tuition - $10000	fees	417	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 15:05:35.221372
1340	6	create	Fee payment: Tuition - $30000	fees	237	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 15:06:25.125896
1341	6	create	Fee payment: Tuition - $10000	fees	386	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 15:07:32.795683
1342	6	create	Fee payment: Tuition - $70000	fees	387	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 15:08:10.359257
1343	6	create	Fee payment: Tuition - $10000	fees	418	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 15:09:42.643173
1344	6	create	Fee payment: Tuition - $23000	fees	420	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 15:12:25.094665
1345	6	create	Fee payment: Tuition - $20000	fees	421	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 15:12:54.245823
1346	6	create	Fee payment: Tuition - $20000	fees	422	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 15:13:47.079889
1347	6	create	Fee payment: Tuition - $23000	fees	423	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 15:14:33.122259
1348	6	create	Fee payment: Tuition - $15000	fees	426	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 15:15:12.568248
1349	6	create	Fee payment: Tuition - $33000	fees	430	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 15:16:36.189512
1350	6	create	Fee payment: Tuition - $30000	fees	429	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 15:17:16.048669
1351	6	create	Fee payment: Tuition - $20000	fees	431	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 15:18:00.82651
1352	6	create	Fee payment: Tuition - $20000	fees	431	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 15:18:01.252087
1353	6	update	Reconciled Tuition to 20000	fees	431	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 15:18:46.989893
1354	6	create	Fee payment: Tuition - $83000	fees	427	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 15:19:35.601049
1355	6	create	Fee payment: Tuition - $27000	fees	428	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 15:20:14.59622
1356	6	create	Fee payment: Tuition - $25000	fees	438	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 15:20:54.303769
1357	6	create	Fee payment: Tuition - $23000	fees	439	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 15:21:25.633139
1358	6	create	Fee payment: Tuition - $100000	fees	440	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 15:22:08.400447
1359	6	create	Fee payment: Tuition - $50000	fees	441	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 15:22:40.906755
1360	6	create	Fee payment: Tuition - $50000	fees	441	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 15:22:53.642202
1361	6	update	Reconciled Tuition to 50000	fees	441	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 15:23:15.11522
1362	6	create	Fee payment: Tuition - $100000	fees	432	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 15:24:11.504549
1363	6	create	Fee payment: Tuition - $50000	fees	433	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 15:24:56.166866
1364	6	create	Fee payment: Tuition - $100000	fees	437	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 15:25:34.04777
1365	6	create	Fee payment: Tuition - $50000	fees	435	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 15:26:12.988762
1366	6	create	Fee payment: Tuition - $30000	fees	436	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 15:27:06.293796
1367	6	create	Fee payment: Tuition - $60000	fees	448	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-05 15:38:49.3788
1368	2	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-11-05 15:53:50.310727
1369	2	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-11-05 15:57:08.277104
1370	2	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-11-05 16:05:41.667831
1371	7	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-11-05 17:15:44.348015
1372	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-11-06 07:05:07.154626
1373	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-06 07:12:50.944849
1374	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-06 08:33:22.598136
1375	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-11-06 09:14:44.960901
1376	2	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-11-06 13:36:10.975462
1377	18	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-11-06 13:38:04.31312
1378	2	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-11-06 13:43:38.083414
1379	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-06 13:51:43.677039
1380	2	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-11-06 14:02:36.344132
1381	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-06 14:12:45.481483
1382	2	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-11-06 14:31:37.495303
1383	2	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-11-06 15:49:41.400842
1384	7	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-11-06 16:09:32.910244
1385	2	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-11-06 16:18:29.412497
1386	33	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-11-07 06:23:28.971242
1387	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-11-07 07:49:33.862166
1388	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-07 09:03:12.791468
1389	45	create	Created user: Prof123	user	45	Prof123	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-11-07 09:15:35.423741
1390	15	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-11-07 09:15:48.145716
1391	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-11-07 09:21:59.580642
1392	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-11-07 09:39:24.142545
1393	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-11-07 09:50:39.914667
1394	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-11-07 11:42:07.437422
1395	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-11-07 13:43:20.082134
1396	2	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-11-07 13:48:32.577837
1397	2	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-11-07 14:02:55.86545
1398	7	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-07 18:29:08.231715
1399	2	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	2025-11-07 19:32:55.021124
1400	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	2025-11-08 01:21:06.752031
1401	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	2025-11-08 01:22:29.486289
1402	2	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	2025-11-08 07:48:50.512553
1403	2	update	Updated user: Che	user	36	Che	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	2025-11-08 07:50:07.119047
1404	2	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	2025-11-08 07:50:46.295464
1405	46	create	Created user: Kum	user	46	Kum	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	2025-11-08 07:53:44.631194
1406	46	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	2025-11-08 07:54:02.337083
1407	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-08 08:02:35.000026
1408	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-11-08 08:06:36.274155
1409	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	2025-11-08 08:35:15.398076
1410	20	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-08 12:00:44.021869
1411	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	2025-11-08 14:52:49.349464
1412	1	login	User logged in successfully	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	2025-11-08 19:40:43.247817
1413	1	login	User logged in successfully	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	2025-11-08 20:05:08.152711
1414	7	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-09 00:44:20.047792
1415	7	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-09 02:07:02.546978
1416	20	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-09 08:46:14.026068
1417	20	create	Uploaded lesson plan: Introduction to civil engineering building construction 	lesson_plan	58	Introduction to civil engineering building construction 	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-09 09:57:27.283649
1418	20	create	Uploaded lesson plan: Introduction to soils 	lesson_plan	59	Introduction to soils 	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-09 09:58:11.288583
1419	20	create	Uploaded lesson plan: Introduction and basic concept of drawing 	lesson_plan	60	Introduction and basic concept of drawing 	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-09 10:23:15.793215
1420	20	create	Uploaded lesson plan: Introduction to survey 	lesson_plan	61	Introduction to survey 	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-09 10:47:32.914187
1421	20	create	Uploaded lesson plan: Introduction to soils and materials (ITVEE)	lesson_plan	62	Introduction to soils and materials (ITVEE)	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-09 10:49:37.540456
1422	2	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	2025-11-09 13:59:22.048888
1424	20	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-09 15:18:33.570061
1425	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	2025-11-09 18:21:14.031021
1426	20	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-09 18:38:56.781396
1427	20	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-09 18:48:58.591712
1428	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-11-09 23:24:51.13328
1429	20	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-10 03:08:34.725036
1430	20	create	Uploaded lesson plan: Atterberg's limits test/said equivalent test 	lesson_plan	63	Atterberg's limits test/said equivalent test 	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-10 03:15:10.125184
1431	1	login	User logged in successfully	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	2025-11-10 07:37:17.608964
1432	33	login	User logged in successfully	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	2025-11-10 07:40:46.76205
1433	1	login	User logged in successfully	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	2025-11-10 07:43:33.510713
1434	17	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-10 10:36:38.858839
1435	20	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-10 10:44:55.127964
1436	1	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-10 11:00:39.541123
1437	25	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-11-10 16:04:26.071135
1438	25	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-11-10 16:05:45.037581
1439	1	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-10 16:08:38.033336
1440	33	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-10 16:10:27.652542
1441	1	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-10 16:11:25.121943
1442	9	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	2025-11-10 17:40:43.417717
1443	20	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-10 18:24:00.040893
1444	35	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-11-11 06:34:32.941115
1445	13	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2025-11-11 07:32:36.553539
1447	33	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	2025-11-11 10:28:39.507069
1448	12	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (iPhone; CPU iPhone OS 17_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.7 Mobile/15E148 Safari/604.1	2025-11-11 10:50:47.073674
1449	12	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (iPhone; CPU iPhone OS 17_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.7 Mobile/15E148 Safari/604.1	2025-11-11 10:51:44.616681
1450	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-11-11 10:55:09.259788
1451	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-11-11 11:16:35.911779
1452	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	2025-11-11 11:58:59.957334
1453	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	2025-11-11 12:05:55.999361
1454	17	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-11 15:00:26.63369
1455	23	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (iPhone; CPU iPhone OS 17_6_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.6 Mobile/15E148 Safari/604.1	2025-11-11 15:01:00.458518
1456	17	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-11 15:10:55.619106
1457	46	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	2025-11-11 15:42:04.858035
1458	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	2025-11-11 15:43:13.994654
1459	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-12 08:11:28.79302
1460	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-12 08:30:34.737416
1461	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-12 08:46:17.041093
1462	46	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-12 08:49:32.530386
1463	46	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-12 09:36:18.336956
1464	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-12 09:49:31.614381
1465	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	2025-11-12 10:39:40.073938
1466	12	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (iPhone; CPU iPhone OS 17_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.7 Mobile/15E148 Safari/604.1	2025-11-12 10:44:43.579522
1467	12	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (iPhone; CPU iPhone OS 17_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.7 Mobile/15E148 Safari/604.1	2025-11-12 10:45:36.594953
1468	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-12 10:52:54.995128
1469	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-12 10:57:08.932551
1470	47	create	Created user: Ringo kimbo	user	47	Ringo kimbo	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-12 11:32:43.306191
1471	17	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-12 12:20:43.983598
1472	17	create	Uploaded lesson plan: Workshop processes ATVEE	lesson_plan	64	Workshop processes ATVEE	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-12 12:21:40.281375
1473	17	create	Uploaded lesson plan: Workshop processes CL1-ITVEE	lesson_plan	65	Workshop processes CL1-ITVEE	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-12 12:22:30.14406
1474	17	create	Uploaded lesson plan: Sheet metal works CL1-ITVEE 	lesson_plan	66	Sheet metal works CL1-ITVEE 	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-12 12:23:29.860823
1475	17	create	Uploaded lesson plan: Sheet metal construction drawing CL1-ITVEE 	lesson_plan	67	Sheet metal construction drawing CL1-ITVEE 	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-12 12:23:55.031625
1476	17	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-12 12:31:06.390604
1477	12	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (iPhone; CPU iPhone OS 17_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.7 Mobile/15E148 Safari/604.1	2025-11-13 01:46:54.434211
1478	12	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (iPhone; CPU iPhone OS 17_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.7 Mobile/15E148 Safari/604.1	2025-11-13 01:48:44.742833
1479	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-13 10:14:47.1334
1480	6	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 10:37:44.325889
1481	6	create	Fee payment: Tuition - $60000	fees	9	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 10:42:07.18005
1482	6	create	Fee payment: Tuition - $80000	fees	10	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 10:42:42.789314
1483	6	create	Fee payment: Tuition - $50000	fees	13	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 10:43:26.423561
1484	6	create	Fee payment: Tuition - $40000	fees	58	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 10:44:02.062707
1485	6	create	Fee payment: Tuition - $20000	fees	59	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 10:44:30.606836
1486	6	create	Fee payment: Tuition - $30000	fees	18	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 10:45:01.332702
1487	6	create	Fee payment: Tuition - $30000	fees	35	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 10:45:38.109603
1488	6	create	Fee payment: Tuition - $20000	fees	449	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 10:46:39.01362
1489	6	create	Fee payment: Tuition - $10000	fees	47	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 10:47:27.685975
1490	6	create	Fee payment: Tuition - $30000	fees	108	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 10:50:48.976376
1491	6	create	Fee payment: Tuition - $30000	fees	115	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 10:51:31.102722
1492	6	create	Fee payment: Tuition - $30000	fees	116	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 10:51:42.972528
1493	6	create	Fee payment: Tuition - $40000	fees	450	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 10:52:23.140105
1494	6	create	Fee payment: Tuition - $70000	fees	451	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 10:53:01.493844
1495	6	create	Fee payment: Tuition - $40000	fees	454	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 10:53:46.290941
1496	6	create	Fee payment: Tuition - $20000	fees	123	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 10:54:25.16872
1497	6	create	Fee payment: Tuition - $20000	fees	127	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 10:56:23.377095
1498	6	create	Fee payment: Tuition - $60000	fees	453	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 10:56:58.749802
1499	6	create	Fee payment: Tuition - $60000	fees	455	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 10:57:20.418478
1500	6	create	Fee payment: Tuition - $10000	fees	210	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 10:58:08.526078
1501	6	create	Fee payment: Tuition - $20000	fees	239	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 10:58:35.948933
1502	6	create	Fee payment: Tuition - $20000	fees	233	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 10:59:06.782698
1503	6	create	Fee payment: Tuition - $60000	fees	279	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 10:59:46.981537
1504	6	create	Fee payment: Tuition - $20000	fees	303	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 11:00:34.139541
1505	6	create	Fee payment: Tuition - $20000	fees	458	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 11:01:57.928432
1506	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	2025-11-13 11:03:00.257953
1507	6	update	Reconciled Tuition to 20000	fees	391	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 11:03:25.826259
1508	6	create	Fee payment: Tuition - $30000	fees	63	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 11:07:04.201586
1509	6	create	Fee payment: Tuition - $35000	fees	65	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 11:08:08.175677
1510	6	create	Fee payment: Tuition - $50000	fees	394	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 11:12:10.321024
1511	6	create	Fee payment: Tuition - $30000	fees	405	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 11:12:50.998737
1512	6	create	Fee payment: Tuition - $20000	fees	457	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 11:13:23.07637
1513	6	create	Fee payment: Tuition - $20000	fees	456	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 11:13:57.106752
1514	6	create	Fee payment: Tuition - $50000	fees	470	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 11:14:17.043957
1515	6	create	Fee payment: Tuition - $15000	fees	70	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 11:15:07.786749
1516	6	create	Fee payment: Tuition - $10000	fees	328	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 11:15:59.186405
1517	6	create	Fee payment: Tuition - $50000	fees	262	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 11:16:25.727754
1518	6	create	Fee payment: Tuition - $25000	fees	5	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 11:17:08.0549
1519	6	create	Fee payment: Tuition - $20000	fees	459	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 11:17:32.171554
1520	6	create	Fee payment: Tuition - $50000	fees	489	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 11:18:07.908673
1521	6	create	Fee payment: Tuition - $30000	fees	72	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 11:21:45.2146
1522	6	create	Fee payment: Tuition - $50000	fees	75	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 11:22:18.563681
1523	6	create	Fee payment: Tuition - $50000	fees	141	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 11:23:06.440881
1524	6	create	Fee payment: Tuition - $50000	fees	471	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 11:23:50.579809
1525	6	create	Fee payment: Tuition - $50000	fees	472	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 11:24:15.310751
1526	6	create	Fee payment: Tuition - $20000	fees	475	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 11:24:35.102553
1527	6	create	Fee payment: Tuition - $50000	fees	146	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 11:25:23.871251
1528	6	create	Fee payment: Tuition - $10000	fees	147	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 11:25:45.469847
1529	6	create	Fee payment: Tuition - $50000	fees	202	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 11:26:11.44146
1530	6	create	Fee payment: Tuition - $30000	fees	322	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 11:26:38.443896
1531	6	create	Fee payment: Tuition - $30000	fees	249	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 11:27:00.664444
1532	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-13 11:27:21.305551
1533	6	create	Fee payment: Tuition - $30000	fees	323	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 11:27:39.632875
1534	6	create	Fee payment: Tuition - $40000	fees	326	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 11:28:13.298781
1535	6	create	Fee payment: Tuition - $30000	fees	327	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 11:28:43.606524
1536	6	create	Fee payment: Tuition - $50000	fees	476	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 11:29:11.826539
1537	6	create	Fee payment: Tuition - $10000	fees	332	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 11:30:12.356686
1538	6	create	Fee payment: Tuition - $10000	fees	206	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 11:32:31.301104
1539	6	create	Fee payment: Tuition - $50000	fees	462	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 11:32:57.986146
1540	6	create	Fee payment: Tuition - $30000	fees	461	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 11:33:29.922728
1541	6	create	Fee payment: Tuition - $15000	fees	76	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 11:33:56.966179
1542	6	create	Fee payment: Tuition - $30000	fees	154	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 11:34:28.772241
1543	6	create	Fee payment: Tuition - $30000	fees	155	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 11:34:47.700154
1544	6	create	Fee payment: Tuition - $30000	fees	344	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 11:35:16.555992
1545	6	create	Fee payment: Tuition - $20000	fees	463	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 11:35:43.509694
1546	6	create	Fee payment: Tuition - $15000	fees	490	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 11:36:13.617335
1547	6	create	Fee payment: Tuition - $20000	fees	158	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 11:37:10.015729
1548	6	create	Fee payment: Tuition - $100000	fees	464	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 11:37:35.183126
1549	6	create	Fee payment: Tuition - $50000	fees	350	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 11:39:11.105062
1550	6	create	Fee payment: Tuition - $10000	fees	215	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 11:39:55.875557
1551	6	create	Fee payment: Tuition - $20000	fees	356	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 11:40:29.598558
1552	6	create	Fee payment: Tuition - $60000	fees	467	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 11:40:52.01776
1553	6	create	Fee payment: Tuition - $50000	fees	468	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 11:41:13.911296
1554	6	create	Fee payment: Tuition - $20000	fees	482	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 11:41:54.265746
1555	6	create	Fee payment: Tuition - $10000	fees	469	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 11:43:05.700851
1556	6	create	Fee payment: Tuition - $50000	fees	93	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 11:43:46.196682
1557	6	create	Fee payment: Tuition - $68000	fees	383	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 11:44:48.894559
1558	6	create	Fee payment: Tuition - $10000	fees	418	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 11:45:17.971624
1559	6	create	Fee payment: Tuition - $25000	fees	484	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 11:45:44.83001
1560	6	create	Fee payment: Tuition - $23000	fees	424	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 11:46:19.453552
1561	6	create	Fee payment: Tuition - $20000	fees	174	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 11:46:40.008654
1562	6	create	Fee payment: Tuition - $30000	fees	138	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 11:47:11.778755
1563	6	create	Fee payment: Tuition - $20000	fees	256	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 11:47:42.211537
1564	6	create	Fee payment: Tuition - $30000	fees	474	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 11:49:51.059692
1565	6	create	Fee payment: Tuition - $15000	fees	100	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 11:50:40.481122
1566	6	create	Fee payment: Tuition - $50000	fees	430	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 11:51:12.422586
1567	6	create	Fee payment: Tuition - $20000	fees	431	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 11:51:38.379571
1568	6	create	Fee payment: Tuition - $60000	fees	488	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 11:52:32.490558
1569	6	create	Fee payment: Tuition - $30000	fees	487	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 11:53:03.577438
1570	6	create	Fee payment: Tuition - $50000	fees	486	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 11:53:36.88269
1571	6	create	Fee payment: Tuition - $50000	fees	485	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 11:54:06.145765
1572	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-13 11:55:03.989995
1573	6	create	Fee payment: Tuition - $95000	fees	491	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 11:58:45.510566
1574	6	create	Fee payment: Tuition - $30000	fees	177	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 12:00:00.3888
1575	6	create	Fee payment: Tuition - $23000	fees	428	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 12:00:58.664854
1576	6	create	Fee payment: Tuition - $80000	fees	439	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 12:01:51.359044
1577	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-13 12:04:18.641746
1578	6	create	Fee payment: Tuition - $20000	fees	492	Tuition	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	2025-11-13 12:04:37.475073
1579	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-13 12:59:24.847827
1580	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Mobile Safari/537.36	2025-11-13 14:06:07.588238
1581	22	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	2025-11-13 14:24:52.995463
1582	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	2025-11-13 14:57:33.205258
1584	22	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	2025-11-13 16:42:26.018513
1585	2	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	2025-11-14 00:13:20.718708
1586	2	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	2025-11-14 00:34:34.920644
1587	2	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	2025-11-14 00:46:58.084545
1588	1	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-14 02:43:18.135351
1589	21	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	2025-11-14 02:49:11.493408
1590	33	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	2025-11-14 02:50:30.497447
1591	1	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-14 02:55:53.046044
1592	21	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-14 03:05:03.411337
1593	21	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	2025-11-14 03:06:51.163763
1594	21	login	User logged in successfully	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-14 03:34:53.347776
1595	1	login	User logged in successfully	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-14 04:50:24.490492
1596	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-14 07:58:07.714174
1597	4	update	Updated user: Ndichia	user	19	Ndichia	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-14 08:45:48.619197
1598	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-14 08:47:18.54096
1599	4	update	Updated user: +123 glein 	user	19	+123 glein 	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-14 08:50:02.154653
1600	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-14 09:07:35.124278
1601	20	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-14 11:30:15.527462
1602	35	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	2025-11-14 11:38:57.436296
1603	25	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-11-14 11:43:23.867914
1604	14	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-14 11:50:34.984114
1605	14	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-11-14 11:51:06.524708
1606	25	create	Uploaded lesson plan: Lesson plan for textile technology ITVEE	lesson_plan	68	Lesson plan for textile technology ITVEE	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-11-14 11:51:27.974022
1607	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-14 11:59:04.753804
1608	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	2025-11-14 11:59:09.71087
1609	25	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	2025-11-14 12:36:50.01423
1610	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-14 12:37:30.926275
1611	2	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	2025-11-14 13:18:06.696153
1612	2	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-14 14:11:39.751461
1613	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-14 14:34:46.538476
1614	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-14 14:51:27.703023
1615	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-14 14:57:03.598699
1616	33	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	2025-11-14 16:48:54.381348
1617	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	2025-11-14 17:33:12.674207
1618	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	2025-11-14 20:22:43.489652
1619	1	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-15 04:41:48.668255
1620	21	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-15 05:46:56.742299
1621	2	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	2025-11-15 06:45:06.930725
1622	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-15 07:15:21.164397
1623	2	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	2025-11-15 07:18:05.962571
1624	48	create	Created user: Ndomenga Dickson 	user	48	Ndomenga Dickson 	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-15 07:19:58.152409
1625	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	2025-11-15 07:49:31.797
1626	49	create	Created user: default 	user	49	default 	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	2025-11-15 07:55:25.225467
1627	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-15 08:18:56.246585
1628	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-15 08:29:32.503478
1629	1	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-15 08:31:52.973247
1630	3	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	2025-11-15 08:50:03.654442
1631	4	login	User logged in successfully	\N	\N	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-15 08:53:10.041916
1632	1	login	User logged in successfully	\N	\N	\N	192.168.0.101	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	2025-11-23 16:10:48.085047
1633	1	login	User logged in successfully	\N	\N	\N	192.168.0.100	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	2025-11-23 16:33:00.616798
1634	1	login	User logged in successfully	\N	\N	\N	192.168.0.100	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	2025-11-23 18:07:21.327928
1635	3	login	User logged in successfully	\N	\N	\N	192.168.0.103	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	2025-11-23 18:08:34.40168
1636	1	login	User logged in successfully	\N	\N	\N	192.168.0.104	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	2025-11-23 19:11:17.726572
\.


--
-- Data for Name: user_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_sessions (id, user_id, session_start, session_end, ip_address, user_agent, status, created_at) FROM stdin;
84	4	2025-09-15 10:14:08.771608	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	active	2025-09-15 10:14:08.771608
85	4	2025-09-15 10:47:38.324803	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	active	2025-09-15 10:47:38.324803
89	4	2025-09-15 10:57:28.603179	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	active	2025-09-15 10:57:28.603179
90	4	2025-09-15 11:04:01.822753	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	active	2025-09-15 11:04:01.822753
91	4	2025-09-15 11:05:36.377708	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	active	2025-09-15 11:05:36.377708
92	3	2025-09-15 11:19:12.117934	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	active	2025-09-15 11:19:12.117934
94	3	2025-09-15 11:24:28.509132	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	active	2025-09-15 11:24:28.509132
95	3	2025-09-15 11:31:59.455239	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	active	2025-09-15 11:31:59.455239
96	3	2025-09-15 11:34:24.276136	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	active	2025-09-15 11:34:24.276136
97	3	2025-09-15 11:42:24.035051	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	active	2025-09-15 11:42:24.035051
98	4	2025-09-15 11:45:08.676879	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	active	2025-09-15 11:45:08.676879
99	4	2025-09-15 11:48:52.669991	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	active	2025-09-15 11:48:52.669991
100	33	2025-09-15 11:57:11.436772	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	active	2025-09-15 11:57:11.436772
101	33	2025-09-15 11:58:11.169389	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	active	2025-09-15 11:58:11.169389
102	33	2025-09-15 12:01:23.820764	\N	31.97.113.198	Mozilla/5.0 (iPhone; CPU iPhone OS 18_6_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/138.0.7204.156 Mobile/15E148 Safari/604.1	active	2025-09-15 12:01:23.820764
103	4	2025-09-15 12:03:59.248446	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	active	2025-09-15 12:03:59.248446
104	3	2025-09-15 12:04:15.594883	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	active	2025-09-15 12:04:15.594883
105	33	2025-09-15 12:04:23.23067	\N	31.97.113.198	Mozilla/5.0 (iPhone; CPU iPhone OS 18_6_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/138.0.7204.156 Mobile/15E148 Safari/604.1	active	2025-09-15 12:04:23.23067
106	34	2025-09-15 12:07:44.33447	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	active	2025-09-15 12:07:44.33447
107	7	2025-09-15 16:38:56.29605	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-09-15 16:38:56.29605
108	4	2025-09-15 18:37:09.335854	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	active	2025-09-15 18:37:09.335854
109	3	2025-09-15 18:38:53.883953	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	active	2025-09-15 18:38:53.883953
110	3	2025-09-15 18:48:05.923832	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	active	2025-09-15 18:48:05.923832
111	3	2025-09-15 18:58:50.505998	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	active	2025-09-15 18:58:50.505998
112	3	2025-09-15 19:04:24.485962	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	active	2025-09-15 19:04:24.485962
113	4	2025-09-15 19:30:06.387025	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	active	2025-09-15 19:30:06.387025
114	3	2025-09-15 19:31:56.753519	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	active	2025-09-15 19:31:56.753519
115	4	2025-09-15 19:40:25.042091	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	active	2025-09-15 19:40:25.042091
116	33	2025-09-15 20:52:18.828718	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	active	2025-09-15 20:52:18.828718
117	33	2025-09-15 21:52:17.89683	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	active	2025-09-15 21:52:17.89683
118	3	2025-09-16 05:18:44.009073	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	active	2025-09-16 05:18:44.009073
119	3	2025-09-16 05:28:33.622037	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	active	2025-09-16 05:28:33.622037
120	4	2025-09-16 08:23:27.191112	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	active	2025-09-16 08:23:27.191112
121	3	2025-09-16 08:39:52.071902	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	active	2025-09-16 08:39:52.071902
122	3	2025-09-16 08:51:57.699101	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	active	2025-09-16 08:51:57.699101
123	3	2025-09-16 09:04:01.249509	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	active	2025-09-16 09:04:01.249509
124	3	2025-09-16 09:04:59.594707	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	active	2025-09-16 09:04:59.594707
125	1	2025-09-16 10:17:27.647506	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-09-16 10:17:27.647506
126	4	2025-09-16 11:11:21.462496	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	active	2025-09-16 11:11:21.462496
127	6	2025-09-16 11:15:20.759614	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	active	2025-09-16 11:15:20.759614
128	3	2025-09-16 11:31:36.025948	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	active	2025-09-16 11:31:36.025948
129	6	2025-09-16 12:22:28.803152	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	active	2025-09-16 12:22:28.803152
130	21	2025-09-16 12:26:40.537038	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-09-16 12:26:40.537038
131	6	2025-09-16 14:58:43.34362	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	active	2025-09-16 14:58:43.34362
132	6	2025-09-16 16:28:20.825673	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	active	2025-09-16 16:28:20.825673
133	7	2025-09-16 16:30:23.257181	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-09-16 16:30:23.257181
134	3	2025-09-16 16:35:11.033634	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	active	2025-09-16 16:35:11.033634
135	23	2025-09-16 16:39:19.33716	\N	31.97.113.198	Mozilla/5.0 (iPhone; CPU iPhone OS 17_6_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.6 Mobile/15E148 Safari/604.1	active	2025-09-16 16:39:19.33716
136	6	2025-09-16 16:51:30.359216	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	active	2025-09-16 16:51:30.359216
137	21	2025-09-16 17:48:16.882222	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	active	2025-09-16 17:48:16.882222
138	21	2025-09-16 17:48:51.471113	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-09-16 17:48:51.471113
139	21	2025-09-16 18:10:46.858472	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	active	2025-09-16 18:10:46.858472
140	7	2025-09-16 19:03:52.824227	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-09-16 19:03:52.824227
141	7	2025-09-16 19:21:34.040295	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	active	2025-09-16 19:21:34.040295
142	21	2025-09-16 20:03:01.872979	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-09-16 20:03:01.872979
143	6	2025-09-16 20:26:40.150285	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	active	2025-09-16 20:26:40.150285
144	6	2025-09-16 20:32:38.456753	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	active	2025-09-16 20:32:38.456753
145	6	2025-09-16 20:38:50.963967	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	active	2025-09-16 20:38:50.963967
146	7	2025-09-16 20:45:23.857182	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	active	2025-09-16 20:45:23.857182
147	6	2025-09-16 20:48:25.27325	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	active	2025-09-16 20:48:25.27325
148	7	2025-09-16 23:05:54.092982	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-09-16 23:05:54.092982
149	1	2025-09-17 01:36:27.249242	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-09-17 01:36:27.249242
150	34	2025-09-17 02:58:05.767952	\N	31.97.113.198	Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1	active	2025-09-17 02:58:05.767952
151	7	2025-09-17 08:07:49.866297	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-09-17 08:07:49.866297
152	7	2025-09-17 08:20:39.56989	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	active	2025-09-17 08:20:39.56989
153	7	2025-09-17 08:29:09.157184	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-09-17 08:29:09.157184
154	7	2025-09-17 08:37:54.035511	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-09-17 08:37:54.035511
155	7	2025-09-17 09:12:44.9251	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-09-17 09:12:44.9251
156	6	2025-09-17 11:03:24.019987	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-09-17 11:03:24.019987
157	6	2025-09-17 14:17:06.471417	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-09-17 14:17:06.471417
158	4	2025-09-17 14:18:50.006346	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	active	2025-09-17 14:18:50.006346
159	3	2025-09-17 15:53:01.310069	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	active	2025-09-17 15:53:01.310069
160	3	2025-09-17 19:11:08.262191	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	active	2025-09-17 19:11:08.262191
161	3	2025-09-17 19:19:10.810447	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	active	2025-09-17 19:19:10.810447
162	3	2025-09-17 19:36:36.224617	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	active	2025-09-17 19:36:36.224617
163	4	2025-09-17 19:55:08.666972	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	active	2025-09-17 19:55:08.666972
164	3	2025-09-17 19:59:39.102301	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	active	2025-09-17 19:59:39.102301
165	9	2025-09-17 20:07:15.720052	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	active	2025-09-17 20:07:15.720052
166	7	2025-09-18 07:35:12.023783	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-09-18 07:35:12.023783
167	33	2025-09-18 09:42:53.176996	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	active	2025-09-18 09:42:53.176996
168	7	2025-09-18 10:45:01.057876	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-09-18 10:45:01.057876
169	3	2025-09-18 19:49:07.681376	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	active	2025-09-18 19:49:07.681376
170	4	2025-09-19 10:56:59.460643	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	active	2025-09-19 10:56:59.460643
171	3	2025-09-19 11:19:32.316537	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	active	2025-09-19 11:19:32.316537
172	6	2025-09-19 12:11:28.366177	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-09-19 12:11:28.366177
173	6	2025-09-19 12:11:40.83884	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-09-19 12:11:40.83884
174	6	2025-09-19 12:11:57.972734	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-09-19 12:11:57.972734
175	6	2025-09-19 12:26:38.134233	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-09-19 12:26:38.134233
176	6	2025-09-20 07:12:05.558454	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-09-20 07:12:05.558454
177	4	2025-09-20 07:32:01.154506	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	active	2025-09-20 07:32:01.154506
178	25	2025-09-20 08:00:21.283198	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	active	2025-09-20 08:00:21.283198
179	25	2025-09-20 08:01:10.07078	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	active	2025-09-20 08:01:10.07078
180	25	2025-09-20 08:02:02.613386	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	active	2025-09-20 08:02:02.613386
181	4	2025-09-20 09:23:24.241262	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	active	2025-09-20 09:23:24.241262
182	35	2025-09-20 09:27:16.343758	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-09-20 09:27:16.343758
183	4	2025-09-20 10:07:23.36153	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	active	2025-09-20 10:07:23.36153
184	4	2025-09-20 11:07:22.452336	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	active	2025-09-20 11:07:22.452336
185	4	2025-09-20 11:09:05.38589	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	active	2025-09-20 11:09:05.38589
186	6	2025-09-20 11:30:58.427429	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	active	2025-09-20 11:30:58.427429
187	6	2025-09-20 11:52:49.681713	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-09-20 11:52:49.681713
188	4	2025-09-20 14:00:13.310423	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	active	2025-09-20 14:00:13.310423
189	3	2025-09-20 14:22:48.444061	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	active	2025-09-20 14:22:48.444061
190	2	2025-09-21 12:58:45.463239	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	active	2025-09-21 12:58:45.463239
191	23	2025-09-21 13:20:39.798528	\N	31.97.113.198	Mozilla/5.0 (iPhone; CPU iPhone OS 17_6_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.6 Mobile/15E148 Safari/604.1	active	2025-09-21 13:20:39.798528
192	7	2025-09-21 20:26:49.933393	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-09-21 20:26:49.933393
193	33	2025-09-22 16:28:31.451463	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	active	2025-09-22 16:28:31.451463
194	3	2025-09-23 03:02:43.971636	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	active	2025-09-23 03:02:43.971636
195	6	2025-09-23 08:29:53.66706	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-09-23 08:29:53.66706
196	35	2025-09-23 14:53:33.255068	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-09-23 14:53:33.255068
197	33	2025-09-23 19:39:17.689752	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	active	2025-09-23 19:39:17.689752
198	22	2025-09-23 20:01:11.48327	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	active	2025-09-23 20:01:11.48327
199	4	2025-09-24 08:54:04.097366	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	active	2025-09-24 08:54:04.097366
200	17	2025-09-24 09:05:18.105599	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-09-24 09:05:18.105599
201	33	2025-09-24 10:06:03.396258	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	active	2025-09-24 10:06:03.396258
202	33	2025-09-24 11:56:46.590428	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	active	2025-09-24 11:56:46.590428
203	1	2025-09-24 12:05:59.815956	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-09-24 12:05:59.815956
204	33	2025-09-24 12:46:18.0892	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36 OPR/120.0.0.0	active	2025-09-24 12:46:18.0892
205	33	2025-09-24 12:46:48.772207	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36 OPR/120.0.0.0	active	2025-09-24 12:46:48.772207
206	33	2025-09-24 12:47:12.274416	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	active	2025-09-24 12:47:12.274416
207	7	2025-09-24 15:01:50.796696	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-09-24 15:01:50.796696
208	22	2025-09-24 18:04:40.531345	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	active	2025-09-24 18:04:40.531345
209	33	2025-09-24 18:09:05.416827	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-09-24 18:09:05.416827
210	33	2025-09-24 18:10:33.888626	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-09-24 18:10:33.888626
211	4	2025-09-24 18:21:25.608545	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	active	2025-09-24 18:21:25.608545
212	7	2025-09-24 18:26:51.887075	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-09-24 18:26:51.887075
213	6	2025-09-24 18:27:04.910626	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-09-24 18:27:04.910626
214	4	2025-09-24 18:28:30.741476	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	active	2025-09-24 18:28:30.741476
215	20	2025-09-24 18:36:17.446579	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-09-24 18:36:17.446579
216	20	2025-09-24 18:37:37.295888	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-09-24 18:37:37.295888
217	20	2025-09-24 18:40:53.823516	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	active	2025-09-24 18:40:53.823516
218	6	2025-09-24 18:41:13.680065	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-09-24 18:41:13.680065
219	6	2025-09-24 19:25:18.34608	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-09-24 19:25:18.34608
220	33	2025-09-24 19:34:03.102118	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	active	2025-09-24 19:34:03.102118
221	22	2025-09-24 19:44:20.49951	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	active	2025-09-24 19:44:20.49951
222	22	2025-09-25 04:26:36.46599	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	active	2025-09-25 04:26:36.46599
223	33	2025-09-25 10:58:18.588254	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	active	2025-09-25 10:58:18.588254
224	33	2025-09-25 15:12:14.630062	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	active	2025-09-25 15:12:14.630062
225	6	2025-09-25 16:27:29.713863	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-09-25 16:27:29.713863
226	6	2025-09-25 17:08:47.56078	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-09-25 17:08:47.56078
227	22	2025-09-25 18:01:42.887253	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	active	2025-09-25 18:01:42.887253
228	3	2025-09-25 18:33:17.008037	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	active	2025-09-25 18:33:17.008037
229	6	2025-09-26 06:52:49.298766	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-09-26 06:52:49.298766
230	4	2025-09-26 06:56:30.460793	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	active	2025-09-26 06:56:30.460793
231	6	2025-09-26 06:59:13.502233	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-09-26 06:59:13.502233
232	4	2025-09-26 07:10:02.289288	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	active	2025-09-26 07:10:02.289288
233	1	2025-09-26 11:11:10.025436	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-09-26 11:11:10.025436
234	7	2025-09-26 11:19:28.949627	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-09-26 11:19:28.949627
235	33	2025-09-26 11:21:19.346187	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	active	2025-09-26 11:21:19.346187
236	6	2025-09-26 12:57:51.24438	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-09-26 12:57:51.24438
237	4	2025-09-26 13:00:55.337118	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	active	2025-09-26 13:00:55.337118
238	6	2025-09-27 06:43:00.787502	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-09-27 06:43:00.787502
239	1	2025-09-27 07:34:47.0624	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36 OPR/120.0.0.0	active	2025-09-27 07:34:47.0624
240	2	2025-09-27 07:57:53.260065	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	active	2025-09-27 07:57:53.260065
241	23	2025-09-27 08:35:20.449734	\N	31.97.113.198	Mozilla/5.0 (iPhone; CPU iPhone OS 17_6_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.6 Mobile/15E148 Safari/604.1	active	2025-09-27 08:35:20.449734
242	4	2025-09-27 09:25:47.045573	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	active	2025-09-27 09:25:47.045573
243	20	2025-09-27 09:30:18.975499	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	active	2025-09-27 09:30:18.975499
244	36	2025-09-27 09:44:25.868794	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	active	2025-09-27 09:44:25.868794
245	4	2025-09-27 09:57:40.844588	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	active	2025-09-27 09:57:40.844588
246	36	2025-09-27 09:59:56.561649	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	active	2025-09-27 09:59:56.561649
247	18	2025-09-27 10:35:56.835476	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	active	2025-09-27 10:35:56.835476
248	18	2025-09-27 10:37:13.872784	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	active	2025-09-27 10:37:13.872784
249	18	2025-09-27 10:38:50.931052	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	active	2025-09-27 10:38:50.931052
250	3	2025-09-27 12:41:46.388221	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	active	2025-09-27 12:41:46.388221
251	3	2025-09-27 13:22:20.359727	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	active	2025-09-27 13:22:20.359727
252	3	2025-09-28 05:26:05.903539	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	active	2025-09-28 05:26:05.903539
253	7	2025-09-28 15:45:37.64771	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-09-28 15:45:37.64771
254	15	2025-09-29 10:09:09.764689	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	active	2025-09-29 10:09:09.764689
255	3	2025-09-30 12:53:37.4276	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	active	2025-09-30 12:53:37.4276
256	6	2025-09-30 18:22:40.36861	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-09-30 18:22:40.36861
257	21	2025-09-30 18:33:34.161609	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-09-30 18:33:34.161609
258	21	2025-09-30 19:02:17.840378	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-09-30 19:02:17.840378
259	3	2025-10-01 01:58:14.833058	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	active	2025-10-01 01:58:14.833058
260	3	2025-10-01 06:47:04.098252	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	active	2025-10-01 06:47:04.098252
261	6	2025-10-01 13:50:07.293568	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	active	2025-10-01 13:50:07.293568
262	4	2025-10-01 14:35:28.451384	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	active	2025-10-01 14:35:28.451384
263	6	2025-10-01 14:36:32.589475	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	active	2025-10-01 14:36:32.589475
264	7	2025-10-01 14:45:26.523695	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-10-01 14:45:26.523695
265	21	2025-10-01 14:49:15.508842	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-10-01 14:49:15.508842
266	21	2025-10-01 14:54:14.214004	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	active	2025-10-01 14:54:14.214004
267	6	2025-10-01 15:49:30.442093	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-10-01 15:49:30.442093
268	4	2025-10-01 15:51:11.098571	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-10-01 15:51:11.098571
269	4	2025-10-01 15:55:31.683359	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	active	2025-10-01 15:55:31.683359
270	6	2025-10-01 15:56:35.532965	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-10-01 15:56:35.532965
271	21	2025-10-01 16:19:27.589192	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36 OPR/120.0.0.0	active	2025-10-01 16:19:27.589192
272	21	2025-10-01 21:30:32.837709	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-10-01 21:30:32.837709
273	21	2025-10-02 11:07:28.561399	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	active	2025-10-02 11:07:28.561399
274	21	2025-10-02 11:32:41.59113	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36 OPR/120.0.0.0	active	2025-10-02 11:32:41.59113
275	9	2025-10-03 13:13:48.087971	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	active	2025-10-03 13:13:48.087971
276	18	2025-10-04 05:51:22.24134	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-10-04 05:51:22.24134
277	3	2025-10-04 08:05:17.191047	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	active	2025-10-04 08:05:17.191047
278	2	2025-10-04 08:34:09.337596	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	active	2025-10-04 08:34:09.337596
279	3	2025-10-04 09:33:10.462543	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	active	2025-10-04 09:33:10.462543
280	4	2025-10-04 09:37:14.650898	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-04 09:37:14.650898
281	4	2025-10-04 10:20:05.038676	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-04 10:20:05.038676
282	2	2025-10-04 10:43:44.164724	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	active	2025-10-04 10:43:44.164724
283	6	2025-10-04 10:54:15.807811	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-10-04 10:54:15.807811
284	33	2025-10-04 11:08:18.743727	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	active	2025-10-04 11:08:18.743727
285	18	2025-10-04 13:33:01.350539	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-10-04 13:33:01.350539
286	15	2025-10-04 20:53:36.456791	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/28.0 Chrome/130.0.0.0 Mobile Safari/537.36	active	2025-10-04 20:53:36.456791
287	9	2025-10-05 09:45:01.957055	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	active	2025-10-05 09:45:01.957055
288	33	2025-10-06 09:35:25.506025	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	active	2025-10-06 09:35:25.506025
289	7	2025-10-06 15:36:57.825071	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-10-06 15:36:57.825071
290	7	2025-10-06 15:37:27.824184	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-10-06 15:37:27.824184
291	6	2025-10-06 23:35:09.827872	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	active	2025-10-06 23:35:09.827872
292	3	2025-10-07 08:07:14.568842	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	active	2025-10-07 08:07:14.568842
293	3	2025-10-07 08:12:54.118931	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	active	2025-10-07 08:12:54.118931
294	3	2025-10-07 08:14:43.461753	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	active	2025-10-07 08:14:43.461753
295	2	2025-10-07 12:51:45.238211	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	active	2025-10-07 12:51:45.238211
296	7	2025-10-07 14:33:03.017661	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-07 14:33:03.017661
297	7	2025-10-07 14:36:51.027292	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-07 14:36:51.027292
516	43	2025-11-03 13:04:47.087628	\N	127.0.0.1	axios/1.13.1	active	2025-11-03 13:04:47.087628
298	33	2025-10-07 14:43:36.397637	\N	31.97.113.198	Mozilla/5.0 (iPhone; CPU iPhone OS 18_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1	active	2025-10-07 14:43:36.397637
299	7	2025-10-07 14:45:24.357457	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0	active	2025-10-07 14:45:24.357457
300	7	2025-10-07 14:56:19.087023	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-07 14:56:19.087023
301	22	2025-10-08 07:39:49.90437	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	active	2025-10-08 07:39:49.90437
428	22	2025-10-25 16:27:05.858853	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	active	2025-10-25 16:27:05.858853
302	23	2025-10-08 08:49:58.121922	\N	31.97.113.198	Mozilla/5.0 (iPhone; CPU iPhone OS 17_6_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.6 Mobile/15E148 Safari/604.1	active	2025-10-08 08:49:58.121922
303	7	2025-10-08 08:52:43.318049	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-08 08:52:43.318049
304	23	2025-10-08 08:59:13.302749	\N	31.97.113.198	Mozilla/5.0 (iPhone; CPU iPhone OS 17_6_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.6 Mobile/15E148 Safari/604.1	active	2025-10-08 08:59:13.302749
305	22	2025-10-08 14:13:55.004122	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	active	2025-10-08 14:13:55.004122
306	7	2025-10-08 15:30:20.722429	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-08 15:30:20.722429
307	7	2025-10-08 15:32:48.459243	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	active	2025-10-08 15:32:48.459243
308	6	2025-10-08 15:35:13.617192	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-10-08 15:35:13.617192
309	7	2025-10-08 15:50:20.064429	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0	active	2025-10-08 15:50:20.064429
310	2	2025-10-08 16:48:08.91802	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	active	2025-10-08 16:48:08.91802
311	18	2025-10-08 16:59:21.069398	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-10-08 16:59:21.069398
312	18	2025-10-08 17:06:40.17311	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-10-08 17:06:40.17311
313	22	2025-10-08 17:08:52.205846	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	active	2025-10-08 17:08:52.205846
314	18	2025-10-08 17:56:30.020196	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-10-08 17:56:30.020196
315	33	2025-10-08 18:06:57.33866	\N	31.97.113.198	Mozilla/5.0 (iPhone; CPU iPhone OS 18_6_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/138.0.7204.156 Mobile/15E148 Safari/604.1	active	2025-10-08 18:06:57.33866
316	18	2025-10-08 18:16:12.276569	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-10-08 18:16:12.276569
317	18	2025-10-08 18:20:13.979799	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-10-08 18:20:13.979799
318	22	2025-10-08 18:28:34.729255	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	active	2025-10-08 18:28:34.729255
319	18	2025-10-08 18:29:43.605637	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-10-08 18:29:43.605637
320	18	2025-10-08 18:34:22.267598	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-10-08 18:34:22.267598
321	18	2025-10-08 18:36:04.111825	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-10-08 18:36:04.111825
322	35	2025-10-08 19:07:58.532149	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-10-08 19:07:58.532149
323	33	2025-10-08 19:12:23.454558	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	active	2025-10-08 19:12:23.454558
324	7	2025-10-08 19:13:38.213235	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	active	2025-10-08 19:13:38.213235
325	7	2025-10-08 19:16:52.76897	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-08 19:16:52.76897
326	18	2025-10-08 20:07:44.140803	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-10-08 20:07:44.140803
327	18	2025-10-08 20:08:36.721585	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-10-08 20:08:36.721585
328	9	2025-10-08 20:43:59.040788	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	active	2025-10-08 20:43:59.040788
329	18	2025-10-08 20:45:38.192899	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-10-08 20:45:38.192899
330	18	2025-10-08 20:53:45.067626	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-10-08 20:53:45.067626
331	2	2025-10-08 21:07:15.483107	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	active	2025-10-08 21:07:15.483107
332	18	2025-10-08 21:07:29.802298	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-10-08 21:07:29.802298
333	18	2025-10-08 21:08:32.024356	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-10-08 21:08:32.024356
334	18	2025-10-08 21:11:30.946482	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-10-08 21:11:30.946482
335	22	2025-10-08 21:55:30.682205	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	active	2025-10-08 21:55:30.682205
336	2	2025-10-08 22:03:51.164245	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	active	2025-10-08 22:03:51.164245
337	7	2025-10-09 06:17:11.87721	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-09 06:17:11.87721
338	7	2025-10-09 07:14:39.224881	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-09 07:14:39.224881
339	7	2025-10-09 08:49:26.446007	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-09 08:49:26.446007
340	7	2025-10-09 09:36:30.594397	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0	active	2025-10-09 09:36:30.594397
341	33	2025-10-09 09:47:10.30095	\N	31.97.113.198	Mozilla/5.0 (iPhone; CPU iPhone OS 18_6_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/138.0.7204.156 Mobile/15E148 Safari/604.1	active	2025-10-09 09:47:10.30095
342	34	2025-10-09 10:07:14.882615	\N	31.97.113.198	Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1	active	2025-10-09 10:07:14.882615
343	18	2025-10-09 10:12:38.79484	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-10-09 10:12:38.79484
344	7	2025-10-09 10:39:27.138693	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	active	2025-10-09 10:39:27.138693
345	4	2025-10-09 12:48:31.303769	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	active	2025-10-09 12:48:31.303769
346	2	2025-10-09 13:44:47.122288	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	active	2025-10-09 13:44:47.122288
347	33	2025-10-09 17:48:48.086593	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	active	2025-10-09 17:48:48.086593
348	18	2025-10-09 19:09:26.578048	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-10-09 19:09:26.578048
349	18	2025-10-09 19:13:30.004233	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-10-09 19:13:30.004233
350	7	2025-10-10 11:55:39.598928	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-10 11:55:39.598928
351	1	2025-10-10 15:48:08.980386	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36 OPR/122.0.0.0	active	2025-10-10 15:48:08.980386
352	7	2025-10-10 15:50:57.75351	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-10 15:50:57.75351
353	7	2025-10-10 20:20:12.041983	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-10 20:20:12.041983
354	1	2025-10-10 20:24:38.851259	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-10 20:24:38.851259
355	35	2025-10-10 21:09:45.964274	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-10-10 21:09:45.964274
356	35	2025-10-10 22:30:28.986766	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-10-10 22:30:28.986766
357	2	2025-10-12 19:04:12.69314	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	active	2025-10-12 19:04:12.69314
358	35	2025-10-13 07:13:34.406685	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-10-13 07:13:34.406685
359	6	2025-10-14 13:37:05.178881	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	active	2025-10-14 13:37:05.178881
360	7	2025-10-14 19:33:10.44831	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-14 19:33:10.44831
361	1	2025-10-14 19:33:28.405506	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-14 19:33:28.405506
362	35	2025-10-14 20:18:59.645841	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-10-14 20:18:59.645841
363	6	2025-10-15 09:16:56.371887	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	active	2025-10-15 09:16:56.371887
364	35	2025-10-15 10:54:06.389575	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-10-15 10:54:06.389575
365	2	2025-10-15 12:31:39.043155	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	active	2025-10-15 12:31:39.043155
366	39	2025-10-15 12:42:16.777908	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-15 12:42:16.777908
367	2	2025-10-15 12:43:04.968041	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	active	2025-10-15 12:43:04.968041
368	39	2025-10-15 12:57:08.517502	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-15 12:57:08.517502
369	3	2025-10-15 13:14:13.313466	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	active	2025-10-15 13:14:13.313466
370	33	2025-10-15 18:05:25.37288	\N	31.97.113.198	Mozilla/5.0 (iPhone; CPU iPhone OS 18_6_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/138.0.7204.156 Mobile/15E148 Safari/604.1	active	2025-10-15 18:05:25.37288
371	7	2025-10-15 18:13:40.709667	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-15 18:13:40.709667
372	35	2025-10-15 19:18:16.197449	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-10-15 19:18:16.197449
373	7	2025-10-16 07:12:46.636221	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-16 07:12:46.636221
374	15	2025-10-16 08:44:00.164083	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	active	2025-10-16 08:44:00.164083
375	3	2025-10-16 12:11:19.943435	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	active	2025-10-16 12:11:19.943435
376	3	2025-10-16 12:11:46.911112	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	active	2025-10-16 12:11:46.911112
377	3	2025-10-16 12:15:55.454138	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	active	2025-10-16 12:15:55.454138
378	7	2025-10-16 19:00:18.339039	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-16 19:00:18.339039
379	34	2025-10-17 07:10:29.051026	\N	31.97.113.198	Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1	active	2025-10-17 07:10:29.051026
380	4	2025-10-17 09:47:25.867869	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-17 09:47:25.867869
381	2	2025-10-17 15:20:50.852692	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	active	2025-10-17 15:20:50.852692
382	15	2025-10-17 15:38:09.541947	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	active	2025-10-17 15:38:09.541947
517	43	2025-11-03 13:04:47.667948	\N	127.0.0.1	axios/1.13.1	active	2025-11-03 13:04:47.667948
383	7	2025-10-17 19:26:06.813803	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-17 19:26:06.813803
384	2	2025-10-18 07:49:17.809985	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	active	2025-10-18 07:49:17.809985
385	4	2025-10-18 09:38:45.388277	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-18 09:38:45.388277
386	33	2025-10-18 10:19:22.510837	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	active	2025-10-18 10:19:22.510837
387	15	2025-10-18 11:44:55.303888	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	active	2025-10-18 11:44:55.303888
388	9	2025-10-18 12:26:07.841905	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	active	2025-10-18 12:26:07.841905
389	7	2025-10-18 18:40:02.679045	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-18 18:40:02.679045
390	7	2025-10-19 09:07:29.506087	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-19 09:07:29.506087
391	6	2025-10-19 11:40:01.217851	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-19 11:40:01.217851
392	3	2025-10-20 04:27:39.188876	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	active	2025-10-20 04:27:39.188876
393	2	2025-10-20 11:03:32.009183	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	active	2025-10-20 11:03:32.009183
394	4	2025-10-20 13:10:03.276744	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-20 13:10:03.276744
395	7	2025-10-20 14:25:05.85509	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-20 14:25:05.85509
396	33	2025-10-20 14:29:46.155882	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	active	2025-10-20 14:29:46.155882
397	6	2025-10-20 15:45:15.864717	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-20 15:45:15.864717
398	9	2025-10-21 06:53:31.071604	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	active	2025-10-21 06:53:31.071604
399	4	2025-10-21 09:46:37.107164	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-21 09:46:37.107164
400	35	2025-10-21 12:53:56.588671	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-10-21 12:53:56.588671
401	2	2025-10-21 13:26:33.728525	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	active	2025-10-21 13:26:33.728525
402	2	2025-10-21 14:02:17.467907	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-21 14:02:17.467907
403	7	2025-10-21 14:44:45.861162	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-21 14:44:45.861162
404	2	2025-10-21 15:22:57.031182	\N	31.97.113.198	Mozilla/5.0 (iPhone; CPU iPhone OS 18_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1	active	2025-10-21 15:22:57.031182
405	41	2025-10-21 15:25:11.227759	\N	31.97.113.198	Mozilla/5.0 (iPhone; CPU iPhone OS 18_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1	active	2025-10-21 15:25:11.227759
406	41	2025-10-21 15:25:51.319976	\N	31.97.113.198	Mozilla/5.0 (iPhone; CPU iPhone OS 18_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1	active	2025-10-21 15:25:51.319976
407	2	2025-10-21 15:26:28.316154	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-21 15:26:28.316154
408	20	2025-10-21 15:29:02.223943	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-21 15:29:02.223943
409	1	2025-10-22 05:56:33.006224	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-22 05:56:33.006224
410	4	2025-10-22 06:25:42.539794	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-22 06:25:42.539794
411	41	2025-10-22 07:15:20.688617	\N	31.97.113.198	Mozilla/5.0 (iPhone; CPU iPhone OS 18_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1	active	2025-10-22 07:15:20.688617
412	4	2025-10-22 08:37:44.428866	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-22 08:37:44.428866
413	4	2025-10-22 10:57:41.730611	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-22 10:57:41.730611
414	4	2025-10-22 15:21:39.515353	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-22 15:21:39.515353
415	4	2025-10-22 15:28:39.794699	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-22 15:28:39.794699
416	41	2025-10-22 16:21:08.040707	\N	31.97.113.198	Mozilla/5.0 (iPhone; CPU iPhone OS 18_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1	active	2025-10-22 16:21:08.040707
417	7	2025-10-22 17:01:06.878991	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-22 17:01:06.878991
418	7	2025-10-22 17:05:37.711186	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0	active	2025-10-22 17:05:37.711186
419	7	2025-10-22 21:19:49.010465	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-22 21:19:49.010465
420	7	2025-10-23 18:47:02.098975	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-23 18:47:02.098975
421	4	2025-10-24 08:13:47.760691	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-24 08:13:47.760691
422	33	2025-10-24 11:41:43.038635	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	active	2025-10-24 11:41:43.038635
423	4	2025-10-24 11:56:40.108364	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-24 11:56:40.108364
424	7	2025-10-24 21:01:53.134344	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-24 21:01:53.134344
468	7	2025-10-30 10:35:26.792155	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0	active	2025-10-30 10:35:26.792155
425	4	2025-10-25 07:07:29.421739	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-25 07:07:29.421739
426	4	2025-10-25 07:46:58.273213	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-25 07:46:58.273213
427	4	2025-10-25 07:47:24.199824	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-25 07:47:24.199824
429	33	2025-10-26 09:59:21.92062	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	active	2025-10-26 09:59:21.92062
430	7	2025-10-26 15:49:11.054841	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-26 15:49:11.054841
431	1	2025-10-27 06:41:30.829258	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	active	2025-10-27 06:41:30.829258
432	6	2025-10-27 07:31:32.304739	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-27 07:31:32.304739
433	4	2025-10-27 07:34:01.422742	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-27 07:34:01.422742
434	7	2025-10-27 12:16:05.10304	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-27 12:16:05.10304
435	4	2025-10-28 07:20:08.918386	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-28 07:20:08.918386
436	4	2025-10-28 12:00:36.629706	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-28 12:00:36.629706
437	2	2025-10-28 13:09:51.943198	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	active	2025-10-28 13:09:51.943198
438	4	2025-10-28 13:34:25.360875	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-28 13:34:25.360875
439	4	2025-10-28 13:42:46.699399	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-28 13:42:46.699399
440	4	2025-10-28 15:19:49.09469	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-28 15:19:49.09469
441	4	2025-10-28 15:35:37.029962	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-28 15:35:37.029962
442	2	2025-10-28 15:40:42.190764	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	active	2025-10-28 15:40:42.190764
443	3	2025-10-28 15:48:37.131881	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	active	2025-10-28 15:48:37.131881
444	7	2025-10-29 03:55:04.857599	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-29 03:55:04.857599
445	35	2025-10-29 06:35:13.280268	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-10-29 06:35:13.280268
446	4	2025-10-29 11:00:26.429279	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-29 11:00:26.429279
447	3	2025-10-29 12:19:18.233502	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	active	2025-10-29 12:19:18.233502
448	2	2025-10-29 13:38:45.671575	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	active	2025-10-29 13:38:45.671575
449	4	2025-10-29 13:44:18.926354	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-29 13:44:18.926354
450	4	2025-10-29 13:46:13.854733	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-29 13:46:13.854733
451	4	2025-10-29 14:04:19.911813	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-29 14:04:19.911813
452	4	2025-10-29 14:05:46.975814	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-29 14:05:46.975814
453	2	2025-10-29 14:11:16.461286	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-29 14:11:16.461286
454	3	2025-10-29 14:32:20.935843	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	active	2025-10-29 14:32:20.935843
455	4	2025-10-29 14:37:35.82038	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-29 14:37:35.82038
456	3	2025-10-29 14:40:41.097776	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	active	2025-10-29 14:40:41.097776
457	4	2025-10-29 14:52:04.228418	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-29 14:52:04.228418
458	3	2025-10-29 15:02:23.679808	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.114 Safari/537.36	active	2025-10-29 15:02:23.679808
459	2	2025-10-29 15:05:53.105613	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	active	2025-10-29 15:05:53.105613
460	3	2025-10-29 15:12:44.369928	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	active	2025-10-29 15:12:44.369928
461	3	2025-10-29 15:44:02.898799	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.114 Safari/537.36	active	2025-10-29 15:44:02.898799
462	7	2025-10-29 18:27:08.707598	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-29 18:27:08.707598
463	7	2025-10-30 05:57:38.236376	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-30 05:57:38.236376
464	15	2025-10-30 07:33:33.537203	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-30 07:33:33.537203
465	4	2025-10-30 09:11:20.027872	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-30 09:11:20.027872
466	36	2025-10-30 09:14:12.197512	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-30 09:14:12.197512
467	4	2025-10-30 10:17:15.14139	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-30 10:17:15.14139
515	43	2025-11-03 13:04:46.495589	\N	127.0.0.1	axios/1.13.1	active	2025-11-03 13:04:46.495589
469	4	2025-10-30 13:16:50.533954	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-30 13:16:50.533954
470	4	2025-10-30 13:30:50.803412	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-30 13:30:50.803412
471	2	2025-10-30 13:43:52.6508	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-30 13:43:52.6508
472	7	2025-10-30 16:29:16.092429	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-30 16:29:16.092429
473	1	2025-10-30 18:41:14.276448	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	active	2025-10-30 18:41:14.276448
474	4	2025-10-31 06:51:45.386748	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-31 06:51:45.386748
475	22	2025-10-31 06:53:28.837489	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	active	2025-10-31 06:53:28.837489
476	6	2025-10-31 09:51:11.55999	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	active	2025-10-31 09:51:11.55999
477	6	2025-10-31 09:55:58.020527	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-31 09:55:58.020527
478	6	2025-10-31 10:01:58.520767	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	active	2025-10-31 10:01:58.520767
479	4	2025-10-31 10:39:08.876527	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-31 10:39:08.876527
480	33	2025-10-31 11:12:14.864479	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	active	2025-10-31 11:12:14.864479
481	4	2025-10-31 11:37:29.437833	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-31 11:37:29.437833
482	6	2025-10-31 12:37:14.163752	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	active	2025-10-31 12:37:14.163752
483	4	2025-10-31 12:47:31.32305	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-31 12:47:31.32305
484	2	2025-10-31 13:45:02.747855	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-31 13:45:02.747855
485	6	2025-10-31 14:05:24.369777	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	active	2025-10-31 14:05:24.369777
486	2	2025-10-31 15:25:09.292033	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	active	2025-10-31 15:25:09.292033
487	6	2025-10-31 18:16:09.109062	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	active	2025-10-31 18:16:09.109062
488	7	2025-10-31 18:29:10.797569	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-31 18:29:10.797569
489	7	2025-10-31 21:55:58.835242	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-10-31 21:55:58.835242
490	3	2025-11-01 00:11:19.718486	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	active	2025-11-01 00:11:19.718486
491	3	2025-11-01 00:15:13.548383	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	active	2025-11-01 00:15:13.548383
492	3	2025-11-01 00:50:58.112379	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	active	2025-11-01 00:50:58.112379
493	3	2025-11-01 00:52:22.339023	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	active	2025-11-01 00:52:22.339023
494	3	2025-11-01 00:57:57.447113	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36	active	2025-11-01 00:57:57.447113
495	2	2025-11-01 06:55:14.529858	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	active	2025-11-01 06:55:14.529858
496	4	2025-11-01 09:08:36.531724	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-11-01 09:08:36.531724
497	4	2025-11-01 11:25:41.922932	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-11-01 11:25:41.922932
498	2	2025-11-01 11:30:24.926219	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36	active	2025-11-01 11:30:24.926219
499	4	2025-11-01 11:33:08.161904	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-11-01 11:33:08.161904
500	7	2025-11-01 14:56:59.699394	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-11-01 14:56:59.699394
501	3	2025-11-02 14:27:57.521994	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	active	2025-11-02 14:27:57.521994
502	20	2025-11-02 15:07:39.005406	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-11-02 15:07:39.005406
503	20	2025-11-02 15:09:28.896153	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-11-02 15:09:28.896153
504	33	2025-11-03 08:17:35.168257	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	active	2025-11-03 08:17:35.168257
505	7	2025-11-03 08:44:53.327669	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-11-03 08:44:53.327669
506	6	2025-11-03 08:46:27.232913	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-11-03 08:46:27.232913
507	7	2025-11-03 08:47:12.410838	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-11-03 08:47:12.410838
508	22	2025-11-03 11:07:42.040883	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	active	2025-11-03 11:07:42.040883
509	1	2025-11-03 11:37:57.491155	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-11-03 11:37:57.491155
510	43	2025-11-03 13:04:43.563377	\N	127.0.0.1	axios/1.13.1	active	2025-11-03 13:04:43.563377
511	43	2025-11-03 13:04:44.120181	\N	127.0.0.1	axios/1.13.1	active	2025-11-03 13:04:44.120181
512	43	2025-11-03 13:04:44.720334	\N	127.0.0.1	axios/1.13.1	active	2025-11-03 13:04:44.720334
513	43	2025-11-03 13:04:45.280045	\N	127.0.0.1	axios/1.13.1	active	2025-11-03 13:04:45.280045
514	43	2025-11-03 13:04:45.927827	\N	127.0.0.1	axios/1.13.1	active	2025-11-03 13:04:45.927827
518	43	2025-11-03 13:04:48.28789	\N	127.0.0.1	axios/1.13.1	active	2025-11-03 13:04:48.28789
519	43	2025-11-03 13:04:48.841452	\N	127.0.0.1	axios/1.13.1	active	2025-11-03 13:04:48.841452
520	43	2025-11-03 13:04:49.400293	\N	127.0.0.1	axios/1.13.1	active	2025-11-03 13:04:49.400293
521	43	2025-11-03 13:04:49.959531	\N	127.0.0.1	axios/1.13.1	active	2025-11-03 13:04:49.959531
522	43	2025-11-03 13:04:50.504235	\N	127.0.0.1	axios/1.13.1	active	2025-11-03 13:04:50.504235
523	43	2025-11-03 13:04:58.857134	\N	127.0.0.1	axios/1.13.1	active	2025-11-03 13:04:58.857134
524	43	2025-11-03 13:05:18.630928	\N	127.0.0.1	axios/1.13.1	active	2025-11-03 13:05:18.630928
525	43	2025-11-03 13:09:44.317049	\N	127.0.0.1	axios/1.13.1	active	2025-11-03 13:09:44.317049
526	43	2025-11-03 13:10:36.569688	\N	127.0.0.1	axios/1.13.1	active	2025-11-03 13:10:36.569688
527	43	2025-11-03 13:21:11.11942	\N	127.0.0.1	axios/1.13.1	active	2025-11-03 13:21:11.11942
528	15	2025-11-03 16:12:22.838903	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-11-03 16:12:22.838903
529	33	2025-11-03 18:00:28.154657	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	active	2025-11-03 18:00:28.154657
530	4	2025-11-04 07:27:38.062431	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-11-04 07:27:38.062431
531	4	2025-11-04 10:05:51.671832	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-11-04 10:05:51.671832
532	15	2025-11-04 11:23:49.880003	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-11-04 11:23:49.880003
533	2	2025-11-04 12:52:48.410014	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	active	2025-11-04 12:52:48.410014
534	4	2025-11-04 13:00:53.694573	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-11-04 13:00:53.694573
535	2	2025-11-04 13:01:30.370775	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	active	2025-11-04 13:01:30.370775
536	2	2025-11-04 13:16:10.266667	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	active	2025-11-04 13:16:10.266667
537	2	2025-11-04 13:26:27.978037	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	active	2025-11-04 13:26:27.978037
538	2	2025-11-04 14:51:35.19337	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-11-04 14:51:35.19337
539	2	2025-11-04 16:08:55.502634	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-11-04 16:08:55.502634
540	2	2025-11-04 18:50:08.488846	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	active	2025-11-04 18:50:08.488846
541	2	2025-11-04 19:20:08.736716	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	active	2025-11-04 19:20:08.736716
542	7	2025-11-04 20:56:40.368396	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-11-04 20:56:40.368396
543	4	2025-11-05 03:50:10.554705	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-11-05 03:50:10.554705
544	3	2025-11-05 04:26:20.632792	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	active	2025-11-05 04:26:20.632792
545	3	2025-11-05 04:30:27.858836	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	active	2025-11-05 04:30:27.858836
546	3	2025-11-05 04:34:07.500783	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	active	2025-11-05 04:34:07.500783
547	3	2025-11-05 04:42:34.423639	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.5060.114 Safari/537.36 Edg/103.0.1264.62	active	2025-11-05 04:42:34.423639
548	4	2025-11-05 06:10:13.798187	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-11-05 06:10:13.798187
549	33	2025-11-05 07:10:11.116404	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	active	2025-11-05 07:10:11.116404
550	4	2025-11-05 10:55:37.264444	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-11-05 10:55:37.264444
551	4	2025-11-05 11:47:14.030608	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-11-05 11:47:14.030608
552	4	2025-11-05 12:35:15.477693	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-11-05 12:35:15.477693
553	6	2025-11-05 12:36:56.807503	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	active	2025-11-05 12:36:56.807503
554	6	2025-11-05 12:37:15.400027	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	active	2025-11-05 12:37:15.400027
555	2	2025-11-05 13:10:55.540354	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-11-05 13:10:55.540354
556	6	2025-11-05 13:15:27.255167	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-11-05 13:15:27.255167
557	6	2025-11-05 13:16:48.287781	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	active	2025-11-05 13:16:48.287781
558	2	2025-11-05 13:19:21.125522	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	active	2025-11-05 13:19:21.125522
559	2	2025-11-05 13:30:56.847786	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-11-05 13:30:56.847786
560	2	2025-11-05 14:09:39.356636	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-11-05 14:09:39.356636
561	4	2025-11-05 14:49:16.767295	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-11-05 14:49:16.767295
562	2	2025-11-05 15:53:50.31423	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-11-05 15:53:50.31423
563	2	2025-11-05 15:57:08.28479	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-11-05 15:57:08.28479
564	2	2025-11-05 16:05:41.670628	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-11-05 16:05:41.670628
565	7	2025-11-05 17:15:44.351933	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-11-05 17:15:44.351933
566	4	2025-11-06 07:05:07.169616	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-11-06 07:05:07.169616
567	4	2025-11-06 07:12:50.949244	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	active	2025-11-06 07:12:50.949244
568	4	2025-11-06 08:33:22.601166	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	active	2025-11-06 08:33:22.601166
569	4	2025-11-06 09:14:44.963585	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-11-06 09:14:44.963585
570	2	2025-11-06 13:36:10.985774	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-11-06 13:36:10.985774
571	18	2025-11-06 13:38:04.314915	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-11-06 13:38:04.314915
572	2	2025-11-06 13:43:38.087883	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-11-06 13:43:38.087883
573	4	2025-11-06 13:51:43.68034	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	active	2025-11-06 13:51:43.68034
574	2	2025-11-06 14:02:36.352129	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-11-06 14:02:36.352129
575	4	2025-11-06 14:12:45.484603	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	active	2025-11-06 14:12:45.484603
576	2	2025-11-06 14:31:37.499124	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-11-06 14:31:37.499124
577	2	2025-11-06 15:49:41.406849	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-11-06 15:49:41.406849
578	7	2025-11-06 16:09:32.917315	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-11-06 16:09:32.917315
579	2	2025-11-06 16:18:29.415711	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-11-06 16:18:29.415711
580	33	2025-11-07 06:23:28.98495	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	active	2025-11-07 06:23:28.98495
581	4	2025-11-07 07:49:33.869078	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-11-07 07:49:33.869078
582	4	2025-11-07 09:03:12.79899	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	active	2025-11-07 09:03:12.79899
583	15	2025-11-07 09:15:48.147269	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-11-07 09:15:48.147269
584	4	2025-11-07 09:21:59.585459	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-11-07 09:21:59.585459
585	4	2025-11-07 09:39:24.147411	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-11-07 09:39:24.147411
586	4	2025-11-07 09:50:39.918239	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-11-07 09:50:39.918239
587	4	2025-11-07 11:42:07.446591	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-11-07 11:42:07.446591
588	4	2025-11-07 13:43:20.086536	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-11-07 13:43:20.086536
589	2	2025-11-07 13:48:32.582215	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-11-07 13:48:32.582215
590	2	2025-11-07 14:02:55.868185	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-11-07 14:02:55.868185
591	7	2025-11-07 18:29:08.243243	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	active	2025-11-07 18:29:08.243243
592	2	2025-11-07 19:32:55.024792	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	active	2025-11-07 19:32:55.024792
593	3	2025-11-08 01:21:06.760787	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	active	2025-11-08 01:21:06.760787
594	3	2025-11-08 01:22:29.491269	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	active	2025-11-08 01:22:29.491269
595	2	2025-11-08 07:48:50.522196	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	active	2025-11-08 07:48:50.522196
596	2	2025-11-08 07:50:46.296673	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	active	2025-11-08 07:50:46.296673
597	46	2025-11-08 07:54:02.338271	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	active	2025-11-08 07:54:02.338271
598	4	2025-11-08 08:02:35.004705	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	active	2025-11-08 08:02:35.004705
599	4	2025-11-08 08:06:36.275673	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-11-08 08:06:36.275673
600	3	2025-11-08 08:35:15.401396	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	active	2025-11-08 08:35:15.401396
601	20	2025-11-08 12:00:44.031341	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	active	2025-11-08 12:00:44.031341
602	3	2025-11-08 14:52:49.355835	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	active	2025-11-08 14:52:49.355835
603	1	2025-11-08 19:40:43.431611	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	active	2025-11-08 19:40:43.431611
604	1	2025-11-08 20:05:08.3096	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	active	2025-11-08 20:05:08.3096
605	7	2025-11-09 00:44:20.05719	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	active	2025-11-09 00:44:20.05719
606	7	2025-11-09 02:07:02.551873	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	active	2025-11-09 02:07:02.551873
607	20	2025-11-09 08:46:14.044276	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	active	2025-11-09 08:46:14.044276
608	2	2025-11-09 13:59:22.054092	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	active	2025-11-09 13:59:22.054092
609	7	2025-11-09 14:52:52.917962	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:144.0) Gecko/20100101 Firefox/144.0	active	2025-11-09 14:52:52.917962
610	20	2025-11-09 15:18:33.573573	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	active	2025-11-09 15:18:33.573573
611	3	2025-11-09 18:21:14.040387	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	active	2025-11-09 18:21:14.040387
612	20	2025-11-09 18:38:56.784595	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	active	2025-11-09 18:38:56.784595
613	20	2025-11-09 18:48:58.594832	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	active	2025-11-09 18:48:58.594832
614	3	2025-11-09 23:24:51.142584	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	active	2025-11-09 23:24:51.142584
615	20	2025-11-10 03:08:34.735306	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	active	2025-11-10 03:08:34.735306
616	1	2025-11-10 07:37:17.757087	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	active	2025-11-10 07:37:17.757087
617	33	2025-11-10 07:40:46.91008	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	active	2025-11-10 07:40:46.91008
618	1	2025-11-10 07:43:33.650271	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	active	2025-11-10 07:43:33.650271
619	17	2025-11-10 10:36:38.866752	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	active	2025-11-10 10:36:38.866752
620	20	2025-11-10 10:44:55.133505	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	active	2025-11-10 10:44:55.133505
621	1	2025-11-10 11:00:39.545513	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	active	2025-11-10 11:00:39.545513
622	25	2025-11-10 16:04:26.079774	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-11-10 16:04:26.079774
623	25	2025-11-10 16:05:45.039245	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-11-10 16:05:45.039245
624	1	2025-11-10 16:08:38.035779	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	active	2025-11-10 16:08:38.035779
625	33	2025-11-10 16:10:27.657064	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	active	2025-11-10 16:10:27.657064
626	1	2025-11-10 16:11:25.123438	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	active	2025-11-10 16:11:25.123438
627	9	2025-11-10 17:40:43.423516	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	active	2025-11-10 17:40:43.423516
628	20	2025-11-10 18:24:00.044019	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	active	2025-11-10 18:24:00.044019
629	35	2025-11-11 06:34:32.958807	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-11-11 06:34:32.958807
630	13	2025-11-11 07:32:36.558907	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	active	2025-11-11 07:32:36.558907
631	7	2025-11-11 10:13:56.139204	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:144.0) Gecko/20100101 Firefox/144.0	active	2025-11-11 10:13:56.139204
632	33	2025-11-11 10:28:39.510522	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	active	2025-11-11 10:28:39.510522
633	12	2025-11-11 10:50:47.080078	\N	31.97.113.198	Mozilla/5.0 (iPhone; CPU iPhone OS 17_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.7 Mobile/15E148 Safari/604.1	active	2025-11-11 10:50:47.080078
634	12	2025-11-11 10:51:44.618986	\N	31.97.113.198	Mozilla/5.0 (iPhone; CPU iPhone OS 17_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.7 Mobile/15E148 Safari/604.1	active	2025-11-11 10:51:44.618986
635	4	2025-11-11 10:55:09.263141	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-11-11 10:55:09.263141
636	4	2025-11-11 11:16:35.914652	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-11-11 11:16:35.914652
637	3	2025-11-11 11:58:59.960767	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	active	2025-11-11 11:58:59.960767
638	3	2025-11-11 12:05:56.012438	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	active	2025-11-11 12:05:56.012438
639	17	2025-11-11 15:00:26.644406	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	active	2025-11-11 15:00:26.644406
640	23	2025-11-11 15:01:00.459896	\N	31.97.113.198	Mozilla/5.0 (iPhone; CPU iPhone OS 17_6_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.6 Mobile/15E148 Safari/604.1	active	2025-11-11 15:01:00.459896
641	17	2025-11-11 15:10:55.622037	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	active	2025-11-11 15:10:55.622037
642	46	2025-11-11 15:42:04.861868	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	active	2025-11-11 15:42:04.861868
643	3	2025-11-11 15:43:13.997136	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	active	2025-11-11 15:43:13.997136
644	4	2025-11-12 08:11:28.803014	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	active	2025-11-12 08:11:28.803014
645	4	2025-11-12 08:30:34.74075	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	active	2025-11-12 08:30:34.74075
646	4	2025-11-12 08:46:17.044873	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	active	2025-11-12 08:46:17.044873
647	46	2025-11-12 08:49:32.534175	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	active	2025-11-12 08:49:32.534175
648	46	2025-11-12 09:36:18.340279	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	active	2025-11-12 09:36:18.340279
649	4	2025-11-12 09:49:31.617206	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	active	2025-11-12 09:49:31.617206
650	3	2025-11-12 10:39:40.076659	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	active	2025-11-12 10:39:40.076659
651	12	2025-11-12 10:44:43.586796	\N	31.97.113.198	Mozilla/5.0 (iPhone; CPU iPhone OS 17_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.7 Mobile/15E148 Safari/604.1	active	2025-11-12 10:44:43.586796
652	12	2025-11-12 10:45:36.596645	\N	31.97.113.198	Mozilla/5.0 (iPhone; CPU iPhone OS 17_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.7 Mobile/15E148 Safari/604.1	active	2025-11-12 10:45:36.596645
653	4	2025-11-12 10:52:54.998671	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	active	2025-11-12 10:52:54.998671
654	4	2025-11-12 10:57:08.934235	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	active	2025-11-12 10:57:08.934235
655	17	2025-11-12 12:20:43.987299	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	active	2025-11-12 12:20:43.987299
656	17	2025-11-12 12:31:06.394341	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	active	2025-11-12 12:31:06.394341
657	12	2025-11-13 01:46:54.448587	\N	31.97.113.198	Mozilla/5.0 (iPhone; CPU iPhone OS 17_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.7 Mobile/15E148 Safari/604.1	active	2025-11-13 01:46:54.448587
658	12	2025-11-13 01:48:44.745471	\N	31.97.113.198	Mozilla/5.0 (iPhone; CPU iPhone OS 17_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.7 Mobile/15E148 Safari/604.1	active	2025-11-13 01:48:44.745471
659	4	2025-11-13 10:14:47.148259	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	active	2025-11-13 10:14:47.148259
660	6	2025-11-13 10:37:44.331001	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36	active	2025-11-13 10:37:44.331001
661	3	2025-11-13 11:03:00.261289	\N	31.97.113.198	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	active	2025-11-13 11:03:00.261289
662	4	2025-11-13 11:27:21.306497	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	active	2025-11-13 11:27:21.306497
663	4	2025-11-13 11:55:03.992804	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	active	2025-11-13 11:55:03.992804
664	4	2025-11-13 12:04:18.646353	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	active	2025-11-13 12:04:18.646353
665	4	2025-11-13 12:59:24.851704	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	active	2025-11-13 12:59:24.851704
666	3	2025-11-13 14:06:07.590589	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Mobile Safari/537.36	active	2025-11-13 14:06:07.590589
667	22	2025-11-13 14:24:53.004353	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	active	2025-11-13 14:24:53.004353
668	3	2025-11-13 14:57:33.213794	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	active	2025-11-13 14:57:33.213794
669	7	2025-11-13 15:47:14.106234	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:144.0) Gecko/20100101 Firefox/144.0	active	2025-11-13 15:47:14.106234
670	22	2025-11-13 16:42:26.021783	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	active	2025-11-13 16:42:26.021783
671	2	2025-11-14 00:13:20.734911	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	active	2025-11-14 00:13:20.734911
672	2	2025-11-14 00:34:34.924608	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	active	2025-11-14 00:34:34.924608
673	2	2025-11-14 00:46:58.088531	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	active	2025-11-14 00:46:58.088531
674	1	2025-11-14 02:43:18.141627	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	active	2025-11-14 02:43:18.141627
675	21	2025-11-14 02:49:11.498458	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	active	2025-11-14 02:49:11.498458
676	33	2025-11-14 02:50:30.499613	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	active	2025-11-14 02:50:30.499613
677	1	2025-11-14 02:55:53.048835	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	active	2025-11-14 02:55:53.048835
678	21	2025-11-14 03:05:03.415315	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	active	2025-11-14 03:05:03.415315
679	21	2025-11-14 03:06:51.166841	\N	31.97.113.198	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	active	2025-11-14 03:06:51.166841
680	21	2025-11-14 03:34:53.506826	\N	127.0.0.1	Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	active	2025-11-14 03:34:53.506826
681	1	2025-11-14 04:50:24.665483	\N	127.0.0.1	Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	active	2025-11-14 04:50:24.665483
682	4	2025-11-14 07:58:07.724782	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	active	2025-11-14 07:58:07.724782
683	4	2025-11-14 08:47:18.543842	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	active	2025-11-14 08:47:18.543842
684	4	2025-11-14 09:07:35.127401	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	active	2025-11-14 09:07:35.127401
685	20	2025-11-14 11:30:15.537956	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	active	2025-11-14 11:30:15.537956
686	35	2025-11-14 11:38:57.440578	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36	active	2025-11-14 11:38:57.440578
687	25	2025-11-14 11:43:23.870893	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-11-14 11:43:23.870893
688	14	2025-11-14 11:50:34.987099	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	active	2025-11-14 11:50:34.987099
689	14	2025-11-14 11:51:06.525745	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-11-14 11:51:06.525745
690	4	2025-11-14 11:59:04.757211	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	active	2025-11-14 11:59:04.757211
691	3	2025-11-14 11:59:09.712805	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	active	2025-11-14 11:59:09.712805
692	25	2025-11-14 12:36:50.029313	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	active	2025-11-14 12:36:50.029313
693	4	2025-11-14 12:37:30.928843	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	active	2025-11-14 12:37:30.928843
694	2	2025-11-14 13:18:06.699794	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	active	2025-11-14 13:18:06.699794
695	2	2025-11-14 14:11:39.758898	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	active	2025-11-14 14:11:39.758898
696	4	2025-11-14 14:34:46.541266	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	active	2025-11-14 14:34:46.541266
697	4	2025-11-14 14:51:27.706981	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	active	2025-11-14 14:51:27.706981
698	4	2025-11-14 14:57:03.601055	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	active	2025-11-14 14:57:03.601055
699	33	2025-11-14 16:48:54.394115	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36	active	2025-11-14 16:48:54.394115
700	3	2025-11-14 17:33:12.67764	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	active	2025-11-14 17:33:12.67764
701	3	2025-11-14 20:22:43.502224	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	active	2025-11-14 20:22:43.502224
702	1	2025-11-15 04:41:48.678961	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	active	2025-11-15 04:41:48.678961
703	21	2025-11-15 05:46:56.747758	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	active	2025-11-15 05:46:56.747758
704	2	2025-11-15 06:45:06.934535	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	active	2025-11-15 06:45:06.934535
705	4	2025-11-15 07:15:21.167892	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	active	2025-11-15 07:15:21.167892
706	2	2025-11-15 07:18:05.964838	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	active	2025-11-15 07:18:05.964838
707	3	2025-11-15 07:49:31.80024	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	active	2025-11-15 07:49:31.80024
708	4	2025-11-15 08:18:56.249962	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	active	2025-11-15 08:18:56.249962
709	4	2025-11-15 08:29:32.507047	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	active	2025-11-15 08:29:32.507047
710	1	2025-11-15 08:31:52.978578	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	active	2025-11-15 08:31:52.978578
711	3	2025-11-15 08:50:03.658063	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36	active	2025-11-15 08:50:03.658063
712	4	2025-11-15 08:53:10.04362	\N	31.97.113.198	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	active	2025-11-15 08:53:10.04362
713	1	2025-11-23 16:10:48.095453	\N	192.168.0.101	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	active	2025-11-23 16:10:48.095453
714	1	2025-11-23 16:33:00.622319	\N	192.168.0.100	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	active	2025-11-23 16:33:00.622319
715	1	2025-11-23 18:07:21.33339	\N	192.168.0.100	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	active	2025-11-23 18:07:21.33339
716	3	2025-11-23 18:08:34.406751	\N	192.168.0.103	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	active	2025-11-23 18:08:34.406751
717	1	2025-11-23 19:11:17.731518	\N	192.168.0.104	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	active	2025-11-23 19:11:17.731518
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, username, contact, password, name, email, gender, role, created_at, suspended, "createdAt", "updatedAt", profile_image_url) FROM stdin;
37	Madeleine 	677050944	$2a$10$SjdjqOp1QN0GspaMda1rv.tmKSc.qDOhVD/x4Z2IFHmIs7fFSAQOS	MBA EWODO MADELEINE	mbaewodoMadeleine9@gmail.come	\N	Discipline	2025-10-04 10:24:19.088208	f	2025-10-04 11:24:19.088208+01	2025-10-04 11:24:19.088208+01	\N
2	Abang	+237679022388	$2a$10$kBZvkwA1S60GtQuZYvSSquhMQaUIXaawWkS8bJesmTlh7lsMSMAgm	Abang Junior	bannjaga02@gmail.com	\N	Admin3	2025-09-11 11:44:43.890072	f	2025-09-11 12:44:43.890072+01	2025-09-11 12:44:43.890072+01	\N
4	Vera	675768212	$2a$10$0FgFAYh/0uVB11i/bXDuVeZmbEy5IFNXGg8mqfAxeW/VlB26feusS	Nwunjoh Vera 	nwunjohveras@gmail.com	\N	Admin3	2025-09-11 12:31:20.772682	f	2025-09-11 13:31:20.772682+01	2025-09-11 13:31:20.772682+01	\N
38	Ngah 	677250989	$2a$10$H4rV/TTHgCBKUjaeuIvTgO9Sew7D/sovCgAINrY/Hhx.15YHUvEjy	Ngah Divine 	votechs7academy@gmail.com	\N	Teacher	2025-10-04 10:30:01.332232	f	2025-10-04 11:30:01.332232+01	2025-10-04 11:30:01.332232+01	\N
6	Nfebe1	651101601	$2a$10$wYOFg1/BHaQFexUVCxQwX.FFt1GbpWrBHSVw43sM5W.zvws7DWxZO	Nfebe Bless Shu	nfebebless@gmail.com	\N	Admin2	2025-09-11 13:01:08.05176	f	2025-09-11 14:01:08.05176+01	2025-09-11 14:01:08.05176+01	\N
39	Menemoh	672181810	$2a$10$9CDkXOyxo0Uv88Qw4pq1gOGCO0iFxUt8THAOl3z4ukaKlqLMRh65q	Menemoh Fieze Princely	fiezeprincelym@gmail.com	\N	Teacher	2025-10-15 12:34:44.775601	f	2025-10-15 13:34:44.775601+01	2025-10-15 13:34:44.775601+01	\N
9	Chem	676578581	$2a$10$3exxlSjgOq564M3.5L1QK.3.p3/Aq9q/5lYdT9C9dXoYu5WW4dX2u	Chem Sandra Ntala	chemntala21@gmail.com	\N	Teacher	2025-09-11 19:58:48.789188	f	2025-09-11 20:58:48.789188+01	2025-09-11 20:58:48.789188+01	\N
12	Mbaliko	678733884	$2a$10$Yts0mfKmNUUgGUzZvO./l.Cn9YIlWtAG4zcvkkXT7qDse6ZWzipXi	Mbaliko Prosper Khan	mbalikoprosper71@gmail.com	\N	Teacher	2025-09-11 20:09:02.329167	f	2025-09-11 21:09:02.329167+01	2025-09-11 21:09:02.329167+01	\N
13	Mafain	674007866	$2a$10$aHEttPQNiCiBzQGBVXomleWPazu0Y0eUzQ9LJDd.vHcRXzf3RBC3a	Mafain Alice Bih	mafainalicebih@gmail.com	\N	Teacher	2025-09-11 20:11:54.600594	f	2025-09-11 21:11:54.600594+01	2025-09-11 21:11:54.600594+01	\N
14	Brica	679146336	$2a$10$D6dJHX7kptQZFbmWazAM8u5Di3qgNZWjpLPOSgDhjPYlpUE.bAtLG	Brica Ngue Fon	mariaclaret018@gmail.com	\N	Teacher	2025-09-11 20:14:31.579699	f	2025-09-11 21:14:31.579699+01	2025-09-11 21:14:31.579699+01	\N
15	O'Neil	654762663	$2a$10$33Vn.n.gkbZB1rAwVdB0z.0zH46We.C0wKH15wk6BYk43hq6YEldS	Wandum O'Neil Nuvaga	wandumoneil@gmail.com	\N	Teacher	2025-09-11 20:19:59.718207	f	2025-09-11 21:19:59.718207+01	2025-09-11 21:19:59.718207+01	\N
17	Rose	653271023	$2a$10$f/lMGwiERWTxPvWlUgGll.26qXi55HR6gisUiIwpMOtC2AOn9I9xq	Rose Ntone Chuba	rosentanechuba@gmail.com	\N	Teacher	2025-09-11 20:26:43.634316	f	2025-09-11 21:26:43.634316+01	2025-09-11 21:26:43.634316+01	\N
18	Manka'a	675321627	$2a$10$gNkMbfy7sV1lTMRsze3tZ.KxItPRqT5LHlzPZyguXWNxqLW3wgqw6	Manka'a Carine Awah	carinemanka44@gmail.com	\N	Teacher	2025-09-11 20:29:30.034988	f	2025-09-11 21:29:30.034988+01	2025-09-11 21:29:30.034988+01	\N
21	Admin2	+237 679022388	$2a$10$clqoACnvVvQBiUmu8PXYR.cyG.wp0BqiIQoNPOqB2lLDbLZ.qr3kq	Admin2	bannjaga02@gmail.com	\N	Admin2	2025-09-12 14:26:50.250803	f	2025-09-12 15:26:50.250803+01	2025-09-12 15:26:50.250803+01	\N
22	Steve	650555957	$2a$10$ofzK2Z1REI3lz0SHs.4PeuaeSWGyAKcLXcLa8LOGRHKjTKnRMjqkq	Christ Steve 	christatanga412@gmail.com	\N	Teacher	2025-09-13 09:45:06.425706	f	2025-09-13 10:45:06.425706+01	2025-09-13 10:45:06.425706+01	\N
23	Mary	676131561	$2a$10$/7NC4yeBto6OkjeoG9vQ9.0WboSyNyeijmM.np0hJNW1fnSpb3UHS	Ngum Mary 	maryngum282@gmail.com	\N	Teacher	2025-09-13 10:19:22.870648	f	2025-09-13 11:19:22.870648+01	2025-09-13 11:19:22.870648+01	\N
24	Mr Emile 	679272978	$2a$10$LB1CIKKIRFoixA/z2cYWdeesFEC/5cTfToK4xORTOpai5Yyx8obai	Emile Awah	awahmbuhemile@gmail.com	\N	Teacher	2025-09-13 11:54:45.649857	f	2025-09-13 12:54:45.649857+01	2025-09-13 12:54:45.649857+01	\N
25	ROSE	673399787	$2a$10$I3TPhrM.69ssV8CdKoUOk.Hmw8JYHyFDPCJn3aoQp30L/V9Gln7uC	ABU ROSE MENNYI	abuRoSeM@gmail.com	\N	Teacher	2025-09-14 11:22:59.684303	f	2025-09-14 12:22:59.684303+01	2025-09-14 12:22:59.684303+01	\N
26	Mj Mill	 6 75 15 47 46	$2a$10$0B3Tf.zN8viSIC.cx8NIeOEqf4gd3ewzyViLm5UuCY9rKDhF7jK8e	MILLA JOHN-PAUL TEBAH	johnpaulmilla47@gmail.com	\N	Teacher	2025-09-14 11:27:59.206297	f	2025-09-14 12:27:59.206297+01	2025-09-14 12:27:59.206297+01	\N
33	Principal	654499877	$2a$10$vJE/gKQEMdZkHOdO58wySeZcFCZns4RSgPAr7MYzJkSQXLK9hpEwq	NDENG THOMAS AMBE	ngangambe88@gmail.com	\N	Admin4	2025-09-15 11:53:11.495021	f	2025-09-15 12:53:11.495021+01	2025-09-15 12:53:11.495021+01	https://st60307.ispot.cc/votechs7academygroup/users/profile/1757937919168-b3t6ouxyk.jpeg
34	Ramadane	679871459	$2a$10$9r26z9Uotcz8nOlHKQkuLehqyO3uSTd/yioMUhPkBIkOaScRloDvy	SHIWOHNDRE RAMADANE 	ramadaneshiwohndre@icloud.com	\N	Admin4	2025-09-15 12:06:59.862243	f	2025-09-15 13:06:59.862243+01	2025-09-15 13:06:59.862243+01	\N
44	Mimi	676591784	$2a$10$BuFZnk432eGSgtsIAnElo.j.QkaxkXlXTjgZjY5bPIV8EiOU1Md1G	Mirabel fru	mimi@yahoo.com	\N	Teacher	2025-11-04 07:41:06.439584	f	2025-11-04 08:41:06.439584+01	2025-11-04 08:41:06.439584+01	\N
3	Nfor Vitalis	+237 673 547 574	$2a$10$tkg1CFtKxkc65OakxFRmeOFLNKUxxAPKEj4QPu1Vrn.GpMM/jmUD2	Nfor Vitalis Nfor 	vitalisnfor2005@gmail.com	\N	Admin3	2025-09-11 12:29:48.693102	f	2025-09-11 13:29:48.693102+01	2025-09-11 13:29:48.693102+01	https://st60307.ispot.cc/votechs7academygroup/users/profile/1758000579245-fvm61fwo34s.jpg
7	TheCareGiver	677831863	$2a$10$LVPRu0DsJIIfMiAznA5qNOyHSo94Y5L5ygw0ZjZ6TghyIJ51rCHQ6	Ndofor Nwana Davidson Sama	\N	\N	Admin1	2025-09-11 13:11:22.713209	f	2025-09-11 14:11:22.713209+01	2025-09-11 14:11:22.713209+01	\N
1	default	670000000	$2a$10$iAnqFQcxirJ14xCBCdP5eeRQZb8Li1PlGtPuFKoNJvOqcKDigmv3W	Default	\N	\N	Admin3	2025-09-10 19:19:00.242516	f	2025-09-10 20:19:00.242516+01	2025-09-10 20:19:00.242516+01	https://st60307.ispot.cc/votechs7academygroup/users/profile/1757570049774-c03rq27yqmd.png
35	COLLINS	673420402	$2a$10$2fnUAbmgOGfDjK20rlhKyOQ9PWnzRnudQbEUSXlR0OAGm1U1H.G92	DJIMO DJOMO BEN COLLINS	djimoben.collins@gmail.com	\N	Teacher	2025-09-20 09:26:32.567423	f	2025-09-20 10:26:32.567423+01	2025-09-20 10:26:32.567423+01	\N
47	Ringo kimbo	676672484	$2a$10$hhtwKYvL/EmAbfgvd9QabuWjOk/Qmi/wMn0U/cGXwkvZZznacid.a	Kimbo Ringo Nfonguang	ringokimbo@gmail.com	\N	Teacher	2025-11-12 11:32:43.294832	f	2025-11-12 12:32:43.294832+01	2025-11-12 12:32:43.294832+01	\N
41	Tina	675482832	$2a$10$x0bfjFnbm3CgZZfzPju0JeGCyw05i9FIZ4rbHu0mQT5rG8TdYJNo2	Ngah Tina	ngahtina1@gmail.com	\N	Psychosocialist	2025-10-21 15:24:41.615179	f	2025-10-21 16:24:41.615179+01	2025-10-21 16:24:41.615179+01	\N
20	Gebuin	678681732	$2a$10$hYJa8SzsWuAYLnOmFOyYQuxh3w5lzbOhO7TBC8g/zRekqkBhadI0O	Gebuin Bless Yuknwi	\N	\N	Teacher	2025-09-11 20:45:22.264756	f	2025-09-11 21:45:22.264756+01	2025-09-11 21:45:22.264756+01	\N
42	Kechazi	653629629	$2a$10$7AGbfWw429E.84sTE/NQ.Oc0v5e.lAR4onPGNDM8KW1pmGfBc7xza	Kechazi Leonel Nchumi	leonelkechazi@gmail.com	\N	Teacher	2025-10-31 13:52:58.209779	f	2025-10-31 14:52:58.209779+01	2025-10-31 14:52:58.209779+01	\N
43	Tester	\N	$2a$10$gDc6an0J2EkMK5kCw/yc1uveKm//3o11WXojVKdKPiwNACEi4xaFS	Test User	\N	\N	Admin3	2025-11-03 13:04:29.603597	f	2025-11-03 14:04:29.603597+01	2025-11-03 14:04:29.603597+01	\N
45	Prof123	679924210	$2a$10$KY6HC4mC.uFq0QhmV2lY8e/4ss.AInUpU/a2wVI1Nmzfa4XYU6UVm	Ndoh Elvis Che	bobiesbrown82@gmail.com	\N	Admin1	2025-11-07 09:15:35.420359	f	2025-11-07 10:15:35.420359+01	2025-11-07 10:15:35.420359+01	\N
36	Che	677024602	$2a$10$BqLtvnvgZz.GKMbWRnZqFuMwvh/2lXwTi6EbO077kFmPCH2NeGBMq	CHE FLORIMUND KUM	\N	\N	Discipline	2025-09-27 09:43:32.135529	f	2025-09-27 10:43:32.135529+01	2025-09-27 10:43:32.135529+01	\N
46	Kum	677024602	$2a$10$4UsHBPV5SCAu.tFwVW0tguLO8ov1ZOoL62yWnT2DPdMvDKmwqD9u6	Che Florimund Kum	school17@gmail.com	\N	Discipline	2025-11-08 07:53:44.62873	f	2025-11-08 08:53:44.62873+01	2025-11-08 08:53:44.62873+01	\N
19	+123 glein 	683169177	$2a$10$nrTkMXIs3m6/VNxDiAoPb.agiXomBlcQjMFfdUdiNiVoJVD1uoxFi	NDICHIA GLEIN FOINMBAM	\N	\N	Teacher	2025-09-11 20:32:20.544498	f	2025-09-11 21:32:20.544498+01	2025-09-11 21:32:20.544498+01	\N
48	Ndomenga Dickson 	678166878	$2a$10$zSZIc33LQFxrWphgKmQbbe9YTr1/5G.nJiog76YzHa9eoGsl1WLJi	Ndomenga Dickson	dickson.ndomenga@gmail.com	\N	Teacher	2025-11-15 07:19:58.14898	f	2025-11-15 08:19:58.14898+01	2025-11-15 08:19:58.14898+01	\N
49	default 	677833838	$2a$10$../sRCShS0xa/.wKkpAT8u.y/olTiLO1V8nhozZuWdaLFtasQN5eC	default	default@email.com	\N	Admin3	2025-11-15 07:55:25.050853	f	2025-11-15 08:55:25.050853+01	2025-11-15 08:55:25.050853+01	\N
\.


--
-- Data for Name: vocational; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vocational (id, user_id, name, description, picture1, picture2, picture3, picture4, year, created_at, updated_at) FROM stdin;
\.


--
-- Name: academicYears_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."academicYears_id_seq"', 1, true);


--
-- Name: academic_bands_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.academic_bands_id_seq', 1, true);


--
-- Name: academic_years_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.academic_years_id_seq', 1, false);


--
-- Name: applications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.applications_id_seq', 1, false);


--
-- Name: asset_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.asset_categories_id_seq', 1, false);


--
-- Name: asset_depreciation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.asset_depreciation_id_seq', 1, false);


--
-- Name: attendance_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.attendance_records_id_seq', 324, true);


--
-- Name: attendance_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.attendance_sessions_id_seq', 27, true);


--
-- Name: budget_heads_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.budget_heads_id_seq', 1, false);


--
-- Name: case_reports_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.case_reports_id_seq', 1, false);


--
-- Name: case_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.case_sessions_id_seq', 1, false);


--
-- Name: cases_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cases_id_seq', 5, true);


--
-- Name: change_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.change_logs_id_seq', 1, false);


--
-- Name: class_masters_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.class_masters_id_seq', 1, false);


--
-- Name: class_subjects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.class_subjects_id_seq', 510, true);


--
-- Name: classes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.classes_id_seq', 27, true);


--
-- Name: db_swap_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.db_swap_logs_id_seq', 1, false);


--
-- Name: departments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.departments_id_seq', 1, false);


--
-- Name: discipline_cases_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.discipline_cases_id_seq', 1, true);


--
-- Name: events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.events_id_seq', 3, true);


--
-- Name: fees_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.fees_id_seq', 702, true);


--
-- Name: financial_transactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.financial_transactions_id_seq', 1, false);


--
-- Name: group_participants_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.group_participants_id_seq', 9, true);


--
-- Name: groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.groups_id_seq', 1, true);


--
-- Name: hod_teachers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.hod_teachers_id_seq', 18, true);


--
-- Name: hods_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.hods_id_seq', 7, true);


--
-- Name: id_cards_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.id_cards_id_seq', 1, false);


--
-- Name: inventory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.inventory_id_seq', 1, false);


--
-- Name: lesson_plans_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.lesson_plans_id_seq', 68, true);


--
-- Name: lessons_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.lessons_id_seq', 1, false);


--
-- Name: marks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.marks_id_seq', 17, true);


--
-- Name: messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.messages_id_seq', 11, true);


--
-- Name: salaries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.salaries_id_seq', 362, true);


--
-- Name: salary_descriptions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.salary_descriptions_id_seq', 1, false);


--
-- Name: salary_payslip_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.salary_payslip_settings_id_seq', 1, false);


--
-- Name: sequences_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sequences_id_seq', 6, true);


--
-- Name: specialties_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.specialties_id_seq', 10, true);


--
-- Name: specialty_classes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.specialty_classes_id_seq', 1, false);


--
-- Name: staff_attendance_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.staff_attendance_records_id_seq', 352, true);


--
-- Name: staff_attendance_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.staff_attendance_settings_id_seq', 14, true);


--
-- Name: staff_employment_status_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.staff_employment_status_id_seq', 29, true);


--
-- Name: students_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.students_id_seq', 492, true);


--
-- Name: subject_classifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.subject_classifications_id_seq', 1, false);


--
-- Name: subject_coefficients_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.subject_coefficients_id_seq', 1, false);


--
-- Name: subjects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.subjects_id_seq', 46, true);


--
-- Name: teacher_assignments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.teacher_assignments_id_seq', 60, true);


--
-- Name: teacher_discipline_cases_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.teacher_discipline_cases_id_seq', 1, true);


--
-- Name: teachers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.teachers_id_seq', 1, false);


--
-- Name: terms_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.terms_id_seq', 3, true);


--
-- Name: timetable_configs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.timetable_configs_id_seq', 2, true);


--
-- Name: timetables_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.timetables_id_seq', 2, true);


--
-- Name: user_activities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_activities_id_seq', 1636, true);


--
-- Name: user_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_sessions_id_seq', 717, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 49, true);


--
-- Name: vocational_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.vocational_id_seq', 1, false);


--
-- Name: SequelizeMeta SequelizeMeta_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SequelizeMeta"
    ADD CONSTRAINT "SequelizeMeta_pkey" PRIMARY KEY (name);


--
-- Name: academicYears academicYears_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."academicYears"
    ADD CONSTRAINT "academicYears_pkey" PRIMARY KEY (id);


--
-- Name: academic_bands academic_bands_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.academic_bands
    ADD CONSTRAINT academic_bands_pkey PRIMARY KEY (id);


--
-- Name: academic_years academic_years_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.academic_years
    ADD CONSTRAINT academic_years_pkey PRIMARY KEY (id);


--
-- Name: applications applications_applicant_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.applications
    ADD CONSTRAINT applications_applicant_id_key UNIQUE (applicant_id);


--
-- Name: applications applications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.applications
    ADD CONSTRAINT applications_pkey PRIMARY KEY (id);


--
-- Name: asset_categories asset_categories_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.asset_categories
    ADD CONSTRAINT asset_categories_name_key UNIQUE (name);


--
-- Name: asset_categories asset_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.asset_categories
    ADD CONSTRAINT asset_categories_pkey PRIMARY KEY (id);


--
-- Name: asset_depreciation asset_depreciation_inventory_id_calculation_date_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.asset_depreciation
    ADD CONSTRAINT asset_depreciation_inventory_id_calculation_date_key UNIQUE (inventory_id, calculation_date);


--
-- Name: asset_depreciation asset_depreciation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.asset_depreciation
    ADD CONSTRAINT asset_depreciation_pkey PRIMARY KEY (id);


--
-- Name: attendance_records attendance_records_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_records
    ADD CONSTRAINT attendance_records_pkey PRIMARY KEY (id);


--
-- Name: attendance_records attendance_records_session_id_student_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_records
    ADD CONSTRAINT attendance_records_session_id_student_id_key UNIQUE (session_id, student_id);


--
-- Name: attendance_records attendance_records_session_teacher_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_records
    ADD CONSTRAINT attendance_records_session_teacher_unique UNIQUE (session_id, teacher_id);


--
-- Name: attendance_sessions attendance_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_sessions
    ADD CONSTRAINT attendance_sessions_pkey PRIMARY KEY (id);


--
-- Name: budget_heads budget_heads_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budget_heads
    ADD CONSTRAINT budget_heads_code_key UNIQUE (code);


--
-- Name: budget_heads budget_heads_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budget_heads
    ADD CONSTRAINT budget_heads_name_key UNIQUE (name);


--
-- Name: budget_heads budget_heads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budget_heads
    ADD CONSTRAINT budget_heads_pkey PRIMARY KEY (id);


--
-- Name: case_reports case_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_reports
    ADD CONSTRAINT case_reports_pkey PRIMARY KEY (id);


--
-- Name: case_sessions case_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_sessions
    ADD CONSTRAINT case_sessions_pkey PRIMARY KEY (id);


--
-- Name: cases cases_case_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cases
    ADD CONSTRAINT cases_case_number_key UNIQUE (case_number);


--
-- Name: cases cases_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cases
    ADD CONSTRAINT cases_pkey PRIMARY KEY (id);


--
-- Name: change_logs change_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.change_logs
    ADD CONSTRAINT change_logs_pkey PRIMARY KEY (id);


--
-- Name: class_masters class_masters_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.class_masters
    ADD CONSTRAINT class_masters_pkey PRIMARY KEY (id);


--
-- Name: class_subjects class_subjects_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.class_subjects
    ADD CONSTRAINT class_subjects_pkey PRIMARY KEY (id);


--
-- Name: classes classes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classes
    ADD CONSTRAINT classes_pkey PRIMARY KEY (id);


--
-- Name: cnps_preferences cnps_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cnps_preferences
    ADD CONSTRAINT cnps_preferences_pkey PRIMARY KEY (user_id);


--
-- Name: db_swap_logs db_swap_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.db_swap_logs
    ADD CONSTRAINT db_swap_logs_pkey PRIMARY KEY (id);


--
-- Name: departments departments_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_name_key UNIQUE (name);


--
-- Name: departments departments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_pkey PRIMARY KEY (id);


--
-- Name: discipline_cases discipline_cases_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.discipline_cases
    ADD CONSTRAINT discipline_cases_pkey PRIMARY KEY (id);


--
-- Name: events events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_pkey PRIMARY KEY (id);


--
-- Name: fees fees_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fees
    ADD CONSTRAINT fees_pkey PRIMARY KEY (id);


--
-- Name: financial_transactions financial_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.financial_transactions
    ADD CONSTRAINT financial_transactions_pkey PRIMARY KEY (id);


--
-- Name: group_participants group_participants_group_id_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_participants
    ADD CONSTRAINT group_participants_group_id_user_id_key UNIQUE (group_id, user_id);


--
-- Name: group_participants group_participants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_participants
    ADD CONSTRAINT group_participants_pkey PRIMARY KEY (id);


--
-- Name: groups groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_pkey PRIMARY KEY (id);


--
-- Name: hod_teachers hod_teachers_hod_id_teacher_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hod_teachers
    ADD CONSTRAINT hod_teachers_hod_id_teacher_id_key UNIQUE (hod_id, teacher_id);


--
-- Name: hod_teachers hod_teachers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hod_teachers
    ADD CONSTRAINT hod_teachers_pkey PRIMARY KEY (id);


--
-- Name: hods hods_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hods
    ADD CONSTRAINT hods_pkey PRIMARY KEY (id);


--
-- Name: id_cards id_cards_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.id_cards
    ADD CONSTRAINT id_cards_pkey PRIMARY KEY (id);


--
-- Name: inventory inventory_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory
    ADD CONSTRAINT inventory_pkey PRIMARY KEY (id);


--
-- Name: lesson_plans lesson_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lesson_plans
    ADD CONSTRAINT lesson_plans_pkey PRIMARY KEY (id);


--
-- Name: lessons lessons_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lessons
    ADD CONSTRAINT lessons_pkey PRIMARY KEY (id);


--
-- Name: marks marks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.marks
    ADD CONSTRAINT marks_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: salaries salaries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salaries
    ADD CONSTRAINT salaries_pkey PRIMARY KEY (id);


--
-- Name: salaries salaries_user_id_month_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salaries
    ADD CONSTRAINT salaries_user_id_month_key UNIQUE (user_id, month);


--
-- Name: salaries salaries_user_id_month_year_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salaries
    ADD CONSTRAINT salaries_user_id_month_year_key UNIQUE (user_id, month, year);


--
-- Name: salary_descriptions salary_descriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salary_descriptions
    ADD CONSTRAINT salary_descriptions_pkey PRIMARY KEY (id);


--
-- Name: salary_payslip_settings salary_payslip_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salary_payslip_settings
    ADD CONSTRAINT salary_payslip_settings_pkey PRIMARY KEY (id);


--
-- Name: sequences sequences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sequences
    ADD CONSTRAINT sequences_pkey PRIMARY KEY (id);


--
-- Name: specialties specialties_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.specialties
    ADD CONSTRAINT specialties_pkey PRIMARY KEY (id);


--
-- Name: specialty_classes specialty_classes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.specialty_classes
    ADD CONSTRAINT specialty_classes_pkey PRIMARY KEY (id);


--
-- Name: staff_attendance_records staff_attendance_records_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff_attendance_records
    ADD CONSTRAINT staff_attendance_records_pkey PRIMARY KEY (id);


--
-- Name: staff_attendance_settings staff_attendance_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff_attendance_settings
    ADD CONSTRAINT staff_attendance_settings_pkey PRIMARY KEY (id);


--
-- Name: staff_attendance_settings staff_attendance_settings_setting_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff_attendance_settings
    ADD CONSTRAINT staff_attendance_settings_setting_key_key UNIQUE (setting_key);


--
-- Name: staff_employment_status staff_employment_status_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff_employment_status
    ADD CONSTRAINT staff_employment_status_pkey PRIMARY KEY (id);


--
-- Name: staff_employment_status staff_employment_status_staff_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff_employment_status
    ADD CONSTRAINT staff_employment_status_staff_name_key UNIQUE (staff_name);


--
-- Name: students students_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_pkey PRIMARY KEY (id);


--
-- Name: students students_student_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_student_id_key UNIQUE (student_id);


--
-- Name: subject_classifications subject_classifications_class_id_subject_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subject_classifications
    ADD CONSTRAINT subject_classifications_class_id_subject_id_key UNIQUE (class_id, subject_id);


--
-- Name: subject_classifications subject_classifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subject_classifications
    ADD CONSTRAINT subject_classifications_pkey PRIMARY KEY (id);


--
-- Name: subject_coefficients subject_coefficients_class_id_subject_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subject_coefficients
    ADD CONSTRAINT subject_coefficients_class_id_subject_id_key UNIQUE (class_id, subject_id);


--
-- Name: subject_coefficients subject_coefficients_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subject_coefficients
    ADD CONSTRAINT subject_coefficients_pkey PRIMARY KEY (id);


--
-- Name: subjects subjects_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subjects
    ADD CONSTRAINT subjects_code_key UNIQUE (code);


--
-- Name: subjects subjects_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subjects
    ADD CONSTRAINT subjects_pkey PRIMARY KEY (id);


--
-- Name: system_mode system_mode_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_mode
    ADD CONSTRAINT system_mode_pkey PRIMARY KEY (mode);


--
-- Name: teacher_assignments teacher_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teacher_assignments
    ADD CONSTRAINT teacher_assignments_pkey PRIMARY KEY (id);


--
-- Name: teacher_assignments teacher_assignments_teacher_id_class_id_subject_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teacher_assignments
    ADD CONSTRAINT teacher_assignments_teacher_id_class_id_subject_id_key UNIQUE (teacher_id, class_id, subject_id);


--
-- Name: teacher_discipline_cases teacher_discipline_cases_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teacher_discipline_cases
    ADD CONSTRAINT teacher_discipline_cases_pkey PRIMARY KEY (id);


--
-- Name: teachers teachers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teachers
    ADD CONSTRAINT teachers_pkey PRIMARY KEY (id);


--
-- Name: terms terms_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.terms
    ADD CONSTRAINT terms_pkey PRIMARY KEY (id);


--
-- Name: timetable_configs timetable_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.timetable_configs
    ADD CONSTRAINT timetable_configs_pkey PRIMARY KEY (id);


--
-- Name: timetables timetables_class_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.timetables
    ADD CONSTRAINT timetables_class_id_key UNIQUE (class_id);


--
-- Name: timetables timetables_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.timetables
    ADD CONSTRAINT timetables_pkey PRIMARY KEY (id);


--
-- Name: class_subjects unique_class_subject_department; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.class_subjects
    ADD CONSTRAINT unique_class_subject_department UNIQUE (class_id, subject_id, department_id);


--
-- Name: class_subjects unique_class_subject_teacher; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.class_subjects
    ADD CONSTRAINT unique_class_subject_teacher UNIQUE (class_id, subject_id, teacher_id);


--
-- Name: marks unique_mark_constraint; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.marks
    ADD CONSTRAINT unique_mark_constraint UNIQUE (student_id, subject_id, class_id, academic_year_id, term_id, sequence_id);


--
-- Name: user_activities user_activities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_activities
    ADD CONSTRAINT user_activities_pkey PRIMARY KEY (id);


--
-- Name: user_sessions user_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: vocational vocational_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vocational
    ADD CONSTRAINT vocational_pkey PRIMARY KEY (id);


--
-- Name: academic_bands_academic_year_id_class_id_band_min_band_max; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX academic_bands_academic_year_id_class_id_band_min_band_max ON public.academic_bands USING btree (academic_year_id, class_id, band_min, band_max);


--
-- Name: class_subjects_unique_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX class_subjects_unique_idx ON public.class_subjects USING btree (class_id, subject_id, teacher_id);


--
-- Name: idx_discipline_cases_teacher; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_discipline_cases_teacher ON public.discipline_cases USING btree (teacher_id);


--
-- Name: idx_discipline_cases_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_discipline_cases_type ON public.discipline_cases USING btree (case_type);


--
-- Name: idx_messages_read; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_messages_read ON public.messages USING btree (read);


--
-- Name: idx_staff_attendance_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_staff_attendance_date ON public.staff_attendance_records USING btree (date);


--
-- Name: idx_staff_attendance_staff_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_staff_attendance_staff_name ON public.staff_attendance_records USING btree (staff_name);


--
-- Name: idx_staff_employment_status_staff_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_staff_employment_status_staff_name ON public.staff_employment_status USING btree (staff_name);


--
-- Name: idx_user_activities_activity_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_activities_activity_type ON public.user_activities USING btree (activity_type);


--
-- Name: idx_user_activities_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_activities_created_at ON public.user_activities USING btree (created_at);


--
-- Name: idx_user_activities_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_activities_user_id ON public.user_activities USING btree (user_id);


--
-- Name: idx_user_sessions_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_sessions_status ON public.user_sessions USING btree (status);


--
-- Name: idx_user_sessions_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_sessions_user_id ON public.user_sessions USING btree (user_id);


--
-- Name: marks_academic_year_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX marks_academic_year_id ON public.marks USING btree (academic_year_id);


--
-- Name: marks_class_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX marks_class_id ON public.marks USING btree (class_id);


--
-- Name: marks_sequence_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX marks_sequence_id ON public.marks USING btree (sequence_id);


--
-- Name: marks_student_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX marks_student_id ON public.marks USING btree (student_id);


--
-- Name: marks_subject_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX marks_subject_id ON public.marks USING btree (subject_id);


--
-- Name: marks_term_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX marks_term_id ON public.marks USING btree (term_id);


--
-- Name: sequences_academic_year_id_name; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX sequences_academic_year_id_name ON public.sequences USING btree (academic_year_id, name);


--
-- Name: sequences_term_id_order_number; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX sequences_term_id_order_number ON public.sequences USING btree (term_id, order_number);


--
-- Name: terms_academic_year_id_name_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX terms_academic_year_id_name_key ON public.terms USING btree (academic_year_id, name);


--
-- Name: unique_class_name_per_department; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX unique_class_name_per_department ON public.classes USING btree (name, department_id);


--
-- Name: academic_bands academic_bands_academic_year_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.academic_bands
    ADD CONSTRAINT academic_bands_academic_year_id_fkey FOREIGN KEY (academic_year_id) REFERENCES public."academicYears"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: academic_bands academic_bands_class_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.academic_bands
    ADD CONSTRAINT academic_bands_class_id_fkey FOREIGN KEY (class_id) REFERENCES public.classes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: applications applications_applicant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.applications
    ADD CONSTRAINT applications_applicant_id_fkey FOREIGN KEY (applicant_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: applications applications_reviewed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.applications
    ADD CONSTRAINT applications_reviewed_by_fkey FOREIGN KEY (reviewed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: asset_depreciation asset_depreciation_inventory_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.asset_depreciation
    ADD CONSTRAINT asset_depreciation_inventory_id_fkey FOREIGN KEY (inventory_id) REFERENCES public.inventory(id) ON DELETE CASCADE;


--
-- Name: attendance_records attendance_records_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_records
    ADD CONSTRAINT attendance_records_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.attendance_sessions(id) ON DELETE CASCADE;


--
-- Name: attendance_records attendance_records_teacher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_records
    ADD CONSTRAINT attendance_records_teacher_id_fkey FOREIGN KEY (teacher_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: attendance_sessions attendance_sessions_class_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_sessions
    ADD CONSTRAINT attendance_sessions_class_id_fkey FOREIGN KEY (class_id) REFERENCES public.classes(id) ON DELETE SET NULL;


--
-- Name: attendance_sessions attendance_sessions_taken_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_sessions
    ADD CONSTRAINT attendance_sessions_taken_by_fkey FOREIGN KEY (taken_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: case_reports case_reports_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_reports
    ADD CONSTRAINT case_reports_case_id_fkey FOREIGN KEY (case_id) REFERENCES public.cases(id) ON DELETE CASCADE;


--
-- Name: case_reports case_reports_sent_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_reports
    ADD CONSTRAINT case_reports_sent_by_fkey FOREIGN KEY (sent_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: case_reports case_reports_sent_to_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_reports
    ADD CONSTRAINT case_reports_sent_to_fkey FOREIGN KEY (sent_to) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: case_sessions case_sessions_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_sessions
    ADD CONSTRAINT case_sessions_case_id_fkey FOREIGN KEY (case_id) REFERENCES public.cases(id) ON DELETE CASCADE;


--
-- Name: case_sessions case_sessions_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_sessions
    ADD CONSTRAINT case_sessions_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: cases cases_assigned_to_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cases
    ADD CONSTRAINT cases_assigned_to_fkey FOREIGN KEY (assigned_to) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: cases cases_class_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cases
    ADD CONSTRAINT cases_class_id_fkey FOREIGN KEY (class_id) REFERENCES public.classes(id) ON DELETE SET NULL;


--
-- Name: cases cases_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cases
    ADD CONSTRAINT cases_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: change_logs change_logs_changed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.change_logs
    ADD CONSTRAINT change_logs_changed_by_fkey FOREIGN KEY (changed_by) REFERENCES public.users(id) ON UPDATE CASCADE;


--
-- Name: class_masters class_masters_class_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.class_masters
    ADD CONSTRAINT class_masters_class_id_fkey FOREIGN KEY (class_id) REFERENCES public.classes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: class_subjects class_subjects_class_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.class_subjects
    ADD CONSTRAINT class_subjects_class_id_fkey FOREIGN KEY (class_id) REFERENCES public.classes(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: class_subjects class_subjects_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.class_subjects
    ADD CONSTRAINT class_subjects_department_id_fkey FOREIGN KEY (department_id) REFERENCES public.specialties(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: class_subjects class_subjects_subject_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.class_subjects
    ADD CONSTRAINT class_subjects_subject_id_fkey FOREIGN KEY (subject_id) REFERENCES public.subjects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: class_subjects class_subjects_teacher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.class_subjects
    ADD CONSTRAINT class_subjects_teacher_id_fkey FOREIGN KEY (teacher_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: classes classes_class_master_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classes
    ADD CONSTRAINT classes_class_master_id_fkey FOREIGN KEY (class_master_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: classes classes_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classes
    ADD CONSTRAINT classes_department_id_fkey FOREIGN KEY (department_id) REFERENCES public.specialties(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: db_swap_logs db_swap_logs_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.db_swap_logs
    ADD CONSTRAINT db_swap_logs_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: discipline_cases discipline_cases_class_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.discipline_cases
    ADD CONSTRAINT discipline_cases_class_id_fkey FOREIGN KEY (class_id) REFERENCES public.classes(id) ON DELETE CASCADE;


--
-- Name: discipline_cases discipline_cases_recorded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.discipline_cases
    ADD CONSTRAINT discipline_cases_recorded_by_fkey FOREIGN KEY (recorded_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: discipline_cases discipline_cases_resolved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.discipline_cases
    ADD CONSTRAINT discipline_cases_resolved_by_fkey FOREIGN KEY (resolved_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: discipline_cases discipline_cases_teacher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.discipline_cases
    ADD CONSTRAINT discipline_cases_teacher_id_fkey FOREIGN KEY (teacher_id) REFERENCES public.teachers(id) ON DELETE SET NULL;


--
-- Name: events events_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: financial_transactions financial_transactions_budget_head_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.financial_transactions
    ADD CONSTRAINT financial_transactions_budget_head_id_fkey FOREIGN KEY (budget_head_id) REFERENCES public.budget_heads(id);


--
-- Name: financial_transactions financial_transactions_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.financial_transactions
    ADD CONSTRAINT financial_transactions_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: group_participants group_participants_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_participants
    ADD CONSTRAINT group_participants_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.groups(id) ON DELETE CASCADE;


--
-- Name: group_participants group_participants_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_participants
    ADD CONSTRAINT group_participants_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: groups groups_creator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_creator_id_fkey FOREIGN KEY (creator_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: hod_teachers hod_teachers_hod_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hod_teachers
    ADD CONSTRAINT hod_teachers_hod_id_fkey FOREIGN KEY (hod_id) REFERENCES public.hods(id) ON DELETE CASCADE;


--
-- Name: hod_teachers hod_teachers_teacher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hod_teachers
    ADD CONSTRAINT hod_teachers_teacher_id_fkey FOREIGN KEY (teacher_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: hods hods_hod_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hods
    ADD CONSTRAINT hods_hod_user_id_fkey FOREIGN KEY (hod_user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: hods hods_subject_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hods
    ADD CONSTRAINT hods_subject_id_fkey FOREIGN KEY (subject_id) REFERENCES public.subjects(id) ON DELETE CASCADE;


--
-- Name: lesson_plans lesson_plans_reviewed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lesson_plans
    ADD CONSTRAINT lesson_plans_reviewed_by_fkey FOREIGN KEY (reviewed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: lesson_plans lesson_plans_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lesson_plans
    ADD CONSTRAINT lesson_plans_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: lessons lessons_reviewed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lessons
    ADD CONSTRAINT lessons_reviewed_by_fkey FOREIGN KEY (reviewed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: lessons lessons_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lessons
    ADD CONSTRAINT lessons_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: marks marks_academic_year_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.marks
    ADD CONSTRAINT marks_academic_year_id_fkey FOREIGN KEY (academic_year_id) REFERENCES public."academicYears"(id) ON DELETE CASCADE;


--
-- Name: marks marks_class_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.marks
    ADD CONSTRAINT marks_class_id_fkey FOREIGN KEY (class_id) REFERENCES public.classes(id) ON DELETE CASCADE;


--
-- Name: marks marks_sequence_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.marks
    ADD CONSTRAINT marks_sequence_id_fkey FOREIGN KEY (sequence_id) REFERENCES public.sequences(id) ON DELETE CASCADE;


--
-- Name: marks marks_subject_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.marks
    ADD CONSTRAINT marks_subject_id_fkey FOREIGN KEY (subject_id) REFERENCES public.subjects(id) ON DELETE CASCADE;


--
-- Name: marks marks_term_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.marks
    ADD CONSTRAINT marks_term_id_fkey FOREIGN KEY (term_id) REFERENCES public.terms(id) ON DELETE CASCADE;


--
-- Name: marks marks_uploaded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.marks
    ADD CONSTRAINT marks_uploaded_by_fkey FOREIGN KEY (uploaded_by) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: messages messages_receiver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_receiver_id_fkey FOREIGN KEY (receiver_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: messages messages_sender_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_sender_id_fkey FOREIGN KEY (sender_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: salaries salaries_applicant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salaries
    ADD CONSTRAINT salaries_applicant_id_fkey FOREIGN KEY (applicant_id) REFERENCES public.applications(id) ON DELETE CASCADE;


--
-- Name: salaries salaries_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salaries
    ADD CONSTRAINT salaries_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: sequences sequences_academic_year_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sequences
    ADD CONSTRAINT sequences_academic_year_id_fkey FOREIGN KEY (academic_year_id) REFERENCES public."academicYears"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: sequences sequences_academic_year_id_fkey1; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sequences
    ADD CONSTRAINT sequences_academic_year_id_fkey1 FOREIGN KEY (academic_year_id) REFERENCES public."academicYears"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: sequences sequences_term_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sequences
    ADD CONSTRAINT sequences_term_id_fkey FOREIGN KEY (term_id) REFERENCES public.terms(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: specialty_classes specialty_classes_class_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.specialty_classes
    ADD CONSTRAINT specialty_classes_class_id_fkey FOREIGN KEY (class_id) REFERENCES public.classes(id) ON DELETE CASCADE;


--
-- Name: specialty_classes specialty_classes_specialty_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.specialty_classes
    ADD CONSTRAINT specialty_classes_specialty_id_fkey FOREIGN KEY (specialty_id) REFERENCES public.specialties(id) ON DELETE CASCADE;


--
-- Name: students students_academic_year_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_academic_year_id_fkey FOREIGN KEY (academic_year_id) REFERENCES public."academicYears"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: students students_class_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_class_id_fkey FOREIGN KEY (class_id) REFERENCES public.classes(id) ON DELETE SET NULL;


--
-- Name: students students_specialty_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_specialty_id_fkey FOREIGN KEY (specialty_id) REFERENCES public.specialties(id) ON DELETE SET NULL;


--
-- Name: subject_classifications subject_classifications_class_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subject_classifications
    ADD CONSTRAINT subject_classifications_class_id_fkey FOREIGN KEY (class_id) REFERENCES public.classes(id) ON DELETE CASCADE;


--
-- Name: subject_classifications subject_classifications_subject_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subject_classifications
    ADD CONSTRAINT subject_classifications_subject_id_fkey FOREIGN KEY (subject_id) REFERENCES public.subjects(id) ON DELETE CASCADE;


--
-- Name: subject_coefficients subject_coefficients_class_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subject_coefficients
    ADD CONSTRAINT subject_coefficients_class_id_fkey FOREIGN KEY (class_id) REFERENCES public.classes(id) ON DELETE CASCADE;


--
-- Name: subject_coefficients subject_coefficients_subject_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subject_coefficients
    ADD CONSTRAINT subject_coefficients_subject_id_fkey FOREIGN KEY (subject_id) REFERENCES public.subjects(id) ON DELETE CASCADE;


--
-- Name: teacher_assignments teacher_assignments_class_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teacher_assignments
    ADD CONSTRAINT teacher_assignments_class_id_fkey FOREIGN KEY (class_id) REFERENCES public.classes(id) ON DELETE CASCADE;


--
-- Name: teacher_assignments teacher_assignments_subject_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teacher_assignments
    ADD CONSTRAINT teacher_assignments_subject_id_fkey FOREIGN KEY (subject_id) REFERENCES public.subjects(id) ON DELETE CASCADE;


--
-- Name: teacher_assignments teacher_assignments_teacher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teacher_assignments
    ADD CONSTRAINT teacher_assignments_teacher_id_fkey FOREIGN KEY (teacher_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: teacher_discipline_cases teacher_discipline_cases_class_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teacher_discipline_cases
    ADD CONSTRAINT teacher_discipline_cases_class_id_fkey FOREIGN KEY (class_id) REFERENCES public.classes(id) ON DELETE SET NULL;


--
-- Name: teacher_discipline_cases teacher_discipline_cases_recorded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teacher_discipline_cases
    ADD CONSTRAINT teacher_discipline_cases_recorded_by_fkey FOREIGN KEY (recorded_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: teacher_discipline_cases teacher_discipline_cases_resolved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teacher_discipline_cases
    ADD CONSTRAINT teacher_discipline_cases_resolved_by_fkey FOREIGN KEY (resolved_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: teacher_discipline_cases teacher_discipline_cases_teacher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teacher_discipline_cases
    ADD CONSTRAINT teacher_discipline_cases_teacher_id_fkey FOREIGN KEY (teacher_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: teachers teachers_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teachers
    ADD CONSTRAINT teachers_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: terms terms_academic_year_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.terms
    ADD CONSTRAINT terms_academic_year_id_fkey FOREIGN KEY (academic_year_id) REFERENCES public."academicYears"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: timetables timetables_class_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.timetables
    ADD CONSTRAINT timetables_class_id_fkey FOREIGN KEY (class_id) REFERENCES public.classes(id) ON DELETE CASCADE;


--
-- Name: user_activities user_activities_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_activities
    ADD CONSTRAINT user_activities_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_sessions user_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict t0D2S65Csr5qoiybOGUuAuF4PshcbaJdyUhzr5hbyiQtbMC5eTAgYapehfRJJ2m

